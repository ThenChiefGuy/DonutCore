package fnhndduvxgwosuvi;

public class nqlipuvkfzlomfdg {
   public static int wxqhyeyxrkgiiuik(int var0) {
      return var0 != 0 ? (var0 * 31 >>> 4) % var0 ^ var0 >>> 16 : 0;
   }

   public static int lyvmtarecrvhtwki(int var0) {
      return (var0 & 7 << 29) >> 29 | var0 << 3;
   }
}
