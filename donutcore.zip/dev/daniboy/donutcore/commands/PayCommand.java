package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.database.SQLiteManager;
import dev.daniboy.donutcore.utils.ActionBar;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PayCommand extends Command {
   private final Economy economy;
   private final SQLiteManager sqLiteManager;
   private static int FBtUd90MAp;
   private transient int Uy70tBUnkD;
   private static String jnxthjtris;
   private static String[] nothing_to_see_here = new String[15];

   public PayCommand(Economy var1, SQLiteManager var2, int var3) {
      int var16 = 831508673 ^ 54543093;
      String var5 = "pay";
      super(var5);

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var16)) {
         case 41032075:
            var16 ^= 457976353;
         case 294323079:
            var16 = 1645529682 ^ 467649641 ^ Integer.parseInt("65463457") ^ var3;
            this.Uy70tBUnkD = 527519877 ^ FBtUd90MAp;
            var16 = kktrqujfhdzdkcbe(var16, 2001332146);
            var16 ^= 1483184236;
            String var11 = "donutcore.pay";
            this.setPermission(var11);
            var16 ^= 1020781111;
            String var12 = "/pay <player> <amount>";
            this.setUsage(var12);
            var16 ^= 537197357;
            this.economy = var1;
            var16 ^= 909957513;
            this.sqLiteManager = var2;
            var16 ^= 1556664791;
            return;
         case 1556024098:
         default:
            throw new IOException();
         case 1800127957:
         }
      }
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      double var13;
      Player var19;
      Player var26;
      int var157;
      label189: {
         label199: {
            var157 = 1374414080 ^ 91691870 ^ this.Uy70tBUnkD;
            var157 ^= 456391988;
            byte var17 = var1 instanceof Player;
            if (var17 != (590443206 ^ var157)) {
               var157 ^= 1641428538;
               var19 = (Player)var1;
               var157 ^= 1599368564;
               var157 ^= 1407564568;

               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157) != 130545057) {
                     throw null;
                  }

                  throw new IllegalAccessException();
               } catch (IllegalAccessException var160) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var157)) {
                  case -340249149:
                     var157 ^= 1382300720;
                     break;
                  case 1924437122:
                     var157 ^= 1631954968;
                     break;
                  default:
                     throw new IOException("Error in hash");
                  }

                  var157 = kktrqujfhdzdkcbe(var157, 1089595491);
                  int var21 = var3.length;
                  byte var5 = (byte)(1877136105 ^ var157);
                  if (var21 != var5) {
                     var157 ^= 910279896;
                     String var75 = exvbgxttlj(livbqkqvtkxgmli(), var157);
                     var19.sendMessage(var75);
                     var157 ^= 1087717881;
                     byte var23 = (byte)(427186122 ^ var157);
                     return (boolean)var23;
                  }
               }

               var157 ^= 1484573335;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157) != 197294318) {
                  var157 = kktrqujfhdzdkcbe(var157, 1635610816);
               } else {
                  label170:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157)) {
                     case 197294318:
                        var157 ^= 84161403;
                     case 722080330:
                        break label170;
                     case 1247580305:
                        break;
                     case 1744892631:
                     default:
                        throw new IllegalAccessException();
                     }
                  }

                  Server var25 = var19.getServer();
                  byte var6 = (byte)(848964359 ^ var157);
                  String var77 = var3[var6];
                  var26 = var25.getPlayer(var77);
                  var157 ^= 199608073;
                  if (var26 == null) {
                     var157 ^= 1976161010;
                     MessagesConfig var69 = MessagesConfig.PLAYERNOTFOUND;
                     String var70 = var69.getSingleMessage();
                     var157 ^= 846619247;
                     String var133 = var19.getName();
                     byte var10 = (byte)(2126535827 ^ var157);
                     String var151 = var3[var10];
                     String var103 = this.formatMessage$1504987598(var70, var133, var151, 363046963);
                     var19.sendMessage(var103);
                     var157 ^= 1098112333;
                     byte var72 = (byte)(1068728798 ^ var157);
                     return (boolean)var72;
                  }

                  var157 = kktrqujfhdzdkcbe(var157, 1135974503);
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157) != 233323329) {
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157)) {
                        case 172828396:
                           break;
                        case 206613457:
                        case 245171220:
                        default:
                           throw new IllegalAccessException();
                        case 233323329:
                           var157 ^= 740891861;
                           throw new IllegalAccessException();
                        }
                     }
                  } else {
                     var157 ^= 1817275436;
                     SQLiteManager var29 = this.sqLiteManager;
                     UUID var79 = var26.getUniqueId();
                     byte var30 = var29.getPayToggle$495579768(var79, 2083576082);
                     if (var30 == (379263045 ^ var157)) {
                        var157 ^= 737511355;
                        MessagesConfig var31 = MessagesConfig.PAYMENT_DISABLED_OTHER;
                        var31.send(var19);
                        var157 ^= 1514844720;
                        byte var32 = (byte)(1730424270 ^ var157);
                        return (boolean)var32;
                     }

                     var157 ^= 171869421;
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157) != 125879072) {
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157)) {
                           case 125879072:
                              var157 ^= 1246163988;
                              throw new IllegalAccessException();
                           case 307428141:
                           case 1763846315:
                           default:
                              throw new IllegalAccessException();
                           case 1764490707:
                           }
                        }
                     } else {
                        var157 ^= 713359550;

                        try {
                           byte var105 = (byte)(908106775 ^ var157);
                           String var82 = var3[var105];
                           double var34 = this.parseAmount$1046020412(var82, 782041907);
                           var13 = var34;
                           var157 ^= 1788733004;
                        } catch (NumberFormatException var158) {
                           switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var157)) {
                           case -1325080399:
                              var157 = kktrqujfhdzdkcbe(var157, 1280170467);
                              var157 ^= 304192639;
                              MessagesConfig var83 = MessagesConfig.INVALIDAMOUNT;
                              String var84 = var83.getSingleMessage();
                              var19.sendMessage(var84);
                              var157 ^= 1602905634;
                              byte var38 = (byte)(935772072 ^ var157);
                              return (boolean)var38;
                           default:
                              throw new IllegalAccessException("Error in hash");
                           }
                        }

                        var157 = kktrqujfhdzdkcbe(var157, 1914375137);

                        try {
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157) != 174215932) {
                              throw null;
                           }

                           throw new RuntimeException();
                        } catch (RuntimeException var159) {
                           switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var157)) {
                           case 1966312921:
                              var157 ^= 1192738445;
                              break;
                           case 2023126192:
                              var157 ^= 1721958816;
                              break;
                           default:
                              throw new RuntimeException("Error in hash");
                           }
                        }

                        var157 ^= 927195392;
                        double var106 = 0.0D;
                        double var161;
                        int var41 = (var161 = var13 - var106) == 0.0D ? 0 : (var161 < 0.0D ? -1 : 1);
                        if (var41 <= (1592929846 ^ var157)) {
                           var157 ^= 331898931;
                           MessagesConfig var85 = MessagesConfig.INVALIDAMOUNT;
                           String var86 = var85.getSingleMessage();
                           var19.sendMessage(var86);
                           var157 ^= 12250443;
                           byte var43 = (byte)(1300276046 ^ var157);
                           return (boolean)var43;
                        }

                        var157 = kktrqujfhdzdkcbe(var157, 1035755845);
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157) != 6806176) {
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157)) {
                              case 6806176:
                                 var157 ^= 900540367;
                                 throw new IllegalAccessException();
                              case 1029993818:
                              case 1824054450:
                              default:
                                 throw new IllegalAccessException();
                              case 1117321268:
                              }
                           }
                        } else {
                           var157 ^= 2124522231;
                           Economy var45 = this.economy;
                           double var46 = var45.getBalance(var19);
                           double var162;
                           int var48 = (var162 = var46 - var13) == 0.0D ? 0 : (var162 < 0.0D ? -1 : 1);
                           if (var48 < (502263172 ^ var157)) {
                              var157 ^= 1195867782;
                              MessagesConfig var64 = MessagesConfig.DONOTHAVEENOUGH;
                              String var65 = var64.getSingleMessage();
                              var157 ^= 960800877;
                              String var129 = var19.getName();
                              String var146 = String.valueOf(var13);
                              String var99 = this.formatMessage$1504987598(var65, var129, var146, 363046963);
                              var19.sendMessage(var99);
                              var157 ^= 732955831;
                              String var131 = var19.getName();
                              String var149 = String.valueOf(var13);
                              String var101 = this.formatMessage$1504987598(var65, var131, var149, 363046963);
                              ActionBar.sendActionBar(var19, var101);
                              var157 ^= 427703470;
                              byte var68 = (byte)(1361183606 ^ var157);
                              return (boolean)var68;
                           }

                           label159:
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157)) {
                              case 114576031:
                              default:
                                 throw new IllegalAccessException();
                              case 167821760:
                                 var157 ^= 1483698508;
                                 break label159;
                              case 1091698671:
                                 break;
                              case 1866170921:
                                 break label159;
                              }
                           }

                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157) != 111766083) {
                              var157 = kktrqujfhdzdkcbe(var157, 325317748);
                           } else {
                              while(true) {
                                 switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157)) {
                                 case 111766083:
                                    var157 ^= 608293634;
                                 case 1566574415:
                                    break label189;
                                 case 1792783232:
                                    break;
                                 case 1828357293:
                                 default:
                                    throw new IllegalAccessException();
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            } else {
               var157 = kktrqujfhdzdkcbe(var157, 1431594814);
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157) != 90418421) {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157)) {
                     case 14515808:
                     case 924241217:
                     default:
                        throw new IllegalAccessException();
                     case 90418421:
                        var157 ^= 545684804;
                        throw new IllegalAccessException();
                     case 1272936794:
                     }
                  }
               } else {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var157)) {
                     case 90418421:
                        var157 ^= 1377134821;
                     case 464221072:
                        break label199;
                     case 1097967259:
                     default:
                        throw new IllegalAccessException();
                     case 1330930494:
                     }
                  }
               }
            }

            throw new IllegalAccessException();
         }

         MessagesConfig var73 = MessagesConfig.ONLYPLAYERS;
         var73.send(var1);
         var157 ^= 1426046925;
         byte var74 = (byte)(1888469712 ^ var157);
         return (boolean)var74;
      }

      Economy var50 = this.economy;
      var50.withdrawPlayer(var19, var13);
      var157 ^= 1036832943;
      Economy var53 = this.economy;
      var53.depositPlayer(var26, var13);
      var157 ^= 1289368228;
      MessagesConfig var55 = MessagesConfig.PAYMENTSUCCESS;
      String var56 = var55.getSingleMessage();
      var157 ^= 329934088;
      String var121 = var26.getName();
      String var134 = String.valueOf(var13);
      String var91 = this.formatMessage$1504987598(var56, var121, var134, 363046963);
      var19.sendMessage(var91);
      var157 ^= 1322057327;
      String var123 = var26.getName();
      String var137 = String.valueOf(var13);
      String var93 = this.formatMessage$1504987598(var56, var123, var137, 363046963);
      ActionBar.sendActionBar(var26, var93);
      var157 ^= 68913483;
      MessagesConfig var59 = MessagesConfig.PAYMENTREICVED;
      String var60 = var59.getSingleMessage();
      var157 ^= 918780727;
      String var125 = var19.getName();
      String var140 = String.valueOf(var13);
      String var95 = this.formatMessage$1504987598(var60, var125, var140, 363046963);
      var26.sendMessage(var95);
      var157 ^= 145234785;
      String var127 = var19.getName();
      String var143 = String.valueOf(var13);
      String var97 = this.formatMessage$1504987598(var60, var127, var143, 363046963);
      ActionBar.sendActionBar(var26, var97);
      var157 ^= 212542561;
      byte var63 = (byte)(2070608859 ^ var157);
      return (boolean)var63;
   }

   private double parseAmount$1046020412(String var1, int var2) throws NumberFormatException {
      double var55;
      int var57;
      var57 = 608465335 ^ 2071664201 ^ this.Uy70tBUnkD ^ var2;
      var57 ^= 201660875;
      String var9 = var1.toLowerCase();
      var57 ^= 611404468;
      int var40 = var9.length();
      byte var5 = (byte)(893928991 ^ var57);
      int var41 = var40 - var5;
      char var11 = var9.charAt(var41);
      var57 ^= 1046132254;
      byte var42 = (byte)(185790464 ^ var57);
      int var44 = var9.length();
      byte var6 = (byte)(185790465 ^ var57);
      int var45 = var44 - var6;
      String var13 = var9.substring(var42, var45);
      var57 ^= 1906012335;
      int var59 = var11 ^ var57;
      label122:
      switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var59)) {
      case 225055492:
         var57 ^= 1105697468;
         double var16 = Double.parseDouble(var13);
         double var46 = 1.0E9D;
         double var18 = var16 * var46;
         var55 = var18;
         var57 ^= 255557144;
         var57 = kktrqujfhdzdkcbe(var57, 1347396970);

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57) != 32748209) {
               throw null;
            }

            throw new IllegalAccessException();
         } catch (IllegalAccessException var63) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var57)) {
            case 550898443:
               var57 = kktrqujfhdzdkcbe(var57, 775173016);
               break;
            case 906005097:
               var57 = kktrqujfhdzdkcbe(var57, 1827595188);
               break;
            default:
               throw new IOException("Error in hash");
            }

            var57 = kktrqujfhdzdkcbe(var57, 1787957177);
            return var55;
         }
      case 225055521:
         var57 = kktrqujfhdzdkcbe(var57, 55784937);
         double var36 = Double.parseDouble(var13);
         double var52 = 1.0E12D;
         double var38 = var36 * var52;
         var55 = var38;
         var57 ^= 700526110;
         var57 ^= 283903861;

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57) != 232783456) {
               throw null;
            }

            throw new IOException();
         } catch (IOException var62) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var57)) {
            case -1010634008:
               var57 ^= 1753894255;
               break label122;
            case 129818986:
               var57 ^= 805670687;
               break label122;
            default:
               throw new IOException("Error in hash");
            }
         }
      case 225055730:
         label120:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57)) {
            case 225055706:
               var57 ^= 1759863231;
               break label120;
            case 476213509:
               break;
            case 792101373:
               break label120;
            case 815486791:
            default:
               throw new RuntimeException();
            }
         }

         double var31 = Double.parseDouble(var13);
         double var50 = 1000.0D;
         double var33 = var31 * var50;
         var55 = var33;
         var57 ^= 481180212;

         label109:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57)) {
            case 16674021:
               break;
            case 211387991:
               var57 ^= 1095943617;
            case 1142478613:
               break label109;
            case 1657361237:
            default:
               throw new RuntimeException();
            }
         }

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57) != 170357835) {
               throw null;
            }

            throw new IllegalAccessException();
         } catch (IllegalAccessException var61) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var57)) {
            case 2066108345:
               var57 ^= 1071906926;
               break;
            case 2088826666:
               var57 = kktrqujfhdzdkcbe(var57, 1594939260);
               break;
            default:
               throw new IllegalAccessException("Error in hash");
            }
         }

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57)) {
            case 268015128:
               var57 ^= 809252057;
               return var55;
            case 527053820:
            default:
               throw new RuntimeException();
            case 1228095311:
               break;
            case 1590327589:
               return var55;
            }
         }
      case 225055742:
         var57 ^= 1599406297;
         double var26 = Double.parseDouble(var13);
         double var48 = 1000000.0D;
         double var28 = var26 * var48;
         var55 = var28;
         var57 ^= 2139650202;
         var57 ^= 1385317504;

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57) != 16844247) {
               throw null;
            }

            throw new IllegalAccessException();
         } catch (IllegalAccessException var60) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var57)) {
            case 4112872:
               var57 = kktrqujfhdzdkcbe(var57, 439030971);
               break;
            case 1177936736:
               var57 ^= 317354218;
               break;
            default:
               throw new RuntimeException("Error in hash");
            }

            var57 ^= 982528454;
            return var55;
         }
      default:
         var57 = kktrqujfhdzdkcbe(var57, 1701722796);
         double var23 = Double.parseDouble(var9);
         var55 = var23;
         var57 ^= 1062946627;
         return var55;
      }

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57)) {
         case 103785019:
            return var55;
         case 181761474:
            var57 ^= 1347350130;
            return var55;
         case 748228216:
            break;
         case 1519333042:
         default:
            throw new RuntimeException();
         }
      }
   }

   private String formatMessage$1504987598(String var1, String var2, String var3, int var4) {
      int var13 = 1690837710 ^ 965206330 ^ this.Uy70tBUnkD ^ var4;
      var13 ^= 403867024;
      String var6 = exvbgxttlj(msxdhugvwshnjdt(), var13);
      String var8 = var1.replace(var6, var2);
      String var10 = exvbgxttlj(ohsnngtnwfrvtmj(), var13);
      String var9 = var8.replace(var10, var3);
      return var9;
   }

   static {
      nothing_to_see_here[0] = "⢀⡴⠑⡄⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠸⡇⠀⠿⡀⠀⠀⠀⣀⡴⢿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠑⢄⣠⠾⠁⣀⣄⡈⠙⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⢀⡀⠁⠀⠀⠈⠙⠛⠂⠈⣿⣿⣿⣿⣿⠿⡿⢿⣆⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⢀⡾⣁⣀⠀⠴⠂⠙⣗⡀⠀⢻⣿⣿⠭⢤⣴⣦⣤⣹⠀⠀⠀⢀⢴⣶⣆";
      nothing_to_see_here[5] = "⠀⠀⢀⣾⣿⣿⣿⣷⣮⣽⣾⣿⣥⣴⣿⣿⡿⢂⠔⢚⡿⢿⣿⣦⣴⣾⠁⠸⣼⡿";
      nothing_to_see_here[6] = "⠀⢀⡞⠁⠙⠻⠿⠟⠉⠀⠛⢹⣿⣿⣿⣿⣿⣌⢤⣼⣿⣾⣿⡟⠉⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⣾⣷⣶⠇⠀⠀⣤⣄⣀⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠉⠈⠉⠀⠀⢦⡈⢻⣿⣿⣿⣶⣶⣶⣶⣤⣽⡹⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠉⠲⣽⡻⢿⣿⣿⣿⣿⣿⣿⣷⣜⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣷⣶⣮⣭⣽⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⠿⠿⠿⠿⠛⠉              ";
      jnxthjtris = ByteBuffer.wrap(gmczepehuiyycve()).asCharBuffer().toString();
      int var3 = (new Random(-5132076102418261078L)).nextInt();
      FBtUd90MAp = -48574667 ^ var3;
   }

   public static String exvbgxttlj(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = jnxthjtris;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var91 = StandardCharsets.UTF_16BE;
            String var35 = new String(var11, var91);
            return var35;
         }

         byte var85 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var90 = var8[var92];
         int var86 = var85 ^ var90;
         byte var87 = (byte)var86;
         var11[var12] = var87;
         ++var12;
      }
   }

   private static byte[] livbqkqvtkxgmli() {
      return new byte[]{0, 0, 0, 22, 0, 0, 0, 0};
   }

   private static byte[] msxdhugvwshnjdt() {
      return new byte[]{0, 0, 0, 8, 0, 0, 0, 22};
   }

   private static byte[] ohsnngtnwfrvtmj() {
      return new byte[]{0, 0, 0, 8, 0, 0, 0, 30};
   }

   private static byte[] gmczepehuiyycve() {
      return new byte[]{49, 26, 48, 67, 56, 87, 48, 75, 55, 21, 49, 9, 48, 67, 56, 90, 48, 83, 55, 76, 49, 80, 48, 65, 56, 8, 48, 18, 55, 9, 49, 84, 48, 94, 56, 89, 48, 71, 55, 91, 49, 65, 48, 13, 49, 21, 49, 66, 57, 90, 53, 82, 55, 72, 49, 85, 49, 64, 57, 19, 49, 21, 49, 83, 57, 91, 53, 92, 55, 68, 49, 94, 49, 70, 57, 19};
   }

   private static int kktrqujfhdzdkcbe(int var0, int var1) {
      return var1 ^ var0;
   }
}
