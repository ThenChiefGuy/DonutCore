package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MainConfig;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.config.SoundConfig;
import dev.daniboy.donutcore.config.wrapper.SoundWrapper;
import dev.daniboy.donutcore.database.SQLiteManager;
import dev.daniboy.donutcore.gui.impl.SpawnGUI;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetSpawnCommand extends Command {
   private final DonutCore plugin;
   private final SQLiteManager sqLiteManager;
   private final SpawnGUI spawnGui;
   private static int zF4m10e3sE;
   private transient int UD3VsVxmfn;
   private static String[] nothing_to_see_here = new String[15];

   public SetSpawnCommand(DonutCore var1, SQLiteManager var2, SpawnGUI var3, int var4) {
      int var14 = 2015964457 ^ 1448227603;
      String var6 = "setspawn";
      super(var6);

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var14)) {
         case 168731883:
            var14 ^= 1949361077;
         case 207525875:
            var14 = 554751985 ^ 1760951455 ^ Integer.parseInt("2025814649") ^ var4;
            this.UD3VsVxmfn = 2101734071 ^ zF4m10e3sE;
            var14 ^= 796650574;
            var14 ^= 250825406;
            this.plugin = var1;
            var14 ^= 1301436356;
            this.sqLiteManager = var2;
            var14 ^= 312330863;
            this.spawnGui = var3;
            var14 ^= 1139639355;
            return;
         case 1617761792:
         default:
            throw new IOException();
         case 2083880792:
         }
      }
   }

   public String getName() {
      int var4 = 338112662 ^ 856584657 ^ this.UD3VsVxmfn;
      var4 ^= 464127030;
      String var1 = gcvyhjrxiq(shaigynxwlzwekw(), wevqvqxhckcmnkd(), var4);
      return var1;
   }

   public String getDescription() {
      int var4 = 1462979699 ^ 2051418971 ^ this.UD3VsVxmfn;
      var4 ^= 2125800158;
      String var1 = gcvyhjrxiq(bflnvwlfbmlxofc(), wevqvqxhckcmnkd(), var4);
      return var1;
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      int var72 = 660532617 ^ 5459015 ^ this.UD3VsVxmfn;
      var72 ^= 1462994707;
      byte var12 = var1 instanceof Player;
      if (var12 != (428081256 ^ var72)) {
         var72 ^= 1835697063;
         Player var14 = (Player)var1;
         var72 ^= 310645522;

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72)) {
            case 107880134:
               var72 ^= 1599140535;
            case 2078600392:
               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72) != 249636759) {
                     throw null;
                  }

                  throw new IllegalAccessException();
               } catch (IllegalAccessException var77) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var72)) {
                  case -908913839:
                     var72 = kqbpcpdjwfivnavj(var72, 233108685);
                     break;
                  case 1071802625:
                     var72 ^= 321051527;
                     break;
                  default:
                     throw new IllegalAccessException("Error in hash");
                  }

                  var72 = kqbpcpdjwfivnavj(var72, 1069572924);
                  String var5 = gcvyhjrxiq(jcputdoaisyhzmc(), wevqvqxhckcmnkd(), var72);
                  byte var16 = var14.hasPermission(var5);
                  if (var16 == (186578331 ^ var72)) {
                     var72 ^= 1555146755;
                     MessagesConfig var17 = MessagesConfig.NOPERMISSION;
                     var17.send(var14);
                     var72 ^= 2091510922;
                     SoundWrapper var18 = SoundConfig.NOPERMISSION;
                     var18.play(var14);
                     var72 ^= 1309980852;
                     byte var19 = (byte)(1695680934 ^ var72);
                     return (boolean)var19;
                  }

                  var72 ^= 668218653;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72) == 113834441) {
                     label199:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72)) {
                        case 113834441:
                           var72 ^= 268703115;
                           break label199;
                        case 397463651:
                           break;
                        case 1768200161:
                           break label199;
                        case 1880469783:
                        default:
                           throw new IOException();
                        }
                     }

                     byte var20 = MainConfig.SpawnAFK.NEW_DONUT_SPAWN_AFK;
                     if (var20 != (1020187917 ^ var72)) {
                        var72 ^= 1930791360;
                        int var31 = var3.length;
                        byte var54 = (byte)(1339776204 ^ var72);
                        if (var31 == var54) {
                           var72 ^= 1457807025;

                           int var68;
                           try {
                              byte var55 = (byte)(423559804 ^ var72);
                              String var33 = var3[var55];
                              int var34 = Integer.parseInt(var33);
                              var68 = var34;
                              var72 ^= 600560921;
                           } catch (NumberFormatException var73) {
                              switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var72)) {
                              case -906488864:
                                 var72 ^= 2022596154;
                                 var72 ^= 1742304093;
                                 MessagesConfig var44 = MessagesConfig.INVALIDSPAWNNUMBER;
                                 var44.send(var14);
                                 var72 ^= 1964875234;
                                 byte var45 = (byte)(1937093369 ^ var72);
                                 return (boolean)var45;
                              default:
                                 throw new IllegalAccessException("Error in hash");
                              }
                           }

                           var72 ^= 1873548225;

                           try {
                              if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72) != 89893285) {
                                 throw null;
                              }

                              throw new RuntimeException();
                           } catch (RuntimeException var76) {
                              switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var72)) {
                              case -1429854942:
                                 var72 = kqbpcpdjwfivnavj(var72, 252474330);
                                 break;
                              case 402057528:
                                 var72 = kqbpcpdjwfivnavj(var72, 1487563353);
                                 break;
                              default:
                                 throw new IOException("Error in hash");
                              }
                           }

                           label185:
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72)) {
                              case 251951568:
                                 var72 ^= 1295067276;
                              case 1442438402:
                                 break label185;
                              case 1962159721:
                                 break;
                              case 1997530280:
                              default:
                                 throw new IOException();
                              }
                           }

                           Location var36 = var14.getLocation();
                           var72 ^= 1340775996;
                           SQLiteManager var38 = this.sqLiteManager;
                           var38.setSpawn$19360209(var36, var68, 319223360);
                           var72 ^= 530136539;
                           MessagesConfig var39 = MessagesConfig.SPAWNPOINTSET;
                           byte var63 = (byte)(1192639511 ^ var72);
                           String[] var64 = new String[var63];
                           byte var7 = (byte)(1192639509 ^ var72);
                           String var8 = gcvyhjrxiq(thlhepxczilrqdr(), wevqvqxhckcmnkd(), var72);
                           var64[var7] = var8;
                           byte var65 = (byte)(1192639508 ^ var72);
                           String var67 = String.valueOf(var68);
                           var64[var65] = var67;
                           var39.send(var14, var64);
                           var72 ^= 758277517;
                           SoundWrapper var40 = SoundConfig.SPAWNSET;
                           var40.play(var14);
                           var72 ^= 872175403;
                           SpawnGUI var42 = this.spawnGui;
                           var42.loadSpawnConfigValues$882403349(870176311);
                           var72 ^= 2118444938;
                           var72 ^= 1672639834;

                           try {
                              if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72) != 68815569) {
                                 throw null;
                              }

                              throw new IOException();
                           } catch (IOException var75) {
                              switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var72)) {
                              case 561308442:
                                 var72 ^= 123005714;
                                 break;
                              case 1289736809:
                                 var72 ^= 1793166652;
                                 break;
                              default:
                                 throw new IllegalAccessException("Error in hash");
                              }
                           }

                           label175:
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72)) {
                              case 45941776:
                                 var72 ^= 616103333;
                                 break label175;
                              case 455246855:
                                 break;
                              case 1042310614:
                                 break label175;
                              case 1538067636:
                              default:
                                 throw new IOException();
                              }
                           }
                        } else {
                           var72 = kqbpcpdjwfivnavj(var72, 547438357);
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72) != 134041096) {
                              while(true) {
                                 switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72)) {
                                 case 134041096:
                                    var72 ^= 1323031711;
                                    throw new IOException();
                                 case 536730350:
                                    break;
                                 case 1574413695:
                                 case 1634425249:
                                 default:
                                    throw new IOException();
                                 }
                              }
                           }

                           var72 = kqbpcpdjwfivnavj(var72, 1623800605);
                           MessagesConfig var46 = MessagesConfig.PROVIDESPAWNNUMBER;
                           var46.send(var14);
                           var72 = kqbpcpdjwfivnavj(var72, 1191900639);

                           try {
                              if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72) != 216528859) {
                                 throw null;
                              }

                              throw new IOException();
                           } catch (IOException var74) {
                              switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var72)) {
                              case -2020292845:
                                 var72 = kqbpcpdjwfivnavj(var72, 2059247558);
                                 break;
                              case 1171089618:
                                 var72 ^= 1123461694;
                                 break;
                              default:
                                 throw new RuntimeException("Error in hash");
                              }
                           }

                           var72 = kqbpcpdjwfivnavj(var72, 1837993456);
                        }
                     } else {
                        label165:
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72)) {
                           case 97550343:
                              var72 ^= 77209509;
                           case 730073990:
                              break label165;
                           case 908762880:
                              break;
                           case 1765864148:
                           default:
                              throw new IOException();
                           }
                        }

                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72) != 220492017) {
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72)) {
                              case 220492017:
                                 var72 ^= 435516911;
                                 throw new IOException();
                              case 726265303:
                              case 1489430068:
                              default:
                                 throw new IOException();
                              case 1649879111:
                              }
                           }
                        }

                        label154:
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72)) {
                           case 220492017:
                              var72 ^= 1311736983;
                              break label154;
                           case 607705709:
                              break;
                           case 615786642:
                              break label154;
                           case 1448623782:
                           default:
                              throw new IOException();
                           }
                        }

                        Location var22 = var14.getLocation();
                        var72 ^= 758734486;
                        SQLiteManager var24 = this.sqLiteManager;
                        String var51 = gcvyhjrxiq(ubwuqtnvfkgwaya(), wevqvqxhckcmnkd(), var72);
                        var24.saveLocation$479125106(var51, var22, 1304033000);
                        var72 ^= 1184385324;
                        MessagesConfig var25 = MessagesConfig.SPAWNLOCATIONSET;
                        var25.send(var14);
                        var72 ^= 918452230;
                        SoundWrapper var26 = SoundConfig.SPAWNSET;
                        var26.play(var14);
                        var72 ^= 1810700366;
                        SpawnGUI var28 = this.spawnGui;
                        var28.loadSpawnConfigValues$882403349(870176311);
                        var72 ^= 659272473;
                     }

                     byte var29 = (byte)(1740802773 ^ var72);
                     return (boolean)var29;
                  }

                  var72 = kqbpcpdjwfivnavj(var72, 225148865);
                  throw new IOException();
               }
            case 1617154952:
            default:
               throw new IOException();
            case 2006310448:
            }
         }
      } else {
         var72 = kqbpcpdjwfivnavj(var72, 1460175558);
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72) == 137393085) {
            var72 = kqbpcpdjwfivnavj(var72, 2111403150);
            MessagesConfig var47 = MessagesConfig.ONLYPLAYERS;
            var47.send(var1);
            var72 ^= 623574841;
            byte var48 = (byte)(377424153 ^ var72);
            return (boolean)var48;
         } else {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var72)) {
               case 137393085:
                  var72 ^= 1865235945;
                  throw new IOException();
               case 436927769:
               case 634827493:
               default:
                  throw new IOException();
               case 2100894451:
               }
            }
         }
      }
   }

   static {
      nothing_to_see_here[0] = " ⠁⡼⠋⠀⣆⠀⠀⣰⣿⣫⣾⢿⣿⣿⠍⢠⠠⠀⠀⢀⠰⢾⣺⣻⣿⣿⣿⣷⡀⠀";
      nothing_to_see_here[1] = "⣥⠀⠀⠀⠁⠀⠠⢻⢬⠁⣠⣾⠛⠁⠀⠀⠀⠀⠀⠀⠀⠐⠱⠏⡉⠙⣿⣿⡇⠀";
      nothing_to_see_here[2] = "⢳⠀⢰⡖⠀⠀⠈⠀⣺⢰⣿⢻⣾⣶⣿⣿⣶⣶⣤⣤⣴⣾⣿⣷⣼⡆⢸⣿⣧⠀";
      nothing_to_see_here[3] = "⠈⠀⠜⠈⣀⣔⣦⢨⣿⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣅⣼⠛⢹⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⢋⡿⡿⣯⣭⡟⣟⣿⣿⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⡘⠀";
      nothing_to_see_here[5] = "⡀⠐⠀⠀⠀⣿⣯⡿⣿⣿⣿⣯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣉⢽⣿⡆⠀⠀";
      nothing_to_see_here[6] = "⢳⠀⠄⠀⢀⣿⣿⣿⣿⣿⣿⣿⠙⠉⠉⠉⠛⣻⢛⣿⠛⠃⠀⠐⠛⠻⣿⡇⠀⠀";
      nothing_to_see_here[7] = "⣾⠄⠀⠀⢸⣿⣿⡿⠟⠛⠁⢀⠀⢀⡄⣀⣠⣾⣿⣿⡠⣴⣎⣀⣠⣠⣿⡇⠀⠀";
      nothing_to_see_here[8] = "⣧⠀⣴⣄⣽⣿⣿⣿⣶⣶⣖⣶⣬⣾⣿⣾⣿⣿⣿⣿⣽⣿⣿⣿⣿⣿⣿⡇⠀⠀";
      nothing_to_see_here[9] = "⣿⣶⣈⡯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣹⢧⣿⣿⣿⣄⠙⢿⣿⣿⣿⠇⠀⠀";
      nothing_to_see_here[10] = "⠹⣿⣿⣧⢌⢽⣻⢿⣯⣿⣿⣿⣿⠟⣠⡘⠿⠟⠛⠛⠟⠛⣧⡈⠻⣾⣿⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠈⠉⣷⡿⣽⠶⡾⢿⣿⣿⣿⢃⣤⣿⣷⣤⣤⣄⣄⣠⣼⡿⢷⢀⣿⡏⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⢀⣿⣷⠌⣈⣏⣝⠽⡿⣷⣾⣏⣀⣉⣉⣀⣀⣀⣠⣠⣄⡸⣾⣿⠃⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⣰⡿⣿⣧⡐⠄⠱⣿⣺⣽⢟⣿⣿⢿⣿⣍⠉⢀⣀⣐⣼⣯⡗⠟⡏⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⣰⣿⠀⣿⣿⣴⡀⠂⠘⢹⣭⡂⡚⠿⢿⣿⣿⣿⡿⢿⢿⡿⠿⢁⣴⣿⣷⣶⣦⣤";
      int var3 = (new Random(-8541337118377950880L)).nextInt();
      zF4m10e3sE = -1054898421 ^ var3;
   }

   public static String gcvyhjrxiq(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] wevqvqxhckcmnkd() {
      return new byte[]{105, 76, 99, 1, 52, 39, 57, 5, 75, 104, 4, 65, 1, 125, 83, 17, 83, 60, 15, 46, 9, 78, 16, 29, 101, 19, 38, 32, 79, 88, 79, 57, 57, 126, 79, 73, 12, 41, 76, 90, 109, 78, 84, 12, 111, 52, 8, 89};
   }

   private static byte[] shaigynxwlzwekw() {
      return new byte[]{-90, -121, 81, 75, 12, 112, 13, 69, 126, 41, 53, 5, 51, 37, 107, 84, 103, 102};
   }

   private static byte[] bflnvwlfbmlxofc() {
      return new byte[]{-82, -117, 82, 98, 13, 123, 10, 66, 122, 34, 60, 80, 49, 48, 106, 74, 96, 104, 54, 54, 56, 45, 41, 84, 86, 65, 23, 110, 119, 7, 127, 32, 0, 33, 124, 23, 53, 114, 125, 11, 84, 3, 103, 86, 94, 98, 48, 6, 89, 85, 90, 93, 7, 100, 0, 29, 122, 40, 61, 23, 50, 39, 98, 70, 107, 121, 63, 55, 48, 27, 35, 67, 92, 89, 23, 48, 118, 21, 124, 98, 8, 34, 119, 88, 60, 96, 117, 5, 94, 30, 109, 77, 94, 97, 49, 18, 90, 81};
   }

   private static byte[] thlhepxczilrqdr() {
      return new byte[]{-90, -126, 90, 22, 2, 122, 0, 69, 123, 60, 53, 18, 56, 42, 101, 80, 106, 44};
   }

   private static byte[] jcputdoaisyhzmc() {
      return new byte[]{-90, -117, 85, 80, 3, 112, 10, 88, 122, 44, 60, 3, 52, 41, 107, 77, 96, 127, 62, 115, 63, 85, 39, 86, 86, 69, 23, 101, 119, 29, 122, 126, 1, 44, 124, 15, 61, 127};
   }

   private static byte[] ubwuqtnvfkgwaya() {
      return new byte[]{-90, -122, 80, 67, 4, 98, 15, 86, 114, 40, 53, 26};
   }

   private static int kqbpcpdjwfivnavj(int var0, int var1) {
      return var1 ^ var0;
   }
}
