package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MainConfig;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.config.SoundConfig;
import dev.daniboy.donutcore.config.wrapper.SoundWrapper;
import dev.daniboy.donutcore.database.SQLiteManager;
import dev.daniboy.donutcore.utils.Hex;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ReplyCommand implements CommandExecutor {
   private final DonutCore plugin;
   private final SQLiteManager sqLiteManager;
   private static int gwOMOWbycm;
   private transient int NEheJluVMw;
   private static String[] nothing_to_see_here = new String[18];

   public ReplyCommand(DonutCore var1, SQLiteManager var2, int var3) {
      int var10 = 1444868591 ^ 2096840480;
      super();
      var10 ^= 536821327;
      var10 = 931249530 ^ 165036857 ^ Integer.parseInt("71824652") ^ var3;
      this.NEheJluVMw = 1795574256 ^ gwOMOWbycm;
      var10 = vhawimlcyuohboxf(var10, 159582654);
      var10 ^= 1012872035;
      this.plugin = var1;
      var10 ^= 2110656539;
      this.sqLiteManager = var2;
      var10 ^= 1442332972;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      int var93 = 173332682 ^ 1968792262 ^ this.NEheJluVMw;
      var93 ^= 855564930;
      byte var13 = var1 instanceof Player;
      if (var13 == (1966718971 ^ var93)) {
         var93 ^= 47522719;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93) == 140122349) {
            var93 = vhawimlcyuohboxf(var93, 1094062192);
            MessagesConfig var59 = MessagesConfig.ONLYPLAYERS;
            var59.send(var1);
            var93 ^= 344971556;
            byte var60 = (byte)(576017713 ^ var93);
            return (boolean)var60;
         } else {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93)) {
               case 140122349:
                  var93 ^= 1359897801;
                  throw new RuntimeException();
               case 250745896:
               case 913434870:
               default:
                  throw new RuntimeException();
               case 1468057587:
               }
            }
         }
      } else {
         var93 ^= 1605558368;
         Player var15 = (Player)var1;
         var93 ^= 2008619466;
         var93 ^= 485693637;

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93) != 258402047) {
               throw null;
            }

            throw new RuntimeException();
         } catch (RuntimeException var94) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var93)) {
            case -2097879064:
               var93 ^= 643278959;
               break;
            case 235599010:
               var93 ^= 2009623046;
               break;
            default:
               throw new IOException("Error in hash");
            }
         }

         label168:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93)) {
            case 5283144:
               break;
            case 145875923:
               var93 ^= 570770419;
            case 498623442:
               break label168;
            case 1271098166:
            default:
               throw new RuntimeException();
            }
         }

         String var6 = vdbmlcxfna(lbjhmimttxayqje(), dalabsrwxkdurzu(), var93);
         byte var17 = var15.hasPermission(var6);
         if (var17 == (336361313 ^ var93)) {
            var93 ^= 1885642315;
            MessagesConfig var18 = MessagesConfig.NOPERMISSION;
            var18.send(var15);
            var93 ^= 589906838;
            SoundWrapper var19 = SoundConfig.NOPERMISSION;
            var19.play(var15);
            var93 ^= 154614922;
            byte var20 = (byte)(1316394551 ^ var93);
            return (boolean)var20;
         } else {
            var93 ^= 305316020;
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93) != 98224745) {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93)) {
                  case 98224745:
                     var93 ^= 551309176;
                     throw new RuntimeException();
                  case 837442493:
                     break;
                  case 1881477714:
                  case 2041225808:
                  default:
                     throw new RuntimeException();
                  }
               }
            } else {
               var93 = vhawimlcyuohboxf(var93, 483670661);
               int var22 = var4.length;
               byte var63 = (byte)(451579217 ^ var93);
               if (var22 < var63) {
                  var93 ^= 223963663;
                  String var64 = vdbmlcxfna(tbxhioagcenwehj(), dalabsrwxkdurzu(), var93);
                  var1.sendMessage(var64);
                  var93 ^= 1303016524;
                  byte var24 = (byte)(1511625490 ^ var93);
                  return (boolean)var24;
               } else {
                  var93 ^= 828698345;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93) != 73648824) {
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93)) {
                        case 73648824:
                           var93 ^= 225221396;
                           throw new RuntimeException();
                        case 99425451:
                        case 1955519383:
                        default:
                           throw new RuntimeException();
                        case 1869485720:
                        }
                     }
                  } else {
                     label157:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93)) {
                        case 73648824:
                           var93 ^= 460996831;
                           break label157;
                        case 1237845539:
                           break;
                        case 1478480931:
                           break label157;
                        case 1708704962:
                        default:
                           throw new RuntimeException();
                        }
                     }

                     DonutCore var26 = this.plugin;
                     Map var27 = var26.getLastMessaged$1938418975(498594716);
                     Object var28 = var27.get(var15);
                     Player var29 = (Player)var28;
                     var93 ^= 782775800;
                     if (var29 != null) {
                        var93 ^= 434050480;
                        byte var32 = var29.isOnline();
                        if (var32 != (126026542 ^ var93)) {
                           label143:
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93)) {
                              case 118150520:
                                 var93 ^= 761922149;
                                 break label143;
                              case 385505482:
                                 break;
                              case 788240717:
                              default:
                                 throw new RuntimeException();
                              case 1719810545:
                                 break label143;
                              }
                           }

                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93) != 52648040) {
                              var93 ^= 202111462;
                              throw new RuntimeException();
                           }

                           label132:
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93)) {
                              case 52648040:
                                 var93 ^= 1004449282;
                                 break label132;
                              case 1086339379:
                                 break;
                              case 1399730909:
                                 break label132;
                              case 1613106657:
                              default:
                                 throw new RuntimeException();
                              }
                           }

                           SQLiteManager var36 = this.sqLiteManager;
                           UUID var68 = var29.getUniqueId();
                           byte var37 = var36.getMessageToggle$1388376138(var68, 884977015);
                           if (var37 == (288862025 ^ var93)) {
                              var93 ^= 1800754405;
                              MessagesConfig var57 = MessagesConfig.MESSAGEDISABLED;
                              var57.send(var1);
                              var93 ^= 1248949225;
                              byte var58 = (byte)(806586436 ^ var93);
                              return (boolean)var58;
                           }

                           var93 = vhawimlcyuohboxf(var93, 2121772652);
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93) != 126643575) {
                              var93 ^= 1235417480;
                              throw new RuntimeException();
                           }

                           label121:
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93)) {
                              case 126643575:
                                 var93 ^= 1540592469;
                              case 445329428:
                                 break label121;
                              case 1386251808:
                              default:
                                 throw new RuntimeException();
                              case 1729419340:
                              }
                           }

                           String var38 = vdbmlcxfna(jbjxjsexpgxwicv(), dalabsrwxkdurzu(), var93);
                           String var39 = String.join(var38, var4);
                           var93 ^= 1136671827;
                           String var40 = MainConfig.Chat.REPLY_FORMAT;
                           String var70 = vdbmlcxfna(glekwnxpkagfobb(), dalabsrwxkdurzu(), var93);
                           var93 ^= 1387618683;
                           String var81 = var15.getName();
                           String var41 = var40.replace(var70, var81);
                           String var71 = vdbmlcxfna(ecsjlggvmqymzeq(), dalabsrwxkdurzu(), var93);
                           var93 ^= 739333395;
                           String var83 = var29.getName();
                           String var42 = var41.replace(var71, var83);
                           String var72 = vdbmlcxfna(vqrdyouajdetefl(), dalabsrwxkdurzu(), var93);
                           var93 ^= 457540291;
                           String var43 = var42.replace(var72, var39);
                           var93 ^= 2106746279;
                           String var44 = Hex.hex(var43);
                           var93 ^= 2102860593;
                           String var45 = MainConfig.Chat.REPLY_SENT;
                           String var73 = vdbmlcxfna(thapfyajywgierx(), dalabsrwxkdurzu(), var93);
                           var93 ^= 1833074837;
                           String var86 = var15.getName();
                           String var46 = var45.replace(var73, var86);
                           String var74 = vdbmlcxfna(wqmvxcogzjopazf(), dalabsrwxkdurzu(), var93);
                           var93 ^= 756886652;
                           String var88 = var29.getName();
                           String var47 = var46.replace(var74, var88);
                           String var75 = vdbmlcxfna(rwjblldgrmjnnxa(), dalabsrwxkdurzu(), var93);
                           var93 ^= 514762308;
                           String var48 = var47.replace(var75, var39);
                           var93 ^= 1972113885;
                           String var49 = Hex.hex(var48);
                           var93 ^= 1073653363;
                           var29.sendMessage(var44);
                           var93 ^= 444810790;
                           var15.sendMessage(var49);
                           var93 ^= 1836591592;
                           DonutCore var53 = this.plugin;
                           Map var54 = var53.getLastMessaged$1938418975(498594716);
                           var54.put(var29, var15);
                           var93 ^= 105124016;
                           byte var56 = (byte)(2001445986 ^ var93);
                           return (boolean)var56;
                        }

                        var93 ^= 6591013;
                     } else {
                        var93 ^= 819807997;
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93) != 169518398) {
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var93)) {
                              case 169518398:
                                 var93 ^= 140749006;
                                 throw new RuntimeException();
                              case 611199747:
                                 break;
                              case 632309931:
                              case 1960791038:
                              default:
                                 throw new RuntimeException();
                              }
                           }
                        }

                        var93 ^= 694600040;
                     }

                     MessagesConfig var33 = MessagesConfig.NOMESSAGEREICIVED;
                     var33.send(var1);
                     var93 ^= 2040673128;
                     byte var34 = (byte)(2118492770 ^ var93);
                     return (boolean)var34;
                  }
               }
            }
         }
      }
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣶⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⠿⠟⠛⠻⣿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣆⣀⣀⠀⣿⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠻⣿⣿⣿⠅⠛⠋⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[5] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢼⣿⣿⣿⣃⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[6] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣟⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣛⣛⣫⡄⠀⢸⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣾⡆⠸⣿⣿⣿⡷⠂⠨⣿⣿⣿⣿⣶⣦⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣾⣿⣿⣿⣿⡇⢀⣿⡿⠋⠁⢀⡶⠪⣉⢸⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⡏⢸⣿⣷⣿⣿⣷⣦⡙⣿⣿⣿⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣇⢸⣿⣿⣿⣿⣿⣷⣦⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[15] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[16] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[17] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣵⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      int var3 = (new Random(-3443188960377013066L)).nextInt();
      gwOMOWbycm = -1625714843 ^ var3;
   }

   public static String vdbmlcxfna(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] dalabsrwxkdurzu() {
      return new byte[]{33, 94, 102, 81, 52, 98, 112, 19, 71, 82, 55, 72, 99, 77, 86, 6, 49, 81, 59, 1, 77, 45, 35, 44, 119, 30, 117, 96, 20, 56, 68, 124, 16, 66, 32, 28, 95, 96, 18, 86, 19, 94, 36, 44, 64, 57, 101, 77, 121, 101, 119, 24, 123, 69, 30, 38, 21, 68, 33, 36, 7, 33, 76, 30, 31, 2, 37, 127, 50, 37, 55, 40, 85, 35, 122, 30, 18, 3, 71, 84, 93, 16, 118, 109, 77, 110, 59, 48, 119, 43, 99, 7, 15, 8, 117, 19, 50, 35, 76, 50, 98, 34, 79, 9, 55, 32, 120, 35, 4, 95, 84, 112, 12};
   }

   private static byte[] ecsjlggvmqymzeq() {
      return new byte[]{-23, -110, 83, 76, 12, 35, 67, 67, 117, 7, 4, 24, 91, 28, 101, 67, 4, 6, 13, 64, 120, 48};
   }

   private static byte[] glekwnxpkagfobb() {
      return new byte[]{-19, -111, 86, 69, 13, 38, 66, 65, 112, 13, 5, 28, 83, 25, 111, 67, 3, 67};
   }

   private static byte[] vqrdyouajdetefl() {
      return new byte[]{-18, -105, 81, 70, 6, 62, 72, 69, 114, 16, 1, 12, 81, 30, 103, 89, 2, 1, 10, 18};
   }

   private static byte[] rwjblldgrmjnnxa() {
      return new byte[]{-18, -110, 81, 76, 0, 63, 69, 71, 118, 16, 6, 8, 84, 20, 98, 81, 4, 5, 10, 21};
   }

   private static byte[] jbjxjsexpgxwicv() {
      return new byte[]{-25, -103, 84, 65};
   }

   private static byte[] thapfyajywgierx() {
      return new byte[]{-20, -111, 95, 76, 5, 37, 72, 71, 115, 15, 7, 21, 91, 25, 98, 76, 0, 64};
   }

   private static byte[] wqmvxcogzjopazf() {
      return new byte[]{-19, -112, 85, 64, 6, 35, 72, 78, 114, 8, 5, 28, 80, 16, 100, 67, 9, 12, 14, 74, 127, 57};
   }

   private static byte[] tbxhioagcenwehj() {
      return new byte[]{-20, -104, 81, 50, 2, 39, 65, 70, 116, 6, 14, 26, 85, 65, 96, 23, 5, 77, 8, 74, 122, 126, 21, 106, 70, 70, 70, 42, 45, 47, 114, 118, 38, 30, 20, 74, 108, 42, 37, 19, 37, 9, 21, 127, 115, 111, 92, 68};
   }

   private static byte[] lbjhmimttxayqje() {
      return new byte[]{-20, -110, 80, 6, 2, 60, 67, 76, 116, 20, 4, 10, 80, 24, 103, 90, 0, 16, 8, 87, 123, 48, 21, 111, 68, 74, 70, 35, 39, 98, 119, 51};
   }

   private static int vhawimlcyuohboxf(int var0, int var1) {
      return var1 ^ var0;
   }
}
