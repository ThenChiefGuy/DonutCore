package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.gui.impl.HelpGUI;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HelpCommand implements CommandExecutor {
   private final DonutCore plugin;
   private static int QZ2oEba1yz;
   private transient int FZx6H7ta7b;
   private static String[] nothing_to_see_here = new String[13];

   public HelpCommand(DonutCore var1, int var2) {
      int var7 = 1965989574 ^ 1807858857;
      super();
      var7 ^= 380485197;
      var7 = 644317782 ^ 192054058 ^ Integer.parseInt("626201321") ^ var2;
      this.FZx6H7ta7b = 814751389 ^ QZ2oEba1yz;
      var7 ^= 169276408;
      var7 ^= 1390592975;
      this.plugin = var1;
      var7 ^= 2030289215;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      int var28 = 1597635401 ^ 1010229466 ^ this.FZx6H7ta7b;
      var28 ^= 157952805;
      byte var9 = var1 instanceof Player;
      if (var9 != (465589727 ^ var28)) {
         var28 ^= 1948947297;
         Player var11 = (Player)var1;
         var28 ^= 907608638;

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var28)) {
            case 239605067:
               var28 ^= 1220995509;
            case 1045478766:
               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var28) != 22484643) {
                     throw null;
                  }

                  throw new IllegalAccessException();
               } catch (IllegalAccessException var29) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var28)) {
                  case -1985386072:
                     var28 = qonprnukzfhaulyk(var28, 233102793);
                     break;
                  case 12979400:
                     var28 = qonprnukzfhaulyk(var28, 482947429);
                     break;
                  default:
                     throw new RuntimeException("Error in hash");
                  }

                  var28 = qonprnukzfhaulyk(var28, 646297711);
                  String var6 = svknlhbbfz(kabfbaapxhlslpn(), umsobnpnvknvocf(), var28);
                  byte var13 = var11.hasPermission(var6);
                  if (var13 == (978602131 ^ var28)) {
                     var28 ^= 20274370;
                     MessagesConfig var14 = MessagesConfig.NOPERMISSION;
                     var14.send(var11);
                     var28 ^= 1317356318;
                     byte var15 = (byte)(1977898830 ^ var28);
                     return (boolean)var15;
                  }

                  var28 ^= 190257636;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var28) == 251026645) {
                     var28 = qonprnukzfhaulyk(var28, 1697964919);
                     DonutCore var17 = this.plugin;
                     HelpGUI var18 = var17.getHelpGui$1055651724(1578111927);
                     byte var7 = (byte)(1412936192 ^ var28);
                     Object[] var25 = new Object[var7];
                     var18.open$967512435(var11, var25, 1892453237);
                     var28 ^= 960929106;
                     byte var19 = (byte)(1836134227 ^ var28);
                     return (boolean)var19;
                  }

                  var28 = qonprnukzfhaulyk(var28, 1662761251);
                  throw new RuntimeException();
               }
            case 720575200:
            default:
               throw new RuntimeException();
            case 923796707:
            }
         }
      } else {
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var28)) {
            case 96779680:
               var28 ^= 1927225972;
            case 1012458204:
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var28) == 195862212) {
                  var28 = qonprnukzfhaulyk(var28, 1846533000);
                  MessagesConfig var20 = MessagesConfig.ONLYPLAYERS;
                  var20.send(var1);
                  var28 ^= 1364207392;
                  byte var21 = (byte)(1447070466 ^ var28);
                  return (boolean)var21;
               }

               var28 = qonprnukzfhaulyk(var28, 990355455);
               throw new RuntimeException();
            case 444900071:
            default:
               throw new RuntimeException();
            case 1014468552:
            }
         }
      }
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⣠⣶⡾⠏⠉⠙⠳⢦⡀⠀⠀⠀⢠⠞⠉⠙⠲⡀⠀    ";
      nothing_to_see_here[2] = "⠀⠀⠀⣴⠿⠏⠀⠀⠀⠀⠀⠀⢳⡀⠀⡏⠀⠀⠀⠀⠀⢷     ";
      nothing_to_see_here[3] = "⠀⠀⢠⣟⣋⡀⢀⣀⣀⡀⠀⣀⡀⣧⠀⢸⠀⠀⠀⠀⠀ ⡇    ";
      nothing_to_see_here[4] = "⠀⠀⢸⣯⡭⠁⠸⣛⣟⠆⡴⣻⡲⣿⠀⣸⠀⠀OK⠀ ⡇    ";
      nothing_to_see_here[5] = "⠀⠀⣟⣿⡭⠀⠀⠀⠀⠀⢱⠀⠀⣿⠀⢹⠀⠀⠀⠀⠀ ⡇    ";
      nothing_to_see_here[6] = "⠀⠀⠙⢿⣯⠄⠀⠀⠀⢀⡀⠀⠀⡿⠀⠀⡇⠀⠀⠀⠀⡼     ";
      nothing_to_see_here[7] = "⠀⠀⠀⠀⠹⣶⠆⠀⠀⠀⠀⠀⡴⠃⠀⠀⠘⠤⣄⣠⠞⠀     ";
      nothing_to_see_here[8] = "⠀⠀⠀⠀⠀⢸⣷⡦⢤⡤⢤⣞⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[9] = "⠀⠀⢀⣤⣴⣿⣏⠁⠀⠀⠸⣏⢯⣷⣖⣦⡀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[10] = "⢀⣾⣽⣿⣿⣿⣿⠛⢲⣶⣾⢉⡷⣿⣿⠵⣿⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[11] = "⣼⣿⠍⠉⣿⡭⠉⠙⢺⣇⣼⡏⠀⠀⠀⣄⢸⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[12] = "⣿⣿⣧⣀⣿.........⣀⣰⣏⣘⣆⣀⠀⠀       ";
      int var3 = (new Random(-6685641321514903258L)).nextInt();
      QZ2oEba1yz = 1943602264 ^ var3;
   }

   public static String svknlhbbfz(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] umsobnpnvknvocf() {
      return new byte[]{124, 43, 76, 24, 19, 26, 95};
   }

   private static byte[] kabfbaapxhlslpn() {
      return new byte[]{-69, -29, 116, 74, 35, 71, 110, 33, 26, 0, 47, 95, 44, 12, 78, 117, 127, 91, 42, 72, 103, 100, 27, 22, 41, 69, 43, 10, 75, 99};
   }

   private static int qonprnukzfhaulyk(int var0, int var1) {
      return var1 ^ var0;
   }
}
