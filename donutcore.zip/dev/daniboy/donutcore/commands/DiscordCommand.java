package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.config.MessagesConfig;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DiscordCommand extends Command {
   private static int yc0D7QajYv;
   private transient int uCtaEU1JsW;
   private static byte[] mkhcyfbkqf;
   private static String[] nothing_to_see_here = new String[17];

   public DiscordCommand() {
      int var13 = 1336754271 ^ 1485681909;
      String var2 = "discord";
      super(var2);

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var13)) {
         case 214945065:
            var13 ^= 1666670590;
         case 174258440:
            var13 = 1479573358 ^ 950345985 ^ Integer.parseInt("350418235");
            this.uCtaEU1JsW = 440995502 ^ yc0D7QajYv;
            var13 = mjguoxigenadawwv(var13, 1031809933);
            var13 ^= 1898208540;
            String var8 = "Provides the Discord server link.";
            this.setDescription(var8);
            var13 ^= 1379126877;
            String var9 = "/discord";
            this.setUsage(var9);
            var13 ^= 947917556;
            String var10 = "donutcore.discord";
            this.setPermission(var10);
            var13 ^= 908005429;
            return;
         case 512911945:
            break;
         case 1086600632:
         default:
            throw new IOException();
         }
      }
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      int var23 = 91606411 ^ 661863887 ^ this.uCtaEU1JsW;
      var23 ^= 542079447;
      byte var7 = var1 instanceof Player;
      if (var7 != (1288953518 ^ var23)) {
         var23 ^= 344437677;
         Player var11 = (Player)var1;
         var23 ^= 1556047872;

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23)) {
            case 77353049:
               var23 ^= 1178369623;
            case 1114637496:
               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23) != 25246757) {
                     throw null;
                  }

                  throw new IllegalAccessException();
               } catch (IllegalAccessException var24) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var23)) {
                  case -576693053:
                     var23 = mjguoxigenadawwv(var23, 1832347205);
                     break;
                  case 381409954:
                     var23 = mjguoxigenadawwv(var23, 1414796937);
                     break;
                  default:
                     throw new IOException("Error in hash");
                  }
               }

               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23)) {
                  case 194949727:
                     var23 ^= 1688531589;
                  case 725653352:
                     String var18 = stgmnbnyuc(glxpiavrkqtdlob(), var23);
                     byte var13 = var11.hasPermission(var18);
                     if (var13 == (1915199320 ^ var23)) {
                        var23 ^= 408715589;
                        MessagesConfig var14 = MessagesConfig.NOPERMISSION;
                        var14.send(var11);
                        var23 ^= 2022999532;
                        byte var15 = (byte)(317692912 ^ var23);
                        return (boolean)var15;
                     }

                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23)) {
                        case 180455265:
                           break;
                        case 221034141:
                           var23 ^= 411554595;
                        case 337693200:
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23) == 244776590) {
                              var23 ^= 558754398;
                              MessagesConfig var16 = MessagesConfig.DISCORD;
                              var16.send(var11);
                              var23 ^= 1483687824;
                              byte var17 = (byte)(327344564 ^ var23);
                              return (boolean)var17;
                           }

                           var23 ^= 1886188352;
                           throw new IllegalAccessException();
                        case 1152803971:
                        default:
                           throw new IllegalAccessException();
                        }
                     }
                  case 835183217:
                  default:
                     throw new IllegalAccessException();
                  case 1811043273:
                  }
               }
            case 860691860:
            default:
               throw new IllegalAccessException();
            case 957351681:
            }
         }
      } else {
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23)) {
            case 81408930:
               var23 ^= 531273032;
            case 1250793920:
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23) == 29053044) {
                  var23 ^= 1544844156;
                  MessagesConfig var8 = MessagesConfig.ONLYPLAYERS;
                  var8.send(var1);
                  var23 ^= 189422867;
                  byte var9 = (byte)(69690760 ^ var23);
                  return (boolean)var9;
               }

               var23 = mjguoxigenadawwv(var23, 1236661469);
               throw new IllegalAccessException();
            case 706309685:
            default:
               throw new IllegalAccessException();
            case 1503610594:
            }
         }
      }
   }

   static {
      nothing_to_see_here[0] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⣀⣠⣤⣶⣶⣶⣤⣄⣀⣀⠄⠄⠄⠄⠄";
      nothing_to_see_here[1] = "⠄⠄⠄⠄⠄⠄⠄⠄⣀⣤⣤⣶⣿⣿⣿⣿⣿⣿⣿⣟⢿⣿⣿⣿⣶⣤⡀⠄";
      nothing_to_see_here[2] = "⠄⠄⠄⠄⠄⠄⢀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣜⠿⠿⣿⣿⣧⢓";
      nothing_to_see_here[3] = "⠄⠄⠄⠄⠄⡠⢛⣿⣿⣿⡟⣿⣿⣽⣋⠻⢻⣿⣿⣿⣿⡻⣧⡠⣭⣭⣿⡧";
      nothing_to_see_here[4] = "⠄⠄⠄⠄⠄⢠⣿⡟⣿⢻⠃⣻⣨⣻⠿⡀⣝⡿⣿⣿⣷⣜⣜⢿⣝⡿⡻⢔";
      nothing_to_see_here[5] = "⠄⠄⠄⠄⠄⢸⡟⣷⢿⢈⣚⣓⡡⣻⣿⣶⣬⣛⣓⣉⡻⢿⣎⠢⠻⣴⡾⠫";
      nothing_to_see_here[6] = "⠄⠄⠄⠄⠄⢸⠃⢹⡼⢸⣿⣿⣿⣦⣹⣿⣿⣿⠿⠿⠿⠷⣎⡼⠆⣿⠵⣫";
      nothing_to_see_here[7] = "⠄⠄⠄⠄⠄⠈⠄⠸⡟⡜⣩⡄⠄⣿⣿⣿⣿⣶⢀⢀⣿⣷⣿⣿⡐⡇⡄⣿";
      nothing_to_see_here[8] = "⠄⠄⠄⠄⠄⠄⠄⠄⠁⢶⢻⣧⣖⣿⣿⣿⣿⣿⣿⣿⣿⡏⣿⣇⡟⣇⣷⣿";
      nothing_to_see_here[9] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⣆⣤⣽⣿⡿⠿⠿⣿⣿⣦⣴⡇⣿⢨⣾⣿⢹⢸";
      nothing_to_see_here[10] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⣿⠊⡛⢿⣿⣿⣿⣿⡿⣫⢱⢺⡇⡏⣿⣿⣸⡼";
      nothing_to_see_here[11] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⡿⠄⣿⣷⣾⡍⣭⣶⣿⣿⡌⣼⣹⢱⠹⣿⣇⣧";
      nothing_to_see_here[12] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⣼⠁⣤⣭⣭⡌⢁⣼⣿⣿⣿⢹⡇⣭⣤⣶⣤⡝⡼";
      nothing_to_see_here[13] = "⠄⣀⠤⡀⠄⠄⠄⠄⠄⡏⣈⡻⡿⠃⢀⣾⣿⣿⣿⡿⡼⠁⣿⣿⣿⡿⢷⢸";
      nothing_to_see_here[14] = "⢰⣷⡧⡢⠄⠄⠄⠄⠠⢠⡛⠿⠄⠠⠬⠿⣿⠭⠭⢱⣇⣀⣭⡅⠶⣾⣷⣶";
      nothing_to_see_here[15] = "⠈⢿⣿⣧⠄⠄⠄⠄⢀⡛⠿⠄⠄⠄⠄⢠⠃⠄⠄⡜⠄⠄⣤⢀⣶⣮⡍⣴";
      nothing_to_see_here[16] = "⠄⠈⣿⣿⡀⠄⠄⠄⢩⣝⠃⠄⠄⢀⡄⡎⠄⠄⠄⠇⠄⠄⠅⣴⣶⣶⠄⣶";
      mkhcyfbkqf = glelrnihpfxoczv();
      int var3 = (new Random(5593308598697382775L)).nextInt();
      yc0D7QajYv = -865913218 ^ var3;
   }

   public static String stgmnbnyuc(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = mkhcyfbkqf;
         byte[] var34 = mkhcyfbkqf;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] glelrnihpfxoczv() {
      return new byte[]{48, 66, 97, 50, 76, 80, 121, 50, 10, 48, 18, 127, 74, 8, 83, 32, 15, 72, 105, 8, 109, 77, 102, 62, 15, 24, 50, 84};
   }

   private static byte[] glxpiavrkqtdlob() {
      return new byte[]{-1, -124, 80, 99, 125, 6, 64, 111, 56, 117, 35, 50, 123, 94, 98, 118, 54, 9, 91, 93, 92, 90, 87, 111, 62, 72, 11, 20, 2, 17, 80, 100, 125, 23, 72, 111};
   }

   private static int mjguoxigenadawwv(int var0, int var1) {
      return var0 ^ var1;
   }
}
