package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MainConfig;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.config.SoundConfig;
import dev.daniboy.donutcore.config.wrapper.SoundWrapper;
import dev.daniboy.donutcore.database.SQLiteManager;
import dev.daniboy.donutcore.gui.impl.SpawnGUI;
import dev.daniboy.donutcore.manager.TeleportManager;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpawnCommand extends Command {
   private final DonutCore plugin;
   private final SQLiteManager sqLiteManager;
   private final TeleportManager teleportManager;
   private static int l1uBcDuQeF;
   private transient int ErlIfEX0sM;
   private static String[] nothing_to_see_here = new String[15];

   public SpawnCommand(DonutCore var1, SQLiteManager var2, TeleportManager var3, int var4) {
      int var14 = 1798202486 ^ 772639888;
      String var6 = "spawn";
      super(var6);
      var14 ^= 1185826261;
      var14 = 2097116483 ^ 420818810 ^ Integer.parseInt("976020915") ^ var4;
      this.ErlIfEX0sM = 1521529442 ^ l1uBcDuQeF;
      var14 = zjhjzbmkidnxhvpf(var14, 1893537200);
      var14 ^= 1757912460;
      this.plugin = var1;
      var14 ^= 245337390;
      this.sqLiteManager = var2;
      var14 ^= 176625220;
      this.teleportManager = var3;
      var14 ^= 2075423007;
   }

   public String getName() {
      int var4 = 1460535383 ^ 981826745 ^ this.ErlIfEX0sM;
      var4 ^= 1025302285;
      String var1 = uzhwgzlpho(mdvxwlrzvdwsnuf(), rjwxgraeatjaowq(), var4);
      return var1;
   }

   public String getDescription() {
      int var4 = 1423967870 ^ 1942824499 ^ this.ErlIfEX0sM;
      var4 ^= 1856589830;
      String var1 = uzhwgzlpho(lnrnesxiyvvwzxd(), rjwxgraeatjaowq(), var4);
      return var1;
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      int var46;
      label194: {
         var46 = 533402728 ^ 165167407 ^ this.ErlIfEX0sM;
         var46 ^= 512937663;
         byte var9 = var1 instanceof Player;
         if (var9 == (1756409893 ^ var46)) {
            var46 = zjhjzbmkidnxhvpf(var46, 1619080167);
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46) == 128869300) {
               var46 = zjhjzbmkidnxhvpf(var46, 2071893687);
               MessagesConfig var31 = MessagesConfig.ONLYPLAYERS;
               var31.send(var1);
               var46 ^= 508056828;
               byte var32 = (byte)(1829192073 ^ var46);
               return (boolean)var32;
            }

            var46 ^= 207454316;
         } else {
            var46 ^= 1233338614;
            Player var11 = (Player)var1;
            var46 ^= 1037718744;
            var46 = zjhjzbmkidnxhvpf(var46, 1857975345);

            try {
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46) != 227168551) {
                  throw null;
               }

               throw new RuntimeException();
            } catch (RuntimeException var49) {
               switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var46)) {
               case -1833008685:
                  var46 = zjhjzbmkidnxhvpf(var46, 984773590);
                  break;
               case -249438072:
                  var46 = zjhjzbmkidnxhvpf(var46, 1455529981);
                  break;
               default:
                  throw new IOException("Error in hash");
               }
            }

            var46 ^= 851864931;
            String var5 = uzhwgzlpho(tuzfxwdxtxrbfat(), rjwxgraeatjaowq(), var46);
            byte var13 = var11.hasPermission(var5);
            if (var13 == (2049166991 ^ var46)) {
               var46 ^= 928069022;
               MessagesConfig var28 = MessagesConfig.NOPERMISSION;
               var28.send(var11);
               var46 ^= 1266651006;
               SoundWrapper var29 = SoundConfig.NOPERMISSION;
               var29.play(var11);
               var46 ^= 1547469555;
               byte var30 = (byte)(1513223836 ^ var46);
               return (boolean)var30;
            }

            label182:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46)) {
               case 134221309:
               default:
                  throw new RuntimeException();
               case 212146710:
                  var46 ^= 1419605392;
                  break label182;
               case 499856170:
                  break;
               case 912966855:
                  break label182;
               }
            }

            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46) != 177316914) {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46)) {
                  case 177316914:
                     var46 ^= 718452913;
                     throw new RuntimeException();
                  case 872228274:
                  case 1548821974:
                  default:
                     throw new RuntimeException();
                  case 1165307182:
                  }
               }
            } else {
               label171:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46)) {
                  case 177316914:
                     var46 ^= 1044050153;
                  case 420611229:
                     break label171;
                  case 1157746844:
                  default:
                     throw new RuntimeException();
                  case 1791444211:
                  }
               }

               byte var14 = MainConfig.SpawnAFK.NEW_DONUT_SPAWN_AFK;
               if (var14 != (277105654 ^ var46)) {
                  var46 ^= 1571801984;
                  DonutCore var16 = this.plugin;
                  SpawnGUI var17 = var16.getSpawnGui$166485211(362522864);
                  byte var6 = (byte)(1294696566 ^ var46);
                  Object[] var42 = new Object[var6];
                  var17.open$967512435(var11, var42, 1892453237);
                  var46 ^= 2146143256;
                  SoundWrapper var18 = SoundConfig.OPENINVENTORY;
                  var18.play(var11);
                  var46 = zjhjzbmkidnxhvpf(var46, 2051789641);

                  try {
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46) != 210716880) {
                        throw null;
                     }

                     throw new IOException();
                  } catch (IOException var47) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var46)) {
                     case -1176312454:
                        var46 = zjhjzbmkidnxhvpf(var46, 1825420825);
                        break;
                     case 1147074874:
                        var46 = zjhjzbmkidnxhvpf(var46, 1937388945);
                        break;
                     default:
                        throw new IllegalAccessException("Error in hash");
                     }
                  }

                  var46 ^= 986156272;
                  break label194;
               }

               label160:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46)) {
                  case 17320:
                     var46 ^= 1856690588;
                     break label160;
                  case 206651412:
                     break;
                  case 375010842:
                  default:
                     throw new RuntimeException();
                  case 1602402320:
                     break label160;
                  }
               }

               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46) != 75122051) {
                  var46 ^= 2051183044;
               } else {
                  label149:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46)) {
                     case 75122051:
                        var46 ^= 1637421143;
                        break label149;
                     case 232838958:
                     default:
                        throw new RuntimeException();
                     case 1474878160:
                        break;
                     case 2103435954:
                        break label149;
                     }
                  }

                  SQLiteManager var21 = this.sqLiteManager;
                  String var35 = uzhwgzlpho(lhrshszagaloljo(), rjwxgraeatjaowq(), var46);
                  Location var22 = var21.getLocation$107949963(var35, 1107835745);
                  var46 ^= 18336222;
                  if (var22 != null) {
                     var46 ^= 789303773;
                     TeleportManager var25 = this.teleportManager;
                     var25.teleportWithCountdown$168586022(var11, var22, 1255099300);
                     var46 = zjhjzbmkidnxhvpf(var46, 2033660216);

                     try {
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46) != 212845511) {
                           throw null;
                        }

                        throw new IllegalAccessException();
                     } catch (IllegalAccessException var48) {
                        switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var46)) {
                        case 85066872:
                           var46 = zjhjzbmkidnxhvpf(var46, 1029502890);
                           break;
                        case 1155881010:
                           var46 ^= 1969364003;
                           break;
                        default:
                           throw new RuntimeException("Error in hash");
                        }
                     }

                     var46 = zjhjzbmkidnxhvpf(var46, 1019793763);
                     break label194;
                  }

                  label138:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46)) {
                     case 190221735:
                        var46 ^= 43014685;
                        break label138;
                     case 254945558:
                     default:
                        throw new RuntimeException();
                     case 563690223:
                        break label138;
                     case 1011310528:
                     }
                  }

                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46) != 110968556) {
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46)) {
                        case 110968556:
                           var46 ^= 408687184;
                           throw new RuntimeException();
                        case 644478304:
                        case 1694661622:
                        default:
                           throw new RuntimeException();
                        case 1450600652:
                        }
                     }
                  } else {
                     label127:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var46)) {
                        case 110968556:
                           var46 ^= 471266913;
                        case 955841444:
                           break label127;
                        case 1661372415:
                           break;
                        case 1673437122:
                        default:
                           throw new RuntimeException();
                        }
                     }

                     MessagesConfig var26 = MessagesConfig.SPAWNNOTSET;
                     var26.send(var11);
                     var46 ^= 1766005083;
                     SoundWrapper var27 = SoundConfig.SPAWNNOTSET;
                     var27.play(var11);
                     var46 ^= 1750308994;
                     break label194;
                  }
               }
            }
         }

         throw new RuntimeException();
      }

      byte var19 = (byte)(20342342 ^ var46);
      return (boolean)var19;
   }

   static {
      nothing_to_see_here[0] = "⢀⡴⠑⡄⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠸⡇⠀⠿⡀⠀⠀⠀⣀⡴⢿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠑⢄⣠⠾⠁⣀⣄⡈⠙⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⢀⡀⠁⠀⠀⠈⠙⠛⠂⠈⣿⣿⣿⣿⣿⠿⡿⢿⣆⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⢀⡾⣁⣀⠀⠴⠂⠙⣗⡀⠀⢻⣿⣿⠭⢤⣴⣦⣤⣹⠀⠀⠀⢀⢴⣶⣆";
      nothing_to_see_here[5] = "⠀⠀⢀⣾⣿⣿⣿⣷⣮⣽⣾⣿⣥⣴⣿⣿⡿⢂⠔⢚⡿⢿⣿⣦⣴⣾⠁⠸⣼⡿";
      nothing_to_see_here[6] = "⠀⢀⡞⠁⠙⠻⠿⠟⠉⠀⠛⢹⣿⣿⣿⣿⣿⣌⢤⣼⣿⣾⣿⡟⠉⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⣾⣷⣶⠇⠀⠀⣤⣄⣀⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠉⠈⠉⠀⠀⢦⡈⢻⣿⣿⣿⣶⣶⣶⣶⣤⣽⡹⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠉⠲⣽⡻⢿⣿⣿⣿⣿⣿⣿⣷⣜⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣷⣶⣮⣭⣽⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⠿⠿⠿⠿⠛⠉              ";
      int var3 = (new Random(-6339243614932408393L)).nextInt();
      l1uBcDuQeF = -1629595592 ^ var3;
   }

   public static String uzhwgzlpho(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] rjwxgraeatjaowq() {
      return new byte[]{11, 57, 50, 106, 27, 88, 57, 13, 86, 23, 53, 48, 50, 108, 55, 8, 70, 65, 4, 66, 106, 28, 81, 85, 74, 120, 111, 115, 38, 35, 118, 77, 56, 47, 86, 45, 119, 74, 77, 77, 88, 109, 99, 60, 97, 103, 109, 121, 26, 76, 56, 32, 27, 109, 30, 113, 57, 14, 12, 13, 68, 89, 113, 45, 105, 86, 15, 75, 44, 117, 7, 83, 75, 102, 106, 72, 60, 92, 13, 25, 96, 89, 5, 45, 93, 78, 39, 122, 2, 5, 29, 64, 19, 127, 36, 1, 117, 38, 4, 34, 27, 126, 72, 31, 101, 51, 53, 26, 25, 63, 27, 14, 24, 35, 85, 106, 110};
   }

   private static byte[] mdvxwlrzvdwsnuf() {
      return new byte[]{-51, -9, 4, 43, 41, 24, 11, 94, 100, 88, 4, 104};
   }

   private static byte[] lnrnesxiyvvwzxd() {
      return new byte[]{-61, -1, 11, 18, 46, 25, 10, 89, 110, 79, 12, 122, 5, 121, 6, 104, 119, 9, 50, 26, 83, 92, 100, 10, 121, 105, 87, 2, 31, 79, 65, 49, 9, 50};
   }

   private static byte[] tuzfxwdxtxrbfat() {
      return new byte[]{-57, -10, 6, 55, 42, 1, 15, 90, 111, 83, 7, 116, 6, 54, 6, 81, 112, 10, 61, 22, 88, 2, 101, 31, 123, 62, 89, 43, 31, 101, 68, 19};
   }

   private static byte[] lhrshszagaloljo() {
      return new byte[]{-64, -11, 0, 40, 41, 24, 8, 94, 99, 85, 6, 108};
   }

   private static int zjhjzbmkidnxhvpf(int var0, int var1) {
      return var0 ^ var1;
   }
}
