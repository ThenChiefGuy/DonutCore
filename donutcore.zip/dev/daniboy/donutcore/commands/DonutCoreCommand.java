package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.ConfigManager;
import dev.daniboy.donutcore.database.SQLiteManager;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class DonutCoreCommand implements CommandExecutor, TabCompleter {
   private final DonutCore plugin;
   private final SQLiteManager sqLiteManager;
   private ConfigManager configManager;
   private static int rYuxbawxxx;
   private transient int xsIhdVWLi8;
   private static String[] nothing_to_see_here = new String[15];

   public DonutCoreCommand(DonutCore var1, SQLiteManager var2, int var3) {
      int var10 = 1397024789 ^ 1696331507;
      super();

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var10)) {
         case 156794242:
            var10 ^= 915211912;
         case 928435282:
            var10 = 1946832049 ^ 1684289668 ^ Integer.parseInt("1745437072") ^ var3;
            this.xsIhdVWLi8 = 356979268 ^ rYuxbawxxx;
            var10 ^= 1696554249;
            var10 ^= 318830217;
            this.plugin = var1;
            var10 ^= 1751322098;
            this.sqLiteManager = var2;
            var10 ^= 532759857;
            return;
         case 524122530:
            break;
         case 1306430521:
         default:
            throw new RuntimeException();
         }
      }
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      int var64 = 1449997339 ^ 1112466673 ^ this.xsIhdVWLi8;
      var64 ^= 389815482;
      byte var16 = var1 instanceof Player;
      if (var16 == (214084882 ^ var64)) {
         var64 ^= 739463154;
         String var50 = agncwsgeku(dhwhcbdcfosjgff(), wlpnfzmsdcifwwk(), var64);
         var1.sendMessage(var50);
         var64 ^= 1636821185;
         byte var44 = (byte)(1096682016 ^ var64);
         return (boolean)var44;
      } else {
         label158:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
            case 146350992:
               var64 ^= 934995142;
            case 1684543777:
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 54080626) {
                  var64 ^= 1970342677;
                  throw new IllegalAccessException();
               }

               var64 = flpwxjwxrozehrlj(var64, 325363274);
               Player var18 = (Player)var1;
               var64 ^= 37093730;
               int var20 = var4.length;
               if (var20 == (707456764 ^ var64)) {
                  var64 ^= 1377167958;
                  String var49 = agncwsgeku(hsqdbvarhgzcptj(), wlpnfzmsdcifwwk(), var64);
                  var18.sendMessage(var49);
                  var64 ^= 1706975330;
                  byte var42 = (byte)(495019209 ^ var64);
                  return (boolean)var42;
               }

               label155:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                  case 28509474:
                     var64 ^= 1731957761;
                  case 929223355:
                     break label155;
                  case 1561426541:
                     break;
                  case 1607569467:
                  default:
                     throw new IllegalAccessException();
                  }
               }

               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 89232219) {
                  var64 = flpwxjwxrozehrlj(var64, 51918908);
                  throw new IllegalAccessException();
               }

               var64 ^= 1699419177;
               byte var6 = (byte)(677015252 ^ var64);
               String var22 = var4[var6];
               var64 ^= 999413579;
               byte var24 = (byte)(-332118432 ^ var64);
               byte var13 = var24;
               int var26 = var22.hashCode();
               int var66 = var26 ^ var64;
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var66)) {
               case 112666037:
                  var64 ^= 1163382333;
                  String var45 = agncwsgeku(cwkxffcukmbirsh(), wlpnfzmsdcifwwk(), var64);
                  byte var28 = var22.equals(var45);
                  if (var28 != (1453094818 ^ var64)) {
                     var64 ^= 1489069512;
                     byte var29 = (byte)(240980587 ^ var64);
                     var13 = var29;
                     var64 ^= 2055950509;
                  } else {
                     label119:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                        case 131035477:
                           var64 ^= 988398319;
                           break label119;
                        case 326779795:
                           break;
                        case 1937003200:
                        default:
                           throw new IllegalAccessException();
                        case 2069525285:
                           break label119;
                        }
                     }

                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 35939120) {
                        var64 = flpwxjwxrozehrlj(var64, 578615180);
                        throw new IllegalAccessException();
                     }

                     var64 = flpwxjwxrozehrlj(var64, 413398922);
                  }
                  break;
               case 155879178:
                  label142:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                     case 106603631:
                        var64 ^= 558729897;
                        break label142;
                     case 612886462:
                     default:
                        throw new IllegalAccessException();
                     case 1277310674:
                        break label142;
                     case 2024159686:
                     }
                  }

                  String var48 = agncwsgeku(nwygrveyleaaovv(), wlpnfzmsdcifwwk(), var64);
                  byte var39 = var22.equals(var48);
                  if (var39 != (847655734 ^ var64)) {
                     var64 ^= 1072859477;
                     byte var40 = (byte)(225753699 ^ var64);
                     var13 = var40;

                     label130:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                        case 168961131:
                           var64 ^= 949024146;
                        case 1339730258:
                           break label130;
                        case 1392755170:
                           break;
                        case 1865897681:
                        default:
                           throw new IllegalAccessException();
                        }
                     }

                     try {
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 141192966) {
                           throw null;
                        }

                        throw new IllegalAccessException();
                     } catch (IllegalAccessException var68) {
                        switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var64)) {
                        case -1356693623:
                           var64 ^= 1441774290;
                           break;
                        case 442888650:
                           var64 = flpwxjwxrozehrlj(var64, 591874842);
                           break;
                        default:
                           throw new IOException("Error in hash");
                        }

                        var64 ^= 350074852;
                     }
                  } else {
                     var64 ^= 1046977519;
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 150289349) {
                        var64 ^= 1122560536;
                        throw new IllegalAccessException();
                     }

                     var64 ^= 2016930334;
                  }
                  break;
               default:
                  var64 ^= 1730018136;
               }

               var66 = var13 ^ var64;
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var66)) {
               case 39802249:
                  var64 ^= 1786405385;
                  DonutCore var51 = this.plugin;
                  HelpMessageCommand var31 = new HelpMessageCommand(var51, 1642548443);
                  var64 ^= 373446145;
                  byte var9 = (byte)(149845711 ^ var64);
                  String[] var59 = new String[var9];
                  var31.onCommand(var18, var2, var3, var59);
                  var64 ^= 912993997;
                  break label158;
               case 39802295:
                  label108:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                     case 39802295:
                        var64 ^= 1706118855;
                        break label108;
                     case 1228575478:
                        break;
                     case 1500856438:
                        break label108;
                     case 1995652577:
                     default:
                        throw new IllegalAccessException();
                     }
                  }

                  DonutCore var54 = this.plugin;
                  ConfigManager var57 = this.configManager;
                  ReloadCommand var35 = new ReloadCommand(var54, var57, 1747689705);
                  var64 ^= 1935390367;
                  byte var60 = (byte)(1648147103 ^ var64);
                  String[] var61 = new String[var60];
                  var35.onCommand(var18, var2, var3, var61);
                  var64 ^= 1142261667;
                  var64 = flpwxjwxrozehrlj(var64, 207717656);

                  try {
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 32296589) {
                        throw null;
                     }

                     throw new IOException();
                  } catch (IOException var67) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var64)) {
                     case 413169491:
                        var64 = flpwxjwxrozehrlj(var64, 1234340823);
                        break;
                     case 1380303137:
                        var64 ^= 13516057;
                        break;
                     default:
                        throw new IllegalAccessException("Error in hash");
                     }
                  }

                  var64 = flpwxjwxrozehrlj(var64, 335797567);
                  break label158;
               default:
                  var64 ^= 1246960325;
                  break label158;
               }
            case 1858210802:
               break;
            case 2029947272:
            default:
               throw new IllegalAccessException();
            }
         }

         byte var34 = (byte)(1048926211 ^ var64);
         return (boolean)var34;
      }
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      int var20 = 1801882252 ^ 862009363 ^ this.xsIhdVWLi8;
      var20 ^= 1884066886;
      int var8 = var4.length;
      byte var6 = (byte)(664160154 ^ var20);
      if (var8 == var6) {
         var20 ^= 1829510542;
         ArrayList var10 = new ArrayList();
         var20 ^= 1649781865;
         String var16 = agncwsgeku(ohslkxyqixemsgd(), wlpnfzmsdcifwwk(), var20);
         var10.add(var16);
         var20 ^= 741598916;
         String var17 = agncwsgeku(fzauzeavazyqgaj(), wlpnfzmsdcifwwk(), var20);
         var10.add(var17);
         var20 ^= 2134427127;
         return var10;
      } else {
         var20 = flpwxjwxrozehrlj(var20, 735058031);
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var20) != 130569646) {
            var20 = flpwxjwxrozehrlj(var20, 872236146);
            throw new IllegalAccessException();
         } else {
            var20 ^= 1347305559;
            Object var9 = null;
            return (List)var9;
         }
      }
   }

   static {
      nothing_to_see_here[0] = "⢀⡴⠑⡄⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠸⡇⠀⠿⡀⠀⠀⠀⣀⡴⢿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠑⢄⣠⠾⠁⣀⣄⡈⠙⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⢀⡀⠁⠀⠀⠈⠙⠛⠂⠈⣿⣿⣿⣿⣿⠿⡿⢿⣆⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⢀⡾⣁⣀⠀⠴⠂⠙⣗⡀⠀⢻⣿⣿⠭⢤⣴⣦⣤⣹⠀⠀⠀⢀⢴⣶⣆";
      nothing_to_see_here[5] = "⠀⠀⢀⣾⣿⣿⣿⣷⣮⣽⣾⣿⣥⣴⣿⣿⡿⢂⠔⢚⡿⢿⣿⣦⣴⣾⠁⠸⣼⡿";
      nothing_to_see_here[6] = "⠀⢀⡞⠁⠙⠻⠿⠟⠉⠀⠛⢹⣿⣿⣿⣿⣿⣌⢤⣼⣿⣾⣿⡟⠉⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⣾⣷⣶⠇⠀⠀⣤⣄⣀⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠉⠈⠉⠀⠀⢦⡈⢻⣿⣿⣿⣶⣶⣶⣶⣤⣽⡹⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠉⠲⣽⡻⢿⣿⣿⣿⣿⣿⣿⣷⣜⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣷⣶⣮⣭⣽⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⠿⠿⠿⠿⠛⠉              ";
      int var3 = (new Random(-4128898925115554093L)).nextInt();
      rYuxbawxxx = 516065100 ^ var3;
   }

   public static String agncwsgeku(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] wlpnfzmsdcifwwk() {
      return new byte[]{53, 103, 82, 67, 20, 67, 17, 5, 76, 59, 37, 61, 57, 114};
   }

   private static byte[] nwygrveyleaaovv() {
      return new byte[]{-13, -84, 101, 7, 33, 19, 38, 90, 120, 108, 17, 107, 15, 35};
   }

   private static byte[] cwkxffcukmbirsh() {
      return new byte[]{-6, -84, 103, 24, 36, 31, 37, 81, 125, 115};
   }

   private static byte[] hsqdbvarhgzcptj() {
      return new byte[]{-7, -88, 99, 33, 39, 9, 36, 92, 116, 110, 23, 104, 8, 127, 6, 126, 103, 84, 44, 21, 35, 90, 125, 98, 22, 113, 12, 62, 13, 54, 96, 28, 37, 6, 34, 89, 121, 35, 29, 51, 11, 33, 4, 63, 97, 23, 33, 22, 41, 86, 126, 101, 20, 110, 10, 117};
   }

   private static byte[] dhwhcbdcfosjgff() {
      return new byte[]{-2, -83, 98, 58, 38, 27, 33, 88, 122, 119, 16, 45, 15, 48, 3, 59, 99, 20, 33, 15, 33, 86, 126, 127, 21, 127, 15, 103, 0, 52, 100, 16, 34, 29, 32, 19, 121, 123, 21, 120, 11, 33, 5, 118, 100, 2, 33, 27, 39, 94, 122, 120, 20, 43, 12, 36, 5, 62, 96, 24, 36, 31, 39, 81, 121, 101, 19, 107, 15, 108};
   }

   private static byte[] ohslkxyqixemsgd() {
      return new byte[]{-3, -96, 102, 6, 37, 17, 39, 80, 126, 98, 29, 104, 14, 39};
   }

   private static byte[] fzauzeavazyqgaj() {
      return new byte[]{-13, -85, 100, 25, 44, 20, 32, 95, 116, 120};
   }

   private static int flpwxjwxrozehrlj(int var0, int var1) {
      return var1 ^ var0;
   }
}
