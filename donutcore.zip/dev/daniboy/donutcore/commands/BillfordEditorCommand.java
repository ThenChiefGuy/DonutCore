package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.gui.impl.billford.BillfordEditorGUI;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BillfordEditorCommand extends Command {
   private final DonutCore plugin;
   private static int VqsT3wXzmr;
   private transient int JbzcLq1MAf;
   private static byte[] cnzwccnwqt;
   private static String[] nothing_to_see_here = new String[15];

   public BillfordEditorCommand(DonutCore var1, int var2) {
      int var16 = 149782887 ^ 336162566;
      String var4 = "billfordeditor";
      super(var4);
      var16 ^= 114826578;
      var16 = 1508992155 ^ 923543723 ^ Integer.parseInt("161481291") ^ var2;
      this.JbzcLq1MAf = 1576946516 ^ VqsT3wXzmr;
      var16 = lcngswekdrjwqabx(var16, 1226521261);
      var16 ^= 1288771005;
      this.plugin = var1;
      var16 ^= 718122193;
      String var12 = "Open the Billford Editor GUI";
      this.setDescription(var12);
      var16 ^= 902738518;
      String var13 = "/billfordeditor";
      this.setUsage(var13);
      var16 ^= 689724764;
      String var14 = "donutcore.billfordeditor";
      this.setPermission(var14);
      var16 ^= 467816967;
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      Player var10;
      int var27;
      label146: {
         var27 = 691720808 ^ 1699595664 ^ this.JbzcLq1MAf;
         var27 ^= 738545619;
         byte var8 = var1 instanceof Player;
         if (var8 != (1826027337 ^ var27)) {
            var27 ^= 1000013140;
            var10 = (Player)var1;
            var27 ^= 395378339;

            label87:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
               case 229399276:
                  var27 ^= 267575271;
                  break label87;
               case 1013146539:
               default:
                  throw new RuntimeException();
               case 1897204520:
                  break;
               case 1916570847:
                  break label87;
               }
            }

            try {
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) != 157891794) {
                  throw null;
               }

               throw new RuntimeException();
            } catch (RuntimeException var28) {
               switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var27)) {
               case 60821922:
                  var27 ^= 780695835;
                  break;
               case 2037471946:
                  var27 = lcngswekdrjwqabx(var27, 567431286);
                  break;
               default:
                  throw new IOException("Error in hash");
               }
            }

            label76:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
               case 118046807:
                  var27 ^= 1856177943;
                  break label76;
               case 268767013:
                  break;
               case 1445287218:
                  break label76;
               case 1795141484:
               default:
                  throw new RuntimeException();
               }
            }

            String var5 = winpqlfonf(ftyexgpkwjcrwpg(), var27);
            byte var12 = var10.hasPermission(var5);
            if (var12 == (6257720 ^ var27)) {
               var27 ^= 1513807511;
               MessagesConfig var17 = MessagesConfig.NOPERMISSION;
               var17.send(var10);
               var27 ^= 769967386;
               byte var18 = (byte)(2004969396 ^ var27);
               return (boolean)var18;
            }

            var27 = lcngswekdrjwqabx(var27, 1842657314);
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) != 71214713) {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
                  case 71214713:
                     var27 ^= 1713551423;
                     throw new RuntimeException();
                  case 293320857:
                     break;
                  case 752069480:
                  case 1963460327:
                  default:
                     throw new RuntimeException();
                  }
               }
            } else {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
                  case 71214713:
                     var27 ^= 1938215808;
                     break label146;
                  case 109071705:
                  default:
                     throw new RuntimeException();
                  case 309835414:
                     break;
                  case 391935275:
                     break label146;
                  }
               }
            }
         } else {
            label112:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
               case 48239563:
                  var27 ^= 1094474824;
                  break label112;
               case 384877706:
               default:
                  throw new RuntimeException();
               case 1322441159:
                  break;
               case 1627305647:
                  break label112;
               }
            }

            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) != 150374075) {
               var27 = lcngswekdrjwqabx(var27, 641980196);
               throw new RuntimeException();
            } else {
               label101:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
                  case 72330652:
                  default:
                     throw new RuntimeException();
                  case 150374075:
                     var27 ^= 1756968709;
                  case 1534626538:
                     break label101;
                  case 1712343021:
                  }
               }
            }
         }

         MessagesConfig var19 = MessagesConfig.ONLYPLAYERS;
         var19.send(var1);
         var27 ^= 764577313;
         byte var20 = (byte)(1757485604 ^ var27);
         return (boolean)var20;
      }

      DonutCore var14 = this.plugin;
      BillfordEditorGUI var15 = var14.getBillfordEditorGui$1275699852(1314871027);
      byte var6 = (byte)(504174490 ^ var27);
      Object[] var24 = new Object[var6];
      var15.open$967512435(var10, var24, 1892453237);
      var27 ^= 1655659777;
      byte var16 = (byte)(2091010714 ^ var27);
      return (boolean)var16;
   }

   static {
      nothing_to_see_here[0] = "⢀⡴⠑⡄⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠸⡇⠀⠿⡀⠀⠀⠀⣀⡴⢿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠑⢄⣠⠾⠁⣀⣄⡈⠙⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⢀⡀⠁⠀⠀⠈⠙⠛⠂⠈⣿⣿⣿⣿⣿⠿⡿⢿⣆⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⢀⡾⣁⣀⠀⠴⠂⠙⣗⡀⠀⢻⣿⣿⠭⢤⣴⣦⣤⣹⠀⠀⠀⢀⢴⣶⣆";
      nothing_to_see_here[5] = "⠀⠀⢀⣾⣿⣿⣿⣷⣮⣽⣾⣿⣥⣴⣿⣿⡿⢂⠔⢚⡿⢿⣿⣦⣴⣾⠁⠸⣼⡿";
      nothing_to_see_here[6] = "⠀⢀⡞⠁⠙⠻⠿⠟⠉⠀⠛⢹⣿⣿⣿⣿⣿⣌⢤⣼⣿⣾⣿⡟⠉⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⣾⣷⣶⠇⠀⠀⣤⣄⣀⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠉⠈⠉⠀⠀⢦⡈⢻⣿⣿⣿⣶⣶⣶⣶⣤⣽⡹⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠉⠲⣽⡻⢿⣿⣿⣿⣿⣿⣿⣷⣜⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣷⣶⣮⣭⣽⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⠿⠿⠿⠿⠛⠉              ";
      cnzwccnwqt = pccvoruszombuio();
      int var3 = (new Random(-2132609649897645452L)).nextInt();
      VqsT3wXzmr = 1980393669 ^ var3;
   }

   public static String winpqlfonf(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = cnzwccnwqt;
         byte[] var34 = cnzwccnwqt;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] pccvoruszombuio() {
      return new byte[]{100, 37, 10, 102, 24, 119, 96, 41, 29, 79, 23, 61, 108, 80, 125, 43, 121, 27, 39, 35, 8, 7, 25, 65, 123, 25, 77, 72, 84, 81, 87, 126, 5, 63, 43, 92, 61, 12, 38, 12, 66, 72, 46, 42, 108, 26, 11, 125, 18, 40, 109, 38, 97, 104, 85, 107, 115, 123, 24, 47, 2, 123, 122, 17, 31, 25, 38, 48, 81, 63, 60, 109, 111, 16, 10, 60, 4, 73, 8, 22, 45, 13, 39, 23, 21, 27, 55};
   }

   private static byte[] ftyexgpkwjcrwpg() {
      return new byte[]{-84, -24, 63, 53, 47, 42, 80, 113, 47, 15, 32, 126, 94, 3, 75, 118, 76, 94, 16, 116, 56, 31, 43, 22, 76, 71, 127, 20, 98, 15, 98, 47, 50, 98, 27, 24, 15, 93, 17, 94, 112, 28, 24, 113, 89, 89, 60, 32, 34, 108};
   }

   private static int lcngswekdrjwqabx(int var0, int var1) {
      return var0 ^ var1;
   }
}
