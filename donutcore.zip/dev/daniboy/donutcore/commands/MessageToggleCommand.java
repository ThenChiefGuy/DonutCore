package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MainConfig;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.config.SoundConfig;
import dev.daniboy.donutcore.config.wrapper.SoundWrapper;
import dev.daniboy.donutcore.database.SQLiteManager;
import dev.daniboy.donutcore.utils.Hex;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MessageToggleCommand extends Command {
   private final DonutCore plugin;
   private final SQLiteManager sqLiteManager;
   private static int sixzIvU4wy;
   private transient int 5Vpu6xQwsB;
   private static byte[] jntngkeaof;
   private static String[] nothing_to_see_here = new String[15];

   public MessageToggleCommand(DonutCore var1, SQLiteManager var2, int var3) {
      int var19 = 1986728248 ^ 1225828149;
      String var5 = "msgtoggle";
      super(var5);
      var19 ^= 798893683;
      var19 = 1609382898 ^ 1310338597 ^ Integer.parseInt("305192820") ^ var3;
      this.5Vpu6xQwsB = 676095140 ^ sixzIvU4wy;
      var19 = nedheesbkpfwdilz(var19, 1852486218);
      var19 ^= 1301025168;
      this.plugin = var1;
      var19 ^= 797111349;
      this.sqLiteManager = var2;
      var19 ^= 1804554720;
      String var15 = "Toggle message reception";
      this.setDescription(var15);
      var19 ^= 1557566614;
      String var16 = "/msgtoggle";
      this.setUsage(var16);
      var19 ^= 959728363;
      String var17 = "donutcore.msgtoggle";
      this.setPermission(var17);
      var19 ^= 526537447;
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      int var44 = 357869224 ^ 1610197711 ^ this.5Vpu6xQwsB;
      var44 ^= 1894450283;
      byte var9 = var1 instanceof Player;
      if (var9 != (207013937 ^ var44)) {
         var44 ^= 1266927019;
         Player var13 = (Player)var1;
         var44 ^= 671991525;

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44)) {
            case 146040222:
               var44 ^= 1271076365;
            case 372585199:
               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44) != 99997975) {
                     throw null;
                  }

                  throw new RuntimeException();
               } catch (RuntimeException var46) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var44)) {
                  case -693319630:
                     var44 ^= 793068831;
                     break;
                  case 551480209:
                     var44 = nedheesbkpfwdilz(var44, 1368064363);
                     break;
                  default:
                     throw new RuntimeException("Error in hash");
                  }

                  label88:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44)) {
                     case 63496160:
                        var44 ^= 2027163312;
                        break label88;
                     case 1068396557:
                     default:
                        throw new RuntimeException();
                     case 1203710009:
                        break label88;
                     case 2044379565:
                     }
                  }

                  String var31 = pultcdtzlr(sobzfkzaimdjnno(), var44);
                  byte var15 = var13.hasPermission(var31);
                  if (var15 == (222614185 ^ var44)) {
                     var44 ^= 155649445;
                     MessagesConfig var16 = MessagesConfig.NOPERMISSION;
                     var16.send(var13);
                     var44 ^= 1026235744;
                     SoundWrapper var17 = SoundConfig.NOPERMISSION;
                     var17.play(var13);
                     var44 ^= 316310831;
                     byte var18 = (byte)(737300290 ^ var44);
                     return (boolean)var18;
                  }

                  var44 = nedheesbkpfwdilz(var44, 1557369816);
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44) == 236281693) {
                     var44 ^= 1209544694;
                     UUID var20 = var13.getUniqueId();
                     var44 ^= 74612442;
                     SQLiteManager var22 = this.sqLiteManager;
                     byte var23 = var22.getMessageToggle$1388376138(var20, 884977015);
                     if (var23 == (503124061 ^ var44)) {
                        var44 ^= 410056239;
                        SQLiteManager var29 = this.sqLiteManager;
                        byte var41 = (byte)(93185651 ^ var44);
                        var29.setMessageToggle$521809991(var20, (boolean)var41, 772013593);
                        var44 ^= 2063173129;
                        String var39 = MainConfig.Chat.MSG_TOGGLE_ON;
                        String var40 = Hex.hex(var39);
                        var13.sendMessage(var40);
                        var44 = nedheesbkpfwdilz(var44, 1148291247);

                        try {
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44) != 39536671) {
                              throw null;
                           }

                           throw new IOException();
                        } catch (IOException var45) {
                           switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var44)) {
                           case -667990367:
                              var44 ^= 81983486;
                              break;
                           case 1969035976:
                              var44 ^= 827112563;
                              break;
                           default:
                              throw new RuntimeException("Error in hash");
                           }
                        }

                        label75:
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44)) {
                           case 191452577:
                           default:
                              throw new RuntimeException();
                           case 198177670:
                              var44 ^= 1377117348;
                              break label75;
                           case 1260015540:
                              break;
                           case 1310989828:
                              break label75;
                           }
                        }
                     } else {
                        var44 = nedheesbkpfwdilz(var44, 1564442009);
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44) != 226030697) {
                           var44 ^= 548243143;
                           throw new RuntimeException();
                        }

                        var44 ^= 709111290;
                        SQLiteManager var25 = this.sqLiteManager;
                        byte var6 = (byte)(1787183166 ^ var44);
                        var25.setMessageToggle$521809991(var20, (boolean)var6, 772013593);
                        var44 ^= 132528937;
                        String var36 = MainConfig.Chat.MSG_TOGGLE_OFF;
                        String var37 = Hex.hex(var36);
                        var13.sendMessage(var37);
                        var44 ^= 9584793;
                     }

                     byte var27 = (byte)(1844591503 ^ var44);
                     return (boolean)var27;
                  }

                  var44 = nedheesbkpfwdilz(var44, 838380146);
                  throw new RuntimeException();
               }
            case 327855189:
            default:
               throw new RuntimeException();
            case 473930034:
            }
         }
      } else {
         var44 = nedheesbkpfwdilz(var44, 1067551998);
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44) != 78587558) {
            var44 = nedheesbkpfwdilz(var44, 1402515404);
            throw new RuntimeException();
         } else {
            label116:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44)) {
               case 78587558:
                  var44 ^= 1231865537;
               case 232267390:
                  break label116;
               case 798627349:
               default:
                  throw new RuntimeException();
               case 1164504738:
               }
            }
         }
      }

      MessagesConfig var10 = MessagesConfig.ONLYPLAYERS;
      var10.send(var1);
      var44 ^= 1714841808;
      byte var11 = (byte)(481159903 ^ var44);
      return (boolean)var11;
   }

   static {
      nothing_to_see_here[0] = "⢀⡴⠑⡄⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠸⡇⠀⠿⡀⠀⠀⠀⣀⡴⢿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠑⢄⣠⠾⠁⣀⣄⡈⠙⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⢀⡀⠁⠀⠀⠈⠙⠛⠂⠈⣿⣿⣿⣿⣿⠿⡿⢿⣆⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⢀⡾⣁⣀⠀⠴⠂⠙⣗⡀⠀⢻⣿⣿⠭⢤⣴⣦⣤⣹⠀⠀⠀⢀⢴⣶⣆";
      nothing_to_see_here[5] = "⠀⠀⢀⣾⣿⣿⣿⣷⣮⣽⣾⣿⣥⣴⣿⣿⡿⢂⠔⢚⡿⢿⣿⣦⣴⣾⠁⠸⣼⡿";
      nothing_to_see_here[6] = "⠀⢀⡞⠁⠙⠻⠿⠟⠉⠀⠛⢹⣿⣿⣿⣿⣿⣌⢤⣼⣿⣾⣿⡟⠉⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⣾⣷⣶⠇⠀⠀⣤⣄⣀⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠉⠈⠉⠀⠀⢦⡈⢻⣿⣿⣿⣶⣶⣶⣶⣤⣽⡹⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠉⠲⣽⡻⢿⣿⣿⣿⣿⣿⣿⣷⣜⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣷⣶⣮⣭⣽⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⠿⠿⠿⠿⠛⠉              ";
      jntngkeaof = jopgjyudbyqffly();
      int var3 = (new Random(7602220647211447496L)).nextInt();
      sixzIvU4wy = -1309406411 ^ var3;
   }

   public static String pultcdtzlr(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = jntngkeaof;
         byte[] var34 = jntngkeaof;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] jopgjyudbyqffly() {
      return new byte[]{66, 13, 122, 1, 110, 64, 18, 31, 41, 103, 25, 66, 63, 41, 60, 47, 102, 60, 100, 67, 79, 7, 78, 126, 61, 65, 118, 75, 119, 33, 65, 114, 72, 56, 81, 25, 62, 59, 1, 99, 112, 56, 126, 103, 48, 13, 127, 114, 84, 21, 80, 15, 10, 24, 50, 17, 123, 74};
   }

   private static byte[] sobzfkzaimdjnno() {
      return new byte[]{-114, -64, 72, 83, 95, 27, 35, 73, 28, 32, 43, 4, 9, 123, 8, 113, 94, 123, 86, 20, 125, 31, 127, 39, 12, 10, 67, 30, 69, 103, 119, 44, 124, 110, 105, 75, 12, 101, 51, 48};
   }

   private static int nedheesbkpfwdilz(int var0, int var1) {
      return var0 ^ var1;
   }
}
