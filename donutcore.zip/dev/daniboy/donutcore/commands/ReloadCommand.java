package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.ConfigManager;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.config.SoundConfig;
import dev.daniboy.donutcore.config.wrapper.SoundWrapper;
import dev.daniboy.donutcore.gui.impl.HelpGUI;
import dev.daniboy.donutcore.gui.impl.MediaGUI;
import dev.daniboy.donutcore.gui.impl.SpawnGUI;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ReloadCommand implements CommandExecutor {
   private final DonutCore plugin;
   private final MediaGUI mediaGui;
   private final HelpGUI helpGui;
   private final ConfigManager configManager;
   private final SpawnGUI spawnGui;
   private static int hVUdwXn4MS;
   private transient int ZF63kjl4R5;
   private static String[] nothing_to_see_here = new String[15];

   public ReloadCommand(DonutCore var1, ConfigManager var2, int var3) {
      int var21 = 625864336 ^ 1849375335;
      super();
      var21 = bserlnpapxokhyoi(var21, 1512703871);
      var21 = 42037089 ^ 1880123517 ^ Integer.parseInt("199652477") ^ var3;
      this.ZF63kjl4R5 = 277825525 ^ hVUdwXn4MS;
      var21 ^= 1963891613;
      var21 ^= 949476304;
      this.plugin = var1;
      var21 ^= 51002912;
      MediaGUI var13 = var1.getMediaGui$275199606(1384060441);
      this.mediaGui = var13;
      var21 ^= 936067920;
      HelpGUI var15 = var1.getHelpGui$1055651724(1578111927);
      this.helpGui = var15;
      var21 ^= 330938875;
      SpawnGUI var17 = var1.getSpawnGui$166485211(362522864);
      this.spawnGui = var17;
      var21 ^= 1702409459;
      ConfigManager var19;
      if (var2 != null) {
         var21 ^= 1814416041;
         var19 = var2;
         var21 ^= 1703541458;
      } else {
         label21:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var21)) {
            case 195000315:
               var21 ^= 167870741;
            case 1273639038:
               var19 = new ConfigManager(var1);
               var21 ^= 61714798;
               break label21;
            case 1116777582:
            default:
               throw new IOException();
            case 1209109653:
            }
         }
      }

      this.configManager = var19;
      var21 ^= 1382863854;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      int var31 = 757737747 ^ 891134278 ^ this.ZF63kjl4R5;
      var31 ^= 1414516681;
      byte var8 = var1 instanceof Player;
      if (var8 != (888562537 ^ var31)) {
         var31 ^= 1414644191;
         Player var10 = (Player)var1;
         var31 ^= 713545138;
         String var6 = kvbvgzqczq(anizgyzhxjonrct(), pxpkkafpbngodxy(), var31);
         byte var12 = var10.hasPermission(var6);
         if (var12 == (1243641604 ^ var31)) {
            var31 ^= 2121220540;
            MessagesConfig var13 = MessagesConfig.NOPERMISSION;
            var13.send(var1);
            var31 ^= 1614467460;
            SoundWrapper var14 = SoundConfig.NOPERMISSION;
            var14.play(var10);
            var31 ^= 1886275653;
            byte var15 = (byte)(605794168 ^ var31);
            return (boolean)var15;
         }

         label44:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var31)) {
            case 168644611:
               break;
            case 262057143:
               var31 ^= 1649378501;
               break label44;
            case 653265779:
            default:
               throw new IOException();
            case 1233879761:
               break label44;
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var31) != 240697386) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var31)) {
               case 240697386:
                  var31 ^= 1612514588;
                  throw new IOException();
               case 854475216:
               case 1989462568:
               default:
                  throw new IOException();
               case 1831024560:
               }
            }
         }

         var31 ^= 1242149541;
      } else {
         label69:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var31)) {
            case 42796475:
               break label69;
            case 110974061:
               var31 ^= 103840043;
               break label69;
            case 690707919:
               break;
            case 1527671843:
            default:
               throw new IOException();
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var31) != 39837721) {
            var31 ^= 2058677407;
            throw new IOException();
         } else {
            label58:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var31)) {
               case 39837721:
                  var31 ^= 1352686374;
                  break label58;
               case 253053473:
               default:
                  throw new IOException();
               case 336248170:
                  break;
               case 1638520872:
                  break label58;
               }
            }
         }
      }

      ConfigManager var17 = this.configManager;
      var17.reload();
      var31 ^= 1510281033;
      MediaGUI var19 = this.mediaGui;
      var19.loadMediaConfigValues$2120577358(54860659);
      var31 ^= 1088394609;
      HelpGUI var21 = this.helpGui;
      var21.loadHelpConfigValues$1430792781(839749214);
      var31 ^= 622759571;
      SpawnGUI var23 = this.spawnGui;
      var23.loadSpawnConfigValues$882403349(870176311);
      var31 ^= 1726596374;
      MessagesConfig var24 = MessagesConfig.RELOAD;
      var24.send(var1);
      var31 ^= 1288870684;
      byte var25 = (byte)(2006518724 ^ var31);
      return (boolean)var25;
   }

   static {
      nothing_to_see_here[0] = " ⠁⡼⠋⠀⣆⠀⠀⣰⣿⣫⣾⢿⣿⣿⠍⢠⠠⠀⠀⢀⠰⢾⣺⣻⣿⣿⣿⣷⡀⠀";
      nothing_to_see_here[1] = "⣥⠀⠀⠀⠁⠀⠠⢻⢬⠁⣠⣾⠛⠁⠀⠀⠀⠀⠀⠀⠀⠐⠱⠏⡉⠙⣿⣿⡇⠀";
      nothing_to_see_here[2] = "⢳⠀⢰⡖⠀⠀⠈⠀⣺⢰⣿⢻⣾⣶⣿⣿⣶⣶⣤⣤⣴⣾⣿⣷⣼⡆⢸⣿⣧⠀";
      nothing_to_see_here[3] = "⠈⠀⠜⠈⣀⣔⣦⢨⣿⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣅⣼⠛⢹⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⢋⡿⡿⣯⣭⡟⣟⣿⣿⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⡘⠀";
      nothing_to_see_here[5] = "⡀⠐⠀⠀⠀⣿⣯⡿⣿⣿⣿⣯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣉⢽⣿⡆⠀⠀";
      nothing_to_see_here[6] = "⢳⠀⠄⠀⢀⣿⣿⣿⣿⣿⣿⣿⠙⠉⠉⠉⠛⣻⢛⣿⠛⠃⠀⠐⠛⠻⣿⡇⠀⠀";
      nothing_to_see_here[7] = "⣾⠄⠀⠀⢸⣿⣿⡿⠟⠛⠁⢀⠀⢀⡄⣀⣠⣾⣿⣿⡠⣴⣎⣀⣠⣠⣿⡇⠀⠀";
      nothing_to_see_here[8] = "⣧⠀⣴⣄⣽⣿⣿⣿⣶⣶⣖⣶⣬⣾⣿⣾⣿⣿⣿⣿⣽⣿⣿⣿⣿⣿⣿⡇⠀⠀";
      nothing_to_see_here[9] = "⣿⣶⣈⡯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣹⢧⣿⣿⣿⣄⠙⢿⣿⣿⣿⠇⠀⠀";
      nothing_to_see_here[10] = "⠹⣿⣿⣧⢌⢽⣻⢿⣯⣿⣿⣿⣿⠟⣠⡘⠿⠟⠛⠛⠟⠛⣧⡈⠻⣾⣿⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠈⠉⣷⡿⣽⠶⡾⢿⣿⣿⣿⢃⣤⣿⣷⣤⣤⣄⣄⣠⣼⡿⢷⢀⣿⡏⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⢀⣿⣷⠌⣈⣏⣝⠽⡿⣷⣾⣏⣀⣉⣉⣀⣀⣀⣠⣠⣄⡸⣾⣿⠃⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⣰⡿⣿⣧⡐⠄⠱⣿⣺⣽⢟⣿⣿⢿⣿⣍⠉⢀⣀⣐⣼⣯⡗⠟⡏⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⣰⣿⠀⣿⣿⣴⡀⠂⠘⢹⣭⡂⡚⠿⢿⣿⣿⣿⡿⢿⢿⡿⠿⢁⣴⣿⣷⣶⣦⣤";
      int var3 = (new Random(5741867631813970348L)).nextInt();
      hVUdwXn4MS = -1751466900 ^ var3;
   }

   public static String kvbvgzqczq(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] pxpkkafpbngodxy() {
      return new byte[]{105, 82, 107, 80, 69, 84, 30, 118, 8, 48, 26, 10, 7, 93, 80, 101, 80, 29, 98, 53, 89, 124, 27, 29, 18, 89, 122, 6, 24, 11, 89, 100, 71, 99, 67, 90, 27, 113, 79, 76, 77, 41, 50, 75, 103, 22, 114, 43, 64, 6, 38, 77, 58, 85, 7, 119, 121, 84, 63, 55, 25, 127, 101, 46, 112, 96, 65, 111, 46, 63, 102, 43, 26, 12, 126, 126, 71, 117, 70, 120, 78, 116, 37, 32, 95, 16, 84, 99, 95, 89, 121};
   }

   private static byte[] anizgyzhxjonrct() {
      return new byte[]{-90, -97, 95, 7, 115, 15, 47, 46, 56, 113, 43, 76, 51, 13, 102, 62, 97, 89, 82, 100, 104, 96, 47, 92, 36, 8, 75, 92, 40, 80, 104, 55, 115, 52};
   }

   private static int bserlnpapxokhyoi(int var0, int var1) {
      return var1 ^ var0;
   }
}
