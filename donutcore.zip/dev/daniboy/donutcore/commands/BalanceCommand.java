package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.utils.ActionBar;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BalanceCommand extends Command {
   private final Economy economy;
   private static int LRnAqyVjUV;
   private transient int 1yWT0WZyZd;
   private static byte[] rvffapfrho;
   private static String[] nothing_to_see_here = new String[19];

   public BalanceCommand(Economy var1, int var2) {
      int var16 = 1718329288 ^ 1243295377;
      String var4 = "balance";
      super(var4);
      var16 = olvcapfwpubyxtfx(var16, 1865442424);
      var16 = 1234936523 ^ 739352416 ^ Integer.parseInt("322241494") ^ var2;
      this.1yWT0WZyZd = 1146345759 ^ LRnAqyVjUV;
      var16 ^= 1846534731;
      var16 ^= 1299958038;
      this.economy = var1;
      var16 ^= 2065870634;
      String var12 = "Check the balance of a player";
      this.setDescription(var12);
      var16 ^= 1166747492;
      String var13 = "/balance <player>";
      this.setUsage(var13);
      var16 ^= 367921814;
      String var14 = "donutcore.balance";
      this.setPermission(var14);
      var16 ^= 207106740;
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      int var60 = 1336922962 ^ 1048525788 ^ this.1yWT0WZyZd;
      var60 ^= 996133016;
      byte var15 = var1 instanceof Player;
      if (var15 == (488206648 ^ var60)) {
         var60 ^= 1239542475;
         MessagesConfig var39 = MessagesConfig.ONLYPLAYERS;
         var39.send(var1);
         var60 ^= 1601481551;
         byte var40 = (byte)(193736893 ^ var60);
         return (boolean)var40;
      } else {
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var60)) {
            case 140596805:
               var60 ^= 1139620833;
            case 955379124:
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var60) != 133763056) {
                  var60 = olvcapfwpubyxtfx(var60, 800412114);
               } else {
                  var60 ^= 1483385649;
                  Player var17 = (Player)var1;
                  var60 ^= 225184762;
                  int var19 = var3.length;
                  byte var5 = (byte)(200469011 ^ var60);
                  if (var19 != var5) {
                     var60 ^= 1344266581;
                     String var41 = fummlvunih(wosblvrltgpkljn(), var60);
                     var1.sendMessage(var41);
                     var60 ^= 709184094;
                     byte var21 = (byte)(1906852121 ^ var60);
                     return (boolean)var21;
                  }

                  var60 ^= 748063513;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var60) != 206723937) {
                     var60 ^= 1445296640;
                  } else {
                     var60 ^= 936891472;
                     byte var42 = (byte)(280212827 ^ var60);
                     String var23 = var3[var42];
                     Player var24 = Bukkit.getPlayer(var23);
                     var60 ^= 1635674880;
                     if (var24 == null) {
                        var60 ^= 1597109192;
                        MessagesConfig var50 = MessagesConfig.PLAYERNOTFOUND;
                        String var51 = var50.getSingleMessage();
                        var1.sendMessage(var51);
                        var60 ^= 1563469627;
                        byte var38 = (byte)(1942784681 ^ var60);
                        return (boolean)var38;
                     }

                     var60 = olvcapfwpubyxtfx(var60, 1952316409);
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var60) == 87500503) {
                        var60 = olvcapfwpubyxtfx(var60, 833786073);
                        Economy var27 = this.economy;
                        double var28 = var27.getBalance(var24);
                        var60 ^= 1985902475;
                        String var31 = this.formatBalance$614937173(var28, 1530229980);
                        var60 ^= 560705668;
                        MessagesConfig var32 = MessagesConfig.BALANCEMESSAGE;
                        String var33 = var32.getSingleMessage();
                        var60 ^= 1295353750;
                        String var54 = var24.getName();
                        String var47 = this.formatMessage$1947399162(var33, var54, var31, 2113777724);
                        var1.sendMessage(var47);
                        var60 ^= 1895190034;
                        String var56 = var24.getName();
                        String var49 = this.formatMessage$1947399162(var33, var56, var31, 2113777724);
                        ActionBar.sendActionBar(var17, var49);
                        var60 ^= 2130855553;
                        byte var36 = (byte)(567737712 ^ var60);
                        return (boolean)var36;
                     }

                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var60)) {
                        case 34499330:
                        case 350952648:
                        default:
                           throw new IllegalAccessException();
                        case 87500503:
                           var60 ^= 1959870121;
                           throw new IllegalAccessException();
                        case 863438719:
                        }
                     }
                  }
               }

               throw new IllegalAccessException();
            case 846357062:
            default:
               throw new IllegalAccessException();
            case 1469895535:
            }
         }
      }
   }

   private String formatBalance$614937173(double var1, int var3) {
      int var63 = 202816988 ^ 747010853 ^ this.1yWT0WZyZd ^ var3;
      var63 ^= 1998266959;
      double var7 = 1.0E9D;
      double var64;
      int var14 = (var64 = var1 - var7) == 0.0D ? 0 : (var64 < 0.0D ? -1 : 1);
      if (var14 >= (1529397572 ^ var63)) {
         var63 ^= 1132162762;
         String var15 = fummlvunih(mbqvenewyiyyttt(), var63);
         byte var6 = (byte)(408137615 ^ var63);
         Object[] var29 = new Object[var6];
         byte var9 = (byte)(408137614 ^ var63);
         double var12 = 1.0E9D;
         double var43 = var1 / var12;
         Double var45 = var43;
         var29[var9] = var45;
         String var16 = String.format(var15, var29);
         return var16;
      } else {
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var63)) {
            case 10399067:
               var63 ^= 17389703;
            case 1679764488:
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var63) != 245449672) {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var63)) {
                     case 245449672:
                        var63 ^= 1769828832;
                        throw new RuntimeException();
                     case 897215751:
                        break;
                     case 978379396:
                     case 1754746173:
                     default:
                        throw new RuntimeException();
                     }
                  }
               } else {
                  var63 ^= 865557515;
                  double var36 = 1000000.0D;
                  double var65;
                  int var19 = (var65 = var1 - var36) == 0.0D ? 0 : (var65 < 0.0D ? -1 : 1);
                  if (var19 >= (1773585864 ^ var63)) {
                     var63 ^= 115642373;
                     String var27 = fummlvunih(odjsiarrrrnhoyg(), var63);
                     byte var34 = (byte)(1867666892 ^ var63);
                     Object[] var35 = new Object[var34];
                     byte var42 = (byte)(1867666893 ^ var63);
                     double var61 = 1000000.0D;
                     double var56 = var1 / var61;
                     Double var58 = var56;
                     var35[var42] = var58;
                     String var28 = String.format(var27, var35);
                     return var28;
                  }

                  var63 = olvcapfwpubyxtfx(var63, 1718258975);
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var63) != 247120636) {
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var63)) {
                        case 148286614:
                        case 623630809:
                        default:
                           throw new RuntimeException();
                        case 247120636:
                           var63 ^= 1015062772;
                           throw new RuntimeException();
                        case 2098413316:
                        }
                     }
                  } else {
                     var63 ^= 1337950559;
                     double var38 = 1000.0D;
                     double var66;
                     int var22 = (var66 = var1 - var38) == 0.0D ? 0 : (var66 < 0.0D ? -1 : 1);
                     if (var22 >= (1080281480 ^ var63)) {
                        var63 ^= 1302630764;
                        String var25 = fummlvunih(tvapqlllrwybubu(), var63);
                        byte var32 = (byte)(231168229 ^ var63);
                        Object[] var33 = new Object[var32];
                        byte var41 = (byte)(231168228 ^ var63);
                        double var59 = 1000.0D;
                        double var51 = var1 / var59;
                        Double var53 = var51;
                        var33[var41] = var53;
                        String var26 = String.format(var25, var33);
                        return var26;
                     }

                     var63 ^= 899745085;
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var63) == 69802332) {
                        var63 = olvcapfwpubyxtfx(var63, 1043729267);
                        String var23 = fummlvunih(hftnvpnbkezzvpj(), var63);
                        byte var30 = (byte)(1274333127 ^ var63);
                        Object[] var31 = new Object[var30];
                        byte var40 = (byte)(1274333126 ^ var63);
                        Double var48 = var1;
                        var31[var40] = var48;
                        String var24 = String.format(var23, var31);
                        return var24;
                     }

                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var63)) {
                        case 69802332:
                           var63 ^= 1184769174;
                           throw new RuntimeException();
                        case 748229288:
                        case 1286016978:
                        default:
                           throw new RuntimeException();
                        case 1928419908:
                        }
                     }
                  }
               }
            case 491381153:
               break;
            case 1782662275:
            default:
               throw new RuntimeException();
            }
         }
      }
   }

   private String formatMessage$1947399162(String var1, String var2, String var3, int var4) {
      int var13 = 2066801112 ^ 559736188 ^ this.1yWT0WZyZd ^ var4;
      var13 ^= 1972786917;
      String var6 = fummlvunih(ykbtwztnaslfaoy(), var13);
      String var8 = var1.replace(var6, var2);
      String var10 = fummlvunih(gydbnyqaofmsoqh(), var13);
      String var9 = var8.replace(var10, var3);
      return var9;
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣤⣤⣤⣤⣤⣶⣦⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⡿⠛⠉⠙⠛⠛⠛⠛⠻⢿⣿⣷⣤⡀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠋⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⠈⢻⣿⣿⡄⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⠀⠀⠀⣸⣿⡏⠀⠀⠀⣠⣶⣾⣿⣿⣿⠿⠿⠿⢿⣿⣿⣿⣄⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠁⠀⠀⢰⣿⣿⣯⠁⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣷⡄⠀";
      nothing_to_see_here[5] = "⠀⠀⣀⣤⣴⣶⣶⣿⡟⠀⠀⠀⢸⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣷⠀";
      nothing_to_see_here[6] = "⠀⢰⣿⡟⠋⠉⣹⣿⡇⠀⠀⠀⠘⣿⣿⣿⣿⣷⣦⣤⣤⣤⣶⣶⣶⣶⣿⣿⣿⠀";
      nothing_to_see_here[7] = "⠀⢸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠀";
      nothing_to_see_here[8] = "⠀⣸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠉⠻⠿⣿⣿⣿⣿⡿⠿⠿⠛⢻⣿⡇⠀⠀";
      nothing_to_see_here[9] = "⠀⣿⣿⠁⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣧⠀⠀";
      nothing_to_see_here[10] = "⠀⣿⣿⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀";
      nothing_to_see_here[11] = "⠀⣿⣿⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀";
      nothing_to_see_here[12] = "⠀⢿⣿⡆⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⠀";
      nothing_to_see_here[13] = "⠀⠸⣿⣧⡀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠃⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠛⢿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⣰⣿⣿⣷⣶⣶⣶⣶⠶⠀⢠⣿⣿⠀⠀⠀";
      nothing_to_see_here[15] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⣽⣿⡏⠁⠀⠀⢸⣿⡇⠀⠀⠀";
      nothing_to_see_here[16] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⢹⣿⡆⠀⠀⠀⣸⣿⠇⠀⠀⠀";
      nothing_to_see_here[17] = "⠀⠀⠀⠀⠀⠀⠀⢿⣿⣦⣄⣀⣠⣴⣿⣿⠁⠀⠈⠻⣿⣿⣿⣿⡿⠏⠀⠀⠀⠀";
      nothing_to_see_here[18] = "⠀⠀⠀⠀⠀⠀⠀⠈⠛⠻⠿⠿⠿⠿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      rvffapfrho = lrrqygvgmjhiqsz();
      int var3 = (new Random(1804143439860755769L)).nextInt();
      LRnAqyVjUV = 1949755301 ^ var3;
   }

   public static String fummlvunih(byte[] var0, int var1) {
      String var10 = Integer.toString(var1);
      byte[] var11 = var10.getBytes();
      byte[] var8 = var11;
      byte var12 = 0;
      int var9 = var12;

      while(true) {
         int var17 = var0.length;
         if (var9 >= var17) {
            Charset var5 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var5);
            return var14;
         }

         byte var20 = var0[var9];
         int var33 = var8.length;
         int var30 = var9 % var33;
         byte var27 = var8[var30];
         int var21 = var20 ^ var27;
         byte var22 = (byte)var21;
         var0[var9] = var22;
         byte var23 = var0[var9];
         byte[] var28 = rvffapfrho;
         byte[] var34 = rvffapfrho;
         int var35 = var34.length;
         int var32 = var9 % var35;
         byte var29 = var28[var32];
         int var24 = var23 ^ var29;
         byte var25 = (byte)var24;
         var0[var9] = var25;
         ++var9;
      }
   }

   private static byte[] lrrqygvgmjhiqsz() {
      return new byte[]{20, 44, 112, 77, 75, 77, 55, 30, 45, 17, 80, 69, 64, 106, 36, 48, 79, 53, 47, 33, 95, 33, 14, 71, 2, 75, 115, 64, 87, 16, 101, 114, 39, 14, 42, 33, 103, 32, 33, 72, 8, 18, 71, 126, 2, 112, 51, 29, 51, 40, 49, 16, 40, 43, 52, 21, 116, 43, 53, 114, 71, 9, 112, 65, 97, 121, 85, 90, 83, 85, 86, 58, 41};
   }

   private static byte[] wosblvrltgpkljn() {
      return new byte[]{-37, -26, 68, 42, 121, 8, 6, 74, 26, 67, 97, 21, 116, 98, 22, 38, 126, 47, 24, 118, 110, 117, 58, 25, 48, 28, 66, 27, 96, 70, 84, 34, 19, 28, 24, 43, 86, 101, 22, 17, 57, 70, 115, 53, 48, 35, 2, 90, 4, 35};
   }

   private static byte[] hftnvpnbkezzvpj() {
      return new byte[]{-37, -31, 71, 92, 120, 80, 4, 29, 31, 65};
   }

   private static byte[] tvapqlllrwybubu() {
      return new byte[]{-40, -32, 65, 89, 125, 91, 5, 30, 21, 69, 99, 63};
   }

   private static byte[] odjsiarrrrnhoyg() {
      return new byte[]{-37, -21, 70, 95, 125, 85, 1, 20, 20, 68, 97, 48};
   }

   private static byte[] mbqvenewyiyyttt() {
      return new byte[]{-34, -29, 72, 89, 120, 84, 1, 29, 25, 67, 96, 63};
   }

   private static byte[] ykbtwztnaslfaoy() {
      return new byte[]{-45, -32, 68, 91, 127, 10, 7, 69, 20, 67, 100, 15, 116, 56, 20, 117, 118, 35};
   }

   private static byte[] gydbnyqaofmsoqh() {
      return new byte[]{-45, -32, 68, 91, 127, 27, 7, 68, 20, 77, 100, 3, 116, 51, 20, 115, 118, 35};
   }

   private static int olvcapfwpubyxtfx(int var0, int var1) {
      return var0 ^ var1;
   }
}
