package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.gui.impl.billford.BillfordGUI;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BillfordCommand extends Command {
   private final DonutCore plugin;
   private static int 5liV6tQhdQ;
   private transient int K26xNxo0rI;
   private static byte[] nqdbqpysaz;
   private static String[] nothing_to_see_here = new String[15];

   public BillfordCommand(DonutCore var1, int var2) {
      int var16 = 1814338139 ^ 1832070460;
      String var4 = "billford";
      super(var4);
      var16 = kitaapaqzagcgnuv(var16, 685772661);
      var16 = 2110249711 ^ 975619068 ^ Integer.parseInt("1152841384") ^ var2;
      this.K26xNxo0rI = 1262177015 ^ 5liV6tQhdQ;

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var16)) {
         case 22011221:
            var16 ^= 1396603896;
         case 2012500140:
            var16 ^= 181505738;
            this.plugin = var1;
            var16 ^= 1534253531;
            String var12 = "Open the Billford GUI";
            this.setDescription(var12);
            var16 ^= 539697870;
            String var13 = "/billford";
            this.setUsage(var13);
            var16 ^= 1375829439;
            String var14 = "donutcore.billford";
            this.setPermission(var14);
            var16 ^= 1111741009;
            return;
         case 1080686430:
            break;
         case 1841393666:
         default:
            throw new IllegalAccessException();
         }
      }
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      int var27 = 679523239 ^ 342455510 ^ this.K26xNxo0rI;
      var27 ^= 1313572758;
      byte var8 = var1 instanceof Player;
      if (var8 != (253910723 ^ var27)) {
         var27 ^= 1444515860;
         Player var12 = (Player)var1;
         var27 ^= 1310613848;
         var27 = kitaapaqzagcgnuv(var27, 64870241);

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) != 144801461) {
               throw null;
            }

            throw new IllegalAccessException();
         } catch (IllegalAccessException var28) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var27)) {
            case -1480341648:
               var27 = kitaapaqzagcgnuv(var27, 482855611);
               break;
            case 1780440761:
               var27 ^= 628906370;
               break;
            default:
               throw new IllegalAccessException("Error in hash");
            }

            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
               case 129744656:
                  var27 ^= 1156602557;
               case 23885380:
                  String var21 = ijpzkrhkqi(vlfyowtagexcyts(), var27);
                  byte var14 = var12.hasPermission(var21);
                  if (var14 == (1288693992 ^ var27)) {
                     var27 ^= 1491264539;
                     MessagesConfig var19 = MessagesConfig.NOPERMISSION;
                     var19.send(var12);
                     var27 ^= 780859908;
                     byte var20 = (byte)(984086262 ^ var27);
                     return (boolean)var20;
                  }

                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
                     case 80912270:
                        var27 ^= 743305819;
                     case 223325421:
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) == 184316728) {
                           var27 = kitaapaqzagcgnuv(var27, 627503543);
                           DonutCore var16 = this.plugin;
                           BillfordGUI var17 = var16.getBillfordGui$981559054(348678287);
                           byte var6 = (byte)(1172630276 ^ var27);
                           Object[] var24 = new Object[var6];
                           var17.open$967512435(var12, var24, 1892453237);
                           var27 ^= 705796290;
                           byte var18 = (byte)(1878356935 ^ var27);
                           return (boolean)var18;
                        }

                        var27 ^= 1460204493;
                        throw new IOException();
                     case 180670982:
                     default:
                        throw new IOException();
                     case 2040077043:
                     }
                  }
               case 374326722:
                  break;
               case 1772701778:
               default:
                  throw new IOException();
               }
            }
         }
      } else {
         label91:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
            case 223516859:
               var27 ^= 133810323;
               break label91;
            case 799753561:
               break;
            case 895122891:
               break label91;
            case 1120880597:
            default:
               throw new IOException();
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) != 19495904) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
               case 19495904:
                  var27 ^= 1062305582;
                  throw new IOException();
               case 47925121:
               case 1905057664:
               default:
                  throw new IOException();
               case 471807888:
               }
            }
         } else {
            label81:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
               case 19495904:
                  var27 ^= 886791954;
               case 1034059551:
                  break label81;
               case 1516987402:
               default:
                  throw new IOException();
               case 1682096208:
               }
            }
         }
      }

      MessagesConfig var9 = MessagesConfig.ONLYPLAYERS;
      var9.send(var1);
      var27 ^= 1265601267;
      byte var10 = (byte)(2003780528 ^ var27);
      return (boolean)var10;
   }

   static {
      nothing_to_see_here[0] = "⠄⠄⠄⢰⣧⣼⣯⠄⣸⣠⣶⣶⣦⣾⠄⠄⠄⠄⡀⠄⢀⣿⣿⠄⠄⠄⢸⡇⠄⠄";
      nothing_to_see_here[1] = "⠄⠄⠄⣾⣿⠿⠿⠶⠿⢿⣿⣿⣿⣿⣦⣤⣄⢀⡅⢠⣾⣛⡉⠄⠄⠄⠸⢀⣿⠄";
      nothing_to_see_here[2] = "⠄⠄⢀⡋⣡⣴⣶⣶⡀⠄⠄⠙⢿⣿⣿⣿⣿⣿⣴⣿⣿⣿⢃⣤⣄⣀⣥⣿⣿⠄";
      nothing_to_see_here[3] = "⠄⠄⢸⣇⠻⣿⣿⣿⣧⣀⢀⣠⡌⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿⣿⣿⣿⠄";
      nothing_to_see_here[4] = "⠄⢀⢸⣿⣷⣤⣤⣤⣬⣙⣛⢿⣿⣿⣿⣿⣿⣿⡿⣿⣿⡍⠄⠄⢀⣤⣄⠉⠋⣰";
      nothing_to_see_here[5] = "⠄⣼⣖⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⢇⣿⣿⡷⠶⠶⢿⣿⣿⠇⢀⣤";
      nothing_to_see_here[6] = "⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣽⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣷⣶⣥⣴⣿⡗";
      nothing_to_see_here[7] = "⢀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠄";
      nothing_to_see_here[8] = "⢸⣿⣦⣌⣛⣻⣿⣿⣧⠙⠛⠛⡭⠅⠒⠦⠭⣭⡻⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠄";
      nothing_to_see_here[9] = "⠘⣿⣿⣿⣿⣿⣿⣿⣿⡆⠄⠄⠄⠄⠄⠄⠄⠄⠹⠈⢋⣽⣿⣿⣿⣿⣵⣾⠃⠄";
      nothing_to_see_here[10] = "⠄⠘⣿⣿⣿⣿⣿⣿⣿⣿⠄⣴⣿⣶⣄⠄⣴⣶⠄⢀⣾⣿⣿⣿⣿⣿⣿⠃⠄⠄";
      nothing_to_see_here[11] = "⠄⠄⠈⠻⣿⣿⣿⣿⣿⣿⡄⢻⣿⣿⣿⠄⣿⣿⡀⣾⣿⣿⣿⣿⣛⠛⠁⠄⠄⠄";
      nothing_to_see_here[12] = "⠄⠄⠄⠄⠈⠛⢿⣿⣿⣿⠁⠞⢿⣿⣿⡄⢿⣿⡇⣸⣿⣿⠿⠛⠁⠄⠄⠄⠄⠄";
      nothing_to_see_here[13] = "⠄⠄⠄⠄⠄⠄⠄⠉⠻⣿⣿⣾⣦⡙⠻⣷⣾⣿⠃⠿⠋⠁⠄⠄⠄⠄⠄⢀⣠⣴";
      nothing_to_see_here[14] = "⣿⣿⣿⣶⣶⣮⣥⣒⠲⢮⣝⡿⣿⣿⡆⣿⡿⠃⠄⠄⠄⠄⠄⠄⠄⣠⣴⣿⣿⣿";
      nqdbqpysaz = tdpvrracawfbgmu();
      int var3 = (new Random(5324818054288008021L)).nextInt();
      5liV6tQhdQ = 1728826330 ^ var3;
   }

   public static String ijpzkrhkqi(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = nqdbqpysaz;
         byte[] var34 = nqdbqpysaz;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] tdpvrracawfbgmu() {
      return new byte[]{56, 110, 121, 23, 12, 57, 121, 9, 86, 120, 4, 2, 122, 95, 77, 7, 97, 73};
   }

   private static byte[] vlfyowtagexcyts() {
      return new byte[]{-9, -93, 65, 75, 58, 111, 74, 94, 111, 63, 53, 68, 66, 4, 123, 81, 82, 2, 1, 57, 72, 11, 52, 99, 79, 89, 101, 45, 61, 92, 75, 11, 117, 80, 87, 2, 11, 51};
   }

   private static int kitaapaqzagcgnuv(int var0, int var1) {
      return var1 ^ var0;
   }
}
