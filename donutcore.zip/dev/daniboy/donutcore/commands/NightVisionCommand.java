package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.config.SoundConfig;
import dev.daniboy.donutcore.config.wrapper.SoundWrapper;
import dev.daniboy.donutcore.utils.Hex;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class NightVisionCommand extends Command {
   private final DonutCore plugin;
   private static int Zi3DnHoDaK;
   private transient int eZbe9Fy4AK;
   private static String xamjwglydp;
   private static String[] nothing_to_see_here = new String[15];

   public NightVisionCommand(DonutCore var1, int var2) {
      int var16 = 1351234343 ^ 395846628;
      String var4 = "nightvision";
      super(var4);
      var16 = ztvggdxyidsgztyi(var16, 433302722);
      var16 = 108923268 ^ 330498352 ^ Integer.parseInt("1748599925") ^ var2;
      this.eZbe9Fy4AK = 642422450 ^ Zi3DnHoDaK;

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var16)) {
         case 127337088:
            var16 ^= 349396576;
         case 1120140037:
            var16 ^= 741922038;
            this.plugin = var1;
            var16 ^= 885157980;
            String var12 = "Toggle night vision";
            this.setDescription(var12);
            var16 ^= 1135183864;
            String var13 = "/nightvision";
            this.setUsage(var13);
            var16 ^= 545130002;
            String var14 = "donutcore.nightvision";
            this.setPermission(var14);
            var16 ^= 1507223049;
            return;
         case 254475638:
            break;
         case 1849021542:
         default:
            throw new IllegalAccessException();
         }
      }
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      int var42 = 812433103 ^ 443312749 ^ this.eZbe9Fy4AK;
      var42 ^= 1066070351;
      byte var12 = var1 instanceof Player;
      if (var12 != (1712268658 ^ var42)) {
         var42 ^= 1103396027;
         Player var16 = (Player)var1;
         var42 ^= 1003053036;
         var42 = ztvggdxyidsgztyi(var42, 1705335144);

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var42) != 196358402) {
               throw null;
            } else {
               throw new IOException();
            }
         } catch (IOException var44) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var42)) {
            case -851772821:
               var42 ^= 181240717;
               break;
            case 1873504464:
               var42 = ztvggdxyidsgztyi(var42, 2124394970);
               break;
            default:
               throw new RuntimeException("Error in hash");
            }

            var42 ^= 963478237;
            String var30 = vmhsubgvoz(nzapelthhoaspad(), var42);
            byte var18 = var16.hasPermission(var30);
            if (var18 == (1241996829 ^ var42)) {
               var42 ^= 1663227161;
               MessagesConfig var19 = MessagesConfig.NOPERMISSION;
               var19.send(var16);
               var42 ^= 53746207;
               SoundWrapper var20 = SoundConfig.NOPERMISSION;
               var20.play(var16);
               var42 ^= 486744409;
               byte var21 = (byte)(923971651 ^ var42);
               return (boolean)var21;
            } else {
               label128:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var42)) {
                  case 258870367:
                     var42 ^= 639773114;
                     break label128;
                  case 1050272991:
                  default:
                     throw new IOException();
                  case 1837325150:
                     break;
                  case 2071909702:
                     break label128;
                  }
               }

               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var42) != 25754614) {
                  var42 = ztvggdxyidsgztyi(var42, 1487863951);
                  throw new IOException();
               } else {
                  label117:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var42)) {
                     case 25754614:
                        var42 ^= 1771520943;
                        break label117;
                     case 856327690:
                     default:
                        throw new IOException();
                     case 1258628518:
                        break label117;
                     case 2080833764:
                     }
                  }

                  PotionEffectType var33 = PotionEffectType.NIGHT_VISION;
                  byte var23 = var16.hasPotionEffect(var33);
                  if (var23 != (95564808 ^ var42)) {
                     var42 ^= 1649048967;
                     PotionEffectType var34 = PotionEffectType.NIGHT_VISION;
                     var16.removePotionEffect(var34);
                     var42 ^= 1320052790;
                     String var35 = vmhsubgvoz(nebyzdiyscghopt(), var42);
                     String var36 = Hex.hex(var35);
                     var16.sendMessage(var36);

                     label104:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var42)) {
                        case 1492992:
                           var42 ^= 1794976816;
                           break label104;
                        case 1177492176:
                           break;
                        case 1283513877:
                           break label104;
                        case 1298208088:
                        default:
                           throw new IOException();
                        }
                     }

                     try {
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var42) != 52111762) {
                           throw null;
                        }

                        throw new IllegalAccessException();
                     } catch (IllegalAccessException var43) {
                        switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var42)) {
                        case -1511292496:
                           var42 ^= 1227731283;
                           break;
                        case 492334154:
                           var42 ^= 507235564;
                           break;
                        default:
                           throw new RuntimeException("Error in hash");
                        }
                     }

                     label94:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var42)) {
                        case 88615715:
                           var42 ^= 172348147;
                        case 668611931:
                           break label94;
                        case 1701155911:
                           break;
                        case 1979905469:
                        default:
                           throw new IOException();
                        }
                     }
                  } else {
                     label84:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var42)) {
                        case 89593205:
                           var42 ^= 755935850;
                           break label84;
                        case 552607096:
                        default:
                           throw new IOException();
                        case 1528395144:
                           break label84;
                        case 1676570664:
                        }
                     }

                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var42) != 250436193) {
                        var42 ^= 473360714;
                        throw new IOException();
                     }

                     var42 ^= 170306470;
                     PotionEffectType var6 = PotionEffectType.NIGHT_VISION;
                     int var7 = 1566951995 ^ var42;
                     byte var8 = (byte)(580531653 ^ var42);
                     byte var9 = (byte)(580531652 ^ var42);
                     byte var10 = (byte)(580531652 ^ var42);
                     PotionEffect var37 = new PotionEffect(var6, var7, var8, (boolean)var9, (boolean)var10);
                     var16.addPotionEffect(var37);
                     var42 ^= 1680328025;
                     String var38 = vmhsubgvoz(bvzflphcxkizejd(), var42);
                     String var39 = Hex.hex(var38);
                     var16.sendMessage(var39);
                     var42 ^= 292086539;
                  }

                  byte var26 = (byte)(1473581975 ^ var42);
                  return (boolean)var26;
               }
            }
         }
      } else {
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var42)) {
            case 96288387:
               var42 ^= 1944507789;
            case 593541282:
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var42) == 175462151) {
                  var42 ^= 1295158197;
                  MessagesConfig var13 = MessagesConfig.ONLYPLAYERS;
                  var13.send(var1);
                  var42 ^= 780509764;
                  byte var14 = (byte)(1985927439 ^ var42);
                  return (boolean)var14;
               }

               var42 = ztvggdxyidsgztyi(var42, 560170967);
               throw new IOException();
            case 1167382927:
            default:
               throw new IOException();
            case 2059898409:
            }
         }
      }
   }

   static {
      nothing_to_see_here[0] = " ⠁⡼⠋⠀⣆⠀⠀⣰⣿⣫⣾⢿⣿⣿⠍⢠⠠⠀⠀⢀⠰⢾⣺⣻⣿⣿⣿⣷⡀⠀";
      nothing_to_see_here[1] = "⣥⠀⠀⠀⠁⠀⠠⢻⢬⠁⣠⣾⠛⠁⠀⠀⠀⠀⠀⠀⠀⠐⠱⠏⡉⠙⣿⣿⡇⠀";
      nothing_to_see_here[2] = "⢳⠀⢰⡖⠀⠀⠈⠀⣺⢰⣿⢻⣾⣶⣿⣿⣶⣶⣤⣤⣴⣾⣿⣷⣼⡆⢸⣿⣧⠀";
      nothing_to_see_here[3] = "⠈⠀⠜⠈⣀⣔⣦⢨⣿⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣅⣼⠛⢹⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⢋⡿⡿⣯⣭⡟⣟⣿⣿⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⡘⠀";
      nothing_to_see_here[5] = "⡀⠐⠀⠀⠀⣿⣯⡿⣿⣿⣿⣯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣉⢽⣿⡆⠀⠀";
      nothing_to_see_here[6] = "⢳⠀⠄⠀⢀⣿⣿⣿⣿⣿⣿⣿⠙⠉⠉⠉⠛⣻⢛⣿⠛⠃⠀⠐⠛⠻⣿⡇⠀⠀";
      nothing_to_see_here[7] = "⣾⠄⠀⠀⢸⣿⣿⡿⠟⠛⠁⢀⠀⢀⡄⣀⣠⣾⣿⣿⡠⣴⣎⣀⣠⣠⣿⡇⠀⠀";
      nothing_to_see_here[8] = "⣧⠀⣴⣄⣽⣿⣿⣿⣶⣶⣖⣶⣬⣾⣿⣾⣿⣿⣿⣿⣽⣿⣿⣿⣿⣿⣿⡇⠀⠀";
      nothing_to_see_here[9] = "⣿⣶⣈⡯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣹⢧⣿⣿⣿⣄⠙⢿⣿⣿⣿⠇⠀⠀";
      nothing_to_see_here[10] = "⠹⣿⣿⣧⢌⢽⣻⢿⣯⣿⣿⣿⣿⠟⣠⡘⠿⠟⠛⠛⠟⠛⣧⡈⠻⣾⣿⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠈⠉⣷⡿⣽⠶⡾⢿⣿⣿⣿⢃⣤⣿⣷⣤⣤⣄⣄⣠⣼⡿⢷⢀⣿⡏⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⢀⣿⣷⠌⣈⣏⣝⠽⡿⣷⣾⣏⣀⣉⣉⣀⣀⣀⣠⣠⣄⡸⣾⣿⠃⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⣰⡿⣿⣧⡐⠄⠱⣿⣺⣽⢟⣿⣿⢿⣿⣍⠉⢀⣀⣐⣼⣯⡗⠟⡏⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⣰⣿⠀⣿⣿⣴⡀⠂⠘⢹⣭⡂⡚⠿⢿⣿⣿⣿⡿⢿⢿⡿⠿⢁⣴⣿⣷⣶⣦⣤";
      xamjwglydp = ByteBuffer.wrap(oumlinrtkjxnpkp()).asCharBuffer().toString();
      int var3 = (new Random(1421430891845034427L)).nextInt();
      Zi3DnHoDaK = -201624399 ^ var3;
   }

   public static String vmhsubgvoz(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = xamjwglydp;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var89 = StandardCharsets.UTF_16BE;
            String var34 = new String(var11, var89);
            return var34;
         }

         byte var86 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var91 = var8[var92];
         int var87 = var86 ^ var91;
         byte var88 = (byte)var87;
         var11[var12] = var88;
         ++var12;
      }
   }

   private static byte[] nzapelthhoaspad() {
      return new byte[]{0, 0, 0, 21, 0, 0, 0, 0};
   }

   private static byte[] bvzflphcxkizejd() {
      return new byte[]{0, 0, 0, 32, 0, 0, 0, 21};
   }

   private static byte[] nebyzdiyscghopt() {
      return new byte[]{0, 0, 0, 33, 0, 0, 0, 53};
   }

   private static byte[] oumlinrtkjxnpkp() {
      return new byte[]{49, 86, 52, 94, 57, 87, 54, 77, 50, 77, 49, 81, 52, 94, 57, 75, 54, 93, 50, 23, 49, 92, 52, 88, 57, 94, 54, 80, 50, 77, 49, 68, 52, 88, 57, 74, 54, 81, 50, 86, 49, 92, 49, 23, 56, 87, 56, 123, 51, 89, 50, 86, 49, 89, 56, 66, 56, 21, 51, 102, 50, 88, 49, 66, 56, 95, 56, 90, 51, 94, 50, 17, 49, 89, 56, 87, 56, 70, 51, 16, 50, 83, 49, 84, 56, 83, 56, 91, 51, 16, 50, 84, 49, 95, 56, 87, 56, 87, 51, 92, 50, 84, 49, 85, 56, 24, 54, 31, 51, 86, 49, 126, 53, 81, 53, 81, 57, 91, 53, 69, 48, 21, 56, 99, 54, 80, 51, 70, 49, 89, 53, 87, 53, 88, 57, 19, 53, 89, 48, 84, 56, 70, 54, 25, 51, 87, 49, 85, 53, 93, 53, 88, 57, 19, 53, 85, 48, 92, 56, 70, 54, 88, 51, 87, 49, 92, 53, 93, 53, 82, 57, 29};
   }

   private static int ztvggdxyidsgztyi(int var0, int var1) {
      return var0 ^ var1;
   }
}
