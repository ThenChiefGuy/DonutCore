package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.gui.impl.MediaGUI;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MediaCommand extends Command {
   private final DonutCore plugin;
   private static int nRdiFPm2Dg;
   private transient int G8XrM5llzT;
   private static byte[] rlemyjqxpe;
   private static String[] nothing_to_see_here = new String[13];

   public MediaCommand(DonutCore var1, int var2) {
      int var14 = 892087251 ^ 510224132;
      String var4 = "media";
      super(var4);
      var14 ^= 819671344;
      var14 = 784153895 ^ 876939901 ^ Integer.parseInt("1404340641") ^ var2;
      this.G8XrM5llzT = 830489049 ^ nRdiFPm2Dg;
      var14 = xhehbeympemgjion(var14, 486094212);
      var14 ^= 1173323691;
      this.plugin = var1;
      var14 ^= 75637070;
      String var11 = "Open the Media GUI";
      this.setDescription(var11);
      var14 ^= 1037997651;
      String var12 = "/media";
      this.setUsage(var12);
      var14 ^= 309365123;
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      int var27 = 296406691 ^ 475649196 ^ this.G8XrM5llzT;
      var27 ^= 285408629;
      byte var8 = var1 instanceof Player;
      if (var8 != (1765890340 ^ var27)) {
         var27 ^= 1547637914;
         Player var10 = (Player)var1;
         var27 ^= 2135741334;

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
            case 139112413:
               break;
            case 222644202:
            default:
               throw new IOException();
            case 264394847:
               var27 ^= 1596312608;
            case 2094276488:
               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) != 148716536) {
                     throw null;
                  }

                  throw new IllegalAccessException();
               } catch (IllegalAccessException var28) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var27)) {
                  case -1464168384:
                     var27 = xhehbeympemgjion(var27, 549467149);
                     break;
                  case -288556751:
                     var27 ^= 135199011;
                     break;
                  default:
                     throw new IllegalAccessException("Error in hash");
                  }
               }

               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
                  case 139550846:
                     var27 ^= 1371911313;
                  case 1741243009:
                     String var5 = svekrmdcol(qgqkyrvdxmtejag(), var27);
                     byte var12 = var10.hasPermission(var5);
                     if (var12 == (1678955156 ^ var27)) {
                        var27 ^= 1202283591;
                        MessagesConfig var17 = MessagesConfig.NOPERMISSION;
                        var17.send(var10);
                        var27 ^= 1263228571;
                        byte var18 = (byte)(1760616521 ^ var27);
                        return (boolean)var18;
                     }

                     var27 = xhehbeympemgjion(var27, 83746658);
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) == 198134755) {
                        var27 = xhehbeympemgjion(var27, 589727146);
                        DonutCore var14 = this.plugin;
                        MediaGUI var15 = var14.getMediaGui$275199606(1384060441);
                        byte var6 = (byte)(1137281116 ^ var27);
                        Object[] var24 = new Object[var6];
                        var15.open$967512435(var10, var24, 1892453237);
                        var27 ^= 1525081754;
                        byte var16 = (byte)(422538951 ^ var27);
                        return (boolean)var16;
                     }

                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
                        case 198134755:
                           var27 ^= 94688475;
                           throw new IOException();
                        case 954656358:
                        case 1821097350:
                        default:
                           throw new IOException();
                        case 1753884311:
                        }
                     }
                  case 625918006:
                  default:
                     throw new IOException();
                  case 1319367626:
                  }
               }
            }
         }
      } else {
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
            case 200209908:
               var27 ^= 1975773136;
            case 2072431701:
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) == 121458042) {
                  var27 = xhehbeympemgjion(var27, 113020477);
                  MessagesConfig var19 = MessagesConfig.ONLYPLAYERS;
                  var19.send(var1);
                  var27 ^= 1901266771;
                  byte var20 = (byte)(1802319771 ^ var27);
                  return (boolean)var20;
               }

               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
                  case 121458042:
                     var27 ^= 2043242457;
                     throw new IOException();
                  case 668624090:
                  case 1814841983:
                  default:
                     throw new IOException();
                  case 1807603546:
                  }
               }
            case 486628782:
               break;
            case 2058462809:
            default:
               throw new IOException();
            }
         }
      }
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⣠⣶⡾⠏⠉⠙⠳⢦⡀⠀⠀⠀⢠⠞⠉⠙⠲⡀⠀    ";
      nothing_to_see_here[2] = "⠀⠀⠀⣴⠿⠏⠀⠀⠀⠀⠀⠀⢳⡀⠀⡏⠀⠀⠀⠀⠀⢷     ";
      nothing_to_see_here[3] = "⠀⠀⢠⣟⣋⡀⢀⣀⣀⡀⠀⣀⡀⣧⠀⢸⠀⠀⠀⠀⠀ ⡇    ";
      nothing_to_see_here[4] = "⠀⠀⢸⣯⡭⠁⠸⣛⣟⠆⡴⣻⡲⣿⠀⣸⠀⠀OK⠀ ⡇    ";
      nothing_to_see_here[5] = "⠀⠀⣟⣿⡭⠀⠀⠀⠀⠀⢱⠀⠀⣿⠀⢹⠀⠀⠀⠀⠀ ⡇    ";
      nothing_to_see_here[6] = "⠀⠀⠙⢿⣯⠄⠀⠀⠀⢀⡀⠀⠀⡿⠀⠀⡇⠀⠀⠀⠀⡼     ";
      nothing_to_see_here[7] = "⠀⠀⠀⠀⠹⣶⠆⠀⠀⠀⠀⠀⡴⠃⠀⠀⠘⠤⣄⣠⠞⠀     ";
      nothing_to_see_here[8] = "⠀⠀⠀⠀⠀⢸⣷⡦⢤⡤⢤⣞⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[9] = "⠀⠀⢀⣤⣴⣿⣏⠁⠀⠀⠸⣏⢯⣷⣖⣦⡀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[10] = "⢀⣾⣽⣿⣿⣿⣿⠛⢲⣶⣾⢉⡷⣿⣿⠵⣿⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[11] = "⣼⣿⠍⠉⣿⡭⠉⠙⢺⣇⣼⡏⠀⠀⠀⣄⢸⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[12] = "⣿⣿⣧⣀⣿.........⣀⣰⣏⣘⣆⣀⠀⠀       ";
      rlemyjqxpe = dxetlshcqgegifc();
      int var3 = (new Random(-7153320106692676110L)).nextInt();
      nRdiFPm2Dg = 1268912628 ^ var3;
   }

   public static String svekrmdcol(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = rlemyjqxpe;
         byte[] var34 = rlemyjqxpe;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] dxetlshcqgegifc() {
      return new byte[]{43, 114, 5};
   }

   private static byte[] qgqkyrvdxmtejag() {
      return new byte[]{-28, -69, 50, 119, 75, 95, 30, 45, 48, 104, 67, 71, 28, 41, 60, 113, 71, 70, 30, 33, 52, 51, 69, 80, 18, 34, 48, 126, 71, 90, 26, 37};
   }

   private static int xhehbeympemgjion(int var0, int var1) {
      return var1 ^ var0;
   }
}
