package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.config.SoundConfig;
import dev.daniboy.donutcore.config.wrapper.SoundWrapper;
import dev.daniboy.donutcore.database.SQLiteManager;
import dev.daniboy.donutcore.gui.impl.AfkGUI;
import dev.daniboy.donutcore.manager.TeleportManager;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AfkCommand extends Command {
   private final DonutCore plugin;
   private final SQLiteManager sqLiteManager;
   private final TeleportManager teleportManager;
   private static int Xi600Rqq5w;
   private transient int CYwzStdIfC;
   private static String[] nothing_to_see_here = new String[15];

   public AfkCommand(DonutCore var1, SQLiteManager var2, TeleportManager var3, int var4) {
      int var22 = 1759414736 ^ 1464641126;
      String var6 = "afk";
      super(var6);
      var22 ^= 1889467557;
      var22 = 1606565355 ^ 895529024 ^ Integer.parseInt("1068484638") ^ var4;
      this.CYwzStdIfC = 1777976989 ^ Xi600Rqq5w;

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var22)) {
         case 153655288:
            var22 ^= 1069135653;
         case 1595755470:
            var22 ^= 1627362519;
            this.plugin = var1;
            var22 ^= 103101041;
            this.sqLiteManager = var2;
            var22 ^= 953320546;
            this.teleportManager = var3;
            var22 ^= 635618283;
            String var18 = "Open the AFK GUI";
            this.setDescription(var18);
            var22 ^= 643533752;
            String var19 = "donutcore.afk";
            this.setPermission(var19);
            var22 ^= 1144479394;
            String var20 = "/afk";
            this.setUsage(var20);
            var22 ^= 2067386408;
            return;
         case 801484882:
            break;
         case 1998336211:
         default:
            throw new IOException();
         }
      }
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      int var31 = 128531189 ^ 258019647 ^ this.CYwzStdIfC;
      var31 ^= 175234757;
      byte var8 = var1 instanceof Player;
      if (var8 != (1680969410 ^ var31)) {
         var31 ^= 803802353;
         Player var12 = (Player)var1;
         var31 ^= 1307902811;
         var31 = syexomzmgognwfze(var31, 234774867);

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var31) != 116033953) {
               throw null;
            } else {
               throw new IllegalAccessException();
            }
         } catch (IllegalAccessException var32) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var31)) {
            case 38385529:
               var31 = syexomzmgognwfze(var31, 1577624758);
               break;
            case 1587479000:
               var31 ^= 1972531810;
               break;
            default:
               throw new IOException("Error in hash");
            }

            var31 = syexomzmgognwfze(var31, 2008760231);
            String var23 = dgapekqzqz(qmjosuunvhmekwi(), hfqjgyanxjfsmcz(), var31);
            byte var14 = var12.hasPermission(var23);
            if (var14 == (167423486 ^ var31)) {
               var31 ^= 2045584528;
               MessagesConfig var15 = MessagesConfig.NOPERMISSION;
               var15.send(var12);
               var31 ^= 1655141719;
               SoundWrapper var16 = SoundConfig.NOPERMISSION;
               var16.play(var12);
               var31 ^= 1921047994;
               byte var17 = (byte)(1613767042 ^ var31);
               return (boolean)var17;
            } else {
               var31 ^= 313211255;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var31) == 82711704) {
                  var31 ^= 1526608732;
                  DonutCore var19 = this.plugin;
                  AfkGUI var20 = var19.getAfkGui$1831569283(259577790);
                  byte var6 = (byte)(1102030805 ^ var31);
                  Object[] var28 = new Object[var6];
                  var20.open$967512435(var12, var28, 1892453237);
                  var31 ^= 1614985874;
                  SoundWrapper var21 = SoundConfig.OPENINVENTORY;
                  var21.play(var12);
                  var31 ^= 1177552434;
                  byte var22 = (byte)(1742543732 ^ var31);
                  return (boolean)var22;
               } else {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var31)) {
                     case 82711704:
                        var31 ^= 186719963;
                        throw new IllegalAccessException();
                     case 184336047:
                     case 1872311451:
                     default:
                        throw new IllegalAccessException();
                     case 1912284341:
                     }
                  }
               }
            }
         }
      } else {
         label72:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var31)) {
            case 35676326:
               var31 ^= 272129802;
            case 845379790:
               break label72;
            case 1012632521:
               break;
            case 1272517964:
            default:
               throw new IllegalAccessException();
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var31) != 13857402) {
            var31 = syexomzmgognwfze(var31, 1685674906);
            throw new IllegalAccessException();
         } else {
            label61:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var31)) {
               case 13857402:
                  var31 ^= 885801901;
                  break label61;
               case 255969587:
               default:
                  throw new IllegalAccessException();
               case 1026302168:
                  break label61;
               case 2085622481:
               }
            }

            MessagesConfig var9 = MessagesConfig.ONLYPLAYERS;
            var9.send(var1);
            var31 ^= 938677798;
            byte var10 = (byte)(2000061506 ^ var31);
            return (boolean)var10;
         }
      }
   }

   static {
      nothing_to_see_here[0] = " ⠁⡼⠋⠀⣆⠀⠀⣰⣿⣫⣾⢿⣿⣿⠍⢠⠠⠀⠀⢀⠰⢾⣺⣻⣿⣿⣿⣷⡀⠀";
      nothing_to_see_here[1] = "⣥⠀⠀⠀⠁⠀⠠⢻⢬⠁⣠⣾⠛⠁⠀⠀⠀⠀⠀⠀⠀⠐⠱⠏⡉⠙⣿⣿⡇⠀";
      nothing_to_see_here[2] = "⢳⠀⢰⡖⠀⠀⠈⠀⣺⢰⣿⢻⣾⣶⣿⣿⣶⣶⣤⣤⣴⣾⣿⣷⣼⡆⢸⣿⣧⠀";
      nothing_to_see_here[3] = "⠈⠀⠜⠈⣀⣔⣦⢨⣿⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣅⣼⠛⢹⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⢋⡿⡿⣯⣭⡟⣟⣿⣿⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⡘⠀";
      nothing_to_see_here[5] = "⡀⠐⠀⠀⠀⣿⣯⡿⣿⣿⣿⣯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣉⢽⣿⡆⠀⠀";
      nothing_to_see_here[6] = "⢳⠀⠄⠀⢀⣿⣿⣿⣿⣿⣿⣿⠙⠉⠉⠉⠛⣻⢛⣿⠛⠃⠀⠐⠛⠻⣿⡇⠀⠀";
      nothing_to_see_here[7] = "⣾⠄⠀⠀⢸⣿⣿⡿⠟⠛⠁⢀⠀⢀⡄⣀⣠⣾⣿⣿⡠⣴⣎⣀⣠⣠⣿⡇⠀⠀";
      nothing_to_see_here[8] = "⣧⠀⣴⣄⣽⣿⣿⣿⣶⣶⣖⣶⣬⣾⣿⣾⣿⣿⣿⣿⣽⣿⣿⣿⣿⣿⣿⡇⠀⠀";
      nothing_to_see_here[9] = "⣿⣶⣈⡯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣹⢧⣿⣿⣿⣄⠙⢿⣿⣿⣿⠇⠀⠀";
      nothing_to_see_here[10] = "⠹⣿⣿⣧⢌⢽⣻⢿⣯⣿⣿⣿⣿⠟⣠⡘⠿⠟⠛⠛⠟⠛⣧⡈⠻⣾⣿⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠈⠉⣷⡿⣽⠶⡾⢿⣿⣿⣿⢃⣤⣿⣷⣤⣤⣄⣄⣠⣼⡿⢷⢀⣿⡏⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⢀⣿⣷⠌⣈⣏⣝⠽⡿⣷⣾⣏⣀⣉⣉⣀⣀⣀⣠⣠⣄⡸⣾⣿⠃⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⣰⡿⣿⣧⡐⠄⠱⣿⣺⣽⢟⣿⣿⢿⣿⣍⠉⢀⣀⣐⣼⣯⡗⠟⡏⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⣰⣿⠀⣿⣿⣴⡀⠂⠘⢹⣭⡂⡚⠿⢿⣿⣿⣿⡿⢿⢿⡿⠿⢁⣴⣿⣷⣶⣦⣤";
      int var3 = (new Random(1620924212545175114L)).nextInt();
      Xi600Rqq5w = 520421761 ^ var3;
   }

   public static String dgapekqzqz(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] hfqjgyanxjfsmcz() {
      return new byte[]{120, 59, 123, 108, 17, 4, 23, 112, 54, 41, 96, 116, 3, 86, 64, 70, 82, 57, 74, 33};
   }

   private static byte[] qmjosuunvhmekwi() {
      return new byte[]{-73, -14, 76, 60, 35, 88, 35, 38, 0, 109, 86, 55, 55, 7, 115, 29, 106, 125, 123, 114, 79, 33, 73, 62, 37, 90, 33, 42};
   }

   private static int syexomzmgognwfze(int var0, int var1) {
      return var0 ^ var1;
   }
}
