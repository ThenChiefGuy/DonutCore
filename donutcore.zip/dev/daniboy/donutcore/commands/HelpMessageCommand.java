package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MessagesConfig;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HelpMessageCommand implements CommandExecutor {
   private final DonutCore plugin;
   private static int mkEmrqoO0O;
   private transient int Wb4mam2gc4;
   private static String wajsecajoq;
   private static String[] nothing_to_see_here = new String[15];

   public HelpMessageCommand(DonutCore var1, int var2) {
      int var7 = 567907324 ^ 561350087;
      super();
      var7 ^= 1417547959;
      var7 = 1210684464 ^ 122627661 ^ Integer.parseInt("2052323370") ^ var2;
      this.Wb4mam2gc4 = 1834209170 ^ mkEmrqoO0O;

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var7)) {
         case 72792189:
            var7 ^= 1026996638;
         case 162779836:
            var7 ^= 330950742;
            this.plugin = var1;
            var7 ^= 1762282558;
            return;
         case 269220561:
            break;
         case 1479107372:
         default:
            throw new IOException();
         }
      }
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      int var100 = 766012620 ^ 405885141 ^ this.Wb4mam2gc4;
      var100 ^= 293866650;
      byte var10 = var1 instanceof Player;
      if (var10 == (1908401637 ^ var100)) {
         var100 ^= 2064351278;
         MessagesConfig var28 = MessagesConfig.ONLYPLAYERS;
         var28.send(var1);
         var100 ^= 1813141722;
         byte var29 = (byte)(1722170640 ^ var100);
         return (boolean)var29;
      } else {
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var100)) {
            case 207862996:
               var100 ^= 1949222831;
            case 1640542051:
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var100) == 87561652) {
                  var100 ^= 1165340631;
                  Player var12 = (Player)var1;
                  var100 ^= 1085994422;
                  ChatColor var6 = ChatColor.GOLD;
                  String var30 = String.valueOf(var6);
                  ChatColor var7 = ChatColor.GREEN;
                  String var72 = String.valueOf(var7);
                  ChatColor var8 = ChatColor.GOLD;
                  String var97 = String.valueOf(var8);
                  String var31 = var30 + "======= " + var72 + "DonutCore Help" + var97 + " =======";
                  var12.sendMessage(var31);
                  var100 ^= 447116658;
                  ChatColor var32 = ChatColor.AQUA;
                  String var33 = String.valueOf(var32);
                  ChatColor var73 = ChatColor.WHITE;
                  String var74 = String.valueOf(var73);
                  String var34 = var33 + "/donutcore reload" + var74 + " - Reloads the plugin configuration.";
                  var12.sendMessage(var34);
                  var100 ^= 220863438;
                  ChatColor var35 = ChatColor.AQUA;
                  String var36 = String.valueOf(var35);
                  ChatColor var75 = ChatColor.WHITE;
                  String var76 = String.valueOf(var75);
                  String var37 = var36 + "/donutcore help" + var76 + " - Displays this help message.";
                  var12.sendMessage(var37);
                  var100 ^= 876275498;
                  ChatColor var38 = ChatColor.AQUA;
                  String var39 = String.valueOf(var38);
                  ChatColor var77 = ChatColor.WHITE;
                  String var78 = String.valueOf(var77);
                  String var40 = var39 + "/setspawn" + var78 + " - Sets the spawn location.";
                  var12.sendMessage(var40);
                  var100 ^= 2038085824;
                  ChatColor var41 = ChatColor.AQUA;
                  String var42 = String.valueOf(var41);
                  ChatColor var79 = ChatColor.WHITE;
                  String var80 = String.valueOf(var79);
                  String var43 = var42 + "/setafk" + var80 + " - Sets the afk location.";
                  var12.sendMessage(var43);
                  var100 ^= 646480223;
                  ChatColor var44 = ChatColor.AQUA;
                  String var45 = String.valueOf(var44);
                  ChatColor var81 = ChatColor.WHITE;
                  String var82 = String.valueOf(var81);
                  String var46 = var45 + "/spawn" + var82 + " - Open the Spawn GUI or teleport to Spawn location.";
                  var12.sendMessage(var46);
                  var100 ^= 1710582873;
                  ChatColor var47 = ChatColor.AQUA;
                  String var48 = String.valueOf(var47);
                  ChatColor var83 = ChatColor.WHITE;
                  String var84 = String.valueOf(var83);
                  String var49 = var48 + "/afk" + var84 + " - Open the AFK GUI or teleport to AFK location.";
                  var12.sendMessage(var49);
                  var100 ^= 663880089;
                  ChatColor var50 = ChatColor.AQUA;
                  String var51 = String.valueOf(var50);
                  ChatColor var85 = ChatColor.WHITE;
                  String var86 = String.valueOf(var85);
                  String var52 = var51 + "/msg <player> <message>" + var86 + " - Send a private message to a player.";
                  var12.sendMessage(var52);
                  var100 ^= 1901251157;
                  ChatColor var53 = ChatColor.AQUA;
                  String var54 = String.valueOf(var53);
                  ChatColor var87 = ChatColor.WHITE;
                  String var88 = String.valueOf(var87);
                  String var55 = var54 + "/r <message>" + var88 + " - Reply to the last private message received.";
                  var12.sendMessage(var55);
                  var100 ^= 1546253288;
                  ChatColor var56 = ChatColor.AQUA;
                  String var57 = String.valueOf(var56);
                  ChatColor var89 = ChatColor.WHITE;
                  String var90 = String.valueOf(var89);
                  String var58 = var57 + "/msgtoggle" + var90 + " - Toggle private messages on or off.";
                  var12.sendMessage(var58);
                  var100 ^= 1068069480;
                  ChatColor var59 = ChatColor.AQUA;
                  String var60 = String.valueOf(var59);
                  ChatColor var91 = ChatColor.WHITE;
                  String var92 = String.valueOf(var91);
                  String var61 = var60 + "/help" + var92 + " - Opens the Help GUI.";
                  var12.sendMessage(var61);
                  var100 ^= 986264316;
                  ChatColor var62 = ChatColor.AQUA;
                  String var63 = String.valueOf(var62);
                  ChatColor var93 = ChatColor.WHITE;
                  String var94 = String.valueOf(var93);
                  String var64 = var63 + "/media" + var94 + " - Opens the Media GUI.";
                  var12.sendMessage(var64);
                  var100 ^= 172700447;
                  ChatColor var65 = ChatColor.AQUA;
                  String var66 = String.valueOf(var65);
                  ChatColor var95 = ChatColor.WHITE;
                  String var96 = String.valueOf(var95);
                  String var67 = var66 + "/rules" + var96 + " - Opens the Rules GUI.";
                  var12.sendMessage(var67);
                  var100 ^= 436009502;
                  ChatColor var68 = ChatColor.GOLD;
                  String var69 = String.valueOf(var68);
                  String var70 = var69 + "====================================";
                  var12.sendMessage(var70);
                  var100 ^= 1193589897;
                  byte var27 = (byte)(1123395906 ^ var100);
                  return (boolean)var27;
               }

               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var100)) {
                  case 87561652:
                     var100 ^= 738786917;
                     throw new RuntimeException();
                  case 912524886:
                  case 951198671:
                  default:
                     throw new RuntimeException();
                  case 2056472764:
                  }
               }
            case 447862912:
               break;
            case 933116545:
            default:
               throw new RuntimeException();
            }
         }
      }
   }

   static {
      nothing_to_see_here[0] = "⢀⡴⠑⡄⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠸⡇⠀⠿⡀⠀⠀⠀⣀⡴⢿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠑⢄⣠⠾⠁⣀⣄⡈⠙⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⢀⡀⠁⠀⠀⠈⠙⠛⠂⠈⣿⣿⣿⣿⣿⠿⡿⢿⣆⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⢀⡾⣁⣀⠀⠴⠂⠙⣗⡀⠀⢻⣿⣿⠭⢤⣴⣦⣤⣹⠀⠀⠀⢀⢴⣶⣆";
      nothing_to_see_here[5] = "⠀⠀⢀⣾⣿⣿⣿⣷⣮⣽⣾⣿⣥⣴⣿⣿⡿⢂⠔⢚⡿⢿⣿⣦⣴⣾⠁⠸⣼⡿";
      nothing_to_see_here[6] = "⠀⢀⡞⠁⠙⠻⠿⠟⠉⠀⠛⢹⣿⣿⣿⣿⣿⣌⢤⣼⣿⣾⣿⡟⠉⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⣾⣷⣶⠇⠀⠀⣤⣄⣀⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠉⠈⠉⠀⠀⢦⡈⢻⣿⣿⣿⣶⣶⣶⣶⣤⣽⡹⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠉⠲⣽⡻⢿⣿⣿⣿⣿⣿⣿⣷⣜⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣷⣶⣮⣭⣽⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⠿⠿⠿⠿⠛⠉              ";
      wajsecajoq = ByteBuffer.wrap(quenqlvvkmvmzrr()).asCharBuffer().toString();
      int var3 = (new Random(7428253483715799531L)).nextInt();
      mkEmrqoO0O = -1741223350 ^ var3;
   }

   public static String yvbbhwbfuy(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = wajsecajoq;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var89 = StandardCharsets.UTF_16BE;
            String var34 = new String(var11, var89);
            return var34;
         }

         byte var86 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var91 = var8[var92];
         int var87 = var86 ^ var91;
         byte var88 = (byte)var87;
         var11[var12] = var88;
         ++var12;
      }
   }

   private static byte[] quenqlvvkmvmzrr() {
      return new byte[0];
   }
}
