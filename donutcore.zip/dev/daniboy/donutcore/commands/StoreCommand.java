package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.config.MessagesConfig;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class StoreCommand extends Command {
   private static int DBntv79JSy;
   private transient int rDtlBO2eVS;
   private static String ibwxdnezfw;
   private static String[] nothing_to_see_here = new String[19];

   public StoreCommand() {
      int var13 = 1812727287 ^ 881217865;
      String var2 = "store";
      super(var2);

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var13)) {
         case 5564108:
         default:
            throw new IOException();
         case 193748154:
            var13 ^= 1466007190;
         case 1092945885:
            var13 = 598539794 ^ 580605296 ^ Integer.parseInt("249332042");
            this.rDtlBO2eVS = 694660199 ^ DBntv79JSy;
            var13 ^= 122448500;
            var13 ^= 1709565512;
            String var8 = "Provides the store link.";
            this.setDescription(var8);
            var13 ^= 1124876969;
            String var9 = "/store";
            this.setUsage(var9);
            var13 ^= 667658495;
            String var10 = "donutcore.store";
            this.setPermission(var10);
            var13 ^= 1899378816;
            return;
         case 1646733691:
         }
      }
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      int var23 = 1851773592 ^ 1709119026 ^ this.rDtlBO2eVS;
      var23 ^= 1263190638;
      byte var7 = var1 instanceof Player;
      if (var7 != (1291614724 ^ var23)) {
         var23 ^= 790565463;
         Player var9 = (Player)var1;
         var23 ^= 1898287486;

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23)) {
            case 73502721:
               var23 ^= 1957015212;
            case 1322501151:
               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23) != 106962922) {
                     throw null;
                  }

                  throw new RuntimeException();
               } catch (RuntimeException var24) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var23)) {
                  case 857390091:
                     var23 ^= 644508438;
                     break;
                  case 1246040585:
                     var23 = gqgkdulvxuauygmr(var23, 1765908182);
                     break;
                  default:
                     throw new IllegalAccessException("Error in hash");
                  }

                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23)) {
                     case 202483053:
                        var23 ^= 519840905;
                     case 329301542:
                        String var5 = mjwmyrycjh(evqxdaerxtuhuvk(), var23);
                        byte var11 = var9.hasPermission(var5);
                        if (var11 == (1593120798 ^ var23)) {
                           var23 ^= 1285761207;
                           MessagesConfig var12 = MessagesConfig.NOPERMISSION;
                           var12.send(var9);
                           var23 ^= 413911900;
                           byte var13 = (byte)(184417268 ^ var23);
                           return (boolean)var13;
                        }

                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23)) {
                           case 133857359:
                              var23 ^= 1097374553;
                           case 1517178341:
                              if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23) == 222376388) {
                                 var23 ^= 343337112;
                                 MessagesConfig var14 = MessagesConfig.STORE;
                                 var14.send(var9);
                                 var23 ^= 1516885684;
                                 byte var15 = (byte)(1367522666 ^ var23);
                                 return (boolean)var15;
                              }

                              while(true) {
                                 switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23)) {
                                 case 222376388:
                                    var23 ^= 2134792818;
                                    throw new IllegalAccessException();
                                 case 1137013224:
                                    break;
                                 case 1297969435:
                                 case 1851286116:
                                 default:
                                    throw new IllegalAccessException();
                                 }
                              }
                           case 530968634:
                           default:
                              throw new IllegalAccessException();
                           case 1599057588:
                           }
                        }
                     case 460644043:
                        break;
                     case 1640916504:
                     default:
                        throw new IllegalAccessException();
                     }
                  }
               }
            case 182633396:
            default:
               throw new IllegalAccessException();
            case 1013964104:
            }
         }
      } else {
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23)) {
            case 86597787:
               var23 ^= 478096656;
            case 748936774:
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23) == 201205813) {
                  var23 = gqgkdulvxuauygmr(var23, 1939961697);
                  MessagesConfig var16 = MessagesConfig.ONLYPLAYERS;
                  var16.send(var1);
                  var23 ^= 1771062224;
                  byte var17 = (byte)(1253204900 ^ var23);
                  return (boolean)var17;
               }

               var23 = gqgkdulvxuauygmr(var23, 807439905);
               throw new IllegalAccessException();
            case 258855623:
               break;
            case 1082793338:
            default:
               throw new IllegalAccessException();
            }
         }
      }
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣤⣤⣤⣤⣤⣶⣦⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⡿⠛⠉⠙⠛⠛⠛⠛⠻⢿⣿⣷⣤⡀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠋⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⠈⢻⣿⣿⡄⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⠀⠀⠀⣸⣿⡏⠀⠀⠀⣠⣶⣾⣿⣿⣿⠿⠿⠿⢿⣿⣿⣿⣄⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠁⠀⠀⢰⣿⣿⣯⠁⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣷⡄⠀";
      nothing_to_see_here[5] = "⠀⠀⣀⣤⣴⣶⣶⣿⡟⠀⠀⠀⢸⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣷⠀";
      nothing_to_see_here[6] = "⠀⢰⣿⡟⠋⠉⣹⣿⡇⠀⠀⠀⠘⣿⣿⣿⣿⣷⣦⣤⣤⣤⣶⣶⣶⣶⣿⣿⣿⠀";
      nothing_to_see_here[7] = "⠀⢸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠀";
      nothing_to_see_here[8] = "⠀⣸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠉⠻⠿⣿⣿⣿⣿⡿⠿⠿⠛⢻⣿⡇⠀⠀";
      nothing_to_see_here[9] = "⠀⣿⣿⠁⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣧⠀⠀";
      nothing_to_see_here[10] = "⠀⣿⣿⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀";
      nothing_to_see_here[11] = "⠀⣿⣿⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀";
      nothing_to_see_here[12] = "⠀⢿⣿⡆⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⠀";
      nothing_to_see_here[13] = "⠀⠸⣿⣧⡀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠃⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠛⢿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⣰⣿⣿⣷⣶⣶⣶⣶⠶⠀⢠⣿⣿⠀⠀⠀";
      nothing_to_see_here[15] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⣽⣿⡏⠁⠀⠀⢸⣿⡇⠀⠀⠀";
      nothing_to_see_here[16] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⢹⣿⡆⠀⠀⠀⣸⣿⠇⠀⠀⠀";
      nothing_to_see_here[17] = "⠀⠀⠀⠀⠀⠀⠀⢿⣿⣦⣄⣀⣠⣴⣿⣿⠁⠀⠈⠻⣿⣿⣿⣿⡿⠏⠀⠀⠀⠀";
      nothing_to_see_here[18] = "⠀⠀⠀⠀⠀⠀⠀⠈⠛⠻⠿⠿⠿⠿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      ibwxdnezfw = ByteBuffer.wrap(xkbnmsofbsgllzv()).asCharBuffer().toString();
      int var3 = (new Random(-3544955341514160785L)).nextInt();
      DBntv79JSy = -1754324611 ^ var3;
   }

   public static String mjwmyrycjh(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = ibwxdnezfw;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var91 = StandardCharsets.UTF_16BE;
            String var35 = new String(var11, var91);
            return var35;
         }

         byte var85 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var90 = var8[var92];
         int var86 = var85 ^ var90;
         byte var87 = (byte)var86;
         var11[var12] = var87;
         ++var12;
      }
   }

   private static byte[] evqxdaerxtuhuvk() {
      return new byte[]{0, 0, 0, 15, 0, 0, 0, 0};
   }

   private static byte[] xkbnmsofbsgllzv() {
      return new byte[]{49, 81, 57, 92, 49, 92, 48, 66, 57, 76, 49, 86, 57, 92, 49, 64, 48, 82, 57, 22, 49, 70, 57, 71, 49, 93, 48, 69, 57, 93};
   }

   private static int gqgkdulvxuauygmr(int var0, int var1) {
      return var0 ^ var1;
   }
}
