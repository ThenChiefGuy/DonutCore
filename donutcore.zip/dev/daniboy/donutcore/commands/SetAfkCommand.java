package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.config.SoundConfig;
import dev.daniboy.donutcore.config.wrapper.SoundWrapper;
import dev.daniboy.donutcore.database.SQLiteManager;
import dev.daniboy.donutcore.gui.impl.AfkGUI;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetAfkCommand extends Command {
   private final DonutCore plugin;
   private final SQLiteManager sqLiteManager;
   private final AfkGUI afkGui;
   private static int WenShUG6hN;
   private transient int Gzy2wjTLzQ;
   private static byte[] ijrqgxpats;
   private static String[] nothing_to_see_here = new String[17];

   public SetAfkCommand(DonutCore var1, SQLiteManager var2, AfkGUI var3, int var4) {
      int var22 = 1254743302 ^ 383333142;
      String var6 = "setafk";
      super(var6);
      var22 ^= 1703234899;
      var22 = 1232875940 ^ 1346373942 ^ Integer.parseInt("844158533") ^ var4;
      this.Gzy2wjTLzQ = 44312891 ^ WenShUG6hN;
      var22 = vhmqrvgztwrurlub(var22, 1783434501);
      var22 ^= 884640658;
      this.plugin = var1;
      var22 ^= 418791213;
      this.sqLiteManager = var2;
      var22 ^= 658102894;
      this.afkGui = var3;
      var22 ^= 1948885832;
      String var18 = "Sets an AFK point.";
      this.setDescription(var18);
      var22 ^= 370943462;
      String var19 = "/setafk <number>";
      this.setUsage(var19);
      var22 ^= 150282865;
      String var20 = "donutcore.setafk";
      this.setPermission(var20);
      var22 ^= 550025159;
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      int var51 = 2120594689 ^ 1213441066 ^ this.Gzy2wjTLzQ;
      var51 ^= 1062182491;
      byte var10 = var1 instanceof Player;
      if (var10 == (683884968 ^ var51)) {
         var51 ^= 70071482;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var51) == 118369852) {
            var51 ^= 2085762564;
            MessagesConfig var36 = MessagesConfig.ONLYPLAYERS;
            var36.send(var1);
            var51 ^= 1695297043;
            byte var37 = (byte)(900754692 ^ var51);
            return (boolean)var37;
         }

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var51)) {
            case 118369852:
               var51 ^= 432221164;
               throw new IOException();
            case 1332951939:
            case 1411643728:
            default:
               throw new IOException();
            case 1554535776:
            }
         }
      } else {
         var51 ^= 1709228611;
         Player var12 = (Player)var1;
         var51 ^= 2085193004;
         var51 = vhmqrvgztwrurlub(var51, 1696265875);

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var51) != 60458450) {
               throw null;
            }

            throw new IOException();
         } catch (IOException var55) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var51)) {
            case -1551400286:
               var51 ^= 1698316413;
               break;
            case 1702992217:
               var51 = vhmqrvgztwrurlub(var51, 502956802);
               break;
            default:
               throw new IllegalAccessException("Error in hash");
            }
         }

         var51 = vhmqrvgztwrurlub(var51, 496259485);
         String var5 = vvknvjlmvz(amqvfwnbcnhyhju(), var51);
         byte var14 = var12.hasPermission(var5);
         if (var14 == (752804276 ^ var51)) {
            var51 ^= 1460062448;
            MessagesConfig var33 = MessagesConfig.NOPERMISSION;
            var33.send(var12);
            var51 ^= 846043865;
            SoundWrapper var34 = SoundConfig.NOPERMISSION;
            var34.play(var12);
            var51 ^= 1707404376;
            byte var35 = (byte)(745627588 ^ var51);
            return (boolean)var35;
         }

         label148:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var51)) {
            case 116390290:
               var51 ^= 298836307;
               break label148;
            case 624120877:
               break;
            case 1739836837:
               break label148;
            case 2057333282:
            default:
               throw new IOException();
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var51) != 105958574) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var51)) {
               case 105958574:
                  var51 ^= 138173977;
                  throw new IOException();
               case 1577938742:
                  break;
               case 1706706893:
               case 1715084738:
               default:
                  throw new IOException();
               }
            }
         } else {
            var51 ^= 1775175407;
            int var16 = var3.length;
            byte var38 = (byte)(1423836681 ^ var51);
            if (var16 == var38) {
               var51 ^= 1594452697;

               int var8;
               try {
                  byte var39 = (byte)(198667473 ^ var51);
                  String var18 = var3[var39];
                  int var19 = Integer.parseInt(var18);
                  var8 = var19;
                  var51 ^= 386755153;
               } catch (NumberFormatException var52) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var51)) {
                  case 1589339784:
                     var51 ^= 1554676322;
                     var51 ^= 1255601294;
                     MessagesConfig var21 = MessagesConfig.INVALIDSPAWNNUMBER;
                     var21.send(var12);
                     var51 ^= 2031315197;
                     byte var22 = (byte)(1689815745 ^ var51);
                     return (boolean)var22;
                  default:
                     throw new IOException("Error in hash");
                  }
               }

               label124:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var51)) {
                  case 132542530:
                     var51 ^= 938439503;
                     break label124;
                  case 686107253:
                     break;
                  case 803903127:
                     break label124;
                  case 1377301262:
                  default:
                     throw new IOException();
                  }
               }

               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var51) != 62373748) {
                     throw null;
                  }

                  throw new IllegalAccessException();
               } catch (IllegalAccessException var54) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var51)) {
                  case 1504423545:
                     var51 ^= 1870671412;
                     break;
                  case 2121932008:
                     var51 ^= 1266292838;
                     break;
                  default:
                     throw new IOException("Error in hash");
                  }
               }

               var51 ^= 928734390;
               Location var24 = var12.getLocation();
               var51 ^= 729321926;
               SQLiteManager var26 = this.sqLiteManager;
               var26.setAfk$471806796(var24, var8, 1906740810);
               var51 ^= 126356356;
               MessagesConfig var27 = MessagesConfig.AFKPOINTSET;
               var27.send(var12);
               var51 ^= 1072928684;
               SoundWrapper var28 = SoundConfig.AFKSET;
               var28.play(var12);
               var51 ^= 1693707055;
               AfkGUI var30 = this.afkGui;
               var30.loadAfkConfigValues$568738828(1586297296);
               var51 ^= 1860465220;
               var51 = vhmqrvgztwrurlub(var51, 2078732233);

               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var51) != 19341661) {
                     throw null;
                  }

                  throw new IOException();
               } catch (IOException var53) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var51)) {
                  case -1998331896:
                     var51 ^= 387654458;
                     break;
                  case 843483122:
                     var51 ^= 1078955973;
                     break;
                  default:
                     throw new RuntimeException("Error in hash");
                  }
               }

               var51 ^= 473932765;
            } else {
               label137:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var51)) {
                  case 74350449:
                     var51 ^= 2074625411;
                     break label137;
                  case 300262557:
                  default:
                     throw new IOException();
                  case 1000997846:
                     break;
                  case 1559247191:
                     break label137;
                  }
               }

               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var51) != 200609195) {
                  var51 ^= 442178933;
                  throw new IOException();
               }

               var51 = vhmqrvgztwrurlub(var51, 1537619254);
               MessagesConfig var32 = MessagesConfig.PROVIDEAFKNUMBER;
               var32.send(var12);
               var51 ^= 1860733531;
            }
         }
      }

      byte var31 = (byte)(439942375 ^ var51);
      return (boolean)var31;
   }

   static {
      nothing_to_see_here[0] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⣀⣠⣤⣶⣶⣶⣤⣄⣀⣀⠄⠄⠄⠄⠄";
      nothing_to_see_here[1] = "⠄⠄⠄⠄⠄⠄⠄⠄⣀⣤⣤⣶⣿⣿⣿⣿⣿⣿⣿⣟⢿⣿⣿⣿⣶⣤⡀⠄";
      nothing_to_see_here[2] = "⠄⠄⠄⠄⠄⠄⢀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣜⠿⠿⣿⣿⣧⢓";
      nothing_to_see_here[3] = "⠄⠄⠄⠄⠄⡠⢛⣿⣿⣿⡟⣿⣿⣽⣋⠻⢻⣿⣿⣿⣿⡻⣧⡠⣭⣭⣿⡧";
      nothing_to_see_here[4] = "⠄⠄⠄⠄⠄⢠⣿⡟⣿⢻⠃⣻⣨⣻⠿⡀⣝⡿⣿⣿⣷⣜⣜⢿⣝⡿⡻⢔";
      nothing_to_see_here[5] = "⠄⠄⠄⠄⠄⢸⡟⣷⢿⢈⣚⣓⡡⣻⣿⣶⣬⣛⣓⣉⡻⢿⣎⠢⠻⣴⡾⠫";
      nothing_to_see_here[6] = "⠄⠄⠄⠄⠄⢸⠃⢹⡼⢸⣿⣿⣿⣦⣹⣿⣿⣿⠿⠿⠿⠷⣎⡼⠆⣿⠵⣫";
      nothing_to_see_here[7] = "⠄⠄⠄⠄⠄⠈⠄⠸⡟⡜⣩⡄⠄⣿⣿⣿⣿⣶⢀⢀⣿⣷⣿⣿⡐⡇⡄⣿";
      nothing_to_see_here[8] = "⠄⠄⠄⠄⠄⠄⠄⠄⠁⢶⢻⣧⣖⣿⣿⣿⣿⣿⣿⣿⣿⡏⣿⣇⡟⣇⣷⣿";
      nothing_to_see_here[9] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⣆⣤⣽⣿⡿⠿⠿⣿⣿⣦⣴⡇⣿⢨⣾⣿⢹⢸";
      nothing_to_see_here[10] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⣿⠊⡛⢿⣿⣿⣿⣿⡿⣫⢱⢺⡇⡏⣿⣿⣸⡼";
      nothing_to_see_here[11] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⡿⠄⣿⣷⣾⡍⣭⣶⣿⣿⡌⣼⣹⢱⠹⣿⣇⣧";
      nothing_to_see_here[12] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⣼⠁⣤⣭⣭⡌⢁⣼⣿⣿⣿⢹⡇⣭⣤⣶⣤⡝⡼";
      nothing_to_see_here[13] = "⠄⣀⠤⡀⠄⠄⠄⠄⠄⡏⣈⡻⡿⠃⢀⣾⣿⣿⣿⡿⡼⠁⣿⣿⣿⡿⢷⢸";
      nothing_to_see_here[14] = "⢰⣷⡧⡢⠄⠄⠄⠄⠠⢠⡛⠿⠄⠠⠬⠿⣿⠭⠭⢱⣇⣀⣭⡅⠶⣾⣷⣶";
      nothing_to_see_here[15] = "⠈⢿⣿⣧⠄⠄⠄⠄⢀⡛⠿⠄⠄⠄⠄⢠⠃⠄⠄⡜⠄⠄⣤⢀⣶⣮⡍⣴";
      nothing_to_see_here[16] = "⠄⠈⣿⣿⡀⠄⠄⠄⢩⣝⠃⠄⠄⢀⡄⡎⠄⠄⠄⠇⠄⠄⠅⣴⣶⣶⠄⣶";
      ijrqgxpats = zwvatnbmdfvjrpt();
      int var3 = (new Random(6455330743031921930L)).nextInt();
      WenShUG6hN = 761501828 ^ var3;
   }

   public static String vvknvjlmvz(byte[] var0, int var1) {
      String var10 = Integer.toString(var1);
      byte[] var11 = var10.getBytes();
      byte[] var8 = var11;
      byte var12 = 0;
      int var9 = var12;

      while(true) {
         int var17 = var0.length;
         if (var9 >= var17) {
            Charset var5 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var5);
            return var14;
         }

         byte var20 = var0[var9];
         int var33 = var8.length;
         int var30 = var9 % var33;
         byte var27 = var8[var30];
         int var21 = var20 ^ var27;
         byte var22 = (byte)var21;
         var0[var9] = var22;
         byte var23 = var0[var9];
         byte[] var28 = ijrqgxpats;
         byte[] var34 = ijrqgxpats;
         int var35 = var34.length;
         int var32 = var9 % var35;
         byte var29 = var28[var32];
         int var24 = var23 ^ var29;
         byte var25 = (byte)var24;
         var0[var9] = var25;
         ++var9;
      }
   }

   private static byte[] zwvatnbmdfvjrpt() {
      return new byte[]{106, 108, 81, 104, 30};
   }

   private static byte[] amqvfwnbcnhyhju() {
      return new byte[]{-93, -90, 99, 52, 46, 49, 94, 8, 94, 92, 95, 42, 105, 59, 42, 55, 91, 21, 95, 78, 88, 122, 97, 47, 44, 56, 90, 18, 93, 77, 82, 58, 101, 49};
   }

   private static int vhmqrvgztwrurlub(int var0, int var1) {
      return var1 ^ var0;
   }
}
