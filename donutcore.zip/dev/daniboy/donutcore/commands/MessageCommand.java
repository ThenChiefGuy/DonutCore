package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MainConfig;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.config.SoundConfig;
import dev.daniboy.donutcore.config.wrapper.SoundWrapper;
import dev.daniboy.donutcore.database.SQLiteManager;
import dev.daniboy.donutcore.utils.Hex;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MessageCommand implements CommandExecutor {
   private final DonutCore plugin;
   private final SQLiteManager sqLiteManager;
   private static int lKQ2YvPYPZ;
   private transient int kYO8KV5Y6F;
   private static byte[] xytqskxkjx;
   private static String[] nothing_to_see_here = new String[19];

   public MessageCommand(DonutCore var1, SQLiteManager var2, int var3) {
      int var10 = 999303236 ^ 1673172254;
      super();
      var10 = xmpvgdtddoayhstk(var10, 175929728);
      var10 = 1039143340 ^ 405135269 ^ Integer.parseInt("1875980447") ^ var3;
      this.kYO8KV5Y6F = 391840803 ^ lKQ2YvPYPZ;
      var10 = xmpvgdtddoayhstk(var10, 1481390597);
      var10 ^= 2144696789;
      this.plugin = var1;
      var10 ^= 1671008833;
      this.sqLiteManager = var2;
      var10 ^= 1975011354;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      int var107;
      label167: {
         var107 = 840614188 ^ 1352519463 ^ this.kYO8KV5Y6F;
         var107 ^= 1201471013;
         byte var15 = var1 instanceof Player;
         if (var15 != (940948154 ^ var107)) {
            var107 ^= 1261288752;
            Player var17 = (Player)var1;
            var107 ^= 1232681493;
            var107 = xmpvgdtddoayhstk(var107, 90179954);

            try {
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107) != 173042090) {
                  throw null;
               }

               throw new IllegalAccessException();
            } catch (IllegalAccessException var108) {
               switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var107)) {
               case -1011866280:
                  var107 = xmpvgdtddoayhstk(var107, 1424311557);
                  break;
               case -116807831:
                  var107 ^= 1941075267;
                  break;
               default:
                  throw new IllegalAccessException("Error in hash");
               }
            }

            var107 ^= 1897653541;
            String var6 = jhztnaksru(rkndxztihibcvjs(), var107);
            byte var19 = var17.hasPermission(var6);
            if (var19 == (1032365195 ^ var107)) {
               var107 ^= 1650158625;
               MessagesConfig var62 = MessagesConfig.NOPERMISSION;
               var62.send(var17);
               var107 ^= 1361703119;
               SoundWrapper var63 = SoundConfig.NOPERMISSION;
               var63.play(var17);
               var107 ^= 1051615361;
               byte var64 = (byte)(810834149 ^ var107);
               return (boolean)var64;
            }

            label139:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107)) {
               case 121144133:
                  var107 ^= 694555331;
                  break label139;
               case 252915865:
               default:
                  throw new IOException();
               case 1436756295:
                  break;
               case 1771190207:
                  break label139;
               }
            }

            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107) != 143562181) {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107)) {
                  case 143562181:
                     var107 ^= 1444140881;
                     throw new IOException();
                  case 783972490:
                  case 1598749044:
                  default:
                     throw new IOException();
                  case 1768630159:
                  }
               }
            } else {
               var107 ^= 649167328;
               int var21 = var4.length;
               byte var67 = (byte)(845100970 ^ var107);
               if (var21 < var67) {
                  var107 ^= 1342633849;
                  String var68 = jhztnaksru(qtwtxsigjybheap(), var107);
                  String var69 = Hex.hex(var68);
                  var1.sendMessage(var69);
                  var107 ^= 1962807697;
                  byte var23 = (byte)(380096833 ^ var107);
                  return (boolean)var23;
               }

               var107 ^= 1298962947;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107) != 108289864) {
                  var107 ^= 1036962994;
               } else {
                  var107 ^= 816172294;
                  Player var25 = (Player)var1;
                  var107 ^= 818935928;
                  byte var70 = (byte)(2136578261 ^ var107);
                  String var27 = var4[var70];
                  Player var28 = Bukkit.getPlayer(var27);
                  var107 ^= 1820777245;
                  byte var30 = var25.equals(var28);
                  if (var30 != (333398984 ^ var107)) {
                     var107 ^= 1175400513;
                     MessagesConfig var60 = MessagesConfig.CANTMESSAGEYOURSELF;
                     var60.send(var17);
                     var107 ^= 2052800468;
                     byte var61 = (byte)(797658204 ^ var107);
                     return (boolean)var61;
                  }

                  var107 = xmpvgdtddoayhstk(var107, 751138914);
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107) != 172158083) {
                     var107 = xmpvgdtddoayhstk(var107, 2112314035);
                  } else {
                     label128:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107)) {
                        case 143183016:
                           break label128;
                        case 172158083:
                           var107 ^= 1588562332;
                           break label128;
                        case 524195511:
                           break;
                        case 2049857741:
                        default:
                           throw new IOException();
                        }
                     }

                     if (var28 != null) {
                        var107 ^= 1526986908;
                        byte var33 = var28.isOnline();
                        if (var33 != (985025194 ^ var107)) {
                           var107 = xmpvgdtddoayhstk(var107, 2121930030);
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107) != 88849859) {
                              while(true) {
                                 switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107)) {
                                 case 88849859:
                                    var107 ^= 103890589;
                                    throw new IOException();
                                 case 1277620693:
                                 case 1367707118:
                                 default:
                                    throw new IOException();
                                 case 1305764220:
                                 }
                              }
                           } else {
                              var107 = xmpvgdtddoayhstk(var107, 836421236);
                              SQLiteManager var35 = this.sqLiteManager;
                              UUID var73 = var28.getUniqueId();
                              byte var36 = var35.getMessageToggle$1388376138(var73, 884977015);
                              if (var36 == (1964415472 ^ var107)) {
                                 var107 ^= 9891103;
                                 MessagesConfig var37 = MessagesConfig.MESSAGEDISABLED;
                                 var37.send(var1);
                                 var107 ^= 1230589999;
                                 byte var38 = (byte)(1020863681 ^ var107);
                                 return (boolean)var38;
                              }

                              var107 = xmpvgdtddoayhstk(var107, 129715321);
                              if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107) == 238075668) {
                                 var107 = xmpvgdtddoayhstk(var107, 240319942);
                                 String var39 = jhztnaksru(oxmklyzoocshpmz(), var107);
                                 byte var7 = (byte)(2097096782 ^ var107);
                                 int var104 = var4.length;
                                 Object[] var76 = Arrays.copyOfRange(var4, var7, var104);
                                 CharSequence[] var77 = (CharSequence[])var76;
                                 String var40 = String.join(var39, var77);
                                 var107 ^= 518831437;
                                 String var41 = MainConfig.Chat.MSG_FROM_FORMAT;
                                 String var78 = jhztnaksru(dqdpkowbjmjoshz(), var107);
                                 var107 ^= 247379677;
                                 String var94 = var25.getName();
                                 String var42 = var41.replace(var78, var94);
                                 String var79 = jhztnaksru(muonvhusqsaigcm(), var107);
                                 var107 ^= 1689806932;
                                 String var96 = var28.getName();
                                 String var43 = var42.replace(var79, var96);
                                 String var80 = jhztnaksru(lmbeqrtavqcuejt(), var107);
                                 var107 ^= 1621551536;
                                 String var44 = var43.replace(var80, var40);
                                 var107 ^= 899266849;
                                 String var45 = Hex.hex(var44);
                                 var107 ^= 1812041384;
                                 String var46 = MainConfig.Chat.MSG_TO_FORMAT;
                                 String var81 = jhztnaksru(uhuzmygoabpqcaw(), var107);
                                 var107 ^= 510168901;
                                 String var99 = var25.getName();
                                 String var47 = var46.replace(var81, var99);
                                 String var82 = jhztnaksru(ocylatqaktdzlql(), var107);
                                 var107 ^= 88456189;
                                 String var101 = var28.getName();
                                 String var48 = var47.replace(var82, var101);
                                 String var83 = jhztnaksru(iivnellzmoxvdtp(), var107);
                                 var107 ^= 1514455778;
                                 String var49 = var48.replace(var83, var40);
                                 var107 ^= 214811850;
                                 String var50 = Hex.hex(var49);
                                 var107 ^= 1493212166;
                                 var28.sendMessage(var45);
                                 var107 ^= 1033348936;
                                 var25.sendMessage(var50);
                                 var107 ^= 756523225;
                                 DonutCore var54 = this.plugin;
                                 Map var55 = var54.getLastMessaged$1938418975(498594716);
                                 var55.put(var28, var25);
                                 var107 ^= 965323655;
                                 byte var57 = (byte)(210147123 ^ var107);
                                 return (boolean)var57;
                              }

                              var107 = xmpvgdtddoayhstk(var107, 810595472);
                              throw new IOException();
                           }
                        }

                        var107 ^= 513633226;
                     } else {
                        var107 ^= 1761596526;
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107) != 33566464) {
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107)) {
                              case 33566464:
                                 var107 ^= 1270286145;
                                 throw new IOException();
                              case 112182414:
                                 break;
                              case 1513110267:
                              case 1735050854:
                              default:
                                 throw new IOException();
                              }
                           }
                        }

                        label116:
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107)) {
                           case 33566464:
                              var107 ^= 761349944;
                              break label116;
                           case 308854374:
                           default:
                              throw new IOException();
                           case 1211035228:
                              break label116;
                           case 2018252442:
                           }
                        }
                     }

                     String var87 = jhztnaksru(vtipzctukfrpzyf(), var107);
                     String var88 = Hex.hex(var87);
                     var1.sendMessage(var88);
                     var107 ^= 576935477;
                     byte var59 = (byte)(105412436 ^ var107);
                     return (boolean)var59;
                  }
               }
            }
         } else {
            var107 ^= 800073417;
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107) != 231786683) {
               var107 = xmpvgdtddoayhstk(var107, 1431895402);
            } else {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var107)) {
                  case 231786683:
                     var107 ^= 971730706;
                  case 422732812:
                     break label167;
                  case 671496869:
                  default:
                     throw new IOException();
                  case 1304034386:
                  }
               }
            }
         }

         throw new IOException();
      }

      MessagesConfig var65 = MessagesConfig.ONLYPLAYERS;
      var65.send(var1);
      var107 ^= 760327076;
      byte var66 = (byte)(52385988 ^ var107);
      return (boolean)var66;
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣤⣤⣤⣤⣤⣶⣦⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⡿⠛⠉⠙⠛⠛⠛⠛⠻⢿⣿⣷⣤⡀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠋⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⠈⢻⣿⣿⡄⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⠀⠀⠀⣸⣿⡏⠀⠀⠀⣠⣶⣾⣿⣿⣿⠿⠿⠿⢿⣿⣿⣿⣄⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠁⠀⠀⢰⣿⣿⣯⠁⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣷⡄⠀";
      nothing_to_see_here[5] = "⠀⠀⣀⣤⣴⣶⣶⣿⡟⠀⠀⠀⢸⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣷⠀";
      nothing_to_see_here[6] = "⠀⢰⣿⡟⠋⠉⣹⣿⡇⠀⠀⠀⠘⣿⣿⣿⣿⣷⣦⣤⣤⣤⣶⣶⣶⣶⣿⣿⣿⠀";
      nothing_to_see_here[7] = "⠀⢸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠀";
      nothing_to_see_here[8] = "⠀⣸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠉⠻⠿⣿⣿⣿⣿⡿⠿⠿⠛⢻⣿⡇⠀⠀";
      nothing_to_see_here[9] = "⠀⣿⣿⠁⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣧⠀⠀";
      nothing_to_see_here[10] = "⠀⣿⣿⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀";
      nothing_to_see_here[11] = "⠀⣿⣿⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀";
      nothing_to_see_here[12] = "⠀⢿⣿⡆⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⠀";
      nothing_to_see_here[13] = "⠀⠸⣿⣧⡀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠃⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠛⢿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⣰⣿⣿⣷⣶⣶⣶⣶⠶⠀⢠⣿⣿⠀⠀⠀";
      nothing_to_see_here[15] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⣽⣿⡏⠁⠀⠀⢸⣿⡇⠀⠀⠀";
      nothing_to_see_here[16] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⢹⣿⡆⠀⠀⠀⣸⣿⠇⠀⠀⠀";
      nothing_to_see_here[17] = "⠀⠀⠀⠀⠀⠀⠀⢿⣿⣦⣄⣀⣠⣴⣿⣿⠁⠀⠈⠻⣿⣿⣿⣿⡿⠏⠀⠀⠀⠀";
      nothing_to_see_here[18] = "⠀⠀⠀⠀⠀⠀⠀⠈⠛⠻⠿⠿⠿⠿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      xytqskxkjx = iipuqmuqvbvoqfu();
      int var3 = (new Random(-2282763439509466664L)).nextInt();
      lKQ2YvPYPZ = -289486409 ^ var3;
   }

   public static String jhztnaksru(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = xytqskxkjx;
         byte[] var34 = xytqskxkjx;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] iipuqmuqvbvoqfu() {
      return new byte[]{56, 114, 39, 4, 19, 126, 123, 40, 92, 39, 72, 102, 39, 66, 59, 56, 34, 119, 123, 87, 5, 73, 96, 59, 8, 6, 13, 61, 18, 90, 60, 125, 91, 42, 93, 83, 82, 72, 43, 86, 47, 103, 51, 31, 95, 86};
   }

   private static byte[] rkndxztihibcvjs() {
      return new byte[]{-9, -67, 20, 82, 32, 39, 78, 119, 101, 103, 121, 34, 20, 19, 8, 97, 23, 52, 66, 7, 52, 87, 83, 100, 59, 67, 56, 107};
   }

   private static byte[] iivnellzmoxvdtp() {
      return new byte[]{-15, -67, 18, 17, 36, 36, 78, 124, 104, 99, 120, 32, 23, 20, 12, 106, 19, 38, 76, 66};
   }

   private static byte[] muonvhusqsaigcm() {
      return new byte[]{-9, -75, 21, 18, 33, 52, 77, 127, 111, 125, 121, 59, 21, 24, 9, 118, 20, 32, 72, 28, 52, 84};
   }

   private static byte[] dqdpkowbjmjoshz() {
      return new byte[]{-9, -69, 19, 20, 39, 56, 75, 121, 101, 113, 121, 52, 19, 18, 15, 127, 18, 102};
   }

   private static byte[] lmbeqrtavqcuejt() {
      return new byte[]{-9, -66, 18, 23, 34, 32, 72, 127, 111, 101, 123, 32, 17, 18, 8, 108, 16, 33, 74, 65};
   }

   private static byte[] uhuzmygoabpqcaw() {
      return new byte[]{-2, -65, 19, 24, 32, 52, 66, 120, 104, 113, 122, 54, 30, 20, 2, 115, 23, 102};
   }

   private static byte[] qtwtxsigjybheap() {
      return new byte[]{-9, -69, 18, 18, 35, 41, 66, 79, 111, 103, 121, 49, 18, 21, 11, 105, 27, 127, 72, 68, 52, 80, 85, 102, 56, 65, 52, 104, 33, 73, 13, 119, 110, 106, 109, 11, 107, 27, 24, 28, 30, 52, 6, 93, 111, 92, 1, 96, 20, 11, 34, 37, 78, 125, 108, 96, 113, 39, 20, 16, 10, 105, 23, 34, 75, 93};
   }

   private static byte[] vtipzctukfrpzyf() {
      return new byte[]{-16, -67, 17, 26, 35, 43, 72, 74, 100, 121, 120, 49, 31, 6, 13, 43, 20, 63, 77, 11, 51, 16, 80, 116, 59, 85, 53, 121, 34, 76, 4, 36, 109, 106, 107, 75, 100, 22, 29, 1, 31, 37, 0, 9, 103, 15, 8, 42, 31, 88, 37, 36, 77, 126, 106, 114, 126, 112};
   }

   private static byte[] ocylatqaktdzlql() {
      return new byte[]{-15, -76, 21, 24, 33, 58, 66, 123, 107, 115, 113, 49, 30, 25, 13, 119, 20, 37, 76, 28, 55, 85};
   }

   private static byte[] oxmklyzoocshpmz() {
      return new byte[]{-12, -67, 30, 19};
   }

   private static int xmpvgdtddoayhstk(int var0, int var1) {
      return var1 ^ var0;
   }
}
