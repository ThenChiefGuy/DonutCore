package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.database.SQLiteManager;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PayToggleCommand extends Command {
   private final SQLiteManager sqLiteManager;
   private static int DJrVbvGjVk;
   private transient int rj6r5cLiYX;
   private static String bwgmxefmeo;
   private static String[] nothing_to_see_here = new String[13];

   public PayToggleCommand(SQLiteManager var1, int var2) {
      int var13 = 738052683 ^ 1260831061;
      String var4 = "paytoggle";
      super(var4);
      var13 ^= 478817629;
      var13 = 235487776 ^ 557009616 ^ Integer.parseInt("1698256933") ^ var2;
      this.rj6r5cLiYX = 927140549 ^ DJrVbvGjVk;
      var13 = qzlzbwvlotljvobx(var13, 971949187);
      var13 ^= 92460036;
      String var9 = "donutcore.paytoggle";
      this.setPermission(var9);
      var13 ^= 1074980635;
      String var10 = "paytoggle";
      this.setUsage(var10);
      var13 ^= 865894169;
      this.sqLiteManager = var1;
      var13 ^= 359369928;
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      int var34 = 655678209 ^ 1925747965 ^ this.rj6r5cLiYX;
      var34 ^= 40002315;
      byte var10 = var1 instanceof Player;
      if (var10 != (1285542648 ^ var34)) {
         var34 ^= 1218415577;
         Player var12 = (Player)var1;
         var34 ^= 433274826;
         var34 = qzlzbwvlotljvobx(var34, 1586957520);

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34) != 39112342) {
               throw null;
            } else {
               throw new RuntimeException();
            }
         } catch (RuntimeException var37) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var34)) {
            case -821948933:
               var34 = qzlzbwvlotljvobx(var34, 38013241);
               break;
            case 438522330:
               var34 ^= 954213053;
               break;
            default:
               throw new IOException("Error in hash");
            }

            var34 = qzlzbwvlotljvobx(var34, 109035308);
            SQLiteManager var14 = this.sqLiteManager;
            UUID var26 = var12.getUniqueId();
            byte var15 = var14.getPayToggle$495579768(var26, 2083576082);
            var34 ^= 1770664959;
            byte var23;
            if (var15 == (340902997 ^ var34)) {
               var34 ^= 372888123;
               var23 = (byte)(40375919 ^ var34);
               var34 ^= 1218602407;

               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34) != 15207071) {
                     throw null;
                  }

                  throw new IllegalAccessException();
               } catch (IllegalAccessException var36) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var34)) {
                  case 751870322:
                     var34 = qzlzbwvlotljvobx(var34, 1665999027);
                     break;
                  case 1448320586:
                     var34 ^= 1813858132;
                     break;
                  default:
                     throw new RuntimeException("Error in hash");
                  }

                  var34 = qzlzbwvlotljvobx(var34, 34705304);
               }
            } else {
               label101:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34)) {
                  case 123631669:
                     var34 ^= 1648688018;
                  case 1153308495:
                     break label101;
                  case 1811567785:
                  default:
                     throw new RuntimeException();
                  case 2105027115:
                  }
               }

               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34) != 80305540) {
                  var34 ^= 650428916;
                  throw new RuntimeException();
               }

               var34 = qzlzbwvlotljvobx(var34, 939484570);
               var23 = (byte)(1105877597 ^ var34);
               var34 ^= 1697440088;
            }

            var34 ^= 390419554;
            SQLiteManager var18 = this.sqLiteManager;
            UUID var28 = var12.getUniqueId();
            var18.setPayToggle$1965917752(var28, (boolean)var23, 583043106);
            var34 ^= 766127540;
            if (var23 != (506053331 ^ var34)) {
               var34 ^= 385934715;
               MessagesConfig var20 = MessagesConfig.PAYMENT_ENABLED;
               var20.send(var12);

               label88:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34)) {
                  case 29341180:
                     var34 ^= 191344690;
                     break label88;
                  case 271788881:
                     break;
                  case 1371257000:
                     break label88;
                  case 1487704895:
                  default:
                     throw new RuntimeException();
                  }
               }

               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34) != 36285550) {
                     throw null;
                  }

                  throw new RuntimeException();
               } catch (RuntimeException var35) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var34)) {
                  case -563597103:
                     var34 ^= 360261867;
                     break;
                  case 309640400:
                     var34 ^= 754628971;
                     break;
                  default:
                     throw new RuntimeException("Error in hash");
                  }

                  var34 = qzlzbwvlotljvobx(var34, 792982418);
               }
            } else {
               var34 ^= 549332918;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34) != 155611876) {
                  var34 = qzlzbwvlotljvobx(var34, 1850088278);
                  throw new RuntimeException();
               }

               var34 = qzlzbwvlotljvobx(var34, 1325923497);
               MessagesConfig var22 = MessagesConfig.PAYMENT_DISABLED;
               var22.send(var12);
               var34 ^= 1885848751;
            }

            byte var21 = (byte)(33021282 ^ var34);
            return (boolean)var21;
         }
      } else {
         var34 ^= 1041168214;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34) == 234441616) {
            var34 = qzlzbwvlotljvobx(var34, 1551300353);
            MessagesConfig var24 = MessagesConfig.ONLYPLAYERS;
            var24.send(var1);
            var34 ^= 1191193940;
            byte var25 = (byte)(1776812027 ^ var34);
            return (boolean)var25;
         } else {
            var34 ^= 574675869;
            throw new RuntimeException();
         }
      }
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⣠⣶⡾⠏⠉⠙⠳⢦⡀⠀⠀⠀⢠⠞⠉⠙⠲⡀⠀    ";
      nothing_to_see_here[2] = "⠀⠀⠀⣴⠿⠏⠀⠀⠀⠀⠀⠀⢳⡀⠀⡏⠀⠀⠀⠀⠀⢷     ";
      nothing_to_see_here[3] = "⠀⠀⢠⣟⣋⡀⢀⣀⣀⡀⠀⣀⡀⣧⠀⢸⠀⠀⠀⠀⠀ ⡇    ";
      nothing_to_see_here[4] = "⠀⠀⢸⣯⡭⠁⠸⣛⣟⠆⡴⣻⡲⣿⠀⣸⠀⠀OK⠀ ⡇    ";
      nothing_to_see_here[5] = "⠀⠀⣟⣿⡭⠀⠀⠀⠀⠀⢱⠀⠀⣿⠀⢹⠀⠀⠀⠀⠀ ⡇    ";
      nothing_to_see_here[6] = "⠀⠀⠙⢿⣯⠄⠀⠀⠀⢀⡀⠀⠀⡿⠀⠀⡇⠀⠀⠀⠀⡼     ";
      nothing_to_see_here[7] = "⠀⠀⠀⠀⠹⣶⠆⠀⠀⠀⠀⠀⡴⠃⠀⠀⠘⠤⣄⣠⠞⠀     ";
      nothing_to_see_here[8] = "⠀⠀⠀⠀⠀⢸⣷⡦⢤⡤⢤⣞⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[9] = "⠀⠀⢀⣤⣴⣿⣏⠁⠀⠀⠸⣏⢯⣷⣖⣦⡀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[10] = "⢀⣾⣽⣿⣿⣿⣿⠛⢲⣶⣾⢉⡷⣿⣿⠵⣿⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[11] = "⣼⣿⠍⠉⣿⡭⠉⠙⢺⣇⣼⡏⠀⠀⠀⣄⢸⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[12] = "⣿⣿⣧⣀⣿.........⣀⣰⣏⣘⣆⣀⠀⠀       ";
      bwgmxefmeo = ByteBuffer.wrap(xqjzeodrvuttdor()).asCharBuffer().toString();
      int var3 = (new Random(3891028569673267625L)).nextInt();
      DJrVbvGjVk = 117823161 ^ var3;
   }

   public static String axipdqxejl(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = bwgmxefmeo;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var89 = StandardCharsets.UTF_16BE;
            String var34 = new String(var11, var89);
            return var34;
         }

         byte var86 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var91 = var8[var92];
         int var87 = var86 ^ var91;
         byte var88 = (byte)var87;
         var11[var12] = var88;
         ++var12;
      }
   }

   private static byte[] xqjzeodrvuttdor() {
      return new byte[0];
   }

   private static int qzlzbwvlotljvobx(int var0, int var1) {
      return var1 ^ var0;
   }
}
