package dev.daniboy.donutcore.commands;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.gui.impl.RulesGUI;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RulesCommand extends Command {
   private final DonutCore plugin;
   private static int y7lDhUCL4Z;
   private transient int dRfa1I3BXt;
   private static String syrlerkppp;
   private static String[] nothing_to_see_here = new String[18];

   public RulesCommand(DonutCore var1, int var2) {
      int var16 = 1156844796 ^ 3507818;
      String var4 = "rules";
      super(var4);
      var16 = vhfdzjzhpbyzqeja(var16, 2029055496);
      var16 = 1706721732 ^ 1631911653 ^ Integer.parseInt("1061788341") ^ var2;
      this.dRfa1I3BXt = 1455587039 ^ y7lDhUCL4Z;

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var16)) {
         case 77565635:
            var16 ^= 222613995;
         case 80941268:
            var16 ^= 2128110143;
            this.plugin = var1;
            var16 ^= 18481821;
            String var12 = "Opens the rules GUI";
            this.setDescription(var12);
            var16 ^= 241664862;
            String var13 = "/rules";
            this.setUsage(var13);
            var16 ^= 699625599;
            String var14 = "donutcore.rules";
            this.setPermission(var14);
            var16 ^= 1754194520;
            return;
         case 1254018531:
            break;
         case 2124183579:
         default:
            throw new IOException();
         }
      }
   }

   public boolean execute(CommandSender var1, String var2, String[] var3) {
      int var27 = 1004770386 ^ 708652808 ^ this.dRfa1I3BXt;
      var27 ^= 927388914;
      byte var8 = var1 instanceof Player;
      if (var8 != (1699490386 ^ var27)) {
         var27 ^= 720892000;
         Player var12 = (Player)var1;
         var27 ^= 1195368385;
         var27 ^= 1013010868;

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) != 108816300) {
               throw null;
            }

            throw new IOException();
         } catch (IOException var28) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var27)) {
            case -1490378183:
               var27 = vhfdzjzhpbyzqeja(var27, 1420493769);
               break;
            case 475449386:
               var27 = vhfdzjzhpbyzqeja(var27, 600084107);
               break;
            default:
               throw new RuntimeException("Error in hash");
            }
         }

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
            case 177711597:
               var27 ^= 155720007;
            case 196447441:
               String var21 = wspzbispkq(wmydjrjgyrymuax(), var27);
               byte var14 = var12.hasPermission(var21);
               if (var14 == (1762021065 ^ var27)) {
                  var27 ^= 1365268255;
                  MessagesConfig var19 = MessagesConfig.NOPERMISSION;
                  var19.send(var12);
                  var27 ^= 142911567;
                  byte var20 = (byte)(820162968 ^ var27);
                  return (boolean)var20;
               }

               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
                  case 192696739:
                     var27 ^= 1997737956;
                  case 487909486:
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) == 172568658) {
                        var27 = vhfdzjzhpbyzqeja(var27, 1679770545);
                        DonutCore var16 = this.plugin;
                        RulesGUI var17 = var16.getRulesGui$369068666(2053000771);
                        byte var6 = (byte)(2047476380 ^ var27);
                        Object[] var24 = new Object[var6];
                        var17.open$967512435(var12, var24, 1892453237);
                        var27 ^= 1580494723;
                        byte var18 = (byte)(608070942 ^ var27);
                        return (boolean)var18;
                     }

                     var27 ^= 1607861881;
                     throw new IOException();
                  case 469142513:
                     break;
                  case 698907484:
                  default:
                     throw new IOException();
                  }
               }
            case 199240419:
            default:
               throw new IOException();
            case 1886304668:
            }
         }
      } else {
         var27 = vhfdzjzhpbyzqeja(var27, 1746414607);
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) == 164806912) {
            var27 ^= 897285811;
            MessagesConfig var9 = MessagesConfig.ONLYPLAYERS;
            var9.send(var1);
            var27 ^= 285921302;
            byte var10 = (byte)(690333945 ^ var27);
            return (boolean)var10;
         } else {
            var27 = vhfdzjzhpbyzqeja(var27, 1284981001);
            throw new IOException();
         }
      }
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣶⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⠿⠟⠛⠻⣿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣆⣀⣀⠀⣿⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠻⣿⣿⣿⠅⠛⠋⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[5] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢼⣿⣿⣿⣃⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[6] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣟⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣛⣛⣫⡄⠀⢸⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣾⡆⠸⣿⣿⣿⡷⠂⠨⣿⣿⣿⣿⣶⣦⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣾⣿⣿⣿⣿⡇⢀⣿⡿⠋⠁⢀⡶⠪⣉⢸⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⡏⢸⣿⣷⣿⣿⣷⣦⡙⣿⣿⣿⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣇⢸⣿⣿⣿⣿⣿⣷⣦⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[15] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[16] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[17] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣵⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      syrlerkppp = ByteBuffer.wrap(ixewlpktmhsaxxn()).asCharBuffer().toString();
      int var3 = (new Random(-1147231557362976169L)).nextInt();
      y7lDhUCL4Z = -2009714221 ^ var3;
   }

   public static String wspzbispkq(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = syrlerkppp;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var91 = StandardCharsets.UTF_16BE;
            String var35 = new String(var11, var91);
            return var35;
         }

         byte var85 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var90 = var8[var92];
         int var86 = var85 ^ var90;
         byte var87 = (byte)var86;
         var11[var12] = var87;
         ++var12;
      }
   }

   private static byte[] wmydjrjgyrymuax() {
      return new byte[]{0, 0, 0, 15, 0, 0, 0, 0};
   }

   private static byte[] ixewlpktmhsaxxn() {
      return new byte[]{49, 83, 54, 93, 48, 92, 49, 69, 54, 65, 49, 84, 54, 93, 48, 64, 49, 85, 54, 27, 49, 69, 54, 71, 48, 94, 49, 85, 54, 70};
   }

   private static int vhfdzjzhpbyzqeja(int var0, int var1) {
      return var0 ^ var1;
   }
}
