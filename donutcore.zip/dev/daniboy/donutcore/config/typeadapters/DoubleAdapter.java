package dev.daniboy.donutcore.config.typeadapters;

import org.bukkit.configuration.ConfigurationSection;

public class DoubleAdapter implements FieldAdapter {
   public boolean isInstance(Object var1) {
      return var1 instanceof Double;
   }

   public void setValue(ConfigurationSection var1, String var2, Object var3) {
      var1.set(var2, var3);
   }

   public Object getValue(ConfigurationSection var1, String var2) {
      return var1.getDouble(var2);
   }
}
