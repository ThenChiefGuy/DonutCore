package dev.daniboy.donutcore.config.typeadapters;

import org.bukkit.configuration.ConfigurationSection;

public class StringAdapter implements FieldAdapter {
   public boolean isInstance(Object var1) {
      return var1 instanceof String;
   }

   public void setValue(ConfigurationSection var1, String var2, Object var3) {
      var1.set(var2, var3);
   }

   public Object getValue(ConfigurationSection var1, String var2) {
      return var1.getString(var2);
   }
}
