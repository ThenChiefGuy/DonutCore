package dev.daniboy.donutcore.config.typeadapters;

import org.bukkit.configuration.ConfigurationSection;

public interface FieldAdapter {
   boolean isInstance(Object var1);

   void setValue(ConfigurationSection var1, String var2, Object var3);

   Object getValue(ConfigurationSection var1, String var2);
}
