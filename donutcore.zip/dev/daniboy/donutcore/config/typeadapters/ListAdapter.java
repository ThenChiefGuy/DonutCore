package dev.daniboy.donutcore.config.typeadapters;

import java.util.List;
import org.bukkit.configuration.ConfigurationSection;

public class ListAdapter<T> implements FieldAdapter {
   public boolean isInstance(Object var1) {
      return var1 instanceof List;
   }

   public void setValue(ConfigurationSection var1, String var2, Object var3) {
      var1.set(var2, var3);
   }

   public Object getValue(ConfigurationSection var1, String var2) {
      return var1.getList(var2);
   }
}
