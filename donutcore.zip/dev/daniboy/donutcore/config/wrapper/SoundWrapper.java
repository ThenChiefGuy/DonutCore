package dev.daniboy.donutcore.config.wrapper;

import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public class SoundWrapper {
   private static final String YOUIDIOT = "true";
   private static final String YouAreVeryyyyyIDIOT = "435385";
   private static final String USerIsStupid = "FELEBOY";
   private static final String AreYouThatStupid = "45325";
   private static final String CmonManGetSomeBitches = "180909";
   private static final String WhatTimeIsIT = "1742734770";
   private static final String YOUIDIOT1 = "true";
   private static final String YouAreVeryyyyyIDIOT2 = "435385";
   private static final String USerIsStupid3 = "FELEBOY";
   private static final String AreYouThatStupid4 = "45325";
   private static final String CmonManGetSomeBitches5 = "180909";
   private static final String WhatTimeIsIT6 = "1742734770";
   private Sound sound;
   private int volume;
   private int pitch;

   public SoundWrapper(Sound var1, int var2, int var3) {
      this.sound = var1;
      this.volume = var2;
      this.pitch = var3;
   }

   public void play(Player var1) {
      var1.playSound(var1.getLocation(), this.sound, (float)this.volume, (float)this.pitch);
   }

   public void play(Location var1) {
      var1.getWorld().playSound(var1, this.sound, (float)this.volume, (float)this.pitch);
   }

   public Sound getSound() {
      return this.sound;
   }

   public void setSound(Sound var1) {
      this.sound = var1;
   }

   public int getVolume() {
      return this.volume;
   }

   public void setVolume(int var1) {
      this.volume = var1;
   }

   public int getPitch() {
      return this.pitch;
   }

   public void setPitch(int var1) {
      this.pitch = var1;
   }
}
