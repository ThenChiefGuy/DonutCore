package dev.daniboy.donutcore.config;

import com.google.common.collect.Lists;
import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.typeadapters.BooleanAdapter;
import dev.daniboy.donutcore.config.typeadapters.DoubleAdapter;
import dev.daniboy.donutcore.config.typeadapters.FieldAdapter;
import dev.daniboy.donutcore.config.typeadapters.IntegerAdapter;
import dev.daniboy.donutcore.config.typeadapters.ListAdapter;
import dev.daniboy.donutcore.config.typeadapters.LongAdapter;
import dev.daniboy.donutcore.config.typeadapters.StringAdapter;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.Generated;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class ConfigManager {
   private final DonutCore plugin;
   private Map<String, FileConfiguration> configMap = new ConcurrentHashMap();
   private List<FieldAdapter> adapters = Lists.newArrayList(new FieldAdapter[]{new BooleanAdapter(), new DoubleAdapter(), new IntegerAdapter(), new ListAdapter(), new StringAdapter(), new LongAdapter()});
   private List<Class<? extends Config>> configs = new ArrayList();

   public ConfigManager(DonutCore var1) {
      this.plugin = var1;
   }

   public void reload() {
      this.configs.forEach(this::initReflectConfig);
   }

   public void register(Class<? extends Config> var1) {
      this.configs.add(var1);
      this.initReflectConfig(var1);
   }

   private void initReflectConfig(Class<? extends Config> var1) {
      ConfigClass var2 = (ConfigClass)var1.getAnnotation(ConfigClass.class);
      String var3 = var2.value();
      File var4 = new File(this.plugin.getDataFolder().toURI());
      if (!var4.exists()) {
         var4.mkdirs();
      }

      File var5;
      if (var3.contains("/")) {
         var5 = new File(this.plugin.getDataFolder(), var3.split("/")[0]);
         if (!var5.exists()) {
            var5.mkdirs();
         }
      }

      var5 = new File(this.plugin.getDataFolder(), var3);
      if (!var5.exists()) {
         try {
            var5.createNewFile();
         } catch (IOException var16) {
            throw new RuntimeException(var16);
         }
      }

      YamlConfiguration var6 = YamlConfiguration.loadConfiguration(var5);
      this.analyzeFields(var3, var1, var6);
      ArrayList var7 = new ArrayList(Arrays.stream(var1.getDeclaredClasses()).toList());
      Collections.reverse(var7);
      Class[] var8 = (Class[])var7.toArray(new Class[0]);
      int var9 = var8.length;

      for(int var10 = 0; var10 < var9; ++var10) {
         Class var11 = var8[var10];
         ConfigSection var12 = (ConfigSection)var11.getAnnotation(ConfigSection.class);
         if (var12 != null) {
            ConfigurationSection var13 = var6.get(var12.value()) == null ? var6.createSection(var12.value()) : var6.getConfigurationSection(var12.value());
            String[] var14 = var12.comments();
            if (var14.length != 0) {
               var6.setComments(var12.value(), Arrays.stream(var14).toList());
            }

            this.analyzeFields(var3, var11, var13);
         }
      }

      try {
         var6.save(var5);
      } catch (IOException var15) {
         var15.printStackTrace();
      }

   }

   public void analyzeFields(String var1, Class var2, ConfigurationSection var3) {
      Field[] var4 = var2.getDeclaredFields();
      int var5 = var4.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         Field var7 = var4[var6];
         var7.setAccessible(true);
         Class var8 = var7.getType();

         Object var9;
         try {
            var9 = var7.get((Object)null);
         } catch (IllegalAccessException var20) {
            throw new RuntimeException(var20);
         }

         if (var9 == null) {
            System.out.println("ERROR WHILE PARSING THE " + var1 + ".yml CLASS");
         } else {
            ConfigValue var10 = (ConfigValue)var7.getAnnotation(ConfigValue.class);
            String var11 = "";
            String[] var12 = null;
            boolean var13 = false;
            if (var10 != null) {
               var13 = var10.inline();
               var11 = var10.path();
               var12 = var10.comments().length == 0 ? null : var10.comments();
            } else {
               StringBuilder var14 = new StringBuilder();
               String[] var15 = var7.getName().split("_");
               int var16 = var15.length;

               for(int var17 = 0; var17 < var16; ++var17) {
                  String var18 = var15[var17];
                  var14.append(Character.toUpperCase(var18.charAt(0))).append(var18.substring(1).toLowerCase());
               }

               var11 = var14.toString();
            }

            Iterator var21;
            FieldAdapter var22;
            if (var3.get(var11) == null) {
               var21 = this.adapters.iterator();

               while(var21.hasNext()) {
                  var22 = (FieldAdapter)var21.next();
                  if (var22.isInstance(var9)) {
                     var22.setValue(var3, var11, var9);
                     break;
                  }
               }
            } else {
               var21 = this.adapters.iterator();

               while(var21.hasNext()) {
                  var22 = (FieldAdapter)var21.next();
                  if (var22.isInstance(var9)) {
                     try {
                        var7.set((Object)null, var22.getValue(var3, var11));
                        break;
                     } catch (IllegalAccessException var19) {
                        throw new RuntimeException(var19);
                     }
                  }
               }
            }

            if (var12 != null) {
               if (var13) {
                  var3.setInlineComments(var11, Arrays.stream(var12).toList());
               } else {
                  var3.setComments(var11, Arrays.stream(var12).toList());
               }
            }
         }
      }

   }

   @Generated
   public Map<String, FileConfiguration> getConfigMap() {
      return this.configMap;
   }
}
