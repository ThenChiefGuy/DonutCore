package dev.daniboy.donutcore.config;

public interface Config {
}
