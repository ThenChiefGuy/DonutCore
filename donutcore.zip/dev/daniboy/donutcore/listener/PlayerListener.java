package dev.daniboy.donutcore.listener;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.internal.platform.WorldGuardPlatform;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MainConfig;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.database.SQLiteManager;
import dev.daniboy.donutcore.gui.impl.SpawnGUI;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.scheduler.BukkitScheduler;

public class PlayerListener implements Listener {
   private final DonutCore plugin;
   private final SpawnGUI spawnGUI;
   private final SQLiteManager sqLiteManager;
   private static int WyyHu8EqkF;
   private transient int 6o9XbmDlpF;
   private static byte[] fwablzzmpp;
   private static String[] nothing_to_see_here = new String[15];

   public PlayerListener(DonutCore var1, SpawnGUI var2, SQLiteManager var3, int var4) {
      int var13 = 1368685719 ^ 1059328883;
      super();
      var13 = hexptuzeegejvbte(var13, 891817762);
      var13 = 1270036847 ^ 1514722754 ^ Integer.parseInt("1435864693") ^ var4;
      this.6o9XbmDlpF = 1982864312 ^ WyyHu8EqkF;

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var13)) {
         case 24600807:
            var13 ^= 496885488;
         case 1286793633:
            var13 ^= 112165920;
            this.plugin = var1;
            var13 ^= 252078816;
            this.spawnGUI = var2;
            var13 ^= 629987070;
            this.sqLiteManager = var3;
            var13 ^= 985686086;
            return;
         case 303623541:
         default:
            throw new IOException();
         case 2112746173:
         }
      }
   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent var1) {
      int var13 = 1752811357 ^ 155912145 ^ this.6o9XbmDlpF;
      var13 ^= 1075953480;
      HumanEntity var5 = var1.getPlayer();
      UUID var6 = var5.getUniqueId();
      Player var7 = Bukkit.getPlayer(var6);
      var13 ^= 1399625382;
      if (var7 != null) {
         var13 ^= 1236257859;
         DonutCore var10 = this.plugin;
         var10.clean$2056612436(var7, 350447023);
         var13 ^= 533601601;
      } else {
         var13 = hexptuzeegejvbte(var13, 595136486);
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var13) != 194178048) {
            var13 ^= 1239388243;
            throw new RuntimeException();
         }

         var13 ^= 1964564196;
      }

   }

   @EventHandler
   public void onQuit(PlayerQuitEvent var1) {
      int var10 = 1513404445 ^ 461806011 ^ this.6o9XbmDlpF;
      var10 ^= 888311591;
      Player var5 = var1.getPlayer();
      var10 ^= 812861450;
      DonutCore var7 = this.plugin;
      var7.clean$2056612436(var5, 350447023);
      var10 ^= 1763991781;
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onPlayerJoin(PlayerJoinEvent var1) {
      int var12 = 972716076 ^ 678295403 ^ this.6o9XbmDlpF;
      var12 ^= 481852109;
      Player var5 = var1.getPlayer();
      var12 ^= 485035162;
      byte var7 = var5.hasPlayedBefore();
      if (var7 == (407754527 ^ var12)) {
         var12 ^= 578585643;
         byte var8 = MainConfig.Spawn.ON_FIRSTJOIN;
         if (var8 != (976311092 ^ var12)) {
            var12 ^= 884855099;
            this.teleportToSpawn$423737497(var5, 1990303607);
            var12 ^= 712670741;
         } else {
            var12 ^= 941589900;
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var12) != 34335586) {
               var12 ^= 1800372332;
               throw new IOException();
            } else {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var12)) {
                  case 34335586:
                     var12 ^= 651700898;
                     return;
                  case 864060533:
                     return;
                  case 1944233142:
                  default:
                     throw new IOException();
                  case 2041573260:
                  }
               }
            }
         }
      } else {
         var12 ^= 687864987;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var12) == 240715005) {
            var12 = hexptuzeegejvbte(var12, 340055966);
         } else {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var12)) {
               case 26698384:
               case 124447288:
               default:
                  throw new IOException();
               case 240715005:
                  var12 ^= 1507032400;
                  throw new IOException();
               case 1115430869:
               }
            }
         }
      }
   }

   private void teleportToSpawn$423737497(Player var1, int var2) {
      int var36;
      label142: {
         var36 = 609433281 ^ 394016578 ^ this.6o9XbmDlpF ^ var2;
         var36 ^= 118428848;
         SQLiteManager var10 = this.sqLiteManager;
         Map var11 = var10.getSpawnNumber$1518350224(567915392);
         var36 ^= 758697879;
         if (var11 == null) {
            var36 ^= 1845111370;
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36) == 114554074) {
               var36 ^= 1154705122;
               break label142;
            }

            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36)) {
               case 114554074:
                  var36 ^= 48252661;
                  throw new IOException();
               case 313755027:
               case 634273559:
               default:
                  throw new IOException();
               case 865653365:
               }
            }
         } else {
            var36 ^= 745028356;
            byte var14 = var11.isEmpty();
            if (var14 != (1247432920 ^ var36)) {
               var36 ^= 88176556;
               break label142;
            }

            label131:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36)) {
               case 964344:
                  var36 ^= 1149394910;
                  break label131;
               case 183451125:
               default:
                  throw new IOException();
               case 524425196:
                  break label131;
               case 1135241230:
               }
            }

            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36) != 214078403) {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36)) {
                  case 91959754:
                     break;
                  case 214078403:
                     var36 ^= 133171301;
                     throw new IOException();
                  case 354648289:
                  case 1818115263:
                  default:
                     throw new IOException();
                  }
               }
            } else {
               label120:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36)) {
                  case 214078403:
                     var36 ^= 1996457065;
                  case 734603746:
                     break label120;
                  case 1166207076:
                     break;
                  case 1759159974:
                  default:
                     throw new IOException();
                  }
               }

               Collection var16 = var11.values();
               Iterator var17 = var16.iterator();
               Iterator var8 = var17;
               var36 ^= 1385740947;

               label110:
               while(true) {
                  byte var19 = var8.hasNext();
                  if (var19 == (717173244 ^ var36)) {
                     var36 ^= 885850430;
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36) == 184360965) {
                        var36 ^= 1776857223;
                        MessagesConfig var20 = MessagesConfig.SPAWNISFULL;
                        var20.send(var1);
                        var36 ^= 1074520840;
                        return;
                     }

                     var36 ^= 391788449;
                     break;
                  }

                  var36 ^= 851794626;
                  Object var22 = var8.next();
                  Location var23 = (Location)var22;
                  var36 ^= 949291608;
                  byte var25 = this.isSpawnFull$339080362(var23, 220528071);
                  if (var25 == (552558950 ^ var36)) {
                     var36 ^= 2042556714;
                     BukkitScheduler var26 = Bukkit.getScheduler();
                     DonutCore var31 = this.plugin;
                     Runnable var33 = () -> {
                        int var7 = 1935300546 ^ 1812051415 ^ WyyHu8EqkF;
                        var7 ^= 1840429391;
                        boolean var4 = var1.teleport(var23);
                        var7 ^= 565505815;
                     };
                     long var34 = 3L;
                     var26.runTaskLater(var31, var33, var34);
                     var36 ^= 1221373559;
                     return;
                  }

                  var36 ^= 2147388010;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36) != 137554038) {
                     var36 ^= 1446636655;
                     break;
                  }

                  var36 = hexptuzeegejvbte(var36, 327476805);

                  label87:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36)) {
                     case 19336410:
                     default:
                        throw new IOException();
                     case 73434408:
                        var36 ^= 65245188;
                        break label87;
                     case 901423860:
                        break;
                     case 1614454876:
                        break label87;
                     }
                  }

                  try {
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36) != 167092147) {
                        throw null;
                     }

                     throw new IOException();
                  } catch (IOException var37) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var36)) {
                     case -390896127:
                        var36 = hexptuzeegejvbte(var36, 101277456);
                        break;
                     case 2075454058:
                        var36 ^= 1953083037;
                        break;
                     default:
                        throw new RuntimeException("Error in hash");
                     }

                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36)) {
                        case 42749820:
                           var36 ^= 295698988;
                           continue label110;
                        case 337579148:
                           break;
                        case 429070065:
                        default:
                           throw new IOException();
                        case 1331913550:
                           continue label110;
                        }
                     }
                  }
               }
            }
         }

         throw new IOException();
      }

      MessagesConfig var28 = MessagesConfig.SPAWNNOTSET;
      var28.send(var1);
      var36 ^= 266128780;
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onPlayerRespawn(PlayerRespawnEvent var1) {
      int var23 = 2113004413 ^ 1339393916 ^ this.6o9XbmDlpF;
      var23 ^= 45434785;
      byte var2 = MainConfig.Spawn.ON_DEATH;
      if (var2 == (958008751 ^ var23)) {
         var23 ^= 1310882809;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23) == 117248638) {
            var23 = hexptuzeegejvbte(var23, 1374221768);
            return;
         }

         var23 = hexptuzeegejvbte(var23, 827771607);
      } else {
         var23 ^= 813466351;
         Player var9 = var1.getPlayer();
         var23 ^= 1654588296;
         Location var11 = this.getRespawnLocationForPlayer$982970030(var9, 766339543);
         var23 ^= 755883848;
         if (var11 != null) {
            var23 ^= 2014890439;
            var1.setRespawnLocation(var11);
            var23 ^= 105549735;
            BukkitScheduler var14 = Bukkit.getScheduler();
            DonutCore var18 = this.plugin;
            Runnable var19 = () -> {
               int var7 = 238983423 ^ 368979628 ^ WyyHu8EqkF;
               var7 ^= 2003685950;
               boolean var4 = var9.teleport(var11);
               var7 ^= 1755448149;
            };
            long var20 = 3L;
            var14.runTaskLater(var18, var19, var20);
            var23 ^= 511088254;
            return;
         }

         label35:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23)) {
            case 158934844:
               var23 ^= 651306560;
               break label35;
            case 810272159:
               break;
            case 1844088128:
               break label35;
            case 2133461308:
            default:
               throw new IOException();
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var23) == 172680194) {
            var23 ^= 1190590046;
            return;
         }

         var23 = hexptuzeegejvbte(var23, 642304321);
      }

      throw new IOException();
   }

   private Location getRespawnLocationForPlayer$982970030(Player var1, int var2) {
      int var27 = 616679962 ^ 1929189055 ^ this.6o9XbmDlpF ^ var2;
      var27 ^= 1007192668;
      SQLiteManager var8 = this.sqLiteManager;
      Map var9 = var8.getSpawnNumber$1518350224(567915392);
      var27 ^= 1025906951;
      if (var9 != null) {
         var27 ^= 173189110;
         byte var12 = var9.isEmpty();
         if (var12 == (2036772816 ^ var27)) {
            var27 ^= 1819163509;
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) != 146836215) {
               var27 = hexptuzeegejvbte(var27, 1647822536);
               throw new RuntimeException();
            }

            label88:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
               case 15247262:
                  break;
               case 146836215:
                  var27 ^= 781972607;
                  break label88;
               case 311404114:
               default:
                  throw new RuntimeException();
               case 2087246938:
                  break label88;
               }
            }

            Collection var15 = var9.values();
            Iterator var16 = var15.iterator();
            Iterator var6 = var16;
            var27 ^= 786539118;

            while(true) {
               byte var18 = var6.hasNext();
               if (var18 == (359842484 ^ var27)) {
                  var27 ^= 912829084;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) == 67308247) {
                     var27 = hexptuzeegejvbte(var27, 1292084353);
                     Object var25 = null;
                     return (Location)var25;
                  }

                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
                     case 67308247:
                        var27 ^= 1411725893;
                        throw new RuntimeException();
                     case 980150348:
                     case 1033802567:
                     default:
                        throw new RuntimeException();
                     case 1078754970:
                     }
                  }
               }

               var27 ^= 439047511;
               Object var20 = var6.next();
               Location var21 = (Location)var20;
               var27 ^= 1759167190;
               byte var23 = this.isSpawnFull$339080362(var21, 220528071);
               if (var23 == (1736660277 ^ var27)) {
                  var27 ^= 136162553;
                  return var21;
               }

               var27 ^= 1929341551;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) != 161525698) {
                  var27 ^= 1648586039;
                  throw new RuntimeException();
               }

               var27 = hexptuzeegejvbte(var27, 533703837);

               label70:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
                  case 79422690:
                     var27 ^= 560267306;
                  case 312501207:
                     break label70;
                  case 413544993:
                  default:
                     throw new RuntimeException();
                  case 1474160580:
                  }
               }

               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) != 82810189) {
                     throw null;
                  }

                  throw new IllegalAccessException();
               } catch (IllegalAccessException var28) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var27)) {
                  case -630884045:
                     var27 ^= 1525430678;
                     break;
                  case 1588895593:
                     var27 = hexptuzeegejvbte(var27, 175506781);
                     break;
                  default:
                     throw new IllegalAccessException("Error in hash");
                  }

                  var27 ^= 886199300;
               }
            }
         }

         var27 ^= 1780832786;
      } else {
         var27 ^= 1904992176;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) != 43243683) {
            var27 ^= 1971357179;
            throw new RuntimeException();
         }

         var27 ^= 301736532;
      }

      Object var13 = null;
      return (Location)var13;
   }

   private boolean isSpawnFull$339080362(Location var1, int var2) {
      int var53 = 812946537 ^ 1782127299 ^ this.6o9XbmDlpF ^ var2;
      var53 ^= 888387638;
      WorldGuard var3 = WorldGuard.getInstance();
      WorldGuardPlatform var12 = var3.getPlatform();
      RegionContainer var13 = var12.getRegionContainer();
      var53 ^= 2136404740;
      World var42 = var1.getWorld();
      com.sk89q.worldedit.world.World var43 = BukkitAdapter.adapt(var42);
      RegionManager var15 = var13.get(var43);
      var53 ^= 1781556515;
      if (var15 == null) {
         var53 ^= 446996003;
         byte var17 = (byte)(1708387664 ^ var53);
         return (boolean)var17;
      } else {
         var53 = hexptuzeegejvbte(var53, 100671843);
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53) != 190273416) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53)) {
               case 190273416:
                  var53 ^= 1660853068;
                  throw new RuntimeException();
               case 343949362:
               case 511556262:
               default:
                  throw new RuntimeException();
               case 1396569565:
               }
            }
         } else {
            var53 = hexptuzeegejvbte(var53, 888353484);
            byte var18 = (byte)(1300521180 ^ var53);
            int var7 = var18;
            var53 ^= 736854561;
            BlockVector3 var45 = BukkitAdapter.asBlockVector(var1);
            ApplicableRegionSet var20 = var15.getApplicableRegions(var45);
            Iterator var21 = var20.iterator();
            Iterator var8 = var21;
            var53 ^= 537311936;

            while(true) {
               byte var23 = var8.hasNext();
               if (var23 == (1181308989 ^ var53)) {
                  var53 ^= 1460988589;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53) != 31692938) {
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53)) {
                        case 15067276:
                        case 887643107:
                        default:
                           throw new RuntimeException();
                        case 31692938:
                           var53 ^= 183794636;
                           throw new RuntimeException();
                        case 886099150:
                        }
                     }
                  }

                  var53 = hexptuzeegejvbte(var53, 1729784316);
                  DonutCore var25 = this.plugin;
                  FileConfiguration var26 = var25.getafkSpawnGuiConfig$23715181(125321510);
                  String var46 = pkyoclpqtm(rlcabcpfpdrrjer(), var53);
                  int var27 = var26.getInt(var46);
                  var53 ^= 1256221528;
                  byte var29;
                  if (var7 >= var27) {
                     var53 ^= 1074691920;
                     var29 = (byte)(2089406309 ^ var53);

                     label122:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53)) {
                        case 21724504:
                           var53 ^= 289933586;
                        case 853397725:
                           break label122;
                        case 951406487:
                           break;
                        case 2005030724:
                        default:
                           throw new RuntimeException();
                        }
                     }

                     try {
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53) != 78060869) {
                           throw null;
                        }

                        throw new IllegalAccessException();
                     } catch (IllegalAccessException var54) {
                        switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var53)) {
                        case -961003406:
                           var53 = hexptuzeegejvbte(var53, 1330865818);
                           break;
                        case 1846424499:
                           var53 = hexptuzeegejvbte(var53, 2051385570);
                           break;
                        default:
                           throw new RuntimeException("Error in hash");
                        }
                     }

                     var53 ^= 1279549710;
                  } else {
                     label144:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53)) {
                        case 88529379:
                           var53 ^= 807205792;
                           break label144;
                        case 205613099:
                           break;
                        case 1274656811:
                           break label144;
                        case 1630965635:
                        default:
                           throw new RuntimeException();
                        }
                     }

                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53) != 141356789) {
                        var53 = hexptuzeegejvbte(var53, 387089096);
                        throw new RuntimeException();
                     }

                     label133:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53)) {
                        case 141356789:
                           var53 ^= 1045763750;
                        case 840945693:
                           break label133;
                        case 1064284028:
                        default:
                           throw new RuntimeException();
                        case 2126591678:
                        }
                     }

                     var29 = (byte)(852385074 ^ var53);
                     var53 ^= 1762546344;
                  }

                  return (boolean)var29;
               }

               var53 ^= 605865992;
               Object var31 = var8.next();
               ProtectedRegion var32 = (ProtectedRegion)var31;
               ProtectedRegion var9 = var32;
               var53 ^= 329923137;
               Collection var33 = Bukkit.getOnlinePlayers();
               Iterator var34 = var33.iterator();
               Iterator var10 = var34;
               var53 ^= 481932563;

               while(true) {
                  byte var36 = var10.hasNext();
                  if (var36 == (1835409255 ^ var53)) {
                     label179:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53)) {
                        case 66433457:
                           var53 ^= 782296584;
                        case 101338581:
                           break label179;
                        case 436936348:
                        default:
                           throw new RuntimeException();
                        case 904412127:
                        }
                     }

                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53) != 55689345) {
                        var53 = hexptuzeegejvbte(var53, 1481584691);
                        throw new RuntimeException();
                     }

                     label168:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53)) {
                        case 55689345:
                           var53 ^= 1604333229;
                           break label168;
                        case 942877124:
                           break;
                        case 1457767836:
                        default:
                           throw new RuntimeException();
                        case 1515940694:
                           break label168;
                        }
                     }

                     label159:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53)) {
                        case 117923425:
                           var53 ^= 383424833;
                        case 589303920:
                           break label159;
                        case 989685628:
                        default:
                           throw new RuntimeException();
                        case 1643140027:
                        }
                     }

                     try {
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53) != 80532129) {
                           throw null;
                        }

                        throw new RuntimeException();
                     } catch (RuntimeException var55) {
                        switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var53)) {
                        case 255610379:
                           var53 ^= 1655773694;
                           break;
                        case 1440904216:
                           var53 ^= 166387388;
                           break;
                        default:
                           throw new IllegalAccessException("Error in hash");
                        }

                        var53 = hexptuzeegejvbte(var53, 1161807874);
                        break;
                     }
                  }

                  var53 ^= 1385251091;
                  Object var38 = var10.next();
                  Player var39 = (Player)var38;
                  var53 ^= 1017719657;
                  Location var49 = var39.getLocation();
                  BlockVector3 var50 = BukkitAdapter.asBlockVector(var49);
                  byte var41 = var9.contains(var50);
                  if (var41 != (56522013 ^ var53)) {
                     var53 ^= 397440669;
                     var7 += 351142785 ^ var53;
                     var53 ^= 556807646;
                  } else {
                     label200:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53)) {
                        case 52989589:
                           var53 ^= 174328858;
                        case 456580219:
                           break label200;
                        case 1237075265:
                        default:
                           throw new RuntimeException();
                        case 2056459887:
                        }
                     }

                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53) != 31540039) {
                        var53 ^= 313765979;
                        throw new RuntimeException();
                     }

                     var53 ^= 1021595481;
                  }

                  var53 = hexptuzeegejvbte(var53, 1543456184);

                  try {
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var53) != 90226348) {
                        throw null;
                     }

                     throw new IllegalAccessException();
                  } catch (IllegalAccessException var56) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var53)) {
                     case 1440820537:
                        var53 ^= 949256285;
                        break;
                     case 1896587059:
                        var53 ^= 2081019420;
                        break;
                     default:
                        throw new IOException("Error in hash");
                     }

                     var53 ^= 2135866013;
                  }
               }
            }
         }
      }
   }

   static {
      nothing_to_see_here[0] = "⠄⠄⠄⢰⣧⣼⣯⠄⣸⣠⣶⣶⣦⣾⠄⠄⠄⠄⡀⠄⢀⣿⣿⠄⠄⠄⢸⡇⠄⠄";
      nothing_to_see_here[1] = "⠄⠄⠄⣾⣿⠿⠿⠶⠿⢿⣿⣿⣿⣿⣦⣤⣄⢀⡅⢠⣾⣛⡉⠄⠄⠄⠸⢀⣿⠄";
      nothing_to_see_here[2] = "⠄⠄⢀⡋⣡⣴⣶⣶⡀⠄⠄⠙⢿⣿⣿⣿⣿⣿⣴⣿⣿⣿⢃⣤⣄⣀⣥⣿⣿⠄";
      nothing_to_see_here[3] = "⠄⠄⢸⣇⠻⣿⣿⣿⣧⣀⢀⣠⡌⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿⣿⣿⣿⠄";
      nothing_to_see_here[4] = "⠄⢀⢸⣿⣷⣤⣤⣤⣬⣙⣛⢿⣿⣿⣿⣿⣿⣿⡿⣿⣿⡍⠄⠄⢀⣤⣄⠉⠋⣰";
      nothing_to_see_here[5] = "⠄⣼⣖⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⢇⣿⣿⡷⠶⠶⢿⣿⣿⠇⢀⣤";
      nothing_to_see_here[6] = "⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣽⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣷⣶⣥⣴⣿⡗";
      nothing_to_see_here[7] = "⢀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠄";
      nothing_to_see_here[8] = "⢸⣿⣦⣌⣛⣻⣿⣿⣧⠙⠛⠛⡭⠅⠒⠦⠭⣭⡻⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠄";
      nothing_to_see_here[9] = "⠘⣿⣿⣿⣿⣿⣿⣿⣿⡆⠄⠄⠄⠄⠄⠄⠄⠄⠹⠈⢋⣽⣿⣿⣿⣿⣵⣾⠃⠄";
      nothing_to_see_here[10] = "⠄⠘⣿⣿⣿⣿⣿⣿⣿⣿⠄⣴⣿⣶⣄⠄⣴⣶⠄⢀⣾⣿⣿⣿⣿⣿⣿⠃⠄⠄";
      nothing_to_see_here[11] = "⠄⠄⠈⠻⣿⣿⣿⣿⣿⣿⡄⢻⣿⣿⣿⠄⣿⣿⡀⣾⣿⣿⣿⣿⣛⠛⠁⠄⠄⠄";
      nothing_to_see_here[12] = "⠄⠄⠄⠄⠈⠛⢿⣿⣿⣿⠁⠞⢿⣿⣿⡄⢿⣿⡇⣸⣿⣿⠿⠛⠁⠄⠄⠄⠄⠄";
      nothing_to_see_here[13] = "⠄⠄⠄⠄⠄⠄⠄⠉⠻⣿⣿⣾⣦⡙⠻⣷⣾⣿⠃⠿⠋⠁⠄⠄⠄⠄⠄⢀⣠⣴";
      nothing_to_see_here[14] = "⣿⣿⣿⣶⣶⣮⣥⣒⠲⢮⣝⡿⣿⣿⡆⣿⡿⠃⠄⠄⠄⠄⠄⠄⠄⣠⣴⣿⣿⣿";
      fwablzzmpp = thkkjbdxozlobvp();
      int var3 = (new Random(1700577311106956874L)).nextInt();
      WyyHu8EqkF = -172701754 ^ var3;
   }

   public static String pkyoclpqtm(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = fwablzzmpp;
         byte[] var34 = fwablzzmpp;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] thkkjbdxozlobvp() {
      return new byte[]{124, 124, 99, 61, 47, 49, 60, 66, 30, 101, 73, 73, 37, 110, 101, 44, 81, 101, 98, 45, 95};
   }

   private static byte[] rlcabcpfpdrrjer() {
      return new byte[]{-77, -70, 91, 120, 26, 112, 11, 27, 40, 42, 120, 30, 29, 7, 80, 122, 102, 40, 84, 124, 110, 107, 68, 56, 8, 127, 6, 124, 116, 121, 84, 0, 113, 127, 91, 53, 27, 16, 83, 63, 28, 20, 68, 57};
   }

   private static int hexptuzeegejvbte(int var0, int var1) {
      return var1 ^ var0;
   }
}
