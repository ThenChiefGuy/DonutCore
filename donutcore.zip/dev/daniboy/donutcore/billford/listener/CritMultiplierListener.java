package dev.daniboy.donutcore.billford.listener;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.config.SoundConfig;
import dev.daniboy.donutcore.config.wrapper.SoundWrapper;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitScheduler;

public class CritMultiplierListener implements Listener {
   private DonutCore plugin;
   private HashMap<UUID, Long> cooldowns;
   private static int VWB2bN7dRE;
   private transient int gGPP3Mm03c;
   private static byte[] mnpxjolvrb;
   private static String[] nothing_to_see_here = new String[17];

   public CritMultiplierListener(DonutCore var1, int var2) {
      int var9 = 697527901 ^ 518568714;
      super();
      var9 ^= 701709692;
      var9 = 1164968502 ^ 618671290 ^ Integer.parseInt("260115619") ^ var2;
      this.gGPP3Mm03c = 2027548951 ^ VWB2bN7dRE;

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var9)) {
         case 191324027:
            var9 ^= 1949068920;
         case 94495728:
            var9 ^= 1438196228;
            HashMap var4 = new HashMap();
            this.cooldowns = var4;
            var9 ^= 939362068;
            this.plugin = var1;
            var9 ^= 164238532;
            return;
         case 1669151777:
         default:
            throw new IllegalAccessException();
         case 1825048126:
         }
      }
   }

   @EventHandler
   public void onPlayerInteract(PlayerInteractEvent var1) {
      int var161 = 2058818176 ^ 1557989670 ^ this.gGPP3Mm03c;
      var161 ^= 1632548989;
      final Player var15 = var1.getPlayer();
      var161 ^= 958228349;
      ItemStack var17 = var1.getItem();
      var161 ^= 1170698224;
      if (var17 != null) {
         var161 ^= 1642921565;
         byte var20 = var17.hasItemMeta();
         if (var20 != (1176451681 ^ var161)) {
            var161 ^= 1055513839;
            ItemMeta var22 = var17.getItemMeta();
            PersistentDataContainer var23 = var22.getPersistentDataContainer();
            DonutCore var132 = this.plugin;
            String var5 = tmvemkyftf(uopghdxwhxfnubi(), var161);
            NamespacedKey var3 = new NamespacedKey(var132, var5);
            PersistentDataType var106 = PersistentDataType.STRING;
            byte var24 = var23.has(var3, var106);
            if (var24 != (2029446798 ^ var161)) {
               var161 ^= 1952633653;
               String var81 = tmvemkyftf(yjlmqgvqywsaasg(), var161);
               byte var26 = var15.hasMetadata(var81);
               if (var26 != (211039675 ^ var161)) {
                  var161 ^= 1936384475;
                  MessagesConfig var27 = MessagesConfig.CRITMULTIPLERACTIVE;
                  var27.send(var15);
                  var161 ^= 1216911476;
                  SoundWrapper var28 = SoundConfig.CRITMULTIPLIERACTIVE;
                  var28.play(var15);
                  var161 ^= 2009762560;
                  return;
               }

               var161 ^= 1672685496;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161) != 123461058) {
                  var161 ^= 500902687;
               } else {
                  label104:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161)) {
                     case 123461058:
                        var161 ^= 790424678;
                     case 595469826:
                        break label104;
                     case 1279264188:
                        break;
                     case 1860642635:
                     default:
                        throw new IOException();
                     }
                  }

                  DonutCore var30 = this.plugin;
                  FileConfiguration var31 = var30.getBillfordGuiConfig$756205206(1840850862);
                  String var84 = tmvemkyftf(grbegedszpfgmll(), var161);
                  long var32 = var31.getLong(var84);
                  long var107 = 1000L;
                  long var34 = var32 * var107;
                  var161 ^= 1200729219;
                  HashMap var37 = this.cooldowns;
                  UUID var86 = var15.getUniqueId();
                  byte var38 = var37.containsKey(var86);
                  if (var38 != (128602854 ^ var161)) {
                     var161 ^= 1254275642;
                     HashMap var40 = this.cooldowns;
                     UUID var88 = var15.getUniqueId();
                     Object var41 = var40.get(var88);
                     Long var42 = (Long)var41;
                     long var43 = var42;
                     long var45 = var43 + var34;
                     long var111 = System.currentTimeMillis();
                     long var47 = var45 - var111;
                     var161 ^= 108085017;
                     long var113 = 0L;
                     long var162;
                     int var51 = (var162 = var47 - var113) == 0L ? 0 : (var162 < 0L ? -1 : 1);
                     if (var51 > (1259984837 ^ var161)) {
                        var161 ^= 345331093;
                        MessagesConfig var52 = MessagesConfig.CRITMULTIPLIERCOOLDOWN;
                        String var53 = var52.getSingleMessage();
                        String var89 = tmvemkyftf(idnjhtdhoftyjds(), var161);
                        long var144 = 1000L;
                        long var117 = var47 / var144;
                        String var119 = String.valueOf(var117);
                        String var54 = var53.replace(var89, var119);
                        var161 ^= 34312430;
                        var15.sendMessage(var54);
                        var161 ^= 1046110742;
                        MessagesConfig var56 = MessagesConfig.CRITMULTIPLIERCOOLDOWN;
                        var56.sendActionBar(var15);
                        var161 ^= 1741662331;
                        SoundWrapper var57 = SoundConfig.CRITMULTIPLIERCOOLDOWN;
                        var57.play(var15);
                        var161 ^= 232570140;
                        return;
                     }

                     var161 = vbmqmudythifskmq(var161, 250727884);
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161) != 124909465) {
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161)) {
                           case 124909465:
                              var161 ^= 924066581;
                              throw new IOException();
                           case 605761002:
                           case 1113677427:
                           default:
                              throw new IOException();
                           case 1347422158:
                           }
                        }
                     }

                     var161 = vbmqmudythifskmq(var161, 186755110);
                  } else {
                     label92:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161)) {
                        case 120564253:
                           var161 ^= 731840873;
                           break label92;
                        case 411400150:
                           break;
                        case 1281859787:
                        default:
                           throw new IOException();
                        case 1417390242:
                           break label92;
                        }
                     }

                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161) != 94862800) {
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161)) {
                           case 94862800:
                              var161 ^= 1590258323;
                              throw new IOException();
                           case 393502653:
                           case 828760173:
                           default:
                              throw new IOException();
                           case 1743145187:
                           }
                        }
                     }

                     label82:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161)) {
                        case 94862800:
                           var161 ^= 1660740000;
                           break label82;
                        case 412682411:
                        default:
                           throw new IOException();
                        case 987130955:
                           break;
                        case 990948738:
                           break label82;
                        }
                     }
                  }

                  HashMap var59 = this.cooldowns;
                  UUID var94 = var15.getUniqueId();
                  long var120 = System.currentTimeMillis();
                  Long var122 = var120;
                  var59.put(var94, var122);
                  var161 ^= 866463828;
                  int var96 = var17.getAmount();
                  byte var123 = (byte)(2104263290 ^ var161);
                  int var97 = var96 - var123;
                  var17.setAmount(var97);
                  var161 ^= 199961958;
                  ItemMeta var63 = var17.getItemMeta();
                  PersistentDataContainer var64 = var63.getPersistentDataContainer();
                  DonutCore var134 = this.plugin;
                  String var146 = tmvemkyftf(mbguqzpbnryzocw(), var161);
                  NamespacedKey var98 = new NamespacedKey(var134, var146);
                  PersistentDataType var124 = PersistentDataType.DOUBLE;
                  Object var65 = var64.get(var98, var124);
                  Double var66 = (Double)var65;
                  double var67 = var66;
                  var161 ^= 1071642031;
                  ItemMeta var70 = var17.getItemMeta();
                  PersistentDataContainer var71 = var70.getPersistentDataContainer();
                  DonutCore var136 = this.plugin;
                  String var147 = tmvemkyftf(dwenzlmwclajnvl(), var161);
                  NamespacedKey var99 = new NamespacedKey(var136, var147);
                  PersistentDataType var125 = PersistentDataType.INTEGER;
                  Object var72 = var71.get(var99, var125);
                  Integer var73 = (Integer)var72;
                  final int var74 = var73;
                  var161 ^= 614987906;
                  String var100 = tmvemkyftf(yvzilmjvyptqjwt(), var161);
                  DonutCore var149 = this.plugin;
                  Double var153 = var67;
                  FixedMetadataValue var126 = new FixedMetadataValue(var149, var153);
                  var15.setMetadata(var100, var126);
                  var161 ^= 1945778895;
                  SoundWrapper var76 = SoundConfig.CRITMULTIPLIERACTIVATED;
                  var76.play(var15);
                  var161 ^= 1546280174;
                  BukkitRunnable var77 = new BukkitRunnable(1403651359) {
                     int remainingDuration;
                     private static int K8cgQ6JdHk;
                     private transient int CbRB7Nk9VR;
                     private static String mimycpafqd;
                     private static String[] nothing_to_see_here = new String[17];

                     {
                        int var16 = 1897412479 ^ 1930325922;
                        var16 ^= 1556132517;
                        var16 = 2068793781 ^ 739273015 ^ Integer.parseInt("1512296421") ^ var4;
                        this.CbRB7Nk9VR = 1241799326 ^ K8cgQ6JdHk;

                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var16)) {
                           case 130037918:
                              var16 ^= 669278770;
                           case 57888482:
                              var16 ^= 858950689;
                              int var14 = var74;
                              this.remainingDuration = var14;
                              var16 ^= 662248167;
                              return;
                           case 939805410:
                              break;
                           case 1478333213:
                           default:
                              throw new RuntimeException();
                           }
                        }
                     }

                     public void run() {
                        int var27 = 1846884840 ^ 1032516239 ^ this.CbRB7Nk9VR;
                        var27 ^= 1162390505;
                        int var6 = this.remainingDuration;
                        if (var6 <= (417916123 ^ var27)) {
                           var27 ^= 561879832;
                           this.cancel();
                           var27 ^= 1239398985;
                           Player var9 = var15;
                           String var2 = epwmlfolgh(uzohkntzyysafkm(), var27);
                           CritMultiplierListener var16 = CritMultiplierListener.this;
                           DonutCore var17 = var16.plugin;
                           var9.removeMetadata(var2, var17);
                           var27 ^= 1552043581;

                           try {
                              if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) != 113549946) {
                                 throw null;
                              }

                              throw new RuntimeException();
                           } catch (RuntimeException var28) {
                              switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var27)) {
                              case 639989376:
                                 var27 = remjxkmfpgqfotmi(var27, 1555251269);
                                 break;
                              case 1715756473:
                                 var27 = remjxkmfpgqfotmi(var27, 1958700322);
                                 break;
                              default:
                                 throw new RuntimeException("Error in hash");
                              }

                              var27 ^= 77508680;
                           }
                        } else {
                           var27 ^= 2143312526;
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) != 132028396) {
                              while(true) {
                                 switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
                                 case 132028396:
                                    var27 ^= 1218849759;
                                    throw new RuntimeException();
                                 case 354680827:
                                 case 1007302957:
                                 default:
                                    throw new RuntimeException();
                                 case 1477804829:
                                 }
                              }
                           }

                           var27 ^= 1466092647;
                           MessagesConfig var10 = MessagesConfig.CRITMULTIPLER;
                           Player var13 = var15;
                           byte var18 = (byte)(810185264 ^ var27);
                           String[] var19 = new String[var18];
                           byte var4 = (byte)(810185266 ^ var27);
                           String var5 = epwmlfolgh(ogkhagngpuahcea(), var27);
                           var19[var4] = var5;
                           byte var21 = (byte)(810185267 ^ var27);
                           int var23 = this.remainingDuration;
                           String var24 = String.valueOf(var23);
                           var19[var21] = var24;
                           var10.sendActionBar(var13, var19);
                           var27 ^= 1536951903;
                           int var14 = this.remainingDuration;
                           byte var20 = (byte)(1809216620 ^ var27);
                           int var15x = var14 - var20;
                           this.remainingDuration = var15x;
                           var27 ^= 926886576;
                        }

                     }

                     static {
                        nothing_to_see_here[0] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⣀⣠⣤⣶⣶⣶⣤⣄⣀⣀⠄⠄⠄⠄⠄";
                        nothing_to_see_here[1] = "⠄⠄⠄⠄⠄⠄⠄⠄⣀⣤⣤⣶⣿⣿⣿⣿⣿⣿⣿⣟⢿⣿⣿⣿⣶⣤⡀⠄";
                        nothing_to_see_here[2] = "⠄⠄⠄⠄⠄⠄⢀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣜⠿⠿⣿⣿⣧⢓";
                        nothing_to_see_here[3] = "⠄⠄⠄⠄⠄⡠⢛⣿⣿⣿⡟⣿⣿⣽⣋⠻⢻⣿⣿⣿⣿⡻⣧⡠⣭⣭⣿⡧";
                        nothing_to_see_here[4] = "⠄⠄⠄⠄⠄⢠⣿⡟⣿⢻⠃⣻⣨⣻⠿⡀⣝⡿⣿⣿⣷⣜⣜⢿⣝⡿⡻⢔";
                        nothing_to_see_here[5] = "⠄⠄⠄⠄⠄⢸⡟⣷⢿⢈⣚⣓⡡⣻⣿⣶⣬⣛⣓⣉⡻⢿⣎⠢⠻⣴⡾⠫";
                        nothing_to_see_here[6] = "⠄⠄⠄⠄⠄⢸⠃⢹⡼⢸⣿⣿⣿⣦⣹⣿⣿⣿⠿⠿⠿⠷⣎⡼⠆⣿⠵⣫";
                        nothing_to_see_here[7] = "⠄⠄⠄⠄⠄⠈⠄⠸⡟⡜⣩⡄⠄⣿⣿⣿⣿⣶⢀⢀⣿⣷⣿⣿⡐⡇⡄⣿";
                        nothing_to_see_here[8] = "⠄⠄⠄⠄⠄⠄⠄⠄⠁⢶⢻⣧⣖⣿⣿⣿⣿⣿⣿⣿⣿⡏⣿⣇⡟⣇⣷⣿";
                        nothing_to_see_here[9] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⣆⣤⣽⣿⡿⠿⠿⣿⣿⣦⣴⡇⣿⢨⣾⣿⢹⢸";
                        nothing_to_see_here[10] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⣿⠊⡛⢿⣿⣿⣿⣿⡿⣫⢱⢺⡇⡏⣿⣿⣸⡼";
                        nothing_to_see_here[11] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⡿⠄⣿⣷⣾⡍⣭⣶⣿⣿⡌⣼⣹⢱⠹⣿⣇⣧";
                        nothing_to_see_here[12] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⣼⠁⣤⣭⣭⡌⢁⣼⣿⣿⣿⢹⡇⣭⣤⣶⣤⡝⡼";
                        nothing_to_see_here[13] = "⠄⣀⠤⡀⠄⠄⠄⠄⠄⡏⣈⡻⡿⠃⢀⣾⣿⣿⣿⡿⡼⠁⣿⣿⣿⡿⢷⢸";
                        nothing_to_see_here[14] = "⢰⣷⡧⡢⠄⠄⠄⠄⠠⢠⡛⠿⠄⠠⠬⠿⣿⠭⠭⢱⣇⣀⣭⡅⠶⣾⣷⣶";
                        nothing_to_see_here[15] = "⠈⢿⣿⣧⠄⠄⠄⠄⢀⡛⠿⠄⠄⠄⠄⢠⠃⠄⠄⡜⠄⠄⣤⢀⣶⣮⡍⣴";
                        nothing_to_see_here[16] = "⠄⠈⣿⣿⡀⠄⠄⠄⢩⣝⠃⠄⠄⢀⡄⡎⠄⠄⠄⠇⠄⠄⠅⣴⣶⣶⠄⣶";
                        mimycpafqd = ByteBuffer.wrap(ukwogojxphomirc()).asCharBuffer().toString();
                        int var3 = (new Random(-7602760997452512877L)).nextInt();
                        K8cgQ6JdHk = -271586127 ^ var3;
                     }

                     public static String epwmlfolgh(byte[] var0, int var1) {
                        String var13 = Integer.toString(var1);
                        byte[] var14 = var13.getBytes();
                        byte[] var8 = var14;
                        byte var3 = 0;
                        byte var16 = var0[var3];
                        short var36 = 255;
                        int var17 = var16 & var36;
                        byte var37 = 24;
                        int var18 = var17 << var37;
                        byte var4 = 1;
                        byte var39 = var0[var4];
                        short var68 = 255;
                        int var40 = var39 & var68;
                        byte var69 = 16;
                        int var41 = var40 << var69;
                        int var19 = var18 | var41;
                        byte var70 = 2;
                        byte var43 = var0[var70];
                        short var71 = 255;
                        int var44 = var43 & var71;
                        byte var72 = 8;
                        int var45 = var44 << var72;
                        int var20 = var19 | var45;
                        byte var73 = 3;
                        byte var47 = var0[var73];
                        short var74x = 255;
                        int var48 = var47 & var74x;
                        int var21 = var20 | var48;
                        byte var49 = 4;
                        byte var23 = var0[var49];
                        short var50 = 255;
                        int var24 = var23 & var50;
                        byte var51 = 24;
                        int var25 = var24 << var51;
                        byte var75 = 5;
                        byte var53 = var0[var75];
                        short var76 = 255;
                        int var54 = var53 & var76;
                        byte var77 = 16;
                        int var55 = var54 << var77;
                        int var26 = var25 | var55;
                        byte var78 = 6;
                        byte var57 = var0[var78];
                        short var79 = 255;
                        int var58 = var57 & var79;
                        byte var80 = 8;
                        int var59 = var58 << var80;
                        int var27 = var26 | var59;
                        byte var81 = 7;
                        byte var61 = var0[var81];
                        short var82 = 255;
                        int var62 = var61 & var82;
                        int var28 = var27 | var62;
                        String var29 = mimycpafqd;
                        int var84 = var28 + var21;
                        String var30 = var29.substring(var28, var84);
                        Charset var64 = StandardCharsets.UTF_16BE;
                        byte[] var31 = var30.getBytes(var64);
                        byte[] var11 = var31;
                        byte var32 = 0;
                        int var12 = var32;

                        while(true) {
                           int var66 = var11.length;
                           if (var12 >= var66) {
                              Charset var91 = StandardCharsets.UTF_16BE;
                              String var35 = new String(var11, var91);
                              return var35;
                           }

                           byte var85 = var11[var12];
                           int var93 = var8.length;
                           int var92 = var12 % var93;
                           byte var90 = var8[var92];
                           int var86 = var85 ^ var90;
                           byte var87 = (byte)var86;
                           var11[var12] = var87;
                           ++var12;
                        }
                     }

                     private static byte[] ogkhagngpuahcea() {
                        return new byte[]{0, 0, 0, 9, 0, 0, 0, 0};
                     }

                     private static byte[] uzohkntzyysafkm() {
                        return new byte[]{0, 0, 0, 14, 0, 0, 0, 9};
                     }

                     private static byte[] ukwogojxphomirc() {
                        return new byte[]{56, 82, 48, 94, 56, 64, 50, 88, 54, 76, 49, 84, 49, 87, 53, 69, 54, 88, 49, 123, 56, 65, 57, 93, 56, 64, 50, 123, 49, 77, 56, 95, 57, 64, 56, 93, 50, 70, 49, 84, 56, 90, 57, 81, 56, 70};
                     }

                     private static int remjxkmfpgqfotmi(int var0, int var1) {
                        return var0 ^ var1;
                     }
                  };
                  DonutCore var103 = this.plugin;
                  long var128 = 0L;
                  long var151 = 20L;
                  var161 ^= 258346402;
                  var77.runTaskTimer(var103, var128, var151);
                  var161 ^= 573887462;
                  BukkitScheduler var79 = Bukkit.getScheduler();
                  DonutCore var105 = this.plugin;
                  Runnable var131 = () -> {
                     int var8 = 1372893901 ^ 375460325 ^ this.gGPP3Mm03c;
                     var8 ^= 344408017;
                     String var3 = tmvemkyftf(gbgiyilywaotbqg(), var8);
                     DonutCore var5 = this.plugin;
                     var15.removeMetadata(var3, var5);
                  };
                  long var140 = (long)var74;
                  long var154 = 20L;
                  long var142 = var140 * var154;
                  var79.runTaskLater(var105, var131, var142);
                  var161 ^= 1532711829;
                  return;
               }
            } else {
               var161 ^= 1824710448;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161) == 119880660) {
                  var161 = vbmqmudythifskmq(var161, 538079358);
                  return;
               }

               var161 ^= 1724383394;
            }
         } else {
            var161 = vbmqmudythifskmq(var161, 605831417);
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161) == 233234309) {
               var161 ^= 1445278552;
               return;
            }

            var161 = vbmqmudythifskmq(var161, 285164420);
         }
      } else {
         var161 = vbmqmudythifskmq(var161, 441115124);
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161) != 127304842) {
            var161 = vbmqmudythifskmq(var161, 1329929428);
         } else {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161)) {
               case 127304842:
                  var161 ^= 161442824;
                  return;
               case 1376235760:
                  return;
               case 1775594074:
               default:
                  throw new IOException();
               case 1794113426:
               }
            }
         }
      }

      throw new IOException();
   }

   @EventHandler
   public void onEntityDamageByEntity(EntityDamageByEntityEvent var1) {
      int var30 = 570687019 ^ 746453015 ^ this.gGPP3Mm03c;
      var30 ^= 541853682;
      Entity var8 = var1.getDamager();
      byte var9 = var8 instanceof Player;
      if (var9 == (843017892 ^ var30)) {
         var30 ^= 1791866342;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var30) == 207015997) {
            var30 ^= 45489692;
            return;
         }

         var30 ^= 5347555;
      } else {
         var30 ^= 1300814377;
         Entity var11 = var1.getDamager();
         Player var12 = (Player)var11;
         var30 ^= 661901478;
         String var21 = tmvemkyftf(vsydaymrtphfgko(), var30);
         byte var13 = var12.hasMetadata(var21);
         if (var13 != (1489265707 ^ var30)) {
            var30 ^= 255763621;
            String var22 = tmvemkyftf(cdzircnujalrjqe(), var30);
            List var15 = var12.getMetadata(var22);
            byte var23 = (byte)(1476051086 ^ var30);
            Object var16 = var15.get(var23);
            MetadataValue var17 = (MetadataValue)var16;
            double var18 = var17.asDouble();
            var30 ^= 1498168160;
            double var25 = var1.getDamage();
            double var27 = var25 * var18;
            var1.setDamage(var27);
            var30 ^= 1425161904;
            return;
         }

         label34:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var30)) {
            case 31870917:
               break label34;
            case 201120471:
               var30 ^= 1774031872;
               break label34;
            case 355271503:
               break;
            case 1394891116:
            default:
               throw new IllegalAccessException();
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var30) == 266104874) {
            var30 ^= 1799173493;
            return;
         }

         var30 = vbmqmudythifskmq(var30, 1775940490);
      }

      throw new IllegalAccessException();
   }

   static {
      nothing_to_see_here[0] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⣀⣠⣤⣶⣶⣶⣤⣄⣀⣀⠄⠄⠄⠄⠄";
      nothing_to_see_here[1] = "⠄⠄⠄⠄⠄⠄⠄⠄⣀⣤⣤⣶⣿⣿⣿⣿⣿⣿⣿⣟⢿⣿⣿⣿⣶⣤⡀⠄";
      nothing_to_see_here[2] = "⠄⠄⠄⠄⠄⠄⢀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣜⠿⠿⣿⣿⣧⢓";
      nothing_to_see_here[3] = "⠄⠄⠄⠄⠄⡠⢛⣿⣿⣿⡟⣿⣿⣽⣋⠻⢻⣿⣿⣿⣿⡻⣧⡠⣭⣭⣿⡧";
      nothing_to_see_here[4] = "⠄⠄⠄⠄⠄⢠⣿⡟⣿⢻⠃⣻⣨⣻⠿⡀⣝⡿⣿⣿⣷⣜⣜⢿⣝⡿⡻⢔";
      nothing_to_see_here[5] = "⠄⠄⠄⠄⠄⢸⡟⣷⢿⢈⣚⣓⡡⣻⣿⣶⣬⣛⣓⣉⡻⢿⣎⠢⠻⣴⡾⠫";
      nothing_to_see_here[6] = "⠄⠄⠄⠄⠄⢸⠃⢹⡼⢸⣿⣿⣿⣦⣹⣿⣿⣿⠿⠿⠿⠷⣎⡼⠆⣿⠵⣫";
      nothing_to_see_here[7] = "⠄⠄⠄⠄⠄⠈⠄⠸⡟⡜⣩⡄⠄⣿⣿⣿⣿⣶⢀⢀⣿⣷⣿⣿⡐⡇⡄⣿";
      nothing_to_see_here[8] = "⠄⠄⠄⠄⠄⠄⠄⠄⠁⢶⢻⣧⣖⣿⣿⣿⣿⣿⣿⣿⣿⡏⣿⣇⡟⣇⣷⣿";
      nothing_to_see_here[9] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⣆⣤⣽⣿⡿⠿⠿⣿⣿⣦⣴⡇⣿⢨⣾⣿⢹⢸";
      nothing_to_see_here[10] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⣿⠊⡛⢿⣿⣿⣿⣿⡿⣫⢱⢺⡇⡏⣿⣿⣸⡼";
      nothing_to_see_here[11] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⡿⠄⣿⣷⣾⡍⣭⣶⣿⣿⡌⣼⣹⢱⠹⣿⣇⣧";
      nothing_to_see_here[12] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⣼⠁⣤⣭⣭⡌⢁⣼⣿⣿⣿⢹⡇⣭⣤⣶⣤⡝⡼";
      nothing_to_see_here[13] = "⠄⣀⠤⡀⠄⠄⠄⠄⠄⡏⣈⡻⡿⠃⢀⣾⣿⣿⣿⡿⡼⠁⣿⣿⣿⡿⢷⢸";
      nothing_to_see_here[14] = "⢰⣷⡧⡢⠄⠄⠄⠄⠠⢠⡛⠿⠄⠠⠬⠿⣿⠭⠭⢱⣇⣀⣭⡅⠶⣾⣷⣶";
      nothing_to_see_here[15] = "⠈⢿⣿⣧⠄⠄⠄⠄⢀⡛⠿⠄⠄⠄⠄⢠⠃⠄⠄⡜⠄⠄⣤⢀⣶⣮⡍⣴";
      nothing_to_see_here[16] = "⠄⠈⣿⣿⡀⠄⠄⠄⢩⣝⠃⠄⠄⢀⡄⡎⠄⠄⠄⠇⠄⠄⠅⣴⣶⣶⠄⣶";
      mnpxjolvrb = gpjgjaplelzuipv();
      int var3 = (new Random(4393233090589274066L)).nextInt();
      VWB2bN7dRE = -429208644 ^ var3;
   }

   public static String tmvemkyftf(byte[] var0, int var1) {
      String var10 = Integer.toString(var1);
      byte[] var11 = var10.getBytes();
      byte[] var8 = var11;
      byte var12 = 0;
      int var9 = var12;

      while(true) {
         int var17 = var0.length;
         if (var9 >= var17) {
            Charset var5 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var5);
            return var14;
         }

         byte var20 = var0[var9];
         int var33 = var8.length;
         int var30 = var9 % var33;
         byte var27 = var8[var30];
         int var21 = var20 ^ var27;
         byte var22 = (byte)var21;
         var0[var9] = var22;
         byte var23 = var0[var9];
         byte[] var28 = mnpxjolvrb;
         byte[] var34 = mnpxjolvrb;
         int var35 = var34.length;
         int var32 = var9 % var35;
         byte var29 = var28[var32];
         int var24 = var23 ^ var29;
         byte var25 = (byte)var24;
         var0[var9] = var25;
         ++var9;
      }
   }

   private static byte[] gpjgjaplelzuipv() {
      return new byte[]{110, 75, 99, 105, 82, 63, 32, 6, 14, 108, 55, 89, 93, 26, 72, 102, 75, 62, 123, 121, 123, 90, 69, 69, 29, 113, 5, 30, 10, 44, 119, 53, 47, 39, 34, 126, 31, 37, 64, 96, 122};
   }

   private static byte[] gbgiyilywaotbqg() {
      return new byte[]{-95, -121, 81, 19, 103, 116, 17, 94, 54, 47, 6, 39, 111, 86, 125, 51, 122, 123, 67, 39, 74, 25, 119, 16, 40, 33, 52, 74, 50, 105};
   }

   private static byte[] idnjhtdhoftyjds() {
      return new byte[]{-95, -126, 83, 127, 98, 104, 19, 80, 60, 51, 6, 3, 109, 77, 120, 61, 120, 112, 73, 39, 74, 73};
   }

   private static byte[] yvzilmjvyptqjwt() {
      return new byte[]{-95, -116, 87, 31, 102, 123, 25, 88, 58, 44, 6, 44, 105, 90, 124, 60, 114, 125, 79, 36, 74, 18, 113, 28, 41, 46, 60, 76, 62, 106};
   }

   private static byte[] yjlmqgvqywsaasg() {
      return new byte[]{-94, -123, 82, 26, 97, 116, 22, 88, 59, 42, 6, 37, 109, 92, 113, 60, 124, 127, 73, 33, 74, 26, 118, 16, 43, 47, 48, 73, 59, 111};
   }

   private static byte[] uopghdxwhxfnubi() {
      return new byte[]{-94, -124, 81, 57, 102, 120, 22, 114, 55, 38, 5, 0, 111, 87, 124, 31, 125, 124, 66, 45, 73, 30, 119, 21, 41, 53, 51, 69, 51, 125, 69, 96, 29, 108};
   }

   private static byte[] grbegedszpfgmll() {
      return new byte[]{-95, -124, 84, 60, 100, 97, 19, 95, 57, 51, 6, 15, 106, 66, 126, 35, 120, 111, 76, 21, 74, 13, 114, 7, 43, 47, 54, 5, 61, 124, 70, 119, 24, 121, 20, 61, 44, 79, 119, 62, 75, 43, 124, 56, 95, 17, 12, 124, 49, 77, 93, 107, 110, 3, 44, 26, 85, 12, 9, 102, 72, 40, 109, 29, 115, 69, 66, 92, 41, 93, 29, 40, 2, 111, 17, 123};
   }

   private static byte[] mbguqzpbnryzocw() {
      return new byte[]{-95, -115, 91, 60, 100, 122, 19, 92, 57, 47, 6, 9, 101, 82, 126, 58, 120, 97, 76, 43, 74, 17};
   }

   private static byte[] dwenzlmwclajnvl() {
      return new byte[]{-95, -122, 80, 61, 103, 120, 23, 69, 59, 57, 6, 31, 110, 67, 125, 59, 124, 97};
   }

   private static byte[] cdzircnujalrjqe() {
      return new byte[]{-95, -128, 84, 28, 98, 120, 17, 95, 54, 46, 6, 32, 106, 89, 120, 63, 122, 122, 67, 38, 74, 30, 114, 31, 45, 45, 52, 75, 50, 104};
   }

   private static byte[] vsydaymrtphfgko() {
      return new byte[]{-95, -128, 91, 19, 96, 123, 21, 88, 62, 47, 6, 32, 101, 86, 122, 60, 126, 125, 75, 39, 74, 30, 125, 16, 47, 46, 48, 76, 58, 105};
   }

   private static int vbmqmudythifskmq(int var0, int var1) {
      return var1 ^ var0;
   }
}
