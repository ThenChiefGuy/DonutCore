package dev.daniboy.donutcore.billford.listener;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.config.SoundConfig;
import dev.daniboy.donutcore.config.wrapper.SoundWrapper;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Random;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Keyed;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitScheduler;

public class StrenghRodListener implements Listener {
   private DonutCore plugin;
   private HashMap<UUID, Long> cooldowns;
   private static int PVczn9O0r9;
   private transient int EzI26Y4Lfr;
   private static byte[] saemfzllxy;
   private static String[] nothing_to_see_here = new String[15];

   public StrenghRodListener(DonutCore var1, int var2) {
      int var9 = 489680949 ^ 543338533;
      super();
      var9 = wksnwxxltvalsibz(var9, 1940359975);
      var9 = 1936178870 ^ 1062525411 ^ Integer.parseInt("986145763") ^ var2;
      this.EzI26Y4Lfr = 1880145150 ^ PVczn9O0r9;
      var9 = wksnwxxltvalsibz(var9, 931685384);
      var9 ^= 319271882;
      HashMap var4 = new HashMap();
      this.cooldowns = var4;
      var9 ^= 1635686782;
      this.plugin = var1;
      var9 ^= 1368360995;
   }

   @EventHandler
   public void onPlayerInteract(PlayerInteractEvent var1) {
      int var180 = 611440604 ^ 2136404944 ^ this.EzI26Y4Lfr;
      var180 ^= 744847218;
      final Player var20 = var1.getPlayer();
      var180 ^= 726333496;
      ItemStack var22 = var1.getItem();
      var180 ^= 391263677;
      if (var22 != null) {
         var180 ^= 2103964546;
         byte var25 = var22.hasItemMeta();
         if (var25 != (286323171 ^ var180)) {
            var180 ^= 886029671;
            ItemMeta var27 = var22.getItemMeta();
            var180 ^= 121197117;
            if (var27 != null) {
               var180 ^= 1682096693;
               PersistentDataContainer var30 = var27.getPersistentDataContainer();
               DonutCore var136 = this.plugin;
               String var5 = poeporoyzs(gudsqexelmgihvf(), var180);
               NamespacedKey var3 = new NamespacedKey(var136, var5);
               PersistentDataType var113 = PersistentDataType.STRING;
               byte var31 = var30.has(var3, var113);
               if (var31 != (1185209484 ^ var180)) {
                  var180 ^= 2065914561;
                  String var88 = poeporoyzs(goeqommusodcorx(), var180);
                  byte var33 = var20.hasMetadata(var88);
                  if (var33 != (1032291917 ^ var180)) {
                     var180 ^= 405006808;
                     MessagesConfig var34 = MessagesConfig.STRENGHRODACTIVE;
                     var34.send(var20);
                     var180 ^= 2115674938;
                     SoundWrapper var35 = SoundConfig.STRENGTHRODACTIVE;
                     var35.play(var20);
                     var180 ^= 219959719;
                     return;
                  }

                  var180 ^= 1454687422;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var180) != 263404165) {
                     var180 = wksnwxxltvalsibz(var180, 367953363);
                  } else {
                     var180 = wksnwxxltvalsibz(var180, 1699993909);
                     DonutCore var37 = this.plugin;
                     FileConfiguration var38 = var37.getBillfordGuiConfig$756205206(1840850862);
                     String var91 = poeporoyzs(gedmuostredstpn(), var180);
                     long var39 = var38.getLong(var91);
                     long var114 = 1000L;
                     long var41 = var39 * var114;
                     var180 ^= 1235962390;
                     HashMap var44 = this.cooldowns;
                     UUID var93 = var20.getUniqueId();
                     byte var45 = var44.containsKey(var93);
                     if (var45 != (1204539856 ^ var180)) {
                        var180 ^= 1149805849;
                        HashMap var47 = this.cooldowns;
                        UUID var95 = var20.getUniqueId();
                        Object var48 = var47.get(var95);
                        Long var49 = (Long)var48;
                        long var50 = var49;
                        long var52 = var50 + var41;
                        long var118 = System.currentTimeMillis();
                        long var54 = var52 - var118;
                        var180 ^= 497898171;
                        long var120 = 0L;
                        long var181;
                        int var58 = (var181 = var54 - var120) == 0L ? 0 : (var181 < 0L ? -1 : 1);
                        if (var58 > (518923890 ^ var180)) {
                           var180 ^= 1351248340;
                           MessagesConfig var59 = MessagesConfig.STRENGHRODCOOLDOWN;
                           byte var122 = (byte)(1315196836 ^ var180);
                           String[] var123 = new String[var122];
                           byte var149 = (byte)(1315196838 ^ var180);
                           String var6 = poeporoyzs(wtlzgtiitkpxphg(), var180);
                           var123[var149] = var6;
                           byte var150 = (byte)(1315196839 ^ var180);
                           long var8 = 1000L;
                           long var162 = var54 / var8;
                           String var164 = String.valueOf(var162);
                           var123[var150] = var164;
                           var59.send(var20, var123);
                           var180 ^= 1864914045;
                           SoundWrapper var60 = SoundConfig.STRENGTHRODCOOLDOWN;
                           var60.play(var20);
                           var180 ^= 2145199611;
                           return;
                        }

                        var180 = wksnwxxltvalsibz(var180, 1290889512);
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var180) != 253557665) {
                           var180 ^= 750946426;
                           throw new IOException();
                        }

                        var180 = wksnwxxltvalsibz(var180, 1417885218);
                     } else {
                        var180 ^= 1355292342;
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var180) != 211252950) {
                           var180 ^= 1776158790;
                           throw new IOException();
                        }

                        var180 = wksnwxxltvalsibz(var180, 295679518);
                     }

                     HashMap var62 = this.cooldowns;
                     UUID var99 = var20.getUniqueId();
                     long var124 = System.currentTimeMillis();
                     Long var126 = var124;
                     var62.put(var99, var126);
                     var180 ^= 2080728084;
                     int var101 = var22.getAmount();
                     byte var127 = (byte)(2056854893 ^ var180);
                     int var102 = var101 - var127;
                     var22.setAmount(var102);
                     var180 ^= 1725636026;
                     PersistentDataContainer var66 = var27.getPersistentDataContainer();
                     DonutCore var138 = this.plugin;
                     String var151 = poeporoyzs(kjvxpjgendhrfep(), var180);
                     NamespacedKey var103 = new NamespacedKey(var138, var151);
                     PersistentDataType var128 = PersistentDataType.DOUBLE;
                     Object var67 = var66.get(var103, var128);
                     Double var68 = (Double)var67;
                     double var69 = var68;
                     var180 ^= 1505958267;
                     PersistentDataContainer var72 = var27.getPersistentDataContainer();
                     DonutCore var140 = this.plugin;
                     String var152 = poeporoyzs(yjyeeoekqwbikqx(), var180);
                     NamespacedKey var104 = new NamespacedKey(var140, var152);
                     PersistentDataType var129 = PersistentDataType.INTEGER;
                     Object var73 = var72.get(var104, var129);
                     Integer var74 = (Integer)var73;
                     final int var75 = var74;
                     var180 ^= 637166038;
                     String var105 = poeporoyzs(ujglfilmovdxdxk(), var180);
                     DonutCore var154 = this.plugin;
                     Double var167 = var69;
                     FixedMetadataValue var130 = new FixedMetadataValue(var154, var167);
                     var20.setMetadata(var105, var130);
                     var180 ^= 237603244;
                     SoundWrapper var77 = SoundConfig.STRENGTHRODACTIVATED;
                     var77.play(var20);
                     var180 ^= 703405224;
                     Registry var78 = Registry.EFFECT;
                     String var107 = poeporoyzs(gcznmfawvzkxaxr(), var180);
                     Keyed var79 = var78.match(var107);
                     PotionEffectType var80 = (PotionEffectType)var79;
                     var180 ^= 1888429815;
                     byte var168 = (byte)(925944732 ^ var180);
                     int var156 = var75 * var168;
                     int var171 = (int)var69;
                     byte var7 = (byte)(925944713 ^ var180);
                     int var172 = var171 - var7;
                     byte var175 = (byte)(925944712 ^ var180);
                     byte var176 = (byte)(925944713 ^ var180);
                     byte var10 = (byte)(925944713 ^ var180);
                     PotionEffect var108 = new PotionEffect(var80, var156, var172, (boolean)var175, (boolean)var176, (boolean)var10);
                     var20.addPotionEffect(var108);
                     var180 ^= 863645055;
                     BukkitRunnable var83 = new BukkitRunnable(2027293579) {
                        int remainingDuration;
                        private static int bEPRSHbNj9;
                        private transient int dNayAmSV9y;
                        private static String xjzscrfggf;
                        private static String[] nothing_to_see_here = new String[18];

                        {
                           int var16 = 1963502009 ^ 807174918;
                           var16 = qclwqbzkravomozn(var16, 1676899463);
                           var16 = 108136787 ^ 1637342344 ^ Integer.parseInt("970227816") ^ var4;
                           this.dNayAmSV9y = 1165450682 ^ bEPRSHbNj9;
                           var16 = qclwqbzkravomozn(var16, 797947171);
                           var16 ^= 1102450856;
                           int var14 = var75;
                           this.remainingDuration = var14;
                           var16 ^= 212686336;
                        }

                        public void run() {
                           int var27 = 2033717755 ^ 25979876 ^ this.dNayAmSV9y;
                           var27 ^= 384489415;
                           int var6 = this.remainingDuration;
                           if (var6 > (1549811845 ^ var27)) {
                              var27 ^= 573028925;
                              if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) == 78318467) {
                                 var27 ^= 192988626;
                                 MessagesConfig var10 = MessagesConfig.STRENGHRODACTIONBAR;
                                 Player var13 = var20;
                                 byte var18 = (byte)(1975992168 ^ var27);
                                 String[] var19 = new String[var18];
                                 byte var4 = (byte)(1975992170 ^ var27);
                                 String var5 = lhcvyslabi(fxmsssbxktwvrrp(), var27);
                                 var19[var4] = var5;
                                 byte var21 = (byte)(1975992171 ^ var27);
                                 int var23 = this.remainingDuration;
                                 String var24 = String.valueOf(var23);
                                 var19[var21] = var24;
                                 var10.send(var13, var19);
                                 var27 ^= 2129239063;
                                 int var14 = this.remainingDuration;
                                 byte var20x = (byte)(187605884 ^ var27);
                                 int var15 = var14 - var20x;
                                 this.remainingDuration = var15;
                                 var27 ^= 1904567592;
                              } else {
                                 var27 = qclwqbzkravomozn(var27, 1459201885);
                                 throw new RuntimeException();
                              }
                           } else {
                              var27 ^= 1285251613;
                              this.cancel();
                              var27 ^= 627427592;
                              Player var9 = var20;
                              String var2 = lhcvyslabi(ogvyrkifasyivjf(), var27);
                              StrenghRodListener var16 = StrenghRodListener.this;
                              DonutCore var17 = var16.plugin;
                              var9.removeMetadata(var2, var17);

                              label45:
                              while(true) {
                                 switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27)) {
                                 case 132374009:
                                    var27 ^= 998673529;
                                    break label45;
                                 case 1462447276:
                                 default:
                                    throw new RuntimeException();
                                 case 1542347711:
                                    break;
                                 case 1644554681:
                                    break label45;
                                 }
                              }

                              try {
                                 if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var27) != 189744971) {
                                    throw null;
                                 }

                                 throw new IOException();
                              } catch (IOException var28) {
                                 switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var27)) {
                                 case -1143527789:
                                    var27 = qclwqbzkravomozn(var27, 46365185);
                                    break;
                                 case 1891843912:
                                    var27 = qclwqbzkravomozn(var27, 2074212666);
                                    break;
                                 default:
                                    throw new IOException("Error in hash");
                                 }
                              }

                              var27 = qclwqbzkravomozn(var27, 252860550);
                           }
                        }

                        static {
                           nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[1] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣶⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[2] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⠿⠟⠛⠻⣿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[3] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣆⣀⣀⠀⣿⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[4] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠻⣿⣿⣿⠅⠛⠋⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[5] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢼⣿⣿⣿⣃⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[6] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣟⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[7] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣛⣛⣫⡄⠀⢸⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[8] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣾⡆⠸⣿⣿⣿⡷⠂⠨⣿⣿⣿⣿⣶⣦⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣾⣿⣿⣿⣿⡇⢀⣿⡿⠋⠁⢀⡶⠪⣉⢸⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⡏⢸⣿⣷⣿⣿⣷⣦⡙⣿⣿⣿⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣇⢸⣿⣿⣿⣿⣿⣷⣦⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[15] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[16] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           nothing_to_see_here[17] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣵⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
                           xjzscrfggf = ByteBuffer.wrap(uwnmdkqyzdmuxae()).asCharBuffer().toString();
                           int var3 = (new Random(-2894847973109027094L)).nextInt();
                           bEPRSHbNj9 = 601397416 ^ var3;
                        }

                        public static String lhcvyslabi(byte[] var0, int var1) {
                           String var13 = Integer.toString(var1);
                           byte[] var14 = var13.getBytes();
                           byte[] var8 = var14;
                           byte var3 = 0;
                           byte var16 = var0[var3];
                           short var36 = 255;
                           int var17 = var16 & var36;
                           byte var37 = 24;
                           int var18 = var17 << var37;
                           byte var4 = 1;
                           byte var39 = var0[var4];
                           short var68 = 255;
                           int var40 = var39 & var68;
                           byte var69 = 16;
                           int var41 = var40 << var69;
                           int var19 = var18 | var41;
                           byte var70 = 2;
                           byte var43 = var0[var70];
                           short var71 = 255;
                           int var44 = var43 & var71;
                           byte var72 = 8;
                           int var45 = var44 << var72;
                           int var20x = var19 | var45;
                           byte var73 = 3;
                           byte var47 = var0[var73];
                           short var74 = 255;
                           int var48 = var47 & var74;
                           int var21 = var20x | var48;
                           byte var49 = 4;
                           byte var23 = var0[var49];
                           short var50 = 255;
                           int var24 = var23 & var50;
                           byte var51 = 24;
                           int var25 = var24 << var51;
                           byte var75x = 5;
                           byte var53 = var0[var75x];
                           short var76 = 255;
                           int var54 = var53 & var76;
                           byte var77 = 16;
                           int var55 = var54 << var77;
                           int var26 = var25 | var55;
                           byte var78 = 6;
                           byte var57 = var0[var78];
                           short var79 = 255;
                           int var58 = var57 & var79;
                           byte var80 = 8;
                           int var59 = var58 << var80;
                           int var27 = var26 | var59;
                           byte var81 = 7;
                           byte var61 = var0[var81];
                           short var82 = 255;
                           int var62 = var61 & var82;
                           int var28 = var27 | var62;
                           String var29 = xjzscrfggf;
                           int var84 = var28 + var21;
                           String var30 = var29.substring(var28, var84);
                           Charset var64 = StandardCharsets.UTF_16BE;
                           byte[] var31 = var30.getBytes(var64);
                           byte[] var11 = var31;
                           byte var32 = 0;
                           int var12 = var32;

                           while(true) {
                              int var66 = var11.length;
                              if (var12 >= var66) {
                                 Charset var91 = StandardCharsets.UTF_16BE;
                                 String var35 = new String(var11, var91);
                                 return var35;
                              }

                              byte var85 = var11[var12];
                              int var93 = var8.length;
                              int var92 = var12 % var93;
                              byte var90 = var8[var92];
                              int var86 = var85 ^ var90;
                              byte var87 = (byte)var86;
                              var11[var12] = var87;
                              ++var12;
                           }
                        }

                        private static byte[] ogvyrkifasyivjf() {
                           return new byte[]{0, 0, 0, 11, 0, 0, 0, 0};
                        }

                        private static byte[] fxmsssbxktwvrrp() {
                           return new byte[]{0, 0, 0, 9, 0, 0, 0, 11};
                        }

                        private static byte[] uwnmdkqyzdmuxae() {
                           return new byte[]{56, 106, 57, 66, 48, 69, 52, 81, 48, 86, 57, 94, 54, 68, 55, 92, 52, 98, 56, 86, 57, 82, 49, 90, 55, 90, 57, 76, 50, 95, 55, 68, 49, 93, 55, 90, 57, 78, 50, 95};
                        }

                        private static int qclwqbzkravomozn(int var0, int var1) {
                           return var1 ^ var0;
                        }
                     };
                     DonutCore var110 = this.plugin;
                     long var132 = 0L;
                     long var158 = 20L;
                     var180 ^= 2146910396;
                     var83.runTaskTimer(var110, var132, var158);
                     var180 ^= 44284734;
                     if (var75 > (2032016757 ^ var180)) {
                        var180 ^= 1175651410;
                        BukkitScheduler var86 = Bukkit.getScheduler();
                        DonutCore var112 = this.plugin;
                        Runnable var135 = () -> {
                           int var8 = 1273110315 ^ 803355559 ^ this.EzI26Y4Lfr;
                           var8 ^= 1780034707;
                           String var3 = poeporoyzs(wyxdrxkqljxtrwi(), var8);
                           DonutCore var5 = this.plugin;
                           var20.removeMetadata(var3, var5);
                        };
                        long var145 = (long)var75;
                        long var173 = 20L;
                        long var147 = var145 * var173;
                        var86.runTaskLater(var112, var135, var147);
                        var180 ^= 589714795;
                        return;
                     }

                     var180 = wksnwxxltvalsibz(var180, 1525472669);
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var180) != 94795315) {
                        var180 ^= 1563363272;
                     } else {
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var180)) {
                           case 94795315:
                              var180 ^= 1071221924;
                              return;
                           case 500747775:
                              return;
                           case 1690893589:
                           default:
                              throw new IOException();
                           case 1961198437:
                           }
                        }
                     }
                  }
               } else {
                  var180 = wksnwxxltvalsibz(var180, 558850277);
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var180) == 156818144) {
                     var180 ^= 2076241957;
                     return;
                  }

                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var180)) {
                     case 156818144:
                        var180 ^= 423000905;
                        throw new IOException();
                     case 345452071:
                        break;
                     case 651056889:
                     case 1731375297:
                     default:
                        throw new IOException();
                     }
                  }
               }
            } else {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var180)) {
                  case 60684640:
                     var180 ^= 46452433;
                  case 607271673:
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var180) == 239293419) {
                        var180 ^= 1007262756;
                        return;
                     }

                     var180 = wksnwxxltvalsibz(var180, 1593775944);
                     throw new IOException();
                  case 495274431:
                     break;
                  case 1537009016:
                  default:
                     throw new IOException();
                  }
               }
            }
         } else {
            var180 = wksnwxxltvalsibz(var180, 590778037);
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var180) == 19571856) {
               var180 = wksnwxxltvalsibz(var180, 772616986);
               return;
            }

            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var180)) {
               case 19571856:
                  var180 ^= 1291565174;
                  throw new IOException();
               case 218558847:
               case 727293056:
               default:
                  throw new IOException();
               case 685700422:
               }
            }
         }
      } else {
         var180 = wksnwxxltvalsibz(var180, 381708023);
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var180) == 230893653) {
            var180 = wksnwxxltvalsibz(var180, 1721510106);
            return;
         }

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var180)) {
            case 230893653:
               var180 ^= 74097590;
               throw new IOException();
            case 677912019:
            case 1547587686:
            default:
               throw new IOException();
            case 1782626371:
            }
         }
      }

      throw new IOException();
   }

   static {
      nothing_to_see_here[0] = " ⠁⡼⠋⠀⣆⠀⠀⣰⣿⣫⣾⢿⣿⣿⠍⢠⠠⠀⠀⢀⠰⢾⣺⣻⣿⣿⣿⣷⡀⠀";
      nothing_to_see_here[1] = "⣥⠀⠀⠀⠁⠀⠠⢻⢬⠁⣠⣾⠛⠁⠀⠀⠀⠀⠀⠀⠀⠐⠱⠏⡉⠙⣿⣿⡇⠀";
      nothing_to_see_here[2] = "⢳⠀⢰⡖⠀⠀⠈⠀⣺⢰⣿⢻⣾⣶⣿⣿⣶⣶⣤⣤⣴⣾⣿⣷⣼⡆⢸⣿⣧⠀";
      nothing_to_see_here[3] = "⠈⠀⠜⠈⣀⣔⣦⢨⣿⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣅⣼⠛⢹⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⢋⡿⡿⣯⣭⡟⣟⣿⣿⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⡘⠀";
      nothing_to_see_here[5] = "⡀⠐⠀⠀⠀⣿⣯⡿⣿⣿⣿⣯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣉⢽⣿⡆⠀⠀";
      nothing_to_see_here[6] = "⢳⠀⠄⠀⢀⣿⣿⣿⣿⣿⣿⣿⠙⠉⠉⠉⠛⣻⢛⣿⠛⠃⠀⠐⠛⠻⣿⡇⠀⠀";
      nothing_to_see_here[7] = "⣾⠄⠀⠀⢸⣿⣿⡿⠟⠛⠁⢀⠀⢀⡄⣀⣠⣾⣿⣿⡠⣴⣎⣀⣠⣠⣿⡇⠀⠀";
      nothing_to_see_here[8] = "⣧⠀⣴⣄⣽⣿⣿⣿⣶⣶⣖⣶⣬⣾⣿⣾⣿⣿⣿⣿⣽⣿⣿⣿⣿⣿⣿⡇⠀⠀";
      nothing_to_see_here[9] = "⣿⣶⣈⡯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣹⢧⣿⣿⣿⣄⠙⢿⣿⣿⣿⠇⠀⠀";
      nothing_to_see_here[10] = "⠹⣿⣿⣧⢌⢽⣻⢿⣯⣿⣿⣿⣿⠟⣠⡘⠿⠟⠛⠛⠟⠛⣧⡈⠻⣾⣿⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠈⠉⣷⡿⣽⠶⡾⢿⣿⣿⣿⢃⣤⣿⣷⣤⣤⣄⣄⣠⣼⡿⢷⢀⣿⡏⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⢀⣿⣷⠌⣈⣏⣝⠽⡿⣷⣾⣏⣀⣉⣉⣀⣀⣀⣠⣠⣄⡸⣾⣿⠃⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⣰⡿⣿⣧⡐⠄⠱⣿⣺⣽⢟⣿⣿⢿⣿⣍⠉⢀⣀⣐⣼⣯⡗⠟⡏⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⣰⣿⠀⣿⣿⣴⡀⠂⠘⢹⣭⡂⡚⠿⢿⣿⣿⣿⡿⢿⢿⡿⠿⢁⣴⣿⣷⣶⣦⣤";
      saemfzllxy = zzvetotiolygcdd();
      int var3 = (new Random(5251696986285402568L)).nextInt();
      PVczn9O0r9 = 1457312987 ^ var3;
   }

   public static String poeporoyzs(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = saemfzllxy;
         byte[] var34 = saemfzllxy;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] zzvetotiolygcdd() {
      return new byte[]{56, 120, 91, 106, 103, 97, 21, 81, 24, 73, 16, 115, 83, 120, 97, 68, 118, 81, 34, 88, 104, 54, 90, 101, 28, 60, 42, 37, 57, 6, 6, 56, 85, 116, 17, 57, 108, 124, 29, 112, 89, 70, 80, 23, 4, 44, 7, 98, 38, 75, 42, 28, 124, 24, 73, 17, 62, 98, 117, 80, 2, 34, 17, 89, 99, 5, 79, 30, 46, 3, 86, 16, 35};
   }

   private static byte[] wyxdrxkqljxtrwi() {
      return new byte[]{-16, -66, 106, 10, 86, 36, 34, 23, 33, 26, 41, 44, 96, 46, 80, 7, 66, 0, 20, 51, 89, 106, 107, 48};
   }

   private static byte[] yjyeeoekqwbikqx() {
      return new byte[]{-9, -74, 109, 56, 87, 44, 45, 21, 42, 25, 33, 54, 101, 39, 81, 19, 78, 9};
   }

   private static byte[] gedmuostredstpn() {
      return new byte[]{-12, -77, 106, 58, 86, 58, 38, 8, 32, 23, 36, 36, 97, 38, 83, 5, 67, 13, 16, 51, 89, 99, 107, 34, 47, 96, 18, 57, 13, 68, 52, 125, 103, 53, 36, 100, 94, 38, 44, 54, 104, 28, 99, 125, 60, 108, 51, 60, 20, 30, 24, 1, 73, 67, 123, 74, 15, 63, 68, 14, 49, 115, 41, 4, 87, 67, 125, 65};
   }

   private static byte[] gudsqexelmgihvf() {
      return new byte[]{-9, -74, 99, 54, 85, 34, 44, 54, 32, 9, 33, 48, 107, 40, 83, 26, 79, 2, 26, 24, 89, 111, 98, 2, 46, 99, 19, 117};
   }

   private static byte[] goeqommusodcorx() {
      return new byte[]{-9, -73, 104, 11, 85, 44, 36, 26, 41, 27, 33, 45, 96, 45, 83, 9, 71, 0, 19, 61, 89, 105, 105, 51};
   }

   private static byte[] ujglfilmovdxdxk() {
      return new byte[]{-9, -79, 106, 1, 80, 37, 33, 22, 40, 27, 33, 43, 98, 39, 86, 0, 66, 12, 18, 61, 89, 111, 107, 57};
   }

   private static byte[] wtlzgtiitkpxphg() {
      return new byte[]{-9, -76, 106, 60, 86, 55, 35, 6, 43, 29, 33, 36, 98, 34, 80, 10, 64, 7};
   }

   private static byte[] gcznmfawvzkxaxr() {
      return new byte[]{-9, -75, 107, 52, 80, 62, 37, 10, 41, 29, 33, 34, 99, 57, 86, 19, 70, 2, 19, 29, 89, 62, 106, 37, 43, 126, 26, 98, 8, 82, 55, 100, 101, 32, 38, 123, 92, 33};
   }

   private static byte[] kjvxpjgendhrfep() {
      return new byte[]{-14, -80, 111, 41, 95, 34, 35, 16, 32, 24, 39, 41, 99, 39, 86, 6, 69, 1};
   }

   private static int wksnwxxltvalsibz(int var0, int var1) {
      return var1 ^ var0;
   }
}
