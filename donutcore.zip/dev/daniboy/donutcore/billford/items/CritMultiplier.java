package dev.daniboy.donutcore.billford.items;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.utils.Hex;
import java.util.List;
import java.util.Random;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

public class CritMultiplier extends ItemStack {
   private DonutCore plugin;
   private static int tq0QRDhqT8;
   private transient int UaClUqHwu5;
   private static String[] nothing_to_see_here = new String[15];

   public CritMultiplier(DonutCore var1, int var2) {
      int var71 = 707691329 ^ 1781057513;
      Material var4 = Material.BLAZE_POWDER;
      super(var4);
      var71 = auoeqfgumaatlhum(var71, 121820753);
      var71 = 431999195 ^ 674795651 ^ Integer.parseInt("632116041") ^ var2;
      this.UaClUqHwu5 = 1747048709 ^ tq0QRDhqT8;
      var71 = auoeqfgumaatlhum(var71, 1832367717);
      var71 ^= 1683805656;
      this.plugin = var1;
      var71 ^= 1665562585;
      ItemMeta var16 = this.getItemMeta();
      var71 ^= 1170176494;
      FileConfiguration var44 = var1.getBillfordGuiConfig$756205206(1840850862);
      String var5 = "billford_gui.crit_multiplier.display_name";
      String var45 = var44.getString(var5);
      String var46 = Hex.hex(var45);
      var16.setDisplayName(var46);
      var71 ^= 446583610;
      FileConfiguration var19 = var1.getBillfordGuiConfig$756205206(1840850862);
      String var47 = "billford_gui.crit_multiplier.lore";
      List var20 = var19.getStringList(var47);
      var71 ^= 705901134;
      Stream var22 = var20.stream();
      Function var48 = Hex::hex;
      Stream var23 = var22.map(var48);
      Collector var49 = Collectors.toList();
      Object var24 = var23.collect(var49);
      List var25 = (List)var24;
      var71 ^= 1669842856;
      var16.setLore(var25);
      var71 ^= 263780797;
      PersistentDataContainer var28 = var16.getPersistentDataContainer();
      String var7 = "isCritMultiplier";
      NamespacedKey var51 = new NamespacedKey(var1, var7);
      PersistentDataType var57 = PersistentDataType.STRING;
      String var60 = "true";
      var28.set(var51, var57, var60);
      var71 ^= 1858112529;
      FileConfiguration var30 = var1.getBillfordGuiConfig$756205206(1840850862);
      String var52 = "billford_gui.crit_multiplier.multipliers";
      double var31 = var30.getDouble(var52);
      var71 ^= 1609485674;
      PersistentDataContainer var34 = var16.getPersistentDataContainer();
      String var68 = "multiplier";
      NamespacedKey var53 = new NamespacedKey(var1, var68);
      PersistentDataType var58 = PersistentDataType.DOUBLE;
      Double var64 = var31;
      var34.set(var53, var58, var64);
      var71 ^= 700483357;
      FileConfiguration var36 = var1.getBillfordGuiConfig$756205206(1840850862);
      String var54 = "billford_gui.crit_multiplier.duration";
      int var37 = var36.getInt(var54);
      var71 ^= 2049045757;
      PersistentDataContainer var39 = var16.getPersistentDataContainer();
      String var69 = "duration";
      NamespacedKey var55 = new NamespacedKey(var1, var69);
      PersistentDataType var59 = PersistentDataType.INTEGER;
      Integer var67 = var37;
      var39.set(var55, var59, var67);
      var71 ^= 27234641;
      this.setItemMeta(var16);
      var71 ^= 1658640806;
   }

   static {
      nothing_to_see_here[0] = "⠄⠄⠄⢰⣧⣼⣯⠄⣸⣠⣶⣶⣦⣾⠄⠄⠄⠄⡀⠄⢀⣿⣿⠄⠄⠄⢸⡇⠄⠄";
      nothing_to_see_here[1] = "⠄⠄⠄⣾⣿⠿⠿⠶⠿⢿⣿⣿⣿⣿⣦⣤⣄⢀⡅⢠⣾⣛⡉⠄⠄⠄⠸⢀⣿⠄";
      nothing_to_see_here[2] = "⠄⠄⢀⡋⣡⣴⣶⣶⡀⠄⠄⠙⢿⣿⣿⣿⣿⣿⣴⣿⣿⣿⢃⣤⣄⣀⣥⣿⣿⠄";
      nothing_to_see_here[3] = "⠄⠄⢸⣇⠻⣿⣿⣿⣧⣀⢀⣠⡌⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿⣿⣿⣿⠄";
      nothing_to_see_here[4] = "⠄⢀⢸⣿⣷⣤⣤⣤⣬⣙⣛⢿⣿⣿⣿⣿⣿⣿⡿⣿⣿⡍⠄⠄⢀⣤⣄⠉⠋⣰";
      nothing_to_see_here[5] = "⠄⣼⣖⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⢇⣿⣿⡷⠶⠶⢿⣿⣿⠇⢀⣤";
      nothing_to_see_here[6] = "⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣽⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣷⣶⣥⣴⣿⡗";
      nothing_to_see_here[7] = "⢀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠄";
      nothing_to_see_here[8] = "⢸⣿⣦⣌⣛⣻⣿⣿⣧⠙⠛⠛⡭⠅⠒⠦⠭⣭⡻⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠄";
      nothing_to_see_here[9] = "⠘⣿⣿⣿⣿⣿⣿⣿⣿⡆⠄⠄⠄⠄⠄⠄⠄⠄⠹⠈⢋⣽⣿⣿⣿⣿⣵⣾⠃⠄";
      nothing_to_see_here[10] = "⠄⠘⣿⣿⣿⣿⣿⣿⣿⣿⠄⣴⣿⣶⣄⠄⣴⣶⠄⢀⣾⣿⣿⣿⣿⣿⣿⠃⠄⠄";
      nothing_to_see_here[11] = "⠄⠄⠈⠻⣿⣿⣿⣿⣿⣿⡄⢻⣿⣿⣿⠄⣿⣿⡀⣾⣿⣿⣿⣿⣛⠛⠁⠄⠄⠄";
      nothing_to_see_here[12] = "⠄⠄⠄⠄⠈⠛⢿⣿⣿⣿⠁⠞⢿⣿⣿⡄⢿⣿⡇⣸⣿⣿⠿⠛⠁⠄⠄⠄⠄⠄";
      nothing_to_see_here[13] = "⠄⠄⠄⠄⠄⠄⠄⠉⠻⣿⣿⣾⣦⡙⠻⣷⣾⣿⠃⠿⠋⠁⠄⠄⠄⠄⠄⢀⣠⣴";
      nothing_to_see_here[14] = "⣿⣿⣿⣶⣶⣮⣥⣒⠲⢮⣝⡿⣿⣿⡆⣿⡿⠃⠄⠄⠄⠄⠄⠄⠄⣠⣴⣿⣿⣿";
      int var3 = (new Random(-671255109309928009L)).nextInt();
      tq0QRDhqT8 = -1807646176 ^ var3;
   }

   private static int auoeqfgumaatlhum(int var0, int var1) {
      return var1 ^ var0;
   }
}
