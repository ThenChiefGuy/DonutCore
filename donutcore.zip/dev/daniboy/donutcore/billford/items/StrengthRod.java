package dev.daniboy.donutcore.billford.items;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.utils.Hex;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.util.List;
import java.util.Random;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

public class StrengthRod extends ItemStack {
   private DonutCore plugin;
   private static int rGEFkLsDMz;
   private transient int feboJH3aXV;
   private static String[] nothing_to_see_here = new String[15];

   public StrengthRod(DonutCore var1, int var2) {
      int var69 = 1377378692 ^ 348670590;
      Material var4 = Material.BLAZE_ROD;
      super(var4);
      var69 ^= 2066022653;
      var69 = 1713891269 ^ 1976824608 ^ Integer.parseInt("1916108226") ^ var2;
      this.feboJH3aXV = 1269515011 ^ rGEFkLsDMz;

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var69)) {
         case 134853289:
            var69 ^= 462306697;
         case 1608998588:
            var69 ^= 162767828;
            this.plugin = var1;
            var69 ^= 800102895;
            ItemMeta var15 = this.getItemMeta();
            var69 ^= 483964900;
            FileConfiguration var38 = var1.getBillfordGuiConfig$756205206(1840850862);
            String var5 = "billford_gui.strenth_rod.display_name";
            String var39 = var38.getString(var5);
            String var40 = Hex.hex(var39);
            var15.setDisplayName(var40);
            var69 ^= 1905030284;
            FileConfiguration var18 = var1.getBillfordGuiConfig$756205206(1840850862);
            String var41 = "billford_gui.strenth_rod.lore";
            List var19 = var18.getStringList(var41);
            var69 ^= 1681630052;
            Stream var43 = var19.stream();
            Function var53 = Hex::hex;
            Stream var44 = var43.map(var53);
            Collector var54 = Collectors.toList();
            Object var45 = var44.collect(var54);
            List var46 = (List)var45;
            var15.setLore(var46);
            var69 ^= 1876205136;
            PersistentDataContainer var22 = var15.getPersistentDataContainer();
            String var7 = "isStrengthRod";
            NamespacedKey var47 = new NamespacedKey(var1, var7);
            PersistentDataType var55 = PersistentDataType.STRING;
            String var58 = "true";
            var22.set(var47, var55, var58);
            var69 ^= 2081593916;
            FileConfiguration var24 = var1.getBillfordGuiConfig$756205206(1840850862);
            String var48 = "billford_gui.strenth_rod.strength";
            double var25 = var24.getDouble(var48);
            var69 ^= 39335647;
            PersistentDataContainer var28 = var15.getPersistentDataContainer();
            String var66 = "strength";
            NamespacedKey var49 = new NamespacedKey(var1, var66);
            PersistentDataType var56 = PersistentDataType.DOUBLE;
            Double var62 = var25;
            var28.set(var49, var56, var62);
            var69 ^= 1124927346;
            FileConfiguration var30 = var1.getBillfordGuiConfig$756205206(1840850862);
            String var50 = "billford_gui.strenth_rod.duration";
            int var31 = var30.getInt(var50);
            var69 ^= 1141836458;
            PersistentDataContainer var33 = var15.getPersistentDataContainer();
            String var67 = "duration";
            NamespacedKey var51 = new NamespacedKey(var1, var67);
            PersistentDataType var57 = PersistentDataType.INTEGER;
            Integer var65 = var31;
            var33.set(var51, var57, var65);
            var69 ^= 1293027597;
            this.setItemMeta(var15);
            var69 ^= 540540312;
            return;
         case 405170513:
         default:
            throw new RuntimeException();
         case 2004676616:
         }
      }
   }

   static {
      nothing_to_see_here[0] = "⢀⡴⠑⡄⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠸⡇⠀⠿⡀⠀⠀⠀⣀⡴⢿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠑⢄⣠⠾⠁⣀⣄⡈⠙⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⢀⡀⠁⠀⠀⠈⠙⠛⠂⠈⣿⣿⣿⣿⣿⠿⡿⢿⣆⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⢀⡾⣁⣀⠀⠴⠂⠙⣗⡀⠀⢻⣿⣿⠭⢤⣴⣦⣤⣹⠀⠀⠀⢀⢴⣶⣆";
      nothing_to_see_here[5] = "⠀⠀⢀⣾⣿⣿⣿⣷⣮⣽⣾⣿⣥⣴⣿⣿⡿⢂⠔⢚⡿⢿⣿⣦⣴⣾⠁⠸⣼⡿";
      nothing_to_see_here[6] = "⠀⢀⡞⠁⠙⠻⠿⠟⠉⠀⠛⢹⣿⣿⣿⣿⣿⣌⢤⣼⣿⣾⣿⡟⠉⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⣾⣷⣶⠇⠀⠀⣤⣄⣀⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠉⠈⠉⠀⠀⢦⡈⢻⣿⣿⣿⣶⣶⣶⣶⣤⣽⡹⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠉⠲⣽⡻⢿⣿⣿⣿⣿⣿⣿⣷⣜⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣷⣶⣮⣭⣽⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⠿⠿⠿⠿⠛⠉              ";
      int var3 = (new Random(-1830260562922154657L)).nextInt();
      rGEFkLsDMz = -1822066698 ^ var3;
   }
}
