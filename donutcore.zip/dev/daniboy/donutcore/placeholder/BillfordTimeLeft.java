package dev.daniboy.donutcore.placeholder;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MainConfig;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Random;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.scheduler.BukkitScheduler;

public class BillfordTimeLeft extends PlaceholderExpansion {
   private final DonutCore plugin;
   private final long intervalInTicks;
   private final long intervalInMillis;
   private static int lgE8kUUExX;
   private transient int scJEpRXOuN;
   private static String xhzywdmgij;
   private static String[] nothing_to_see_here = new String[13];

   public BillfordTimeLeft(DonutCore var1, int var2) {
      int var23 = 866021417 ^ 773345065;
      super();
      var23 ^= 2112301328;
      var23 = 977293179 ^ 1157546520 ^ Integer.parseInt("1609908519") ^ var2;
      this.scJEpRXOuN = 1492102415 ^ lgE8kUUExX;
      var23 ^= 1336557835;
      var23 ^= 2035277569;
      this.plugin = var1;
      var23 ^= 324291792;
      int var11 = MainConfig.PluginSettings.BILLFORD_RESET_TIMER;
      long var12 = (long)var11;
      long var5 = 20L;
      long var14 = var12 * var5;
      this.intervalInTicks = var14;
      var23 ^= 1036947054;
      int var16 = MainConfig.PluginSettings.BILLFORD_RESET_TIMER;
      long var17 = (long)var16;
      long var21 = 1000L;
      long var19 = var17 * var21;
      this.intervalInMillis = var19;
      var23 ^= 1528034686;
      this.startSwitchingTradeChoice$1555863032(815055844);
      var23 ^= 1768407;
   }

   public boolean persist() {
      int var4 = 1771278043 ^ 199797121 ^ this.scJEpRXOuN;
      var4 ^= 1347668005;
      byte var1 = (byte)(479046053 ^ var4);
      return (boolean)var1;
   }

   public boolean canRegister() {
      int var4 = 1635079753 ^ 1772740830 ^ this.scJEpRXOuN;
      var4 ^= 1172274981;
      byte var1 = (byte)(1671860072 ^ var4);
      return (boolean)var1;
   }

   public String getIdentifier() {
      int var4 = 832388269 ^ 1307820993 ^ this.scJEpRXOuN;
      var4 ^= 1628063196;
      String var1 = egnvpdbhmz(owoywcusnxaoayk(), var4);
      return var1;
   }

   public String getAuthor() {
      int var9 = 1319567661 ^ 862033419 ^ this.scJEpRXOuN;
      var9 ^= 1199602343;
      String var1 = egnvpdbhmz(freumnehswvgcai(), var9);
      DonutCore var4 = this.plugin;
      PluginDescriptionFile var5 = var4.getDescription();
      List var6 = var5.getAuthors();
      String var3 = String.join(var1, var6);
      return var3;
   }

   public String getVersion() {
      int var7 = 1195186415 ^ 410908233 ^ this.scJEpRXOuN;
      var7 ^= 2100182491;
      DonutCore var2 = this.plugin;
      PluginDescriptionFile var3 = var2.getDescription();
      String var4 = var3.getVersion();
      return var4;
   }

   private void startSwitchingTradeChoice$1555863032(int var1) {
      int var14 = 1387141326 ^ 880649879 ^ this.scJEpRXOuN ^ var1;
      var14 ^= 1650618238;
      BukkitScheduler var2 = Bukkit.getScheduler();
      DonutCore var8 = this.plugin;
      Runnable var9 = this::switchTradeChoice;
      long var10 = this.intervalInTicks;
      long var12 = this.intervalInTicks;
      var2.runTaskTimer(var8, var9, var10, var12);
      var14 ^= 1624746684;
   }

   public String onPlaceholderRequest(Player var1, String var2) {
      int var44 = 806009481 ^ 2129448588 ^ this.scJEpRXOuN;
      var44 ^= 499779304;
      String var4 = egnvpdbhmz(vgiutntckoimwnq(), var44);
      byte var14 = var2.equals(var4);
      if (var14 != (2106143798 ^ var44)) {
         var44 ^= 1329046148;
         long var15 = System.currentTimeMillis();
         var44 ^= 230049147;
         long var37 = this.intervalInMillis;
         long var19 = var15 % var37;
         var44 ^= 710138343;
         long var22 = this.intervalInMillis;
         long var24 = var22 - var19;
         var44 ^= 865759727;
         DonutCore var27 = this.plugin;
         FileConfiguration var28 = var27.getBillfordGuiConfig$756205206(1840850862);
         var44 ^= 1954173803;
         String var34 = egnvpdbhmz(vurtullalrrmdkc(), var44);
         String var41 = egnvpdbhmz(oappiexzxoizmzx(), var44);
         String var30 = var28.getString(var34, var41);
         var44 ^= 1418382775;
         String var32 = this.formatTime$2005481180(var24, 1239936047);
         return var32;
      } else {
         var44 = tkpshsrnixsxkzdh(var44, 765646188);
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44) != 190141621) {
            var44 = tkpshsrnixsxkzdh(var44, 689533238);
            throw new IOException();
         } else {
            label26:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44)) {
               case 190141621:
                  var44 ^= 685815905;
               case 1448483923:
                  break label26;
               case 1489577542:
                  break;
               case 2006598452:
               default:
                  throw new IOException();
               }
            }
         }

         Object var33 = null;
         return (String)var33;
      }
   }

   private void switchTradeChoice() {
      int var22 = 1141535842 ^ 111574432 ^ this.scJEpRXOuN;
      var22 ^= 1028004597;
      DonutCore var6 = this.plugin;
      FileConfiguration var7 = var6.getBillfordGuiConfig$756205206(1840850862);
      var22 ^= 640537314;
      String var2 = egnvpdbhmz(xgabqqyzapvfzgr(), var22);
      String var9 = var7.getString(var2);
      var22 ^= 853705828;
      String var10 = egnvpdbhmz(krdwtbqmqvzcvgi(), var22);
      byte var11 = var10.equalsIgnoreCase(var9);
      if (var11 != (1166017386 ^ var22)) {
         var22 ^= 838141029;
         String var18 = egnvpdbhmz(irzcbdqcmwyokyg(), var22);
         String var19 = egnvpdbhmz(quddiykscesiuvn(), var22);
         var7.set(var18, var19);
         var22 ^= 993871301;

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var22) != 161238575) {
               throw null;
            }

            throw new IOException();
         } catch (IOException var23) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var22)) {
            case 296174354:
               var22 ^= 709131883;
               break;
            case 2051151442:
               var22 ^= 658035907;
               break;
            default:
               throw new IOException("Error in hash");
            }
         }

         label45:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var22)) {
            case 50819713:
               break;
            case 173689537:
               var22 ^= 612262731;
               break label45;
            case 1214404055:
            default:
               throw new IOException();
            case 1308347545:
               break label45;
            }
         }
      } else {
         var22 ^= 1768142428;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var22) != 116982779) {
            var22 ^= 349727454;
            throw new IOException();
         }

         var22 ^= 2016899078;
         String var17 = egnvpdbhmz(zgwufwoaplcwchg(), var22);
         String var3 = egnvpdbhmz(hpqrshtntzodbqi(), var22);
         var7.set(var17, var3);
         var22 ^= 416952434;
      }

      DonutCore var14 = this.plugin;
      var14.saveBillfordGuiConfig$978105170(1372127931);
      var22 ^= 353235195;
   }

   private String formatTime$2005481180(long var1, int var3) {
      int var77 = 873924184 ^ 175801456 ^ this.scJEpRXOuN ^ var3;
      var77 ^= 1418257372;
      long var6 = 1000L;
      long var15 = var1 / var6;
      var77 ^= 2113690264;
      long var61 = 60L;
      long var19 = var15 / var61;
      var77 ^= 901060006;
      long var63 = 60L;
      long var23 = var19 / var63;
      var77 ^= 184944108;
      long var65 = 60L;
      long var27 = var15 % var65;
      var77 ^= 570885122;
      long var67 = 60L;
      long var31 = var19 % var67;
      var77 ^= 1129954984;
      StringBuilder var33 = new StringBuilder();
      var77 ^= 218466090;
      long var69 = 0L;
      long var78;
      int var36 = (var78 = var23 - var69) == 0L ? 0 : (var78 < 0L ? -1 : 1);
      if (var36 > (582204498 ^ var77)) {
         var77 ^= 288010696;
         StringBuilder var38 = var33.append(var23);
         String var54 = egnvpdbhmz(uxaitwznatxkyva(), var77);
         var38.append(var54);
         var77 ^= 101716574;
      } else {
         label66:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var77)) {
            case 54271597:
               var77 ^= 762095393;
               break label66;
            case 1113398988:
               break;
            case 1740896236:
               break label66;
            case 1986873085:
            default:
               throw new IOException();
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var77) != 247483121) {
            var77 ^= 849842050;
            throw new IOException();
         }

         label56:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var77)) {
            case 247483121:
               var77 ^= 978715831;
            case 502524172:
               break label56;
            case 1244768188:
            default:
               throw new IOException();
            case 2018942262:
            }
         }
      }

      long var71 = 0L;
      long var79;
      int var42 = (var79 = var31 - var71) == 0L ? 0 : (var79 < 0L ? -1 : 1);
      if (var42 > (898179012 ^ var77)) {
         var77 ^= 1043665355;
         StringBuilder var44 = var33.append(var31);
         String var57 = egnvpdbhmz(ktflyuwxvcyijnp(), var77);
         var44.append(var57);
         var77 ^= 119193513;
      } else {
         label44:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var77)) {
            case 58758700:
               break label44;
            case 129603586:
               var77 ^= 201797356;
               break label44;
            case 554698659:
               break;
            case 1245814640:
            default:
               throw new IOException();
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var77) != 260261555) {
            var77 = tkpshsrnixsxkzdh(var77, 83273177);
            throw new IOException();
         }

         label34:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var77)) {
            case 260261555:
               var77 ^= 891846798;
               break label34;
            case 313619557:
               break;
            case 339664593:
               break label34;
            case 1444043019:
            default:
               throw new IOException();
            }
         }
      }

      StringBuilder var47 = var33.append(var27);
      String var60 = egnvpdbhmz(nhpllmeogjhafyo(), var77);
      var47.append(var60);
      var77 ^= 222574352;
      String var50 = var33.toString();
      String var51 = var50.trim();
      return var51;
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⣠⣶⡾⠏⠉⠙⠳⢦⡀⠀⠀⠀⢠⠞⠉⠙⠲⡀⠀    ";
      nothing_to_see_here[2] = "⠀⠀⠀⣴⠿⠏⠀⠀⠀⠀⠀⠀⢳⡀⠀⡏⠀⠀⠀⠀⠀⢷     ";
      nothing_to_see_here[3] = "⠀⠀⢠⣟⣋⡀⢀⣀⣀⡀⠀⣀⡀⣧⠀⢸⠀⠀⠀⠀⠀ ⡇    ";
      nothing_to_see_here[4] = "⠀⠀⢸⣯⡭⠁⠸⣛⣟⠆⡴⣻⡲⣿⠀⣸⠀⠀OK⠀ ⡇    ";
      nothing_to_see_here[5] = "⠀⠀⣟⣿⡭⠀⠀⠀⠀⠀⢱⠀⠀⣿⠀⢹⠀⠀⠀⠀⠀ ⡇    ";
      nothing_to_see_here[6] = "⠀⠀⠙⢿⣯⠄⠀⠀⠀⢀⡀⠀⠀⡿⠀⠀⡇⠀⠀⠀⠀⡼     ";
      nothing_to_see_here[7] = "⠀⠀⠀⠀⠹⣶⠆⠀⠀⠀⠀⠀⡴⠃⠀⠀⠘⠤⣄⣠⠞⠀     ";
      nothing_to_see_here[8] = "⠀⠀⠀⠀⠀⢸⣷⡦⢤⡤⢤⣞⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[9] = "⠀⠀⢀⣤⣴⣿⣏⠁⠀⠀⠸⣏⢯⣷⣖⣦⡀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[10] = "⢀⣾⣽⣿⣿⣿⣿⠛⢲⣶⣾⢉⡷⣿⣿⠵⣿⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[11] = "⣼⣿⠍⠉⣿⡭⠉⠙⢺⣇⣼⡏⠀⠀⠀⣄⢸⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[12] = "⣿⣿⣧⣀⣿.........⣀⣰⣏⣘⣆⣀⠀⠀       ";
      xhzywdmgij = ByteBuffer.wrap(dmyalfihxejciez()).asCharBuffer().toString();
      int var3 = (new Random(-4061228336009199511L)).nextInt();
      lgE8kUUExX = 270255286 ^ var3;
   }

   public static String egnvpdbhmz(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = xhzywdmgij;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var91 = StandardCharsets.UTF_16BE;
            String var35 = new String(var11, var91);
            return var35;
         }

         byte var85 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var90 = var8[var92];
         int var86 = var85 ^ var90;
         byte var87 = (byte)var86;
         var11[var12] = var87;
         ++var12;
      }
   }

   private static byte[] owoywcusnxaoayk() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, 0};
   }

   private static byte[] freumnehswvgcai() {
      return new byte[]{0, 0, 0, 2, 0, 0, 0, 9};
   }

   private static byte[] vurtullalrrmdkc() {
      return new byte[]{0, 0, 0, 25, 0, 0, 0, 11};
   }

   private static byte[] oappiexzxoizmzx() {
      return new byte[]{0, 0, 0, 7, 0, 0, 0, 36};
   }

   private static byte[] vgiutntckoimwnq() {
      return new byte[]{0, 0, 0, 16, 0, 0, 0, 43};
   }

   private static byte[] krdwtbqmqvzcvgi() {
      return new byte[]{0, 0, 0, 14, 0, 0, 0, 59};
   }

   private static byte[] xgabqqyzapvfzgr() {
      return new byte[]{0, 0, 0, 25, 0, 0, 0, 73};
   }

   private static byte[] zgwufwoaplcwchg() {
      return new byte[]{0, 0, 0, 25, 0, 0, 0, 98};
   }

   private static byte[] hpqrshtntzodbqi() {
      return new byte[]{0, 0, 0, 14, 0, 0, 0, 123};
   }

   private static byte[] irzcbdqcmwyokyg() {
      return new byte[]{0, 0, 0, 25, 0, 0, 0, -119};
   }

   private static byte[] quddiykscesiuvn() {
      return new byte[]{0, 0, 0, 11, 0, 0, 0, -94};
   }

   private static byte[] uxaitwznatxkyva() {
      return new byte[]{0, 0, 0, 7, 0, 0, 0, -83};
   }

   private static byte[] ktflyuwxvcyijnp() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, -76};
   }

   private static byte[] nhpllmeogjhafyo() {
      return new byte[]{0, 0, 0, 8, 0, 0, 0, -67};
   }

   private static byte[] dmyalfihxejciez() {
      return new byte[]{56, 82, 56, 92, 53, 95, 48, 77, 51, 76, 54, 91, 51, 90, 49, 66, 56, 86, 51, 25, 48, 20, 49, 81, 56, 94, 57, 85, 55, 95, 53, 82, 49, 92, 56, 69, 57, 93, 55, 108, 53, 83, 49, 70, 56, 94, 57, 23, 55, 71, 53, 70, 49, 82, 56, 83, 57, 92, 55, 108, 53, 87, 49, 91, 56, 88, 57, 80, 55, 80, 53, 81, 49, 102, 56, 89, 57, 82, 55, 93, 53, 91, 49, 68, 56, 89, 50, 83, 48, 95, 49, 88, 51, 91, 57, 94, 50, 94, 48, 68, 49, 80, 51, 67, 57, 81, 50, 92, 48, 83, 49, 88, 51, 82, 57, 94, 50, 69, 49, 82, 54, 68, 48, 88, 55, 71, 56, 91, 49, 68, 54, 90, 48, 69, 55, 90, 56, 70, 49, 93, 54, 95, 48, 84, 55, 65, 50, 82, 48, 91, 57, 88, 53, 84, 48, 80, 50, 95, 48, 64, 57, 80, 53, 103, 48, 81, 50, 69, 48, 91, 57, 26, 53, 76, 48, 68, 50, 81, 48, 86, 57, 81, 53, 103, 48, 85, 50, 88, 48, 93, 57, 93, 53, 91, 48, 83, 49, 86, 50, 90, 50, 95, 48, 94, 53, 80, 49, 91, 50, 65, 50, 87, 48, 109, 53, 81, 49, 65, 50, 90, 50, 29, 48, 70, 53, 68, 49, 85, 50, 87, 50, 86, 48, 109, 53, 85, 49, 92, 50, 92, 50, 90, 48, 81, 53, 83, 49, 87, 50, 65, 50, 90, 48, 70, 53, 91, 49, 65, 50, 95, 50, 71, 48, 91, 53, 70, 49, 88, 50, 90, 50, 86, 48, 64, 49, 91, 53, 90, 56, 94, 54, 89, 55, 83, 49, 86, 53, 65, 56, 86, 54, 106, 55, 82, 49, 76, 53, 90, 56, 28, 54, 65, 55, 71, 49, 88, 53, 87, 56, 87, 54, 106, 55, 86, 49, 81, 53, 92, 56, 91, 54, 86, 55, 80, 49, 74, 53, 71, 56, 64, 54, 80, 55, 91, 49, 94, 53, 71, 56, 90, 54, 71, 55, 90, 49, 93, 56, 22, 53, 94, 54, 87, 53, 69, 54, 74, 54, 70, 54, 22, 49, 25, 54, 85, 55, 90, 55, 90, 51, 68, 57, 66, 56, 82, 51, 68, 52, 19, 50, 17, 50, 65, 53, 84, 48, 87, 54, 93, 49, 92, 50, 81, 49, 67};
   }

   private static int tkpshsrnixsxkzdh(int var0, int var1) {
      return var1 ^ var0;
   }
}
