package dev.daniboy.donutcore;

import com.sk89q.worldguard.WorldGuard;
import dev.daniboy.donutcore.billford.listener.CritMultiplierListener;
import dev.daniboy.donutcore.billford.listener.StrenghRodListener;
import dev.daniboy.donutcore.commands.AfkCommand;
import dev.daniboy.donutcore.commands.BalanceCommand;
import dev.daniboy.donutcore.commands.BillfordCommand;
import dev.daniboy.donutcore.commands.BillfordEditorCommand;
import dev.daniboy.donutcore.commands.DiscordCommand;
import dev.daniboy.donutcore.commands.DonutCoreCommand;
import dev.daniboy.donutcore.commands.HelpCommand;
import dev.daniboy.donutcore.commands.MediaCommand;
import dev.daniboy.donutcore.commands.MessageCommand;
import dev.daniboy.donutcore.commands.MessageToggleCommand;
import dev.daniboy.donutcore.commands.NightVisionCommand;
import dev.daniboy.donutcore.commands.PayCommand;
import dev.daniboy.donutcore.commands.PayToggleCommand;
import dev.daniboy.donutcore.commands.ReplyCommand;
import dev.daniboy.donutcore.commands.RulesCommand;
import dev.daniboy.donutcore.commands.SetAfkCommand;
import dev.daniboy.donutcore.commands.SetSpawnCommand;
import dev.daniboy.donutcore.commands.SpawnCommand;
import dev.daniboy.donutcore.commands.StoreCommand;
import dev.daniboy.donutcore.config.ConfigManager;
import dev.daniboy.donutcore.config.MainConfig;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.config.SoundConfig;
import dev.daniboy.donutcore.database.SQLiteManager;
import dev.daniboy.donutcore.gui.impl.AfkGUI;
import dev.daniboy.donutcore.gui.impl.HelpGUI;
import dev.daniboy.donutcore.gui.impl.MediaGUI;
import dev.daniboy.donutcore.gui.impl.RulesGUI;
import dev.daniboy.donutcore.gui.impl.SpawnGUI;
import dev.daniboy.donutcore.gui.impl.billford.BillfordEditorGUI;
import dev.daniboy.donutcore.gui.impl.billford.BillfordEditorItemsGUI;
import dev.daniboy.donutcore.gui.impl.billford.BillfordGUI;
import dev.daniboy.donutcore.listener.PlayerListener;
import dev.daniboy.donutcore.manager.TeleportManager;
import dev.daniboy.donutcore.placeholder.BillfordTimeLeft;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Builder;
import java.net.http.HttpClient.Version;
import java.net.http.HttpResponse.BodyHandler;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.logging.Logger;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.Server;
import org.bukkit.command.CommandMap;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.ServicesManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitScheduler;

public final class DonutCore extends JavaPlugin {
   private HelpGUI helpGui;
   private MediaGUI mediaGui;
   private RulesGUI rulesGui;
   private SpawnGUI spawnGui;
   private AfkGUI afkGui;
   private Economy economy;
   private BillfordGUI billfordGui;
   private BillfordEditorGUI billfordEditorGui;
   private BillfordEditorItemsGUI billfordEditorItemsGUI;
   private ConfigManager configManager;
   private SQLiteManager sqLiteManager;
   private TeleportManager teleportManager;
   private BillfordTimeLeft billfordTimeLeft;
   private final Map<Player, Player> lastMessaged;
   private FileConfiguration helpGuiConfig;
   private FileConfiguration mediaGuiConfig;
   private FileConfiguration afkSpawnGuiConfig;
   private FileConfiguration billfordGuiConfig;
   private FileConfiguration rulesGuiConfig;
   private static int soWjD6JRrA;
   private transient int Jm9tEPij1G;
   private static String[] nothing_to_see_here = new String[15];

   public DonutCore() {
      int var6 = 1361073654 ^ 1025902719;
      super();

      label30:
      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var6)) {
         case 21772607:
            var6 ^= 1783144158;
         case 1094401866:
            var6 = 705238893 ^ 1708548203 ^ Integer.parseInt("1234285649");
            this.Jm9tEPij1G = 143268200 ^ soWjD6JRrA;

            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var6)) {
               case 99209583:
                  var6 ^= 498301057;
                  break label30;
               case 763447849:
               default:
                  throw new IOException();
               case 1322990999:
                  break label30;
               case 1793728851:
               }
            }
         case 48558584:
         default:
            throw new IOException();
         case 211087360:
         }
      }

      var6 ^= 224389644;
      HashMap var2 = new HashMap();
      this.lastMessaged = var2;
   }

   public void onEnable() {
      int var281 = 108431712 ^ 704624257 ^ this.Jm9tEPij1G;
      var281 ^= 1686396107;
      WorldGuard var1 = WorldGuard.getInstance();
      if (var1 == null) {
         var281 ^= 871082014;
         Logger var24 = this.getLogger();
         String var2 = xlnoigleho(cniexdbfyewsxht(), rmdqikusoembxnk(), var281);
         var24.severe(var2);
         var281 ^= 888447966;
         Server var26 = this.getServer();
         PluginManager var27 = var26.getPluginManager();
         var27.disablePlugin(this);
         var281 ^= 1938154515;
      } else {
         var281 ^= 1475143576;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 253041117) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
               case 253041117:
                  var281 ^= 740043872;
                  throw new IllegalAccessException();
               case 303953296:
               case 992421586:
               default:
                  throw new IllegalAccessException();
               case 358366877:
               }
            }
         }

         label397:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
            case 253041117:
               var281 ^= 1779266213;
               break label397;
            case 969679862:
            default:
               throw new IllegalAccessException();
            case 1450398696:
               break label397;
            case 2131759070:
            }
         }

         String var3 = xlnoigleho(jlthopxsenqvxco(), rmdqikusoembxnk(), var281);
         FileConfiguration var180 = this.loadConfig$1876126984(var3, 1027462332);
         this.helpGuiConfig = var180;
         var281 ^= 337977170;
         String var227 = xlnoigleho(tagjfuauhtrlydt(), rmdqikusoembxnk(), var281);
         FileConfiguration var182 = this.loadConfig$1876126984(var227, 1027462332);
         this.mediaGuiConfig = var182;
         var281 ^= 1225747687;
         String var228 = xlnoigleho(cynbffydouynyqu(), rmdqikusoembxnk(), var281);
         FileConfiguration var184 = this.loadConfig$1876126984(var228, 1027462332);
         this.rulesGuiConfig = var184;
         var281 ^= 1728893945;
         String var229 = xlnoigleho(fxxydzmlcihogxl(), rmdqikusoembxnk(), var281);
         FileConfiguration var186 = this.loadConfig$1876126984(var229, 1027462332);
         this.afkSpawnGuiConfig = var186;
         var281 ^= 1478234174;
         String var230 = xlnoigleho(sjkermdkehqbkhm(), rmdqikusoembxnk(), var281);
         FileConfiguration var188 = this.loadConfig$1876126984(var230, 1027462332);
         this.billfordGuiConfig = var188;
         var281 ^= 492271771;
         TeleportManager var189 = new TeleportManager(this, 2134981223);
         this.teleportManager = var189;
         var281 ^= 476687910;
         SQLiteManager var190 = new SQLiteManager(this, 1851206422);
         this.sqLiteManager = var190;
         var281 ^= 1454286269;
         HelpGUI var191 = new HelpGUI(this, 1156425752);
         this.helpGui = var191;
         var281 ^= 2138357172;
         SQLiteManager var262 = this.sqLiteManager;
         TeleportManager var271 = this.teleportManager;
         SpawnGUI var192 = new SpawnGUI(this, var262, var271, 588188175);
         this.spawnGui = var192;
         var281 ^= 157942884;
         SQLiteManager var264 = this.sqLiteManager;
         TeleportManager var273 = this.teleportManager;
         AfkGUI var193 = new AfkGUI(this, var264, var273, 469798925);
         this.afkGui = var193;
         var281 ^= 580235221;
         MediaGUI var194 = new MediaGUI(this, 1156425752);
         this.mediaGui = var194;
         var281 ^= 444319747;
         RulesGUI var195 = new RulesGUI(this, 1156425752);
         this.rulesGui = var195;
         var281 ^= 692573391;
         SQLiteManager var266 = this.sqLiteManager;
         BillfordGUI var196 = new BillfordGUI(this, var266, 2049851990);
         this.billfordGui = var196;
         var281 ^= 447806149;
         BillfordEditorGUI var197 = new BillfordEditorGUI(this, 1156425752);
         this.billfordEditorGui = var197;
         var281 ^= 28671794;
         SQLiteManager var268 = this.sqLiteManager;
         BillfordEditorItemsGUI var198 = new BillfordEditorItemsGUI(this, var268, 1474256625);
         this.billfordEditorItemsGUI = var198;
         var281 ^= 1352078573;
         HelpGUI var44 = this.helpGui;
         var44.loadHelpConfigValues$1430792781(839749214);
         var281 ^= 1267265895;
         MediaGUI var46 = this.mediaGui;
         var46.loadMediaConfigValues$2120577358(54860659);
         var281 ^= 221548304;
         RulesGUI var48 = this.rulesGui;
         var48.loadRulesConfigValues$113812495(476948616);
         var281 ^= 976069524;
         SpawnGUI var50 = this.spawnGui;
         var50.loadSpawnConfigValues$882403349(870176311);
         var281 ^= 785090824;
         AfkGUI var52 = this.afkGui;
         var52.loadAfkConfigValues$568738828(1586297296);
         var281 ^= 818312968;
         ConfigManager var199 = new ConfigManager(this);
         this.configManager = var199;
         var281 ^= 513562520;
         ConfigManager var55 = this.configManager;
         Class var200 = MainConfig.class;
         var55.register(var200);
         var281 ^= 16101555;
         ConfigManager var57 = this.configManager;
         Class var201 = SoundConfig.class;
         var57.register(var201);
         var281 ^= 882173858;
         MessagesConfig.loadAll(this);
         var281 ^= 896881548;
         ConfigManager var60 = this.configManager;
         var60.reload();
         var281 ^= 1086485835;
         byte var62 = this.setupEconomy$1059304311(295727738);
         if (var62 == (1859861245 ^ var281)) {
            var281 ^= 2118336758;
            Logger var64 = this.getLogger();
            String var202 = xlnoigleho(ijdrxefcmixajig(), rmdqikusoembxnk(), var281);
            var64.severe(var202);
            var281 ^= 781075233;
         } else {
            label419: {
               label386:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                  case 113814673:
                     var281 ^= 91768217;
                     break label386;
                  case 616110747:
                  default:
                     throw new IllegalAccessException();
                  case 1180249076:
                     break label386;
                  case 1445142711:
                  }
               }

               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 9219442) {
                  var281 = saxuwxcnfwcxyrlg(var281, 1731216976);
                  throw new IllegalAccessException();
               }

               var281 = saxuwxcnfwcxyrlg(var281, 403050157);
               PluginManager var65 = Bukkit.getPluginManager();
               String var203 = xlnoigleho(ermttddynwqzdjy(), rmdqikusoembxnk(), var281);
               Plugin var66 = var65.getPlugin(var203);
               if (var66 != null) {
                  var281 ^= 830328600;
                  BillfordTimeLeft var204 = new BillfordTimeLeft(this, 1093327444);
                  this.billfordTimeLeft = var204;
                  var281 ^= 781027380;
                  BillfordTimeLeft var69 = this.billfordTimeLeft;
                  boolean var70 = var69.register();
                  var281 ^= 261398248;
               } else {
                  label373:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                     case 1114064:
                        var281 ^= 1444889795;
                        break label373;
                     case 412586425:
                        break;
                     case 1542931983:
                        break label373;
                     case 1931419369:
                     default:
                        throw new IllegalAccessException();
                     }
                  }

                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 152626041) {
                     var281 ^= 690555966;
                     throw new IllegalAccessException();
                  }

                  var281 = saxuwxcnfwcxyrlg(var281, 1182506247);
               }

               Server var72 = this.getServer();
               PluginManager var73 = var72.getPluginManager();
               SpawnGUI var270 = this.spawnGui;
               SQLiteManager var275 = this.sqLiteManager;
               PlayerListener var205 = new PlayerListener(this, var270, var275, 536216094);
               var73.registerEvents(var205, this);
               var281 ^= 1236846450;
               Server var75 = this.getServer();
               PluginManager var76 = var75.getPluginManager();
               CritMultiplierListener var206 = new CritMultiplierListener(this, 1891224068);
               var76.registerEvents(var206, this);
               var281 ^= 1925700811;
               Server var78 = this.getServer();
               PluginManager var79 = var78.getPluginManager();
               StrenghRodListener var207 = new StrenghRodListener(this, 941543297);
               var79.registerEvents(var207, this);
               var281 ^= 1636810685;
               SQLiteManager var257 = this.sqLiteManager;
               DonutCoreCommand var80 = new DonutCoreCommand(this, var257, 2025139659);
               var281 ^= 186140587;
               String var208 = xlnoigleho(ptynqgrcmflzlfj(), rmdqikusoembxnk(), var281);
               PluginCommand var82 = this.getCommand(var208);
               var82.setExecutor(var80);
               var281 ^= 114092937;
               String var210 = xlnoigleho(oogneurwvtljopd(), rmdqikusoembxnk(), var281);
               PluginCommand var84 = this.getCommand(var210);
               var84.setTabCompleter(var80);
               var281 ^= 1300027831;
               CommandMap var86 = this.getCommandMap$1431339485(436386096);
               String var212 = xlnoigleho(hrfytwxtqwcaacg(), rmdqikusoembxnk(), var281);
               StoreCommand var235 = new StoreCommand();
               var86.register(var212, var235);
               var281 ^= 1319498573;
               CommandMap var89 = this.getCommandMap$1431339485(436386096);
               String var213 = xlnoigleho(lspttvzdvtcaehd(), rmdqikusoembxnk(), var281);
               DiscordCommand var236 = new DiscordCommand();
               var89.register(var213, var236);
               var281 ^= 1714241487;
               byte var91 = MainConfig.Features.HELP;
               var281 ^= 1516158739;
               if (var91 != (189729293 ^ var281)) {
                  var281 ^= 1949082701;
                  this.loadHelpFeature$2074084618(231613316);
                  var281 ^= 1579710857;
               } else {
                  var281 = saxuwxcnfwcxyrlg(var281, 1060697965);
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 94916253) {
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                        case 94916253:
                           var281 ^= 954516564;
                           throw new IllegalAccessException();
                        case 555336963:
                           break;
                        case 1286485610:
                        case 1519302541:
                        default:
                           throw new IllegalAccessException();
                        }
                     }
                  }

                  var281 = saxuwxcnfwcxyrlg(var281, 356264617);
               }

               byte var94 = MainConfig.Features.MEDIA;
               var281 ^= 363194322;
               if (var94 != (888025115 ^ var281)) {
                  var281 ^= 1171373171;
                  this.loadMediaFeature$658125645(873002043);
                  var281 ^= 2094416900;
               } else {
                  var281 ^= 1150220070;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 163312230) {
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                        case 163312230:
                           var281 ^= 2096365065;
                           throw new IllegalAccessException();
                        case 352009426:
                        case 1755100715:
                        default:
                           throw new IllegalAccessException();
                        case 1234805608:
                        }
                     }
                  }

                  label358:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                     case 163312230:
                        var281 ^= 2106134353;
                        break label358;
                     case 487680139:
                     default:
                        throw new IllegalAccessException();
                     case 1713433368:
                        break;
                     case 1863190501:
                        break label358;
                     }
                  }
               }

               byte var97 = MainConfig.Features.RULES;
               var281 ^= 1214356873;
               if (var97 != (1166562789 ^ var281)) {
                  var281 ^= 649765450;
                  this.loadRulesFeature$424103264(1821726518);
                  var281 ^= 603770121;
               } else {
                  var281 ^= 1188487665;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 53005196) {
                     var281 = saxuwxcnfwcxyrlg(var281, 265129248);
                     throw new IllegalAccessException();
                  }

                  var281 ^= 1133547186;
               }

               byte var100 = MainConfig.Features.SPAWN;
               var281 ^= 99934217;
               if (var100 != (1161484975 ^ var281)) {
                  var281 ^= 1916512203;
                  this.loadSpawnFeature$2109479120(340058453);
                  var281 ^= 1228696659;
               } else {
                  label340:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                     case 102908553:
                        var281 ^= 852202816;
                     case 1081389488:
                        break label340;
                     case 1872154885:
                        break;
                     case 1910764025:
                     default:
                        throw new IllegalAccessException();
                     }
                  }

                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 140770606) {
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                        case 140770606:
                           var281 ^= 2070050523;
                           throw new IllegalAccessException();
                        case 671831788:
                        case 841493089:
                        default:
                           throw new IllegalAccessException();
                        case 2101551940:
                        }
                     }
                  }

                  var281 ^= 164388568;
               }

               byte var103 = MainConfig.Features.AFK;
               var281 ^= 890895936;
               if (var103 != (1260711799 ^ var281)) {
                  var281 ^= 251064522;
                  this.loadAfkFeature$22344590(684220475);
                  var281 ^= 510226679;
               } else {
                  var281 ^= 1788667561;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 22327974) {
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                        case 22327974:
                           var281 ^= 757805290;
                           throw new IllegalAccessException();
                        case 722775635:
                        case 1867576991:
                        default:
                           throw new IllegalAccessException();
                        case 1534728081:
                        }
                     }
                  }

                  label326:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                     case 22327974:
                        var281 ^= 2047043220;
                        break label326;
                     case 338815230:
                     default:
                        throw new IllegalAccessException();
                     case 597248053:
                        break;
                     case 611198777:
                        break label326;
                     }
                  }
               }

               byte var106 = MainConfig.Features.BILLFORD;
               var281 ^= 1046210683;
               if (var106 != (1709213489 ^ var281)) {
                  var281 ^= 1631060233;
                  this.loadBillfordFeature$2003866414(1699244838);
                  var281 ^= 1885078819;
               } else {
                  var281 = saxuwxcnfwcxyrlg(var281, 1521899126);
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 179833391) {
                     var281 = saxuwxcnfwcxyrlg(var281, 868608115);
                     throw new IllegalAccessException();
                  }

                  var281 = saxuwxcnfwcxyrlg(var281, 1272074844);
               }

               byte var109 = (byte)(1954841370 ^ var281);
               var281 ^= 409899501;
               if (var109 != (1827279606 ^ var281)) {
                  var281 ^= 1916138128;
                  this.loadChatFeature$468648758(769278616);
                  var281 ^= 658636785;
               } else {
                  var281 ^= 1363234193;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 125580668) {
                     var281 = saxuwxcnfwcxyrlg(var281, 825779795);
                     throw new IllegalAccessException();
                  }

                  var281 = saxuwxcnfwcxyrlg(var281, 70598896);
               }

               byte var112 = MainConfig.Features.NIGHTVISION;
               var281 ^= 1936556620;
               if (var112 != (1257479643 ^ var281)) {
                  var281 ^= 1830345878;
                  this.loadNightVisionFeature$1305102662(1016545307);
                  var281 ^= 1971350085;
               } else {
                  var281 ^= 1850388619;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 119989106) {
                     var281 = saxuwxcnfwcxyrlg(var281, 673846372);
                     throw new IllegalAccessException();
                  }

                  var281 ^= 1993475672;
               }

               byte var115 = MainConfig.Features.ECONOMY;
               var281 ^= 1624033401;
               if (var115 != (849863537 ^ var281)) {
                  var281 ^= 1070514520;
                  this.loadEconomyFeature$749298711(1728877855);
                  var281 ^= 1164522625;
               } else {
                  var281 = saxuwxcnfwcxyrlg(var281, 1898276079);
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 46966080) {
                     var281 ^= 1326562986;
                     throw new IllegalAccessException();
                  }

                  var281 = saxuwxcnfwcxyrlg(var281, 193106230);
               }

               String var118 = xlnoigleho(pntsouvishvwqwq(), rmdqikusoembxnk(), var281);
               String var17 = var118;
               var281 ^= 1872738196;
               String var119 = xlnoigleho(itamgifmfgyhppz(), rmdqikusoembxnk(), var281);
               var281 ^= 211835217;
               Builder var120 = HttpClient.newBuilder();
               Version var214 = Version.HTTP_2;
               Builder var121 = var120.version(var214);
               long var215 = 10L;
               Duration var217 = Duration.ofSeconds(var215);
               Builder var122 = var121.connectTimeout(var217);
               HttpClient var123 = var122.build();
               HttpClient var19 = var123;
               var281 ^= 1355349791;
               byte var124 = (byte)(2079786866 ^ var281);
               int var20 = var124;
               var281 ^= 1875380909;

               label410: {
                  try {
                     java.net.http.HttpRequest.Builder var125 = HttpRequest.newBuilder();
                     java.net.http.HttpRequest.Builder var126 = var125.GET();
                     URI var219 = URI.create(var17);
                     java.net.http.HttpRequest.Builder var127 = var126.uri(var219);
                     String var220 = xlnoigleho(hrzglhrrfehcrkb(), rmdqikusoembxnk(), var281);
                     String var237 = xlnoigleho(lyprqlhkygpzanm(), rmdqikusoembxnk(), var281);
                     java.net.http.HttpRequest.Builder var128 = var127.setHeader(var220, var237);
                     HttpRequest var129 = var128.build();
                     var281 ^= 1489569399;
                     BodyHandler var238 = BodyHandlers.ofString();
                     HttpResponse var131 = var19.send(var129, var238);
                     var281 ^= 82965148;
                     int var133 = var131.statusCode();
                     var281 ^= 1566876133;
                     var20 = var133;
                     var281 ^= 989614933;
                  } catch (Exception var286) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var281)) {
                     case -1577554184:
                        var281 ^= 812198375;
                        break;
                     case -1424308600:
                        var281 ^= 825588969;
                        break;
                     case 1077922210:
                        var281 ^= 1817304332;
                        break;
                     case 1739611458:
                        var281 ^= 1755328400;
                        break;
                     default:
                        throw new RuntimeException("Error in hash");
                     }

                     var281 ^= 762344943;
                     var286.printStackTrace();
                     var281 ^= 1004853996;
                     break label410;
                  }

                  label308:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                     case 205785552:
                        var281 ^= 1613547875;
                        break label308;
                     case 363641633:
                        break;
                     case 758758784:
                     default:
                        throw new IllegalAccessException();
                     case 1897795173:
                        break label308;
                     }
                  }

                  try {
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 174851628) {
                        throw null;
                     }

                     throw new IllegalAccessException();
                  } catch (IllegalAccessException var285) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var281)) {
                     case -1270571991:
                        var281 ^= 1186725394;
                        break;
                     case 2107512634:
                        var281 ^= 1065398128;
                        break;
                     default:
                        throw new RuntimeException("Error in hash");
                     }
                  }

                  label297:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                     case 157537383:
                        var281 ^= 1123149484;
                        break label297;
                     case 723276650:
                        break;
                     case 1363822907:
                     default:
                        throw new IllegalAccessException();
                     case 2145068895:
                        break label297;
                     }
                  }
               }

               short var222 = (short)(851610611 ^ var281);
               if (var20 != var222) {
                  var281 ^= 1240192965;
                  String var135 = xlnoigleho(qlqophqofftkjdl(), rmdqikusoembxnk(), var281);
                  log$2121372563(var135, 1088644123);
                  var281 ^= 1116112710;
                  String var136 = xlnoigleho(nbgwhdjwtslkblx(), rmdqikusoembxnk(), var281);
                  log$2121372563(var136, 1088644123);
                  var281 ^= 1963516198;
                  String var137 = xlnoigleho(ruujzauydhvwsfc(), rmdqikusoembxnk(), var281);
                  log$2121372563(var137, 1088644123);
                  var281 ^= 1762971707;
                  String var138 = xlnoigleho(mxkzvrcnrhvjlny(), rmdqikusoembxnk(), var281);
                  log$2121372563(var138, 1088644123);
                  var281 ^= 1775415770;
                  String var139 = xlnoigleho(rtslyychbnctbnm(), rmdqikusoembxnk(), var281);
                  log$2121372563(var139, 1088644123);
                  var281 ^= 1406292502;
                  String var140 = xlnoigleho(omdmqfgkespzmdx(), rmdqikusoembxnk(), var281);
                  log$2121372563(var140, 1088644123);
                  var281 ^= 894891271;

                  try {
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 52278256) {
                        throw null;
                     }

                     throw new RuntimeException();
                  } catch (RuntimeException var284) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var281)) {
                     case 281953648:
                        var281 ^= 151331018;
                        break;
                     case 1462756209:
                        var281 = saxuwxcnfwcxyrlg(var281, 569971722);
                        break;
                     default:
                        throw new RuntimeException("Error in hash");
                     }
                  }

                  label249:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                     case 92801373:
                        var281 ^= 1058397250;
                        break label249;
                     case 565617753:
                     default:
                        throw new IllegalAccessException();
                     case 1379283197:
                        break label249;
                     case 1397579954:
                     }
                  }
               } else {
                  label418: {
                     var281 ^= 398127279;
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 144263702) {
                        var281 ^= 703283872;
                        throw new IllegalAccessException();
                     }

                     var281 ^= 236641861;
                     String var142 = MainConfig.PluginSettings.LICENSE_KEY;
                     License.LicenseData var143 = License.getLicenseById(var142);
                     var281 ^= 1091379242;
                     if (var143 != null) {
                        var281 ^= 1453457882;
                        String var146 = var143.product();
                        byte var147 = var146.equals(var119);
                        if (var147 != (1020101665 ^ var281)) {
                           var281 = saxuwxcnfwcxyrlg(var281, 1827411222);
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 188832123) {
                              while(true) {
                                 switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                                 case 188832123:
                                    var281 ^= 1555212291;
                                    throw new IllegalAccessException();
                                 case 642181722:
                                    break;
                                 case 2046317209:
                                 case 2078441100:
                                 default:
                                    throw new IllegalAccessException();
                                 }
                              }
                           }

                           var281 ^= 546872975;
                           SimpleDateFormat var157 = new SimpleDateFormat();
                           var281 ^= 561778162;
                           String var158 = xlnoigleho(hddovgakuafzhrw(), rmdqikusoembxnk(), var281);
                           log$2121372563(var158, 1088644123);
                           var281 ^= 521768113;
                           String var159 = MainConfig.PluginSettings.LICENSE_KEY;
                           byte var225 = (byte)(1323077371 ^ var281);
                           String var239 = MainConfig.PluginSettings.LICENSE_KEY;
                           int var240 = var239.length();
                           byte var258 = (byte)(1323077374 ^ var281);
                           int var241 = var240 / var258;
                           String var160 = var159.substring(var225, var241);
                           String var161 = "§fLicense Key: §b" + var160 + "**********";
                           log$2121372563(var161, 1088644123);
                           var281 ^= 1558479441;
                           String var163 = var143.owner();
                           String var164 = "§fOwner: §b" + var163;
                           log$2121372563(var164, 1088644123);
                           var281 ^= 400974792;
                           long var260 = var143.creation_date();
                           Date var226 = new Date(var260);
                           String var166 = var157.format(var226);
                           String var167 = "§fCreation Date: §b" + var166;
                           log$2121372563(var167, 1088644123);
                           var281 ^= 1147480781;
                           String var169 = var143.product();
                           String var170 = "§fProduct: §b" + var169;
                           log$2121372563(var170, 1088644123);
                           var281 ^= 890781637;
                           String[] var172 = var143.ips();
                           String var173 = Arrays.toString(var172);
                           String var174 = "§fAllowed IPs: §b" + var173;
                           log$2121372563(var174, 1088644123);
                           var281 ^= 815521481;
                           String var175 = xlnoigleho(spbbwyulftrxgui(), rmdqikusoembxnk(), var281);
                           log$2121372563(var175, 1088644123);
                           var281 ^= 1882296453;
                           break label418;
                        }

                        var281 ^= 1555507340;
                     } else {
                        label269:
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                           case 49068549:
                           default:
                              throw new IllegalAccessException();
                           case 238582265:
                              var281 ^= 1196369028;
                           case 465419516:
                              break label269;
                           case 1883767148:
                           }
                        }

                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281) != 124720582) {
                           var281 = saxuwxcnfwcxyrlg(var281, 565418059);
                           throw new IllegalAccessException();
                        }

                        label259:
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var281)) {
                           case 124720582:
                              var281 ^= 1297747410;
                           case 804088191:
                              break label259;
                           case 982438822:
                           default:
                              throw new IllegalAccessException();
                           case 1201456702:
                           }
                        }
                     }

                     String var148 = xlnoigleho(tsddnpzsafepijz(), rmdqikusoembxnk(), var281);
                     log$2121372563(var148, 1088644123);
                     var281 ^= 1784757062;
                     String var149 = xlnoigleho(krgphgxhqctvpda(), rmdqikusoembxnk(), var281);
                     log$2121372563(var149, 1088644123);
                     var281 ^= 1699136190;
                     String var150 = MainConfig.PluginSettings.LICENSE_KEY;
                     String var151 = "§4INVALID LICENSE KEY '" + var150 + "'";
                     log$2121372563(var151, 1088644123);
                     var281 ^= 1915471377;
                     String var152 = xlnoigleho(eimyrkrrrragtwx(), rmdqikusoembxnk(), var281);
                     log$2121372563(var152, 1088644123);
                     var281 ^= 1790462490;
                     String var153 = xlnoigleho(jokmlzzqzjzllcr(), rmdqikusoembxnk(), var281);
                     log$2121372563(var153, 1088644123);
                     var281 ^= 999068142;
                     String var154 = xlnoigleho(omxaixkwcmdstxp(), rmdqikusoembxnk(), var281);
                     log$2121372563(var154, 1088644123);
                     var281 ^= 1456685016;
                     String var155 = xlnoigleho(qrgtupbwgnkpkke(), rmdqikusoembxnk(), var281);
                     log$2121372563(var155, 1088644123);
                     var281 ^= 1724467774;
                     PluginManager var156 = Bukkit.getPluginManager();
                     var156.disablePlugin(this);
                     var281 ^= 1988310921;
                     break label419;
                  }
               }

               this.reloadCrates$1915480240(2123490062);
               var281 ^= 212681971;
            }
         }
      }

      Object var283 = null;
      UpperStackLicense.hexItem(this);
   }

   public static void log$2121372563(String var0, int var1) {
      int var5 = 1578036247 ^ 872201238 ^ soWjD6JRrA ^ var1;
      var5 ^= 448299853;
      ConsoleCommandSender var2 = Bukkit.getConsoleSender();
      var2.sendMessage(var0);
      var5 ^= 1811290902;
   }

   private FileConfiguration loadConfig$1876126984(String var1, int var2) {
      int var16 = 1350913038 ^ 767835762 ^ this.Jm9tEPij1G ^ var2;
      var16 ^= 605079239;
      File var13 = this.getDataFolder();
      File var3 = new File(var13, var1);
      var16 ^= 2079827428;
      byte var8 = var3.exists();
      if (var8 == (603280389 ^ var16)) {
         var16 ^= 833703063;
         byte var14 = (byte)(306452626 ^ var16);
         this.saveResource(var1, (boolean)var14);
         var16 ^= 344256454;
      } else {
         var16 ^= 219060658;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var16) != 185069673) {
            var16 ^= 521602596;
            throw new RuntimeException();
         }

         var16 ^= 674970339;
      }

      YamlConfiguration var11 = YamlConfiguration.loadConfiguration(var3);
      return var11;
   }

   public void onDisable() {
      int var5 = 899021765 ^ 1428924694 ^ this.Jm9tEPij1G;
      var5 ^= 427057815;
      SQLiteManager var2 = this.sqLiteManager;
      var2.close$1371832018(414809750);
      var5 ^= 2001619789;
   }

   public void reloadCrates$1915480240(int var1) {
      int var9 = 1018883727 ^ 256622538 ^ this.Jm9tEPij1G ^ var1;
      var9 ^= 216897913;
      BukkitScheduler var2 = Bukkit.getScheduler();
      Runnable var4 = new Runnable(948210153) {
         private static int 7amdGpmnLt;
         private transient int ZZqJY64ltt;
         private static byte[] ffxualfogu;
         private static String[] nothing_to_see_here = new String[13];

         {
            int var7 = 757250526 ^ 1071608802;
            var7 ^= 2137775521;
            var7 = 1689879607 ^ 528487213 ^ Integer.parseInt("774572398") ^ var2;
            this.ZZqJY64ltt = 1185294448 ^ 7amdGpmnLt;
            var7 ^= 1554377433;
         }

         public void run() {
            int var6 = 1800287126 ^ 1566086487 ^ this.ZZqJY64ltt;
            var6 ^= 1159880372;
            ConsoleCommandSender var1 = Bukkit.getConsoleSender();
            String var2 = kmfrzfchgf(misyqfjeelrqaed(), var6);
            Bukkit.dispatchCommand(var1, var2);
            var6 ^= 528363196;
         }

         static {
            nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ";
            nothing_to_see_here[1] = "⠀⠀⠀⠀⣠⣶⡾⠏⠉⠙⠳⢦⡀⠀⠀⠀⢠⠞⠉⠙⠲⡀⠀    ";
            nothing_to_see_here[2] = "⠀⠀⠀⣴⠿⠏⠀⠀⠀⠀⠀⠀⢳⡀⠀⡏⠀⠀⠀⠀⠀⢷     ";
            nothing_to_see_here[3] = "⠀⠀⢠⣟⣋⡀⢀⣀⣀⡀⠀⣀⡀⣧⠀⢸⠀⠀⠀⠀⠀ ⡇    ";
            nothing_to_see_here[4] = "⠀⠀⢸⣯⡭⠁⠸⣛⣟⠆⡴⣻⡲⣿⠀⣸⠀⠀OK⠀ ⡇    ";
            nothing_to_see_here[5] = "⠀⠀⣟⣿⡭⠀⠀⠀⠀⠀⢱⠀⠀⣿⠀⢹⠀⠀⠀⠀⠀ ⡇    ";
            nothing_to_see_here[6] = "⠀⠀⠙⢿⣯⠄⠀⠀⠀⢀⡀⠀⠀⡿⠀⠀⡇⠀⠀⠀⠀⡼     ";
            nothing_to_see_here[7] = "⠀⠀⠀⠀⠹⣶⠆⠀⠀⠀⠀⠀⡴⠃⠀⠀⠘⠤⣄⣠⠞⠀     ";
            nothing_to_see_here[8] = "⠀⠀⠀⠀⠀⢸⣷⡦⢤⡤⢤⣞⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ";
            nothing_to_see_here[9] = "⠀⠀⢀⣤⣴⣿⣏⠁⠀⠀⠸⣏⢯⣷⣖⣦⡀⠀⠀⠀⠀⠀⠀    ";
            nothing_to_see_here[10] = "⢀⣾⣽⣿⣿⣿⣿⠛⢲⣶⣾⢉⡷⣿⣿⠵⣿⠀⠀⠀⠀⠀⠀    ";
            nothing_to_see_here[11] = "⣼⣿⠍⠉⣿⡭⠉⠙⢺⣇⣼⡏⠀⠀⠀⣄⢸⠀⠀⠀⠀⠀⠀    ";
            nothing_to_see_here[12] = "⣿⣿⣧⣀⣿.........⣀⣰⣏⣘⣆⣀⠀⠀       ";
            ffxualfogu = gbllkvpgwtqpuea();
            int var3 = (new Random(-719429592852278830L)).nextInt();
            7amdGpmnLt = -3568098 ^ var3;
         }

         public static String kmfrzfchgf(byte[] var0, int var1) {
            String var10 = Integer.toString(var1);
            byte[] var11 = var10.getBytes();
            byte[] var8 = var11;
            byte var12 = 0;
            int var9 = var12;

            while(true) {
               int var17 = var0.length;
               if (var9 >= var17) {
                  Charset var5 = StandardCharsets.UTF_16;
                  String var14 = new String(var0, var5);
                  return var14;
               }

               byte var20 = var0[var9];
               int var33 = var8.length;
               int var30 = var9 % var33;
               byte var27 = var8[var30];
               int var21 = var20 ^ var27;
               byte var22 = (byte)var21;
               var0[var9] = var22;
               byte var23 = var0[var9];
               byte[] var28 = ffxualfogu;
               byte[] var34 = ffxualfogu;
               int var35 = var34.length;
               int var32 = var9 % var35;
               byte var29 = var28[var32];
               int var24 = var23 ^ var29;
               byte var25 = (byte)var24;
               var0[var9] = var25;
               ++var9;
            }
         }

         private static byte[] gbllkvpgwtqpuea() {
            return new byte[]{8, 20, 1, 97, 33, 11, 20, 120, 101, 28, 12, 23, 106, 34, 94, 98, 104, 81, 105, 88, 94, 39, 38, 103, 107, 92, 32, 25, 35, 39, 31, 101, 24, 108, 61, 86, 28, 117, 41, 62, 57, 49, 39, 27, 18, 124, 11, 50, 27, 29, 124, 65, 90, 12, 43, 61, 27, 42, 95, 107, 123, 124, 43, 28, 47, 50, 68, 79, 41, 66, 113, 101, 94, 26, 123, 18, 54, 99, 50, 84, 124, 104, 13, 56, 56, 123, 26, 85, 60, 47};
         }

         private static byte[] misyqfjeelrqaed() {
            return new byte[]{-62, -38, 56, 51, 22, 72, 33, 47, 81, 92, 61, 75, 91, 102, 111, 119, 94, 23, 93, 12, 103, 122, 17, 57, 94, 11, 20, 73};
         }
      };
      long var7 = 1200L;
      var2.runTaskLater(this, var4, var7);
      var9 ^= 1726457237;
   }

   public void clean$2056612436(Player var1, int var2) {
      int var28 = 2081824275 ^ 1251865810 ^ this.Jm9tEPij1G ^ var2;
      var28 ^= 1324470430;
      RulesGUI var5 = this.rulesGui;
      var5.remove$1734529989(var1, 378968196);
      var28 ^= 2122129421;
      MediaGUI var7 = this.mediaGui;
      var7.remove$1734529989(var1, 378968196);
      var28 ^= 1909573930;
      HelpGUI var9 = this.helpGui;
      var9.remove$1734529989(var1, 378968196);
      var28 ^= 200878204;
      SpawnGUI var11 = this.spawnGui;
      var11.remove$1734529989(var1, 378968196);
      var28 ^= 631933099;
      AfkGUI var13 = this.afkGui;
      var13.remove$1734529989(var1, 378968196);
      var28 ^= 2087349181;
      BillfordGUI var15 = this.billfordGui;
      var15.remove$1734529989(var1, 378968196);
      var28 ^= 2132088718;
      BillfordEditorGUI var17 = this.billfordEditorGui;
      var17.remove$1734529989(var1, 378968196);
      var28 ^= 517282859;
      BillfordEditorItemsGUI var19 = this.billfordEditorItemsGUI;
      var19.remove$1734529989(var1, 378968196);
      var28 ^= 1822109272;
   }

   private boolean setupEconomy$1059304311(int var1) {
      int var24 = 1490413925 ^ 414842677 ^ this.Jm9tEPij1G ^ var1;
      var24 ^= 2134179322;
      Server var5 = this.getServer();
      PluginManager var6 = var5.getPluginManager();
      String var3 = xlnoigleho(mqiwsbpuxokvcxm(), rmdqikusoembxnk(), var24);
      Plugin var7 = var6.getPlugin(var3);
      if (var7 == null) {
         var24 ^= 1081010679;
         byte var18 = (byte)(1392042433 ^ var24);
         return (boolean)var18;
      } else {
         var24 = saxuwxcnfwcxyrlg(var24, 318339886);
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24) != 6847369) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24)) {
               case 6847369:
                  var24 ^= 111060605;
                  throw new RuntimeException();
               case 372899165:
                  break;
               case 545898731:
               case 815544390:
               default:
                  throw new RuntimeException();
               }
            }
         } else {
            var24 = saxuwxcnfwcxyrlg(var24, 648884703);
            Server var9 = this.getServer();
            ServicesManager var10 = var9.getServicesManager();
            Class var19 = Economy.class;
            RegisteredServiceProvider var11 = var10.getRegistration(var19);
            var24 ^= 1237129485;
            if (var11 == null) {
               var24 ^= 1289609161;
               byte var13 = (byte)(597853187 ^ var24);
               return (boolean)var13;
            } else {
               var24 = saxuwxcnfwcxyrlg(var24, 2037230122);
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24) != 180658864) {
                  var24 = saxuwxcnfwcxyrlg(var24, 283321477);
                  throw new RuntimeException();
               } else {
                  label91:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24)) {
                     case 180658864:
                        var24 ^= 1722369015;
                        break label91;
                     case 634133173:
                     default:
                        throw new RuntimeException();
                     case 944222026:
                        break;
                     case 1260788005:
                        break label91;
                     }
                  }

                  Object var21 = var11.getProvider();
                  Economy var22 = (Economy)var21;
                  this.economy = var22;
                  var24 ^= 1907731564;
                  Economy var16 = this.economy;
                  byte var17;
                  if (var16 != null) {
                     var24 ^= 607349376;
                     var17 = (byte)(624784634 ^ var24);
                     var24 ^= 1974155897;

                     try {
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24) != 203647117) {
                           throw null;
                        }

                        throw new RuntimeException();
                     } catch (RuntimeException var25) {
                        switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var24)) {
                        case -2068679662:
                           var24 = saxuwxcnfwcxyrlg(var24, 319813636);
                           break;
                        case 1377415008:
                           var24 ^= 1239057258;
                           break;
                        default:
                           throw new IllegalAccessException("Error in hash");
                        }
                     }

                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24)) {
                        case 49910330:
                           var24 ^= 918970702;
                           return (boolean)var17;
                        case 402844771:
                        default:
                           throw new RuntimeException();
                        case 622860741:
                           break;
                        case 1240474339:
                           return (boolean)var17;
                        }
                     }
                  } else {
                     var24 ^= 1862850225;
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24) != 86854401) {
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24)) {
                           case 86854401:
                              var24 ^= 1761025455;
                              throw new RuntimeException();
                           case 254205664:
                           case 290767938:
                           default:
                              throw new RuntimeException();
                           case 1330637655:
                           }
                        }
                     } else {
                        var24 ^= 1377060170;
                        var17 = (byte)(1007848832 ^ var24);
                        var24 ^= 1229806152;
                        return (boolean)var17;
                     }
                  }
               }
            }
         }
      }
   }

   public void loadHelpFeature$2074084618(int var1) {
      int var10 = 1788298976 ^ 757540777 ^ this.Jm9tEPij1G ^ var1;
      var10 ^= 670207337;
      String var3 = xlnoigleho(xywwagqubibiryq(), rmdqikusoembxnk(), var10);
      PluginCommand var5 = this.getCommand(var3);
      HelpCommand var8 = new HelpCommand(this, 298935);
      var5.setExecutor(var8);
      var10 ^= 884308239;
      HelpGUI var7 = this.helpGui;
      var7.loadHelpConfigValues$1430792781(839749214);
      var10 ^= 1774673537;
   }

   public void loadSpawnFeature$2109479120(int var1) {
      int var35 = 1205814299 ^ 286135490 ^ this.Jm9tEPij1G ^ var1;
      var35 ^= 573570266;
      TeleportManager var3 = new TeleportManager(this, 2134981223);
      this.teleportManager = var3;
      var35 ^= 354953784;
      SQLiteManager var23 = this.sqLiteManager;
      TeleportManager var26 = this.teleportManager;
      SpawnGUI var17 = new SpawnGUI(this, var23, var26, 588188175);
      this.spawnGui = var17;
      var35 ^= 425467037;
      CommandMap var10 = this.getCommandMap$1431339485(436386096);
      String var18 = xlnoigleho(cxbbnqpocbtkclr(), rmdqikusoembxnk(), var35);
      SQLiteManager var28 = this.sqLiteManager;
      TeleportManager var31 = this.teleportManager;
      SpawnCommand var20 = new SpawnCommand(this, var28, var31, 1548423865);
      var10.register(var18, var20);
      var35 ^= 587569423;
      CommandMap var13 = this.getCommandMap$1431339485(436386096);
      String var19 = xlnoigleho(pdfenrhysygjrxt(), rmdqikusoembxnk(), var35);
      SQLiteManager var30 = this.sqLiteManager;
      SpawnGUI var33 = this.spawnGui;
      SetSpawnCommand var21 = new SetSpawnCommand(this, var30, var33, 1796320408);
      var13.register(var19, var21);
      var35 ^= 1303515688;
      SpawnGUI var16 = this.spawnGui;
      var16.loadSpawnConfigValues$882403349(870176311);
      var35 ^= 1727600198;
   }

   public void loadAfkFeature$22344590(int var1) {
      int var35 = 1359942008 ^ 1108630374 ^ this.Jm9tEPij1G ^ var1;
      var35 ^= 283448070;
      TeleportManager var3 = new TeleportManager(this, 2134981223);
      this.teleportManager = var3;
      var35 ^= 1460863587;
      SQLiteManager var23 = this.sqLiteManager;
      TeleportManager var26 = this.teleportManager;
      AfkGUI var17 = new AfkGUI(this, var23, var26, 469798925);
      this.afkGui = var17;
      var35 ^= 147708668;
      CommandMap var10 = this.getCommandMap$1431339485(436386096);
      String var18 = xlnoigleho(hyhkqmcwtkykysi(), rmdqikusoembxnk(), var35);
      SQLiteManager var28 = this.sqLiteManager;
      TeleportManager var31 = this.teleportManager;
      AfkCommand var20 = new AfkCommand(this, var28, var31, 436311718);
      var10.register(var18, var20);
      var35 ^= 414073051;
      CommandMap var13 = this.getCommandMap$1431339485(436386096);
      String var19 = xlnoigleho(vbqdjcosqbmryeb(), rmdqikusoembxnk(), var35);
      SQLiteManager var30 = this.sqLiteManager;
      AfkGUI var33 = this.afkGui;
      SetAfkCommand var21 = new SetAfkCommand(this, var30, var33, 318328212);
      var13.register(var19, var21);
      var35 ^= 1431303367;
      AfkGUI var16 = this.afkGui;
      var16.loadAfkConfigValues$568738828(1586297296);
      var35 ^= 964685756;
   }

   public void loadMediaFeature$658125645(int var1) {
      int var11 = 9869402 ^ 166406460 ^ this.Jm9tEPij1G ^ var1;
      var11 ^= 595187043;
      CommandMap var6 = this.getCommandMap$1431339485(436386096);
      String var3 = xlnoigleho(nnfkdhdqsvxfnxn(), rmdqikusoembxnk(), var11);
      MediaCommand var4 = new MediaCommand(this, 1389544220);
      var6.register(var3, var4);
      var11 ^= 1867852469;
      MediaGUI var9 = this.mediaGui;
      var9.loadMediaConfigValues$2120577358(54860659);
      var11 ^= 1326041952;
   }

   public void loadRulesFeature$424103264(int var1) {
      int var11 = 952052339 ^ 1459644351 ^ this.Jm9tEPij1G ^ var1;
      var11 ^= 1517932887;
      CommandMap var6 = this.getCommandMap$1431339485(436386096);
      String var3 = xlnoigleho(rpioetbcobamcjc(), rmdqikusoembxnk(), var11);
      RulesCommand var4 = new RulesCommand(this, 126255370);
      var6.register(var3, var4);
      var11 ^= 1722087782;
      RulesGUI var9 = this.rulesGui;
      var9.loadRulesConfigValues$113812495(476948616);
      var11 ^= 1430056523;
   }

   public void loadBillfordFeature$2003866414(int var1) {
      int var15 = 1963804087 ^ 121191186 ^ this.Jm9tEPij1G ^ var1;
      var15 ^= 425491201;
      CommandMap var6 = this.getCommandMap$1431339485(436386096);
      String var3 = xlnoigleho(xhjccugimyrvryi(), rmdqikusoembxnk(), var15);
      BillfordCommand var4 = new BillfordCommand(this, 715151273);
      var6.register(var3, var4);
      var15 ^= 384094505;
      CommandMap var9 = this.getCommandMap$1431339485(436386096);
      String var11 = xlnoigleho(xnpajxdtmlldzsc(), rmdqikusoembxnk(), var15);
      BillfordEditorCommand var12 = new BillfordEditorCommand(this, 2103557448);
      var9.register(var11, var12);
      var15 ^= 1354163076;
   }

   public void loadChatFeature$468648758(int var1) {
      int var25 = 1540365765 ^ 1381872889 ^ this.Jm9tEPij1G ^ var1;
      var25 ^= 1909766547;
      String var3 = xlnoigleho(mrbogjsmmxaeznj(), rmdqikusoembxnk(), var25);
      PluginCommand var7 = this.getCommand(var3);
      SQLiteManager var19 = this.sqLiteManager;
      MessageCommand var13 = new MessageCommand(this, var19, 408042060);
      var7.setExecutor(var13);
      var25 ^= 956737419;
      CommandMap var9 = this.getCommandMap$1431339485(436386096);
      String var14 = xlnoigleho(uqozmorwhwouaqp(), rmdqikusoembxnk(), var25);
      SQLiteManager var23 = this.sqLiteManager;
      MessageToggleCommand var17 = new MessageToggleCommand(this, var23, 321018589);
      var9.register(var14, var17);
      var25 ^= 545507246;
      String var15 = xlnoigleho(alytknsvgsnvspm(), rmdqikusoembxnk(), var25);
      PluginCommand var12 = this.getCommand(var15);
      SQLiteManager var22 = this.sqLiteManager;
      ReplyCommand var16 = new ReplyCommand(this, var22, 252378063);
      var12.setExecutor(var16);
      var25 ^= 2012361562;
   }

   public void loadNightVisionFeature$1305102662(int var1) {
      int var9 = 1444519651 ^ 1324216017 ^ this.Jm9tEPij1G ^ var1;
      var9 ^= 947359624;
      CommandMap var6 = this.getCommandMap$1431339485(436386096);
      String var3 = xlnoigleho(wzakuohmknxkmph(), rmdqikusoembxnk(), var9);
      NightVisionCommand var4 = new NightVisionCommand(this, 590688448);
      var6.register(var3, var4);
      var9 ^= 356600582;
   }

   public void loadEconomyFeature$749298711(int var1) {
      int var26 = 928081957 ^ 1774626834 ^ this.Jm9tEPij1G ^ var1;
      var26 ^= 621619793;
      CommandMap var7 = this.getCommandMap$1431339485(436386096);
      String var3 = xlnoigleho(ccrzaquyypygqyb(), rmdqikusoembxnk(), var26);
      Economy var19 = this.economy;
      SQLiteManager var24 = this.sqLiteManager;
      PayCommand var4 = new PayCommand(var19, var24, 1403933327);
      var7.register(var3, var4);
      var26 ^= 252903990;
      CommandMap var10 = this.getCommandMap$1431339485(436386096);
      String var15 = xlnoigleho(klpgukhwfqklvci(), rmdqikusoembxnk(), var26);
      SQLiteManager var21 = this.sqLiteManager;
      PayToggleCommand var17 = new PayToggleCommand(var21, 911373974);
      var10.register(var15, var17);
      var26 ^= 1216011086;
      CommandMap var13 = this.getCommandMap$1431339485(436386096);
      String var16 = xlnoigleho(cmmpfiecxvtgrfe(), rmdqikusoembxnk(), var26);
      Economy var23 = this.economy;
      BalanceCommand var18 = new BalanceCommand(var23, 905964380);
      var13.register(var16, var18);
      var26 ^= 639035620;
   }

   private CommandMap getCommandMap$1431339485(int var1) {
      int var24 = 101819631 ^ 1731363850 ^ this.Jm9tEPij1G ^ var1;
      var24 ^= 266275845;
      Object var2 = null;
      CommandMap var4 = (CommandMap)var2;
      var24 ^= 898697126;

      label91: {
         try {
            Server var7 = this.getServer();
            if (var7 != null) {
               var24 ^= 978589573;
               Server var9 = this.getServer();
               Class var10 = var9.getClass();
               String var3 = xlnoigleho(tqeuyusgpwtjnwq(), rmdqikusoembxnk(), var24);
               Field var11 = var10.getDeclaredField(var3);
               var24 ^= 348194330;
               byte var19 = (byte)(1402212878 ^ var24);
               var11.setAccessible((boolean)var19);
               var24 ^= 515608873;
               Server var21 = this.getServer();
               Object var14 = var11.get(var21);
               CommandMap var15 = (CommandMap)var14;
               var24 ^= 812047681;
               var4 = var15;
               var24 ^= 2120543581;
               break label91;
            }
         } catch (ReflectiveOperationException var26) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var24)) {
            case -1667198854:
               var24 = saxuwxcnfwcxyrlg(var24, 1058729286);
               break;
            case -402121597:
               var24 ^= 294649049;
               break;
            case -364186821:
               var24 ^= 298295598;
               break;
            case 984129706:
               var24 ^= 735832924;
               break;
            case 1769740594:
               var24 ^= 564231279;
               break;
            default:
               throw new IllegalAccessException("Error in hash");
            }

            var24 ^= 635161234;
            var26.printStackTrace();
            var24 ^= 1538018797;
            return var4;
         }

         var24 ^= 428361602;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24) != 46765931) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24)) {
               case 46765931:
                  var24 ^= 199560037;
                  throw new IOException();
               case 220262715:
                  break;
               case 1225464886:
               case 1978744296:
               default:
                  throw new IOException();
               }
            }
         }

         var24 = saxuwxcnfwcxyrlg(var24, 1738864424);
      }

      label73:
      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24)) {
         case 49994539:
            var24 ^= 1819041163;
         case 294466972:
            break label73;
         case 314114480:
            break;
         case 517705655:
         default:
            throw new IOException();
         }
      }

      try {
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24) != 126865719) {
            throw null;
         }

         throw new IllegalAccessException();
      } catch (IllegalAccessException var25) {
         switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var24)) {
         case -1947618613:
            var24 ^= 173135992;
            break;
         case 2047833483:
            var24 = saxuwxcnfwcxyrlg(var24, 342687888);
            break;
         default:
            throw new IllegalAccessException("Error in hash");
         }
      }

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24)) {
         case 245855859:
            var24 ^= 1775605271;
            return var4;
         case 1792591277:
            return var4;
         case 1926710810:
         default:
            throw new IOException();
         case 2024683180:
         }
      }
   }

   public FileConfiguration getHelpGuiConfig$689393799(int var1) {
      int var5 = 662751929 ^ 1340201903 ^ this.Jm9tEPij1G ^ var1;
      var5 ^= 1849221482;
      FileConfiguration var3 = this.helpGuiConfig;
      return var3;
   }

   public FileConfiguration getMediaGuiConfig$1766465157(int var1) {
      int var5 = 811187623 ^ 1145046845 ^ this.Jm9tEPij1G ^ var1;
      var5 ^= 896829686;
      FileConfiguration var3 = this.mediaGuiConfig;
      return var3;
   }

   public FileConfiguration getRulesGuiConfig$546180320(int var1) {
      int var5 = 1629702232 ^ 907388991 ^ this.Jm9tEPij1G ^ var1;
      var5 ^= 1399888505;
      FileConfiguration var3 = this.rulesGuiConfig;
      return var3;
   }

   public FileConfiguration getafkSpawnGuiConfig$23715181(int var1) {
      int var5 = 675120275 ^ 470555212 ^ this.Jm9tEPij1G ^ var1;
      var5 ^= 765456431;
      FileConfiguration var3 = this.afkSpawnGuiConfig;
      return var3;
   }

   public FileConfiguration getBillfordGuiConfig$756205206(int var1) {
      int var5 = 18186717 ^ 1338512392 ^ this.Jm9tEPij1G ^ var1;
      var5 ^= 1638729159;
      FileConfiguration var3 = this.billfordGuiConfig;
      return var3;
   }

   public HelpGUI getHelpGui$1055651724(int var1) {
      int var5 = 1971181289 ^ 431138791 ^ this.Jm9tEPij1G ^ var1;
      var5 ^= 2000638302;
      HelpGUI var3 = this.helpGui;
      return var3;
   }

   public MediaGUI getMediaGui$275199606(int var1) {
      int var5 = 692382841 ^ 539931916 ^ this.Jm9tEPij1G ^ var1;
      var5 ^= 821542423;
      MediaGUI var3 = this.mediaGui;
      return var3;
   }

   public RulesGUI getRulesGui$369068666(int var1) {
      int var5 = 2129616179 ^ 1219093226 ^ this.Jm9tEPij1G ^ var1;
      var5 ^= 1902392019;
      RulesGUI var3 = this.rulesGui;
      return var3;
   }

   public SpawnGUI getSpawnGui$166485211(int var1) {
      int var5 = 381565519 ^ 1036007141 ^ this.Jm9tEPij1G ^ var1;
      var5 ^= 1622754788;
      SpawnGUI var3 = this.spawnGui;
      return var3;
   }

   public AfkGUI getAfkGui$1831569283(int var1) {
      int var5 = 765760614 ^ 1821409210 ^ this.Jm9tEPij1G ^ var1;
      var5 ^= 655609200;
      AfkGUI var3 = this.afkGui;
      return var3;
   }

   public Map getLastMessaged$1938418975(int var1) {
      int var5 = 158459099 ^ 39886061 ^ this.Jm9tEPij1G ^ var1;
      var5 ^= 561640788;
      Map var3 = this.lastMessaged;
      return var3;
   }

   public BillfordGUI getBillfordGui$981559054(int var1) {
      int var5 = 1057385739 ^ 223926319 ^ this.Jm9tEPij1G ^ var1;
      var5 ^= 1450756350;
      BillfordGUI var3 = this.billfordGui;
      return var3;
   }

   public BillfordEditorGUI getBillfordEditorGui$1275699852(int var1) {
      int var5 = 987657287 ^ 2092525565 ^ this.Jm9tEPij1G ^ var1;
      var5 ^= 351315261;
      BillfordEditorGUI var3 = this.billfordEditorGui;
      return var3;
   }

   public BillfordEditorItemsGUI getBillfordEditorItemsGui$131132968(int var1) {
      int var5 = 1601392893 ^ 404616553 ^ this.Jm9tEPij1G ^ var1;
      var5 ^= 1508930382;
      BillfordEditorItemsGUI var3 = this.billfordEditorItemsGUI;
      return var3;
   }

   public void saveBillfordGuiConfig$978105170(int var1) {
      int var12 = 1994252470 ^ 848300955 ^ this.Jm9tEPij1G ^ var1;
      var12 ^= 437881875;

      try {
         FileConfiguration var7 = this.getBillfordGuiConfig$756205206(1840850862);
         File var10 = this.getDataFolder();
         String var5 = xlnoigleho(jcsxskzsyehaagj(), rmdqikusoembxnk(), var12);
         File var3 = new File(var10, var5);
         var7.save(var3);
         var12 ^= 559100411;
      } catch (IOException var14) {
         switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var12)) {
         case -1616927975:
            var12 ^= 2120947114;
            var12 ^= 506184644;
            var14.printStackTrace();
            var12 ^= 1251668912;
            return;
         default:
            throw new RuntimeException("Error in hash");
         }
      }

      var12 ^= 132373502;

      try {
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var12) != 154279846) {
            throw null;
         } else {
            throw new RuntimeException();
         }
      } catch (RuntimeException var13) {
         switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var12)) {
         case -1441205456:
            var12 ^= 549082816;
            break;
         case 236969354:
            var12 ^= 1950003991;
            break;
         default:
            throw new IOException("Error in hash");
         }

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var12)) {
            case 53721060:
            default:
               throw new IOException();
            case 143837496:
               var12 ^= 751868187;
               return;
            case 1827959520:
               return;
            case 2082740247:
            }
         }
      }
   }

   static {
      nothing_to_see_here[0] = "⢀⡴⠑⡄⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠸⡇⠀⠿⡀⠀⠀⠀⣀⡴⢿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠑⢄⣠⠾⠁⣀⣄⡈⠙⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⢀⡀⠁⠀⠀⠈⠙⠛⠂⠈⣿⣿⣿⣿⣿⠿⡿⢿⣆⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⢀⡾⣁⣀⠀⠴⠂⠙⣗⡀⠀⢻⣿⣿⠭⢤⣴⣦⣤⣹⠀⠀⠀⢀⢴⣶⣆";
      nothing_to_see_here[5] = "⠀⠀⢀⣾⣿⣿⣿⣷⣮⣽⣾⣿⣥⣴⣿⣿⡿⢂⠔⢚⡿⢿⣿⣦⣴⣾⠁⠸⣼⡿";
      nothing_to_see_here[6] = "⠀⢀⡞⠁⠙⠻⠿⠟⠉⠀⠛⢹⣿⣿⣿⣿⣿⣌⢤⣼⣿⣾⣿⡟⠉⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⣾⣷⣶⠇⠀⠀⣤⣄⣀⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠉⠈⠉⠀⠀⢦⡈⢻⣿⣿⣿⣶⣶⣶⣶⣤⣽⡹⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠉⠲⣽⡻⢿⣿⣿⣿⣿⣿⣿⣷⣜⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣷⣶⣮⣭⣽⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⠿⠿⠿⠿⠛⠉              ";
      int var3 = (new Random(-1529101671205845689L)).nextInt();
      soWjD6JRrA = 94260313 ^ var3;
   }

   public static String xlnoigleho(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] rmdqikusoembxnk() {
      return new byte[]{90, 18, 116, 71, 29, 63, 33, 115, 65, 11, 18, 63, 76, 91, 70, 4, 28, 45, 96, 13, 4, 74, 24, 37, 10, 78, 92, 94, 83, 14, 109, 116, 120, 31, 81, 17, 37, 19, 93, 39, 91, 2, 76, 118, 73, 27, 107, 92, 17, 108, 99, 94, 80, 62, 55, 71, 71, 48, 53, 60, 58, 90};
   }

   private static byte[] ptynqgrcmflzlfj() {
      return new byte[]{-100, -39, 69, 22, 43, 103, 16, 46, 121, 70, 38, 122, 121, 14, 113, 90, 47, 103, 88, 92};
   }

   private static byte[] fxxydzmlcihogxl() {
      return new byte[]{-107, -43, 76, 25, 37, 126, 22, 40, 115, 65, 35, 40, 116, 17, 126, 64, 43, 126, 82, 67, 53, 28, 32, 67, 50, 27, 107, 10, 97, 92, 92, 98, 64, 95, 105, 72, 18, 77};
   }

   private static byte[] rtslyychbnctbnm() {
      return new byte[]{-107, -33, 76, -47, 41, 63, 25, 102, 114, 23, 35, 32, 116, 71, 114, 29, 36, 56, 83, 17, 53, 85, 32, 57, 62, 87, 100, 75, 96, 18, 92, 107, 64, 3, 101, 8, 29, 6, 110, 59, 106, 29};
   }

   private static byte[] jlthopxsenqvxco() {
      return new byte[]{-107, -33, 65, 16, 45, 124, 17, 40, 118, 75, 35, 34, 121, 3, 118, 87, 44, 115, 87, 78, 53, 86, 45, 108, 58, 21, 108, 0};
   }

   private static byte[] itamgifmfgyhppz() {
      return new byte[]{-110, -37, 64, 52, 42, 98, 24, 47, 117, 72, 36, 127, 123, 47, 116, 82, 46, 107, 86, 94};
   }

   private static byte[] pntsouvishvwqwq() {
      return new byte[]{-107, -33, 68, 24, 36, 125, 20, 52, 116, 73, 35, 126, 124, 86, 127, 29, 41, 49, 85, 83, 53, 17, 40, 113, 51, 29, 105, 3, 102, 79, 92, 35, 72, 6, 104, 87, 16, 73, 104, 126, 106, 74, 124, 50, 112, 89, 94, 26, 36, 58, 82, 5, 96, 102, 14, 95, 114, 123, 0, 119, 11, 18};
   }

   private static byte[] ruujzauydhvwsfc() {
      return new byte[]{-107, -33, 76, -42, 45, 57, 22, 26, 114, 115, 35, 72, 116, 44, 118, 101, 43, 81, 83, 25, 53, 59, 32, 92, 58, 50, 107, 51, 96, 123, 92, 5, 64, 125, 97, 3, 18, 126, 110, 91, 106, 117, 116, 96, 121, 104, 92, 48, 34, 12, 82, 36, 104, 71, 7, 39, 112, 41, 6, 71, 11, 38, 98, 4, 68, 49, 42, 79, 18, 20, 112, 122, 42, 70, 124, 59, 113, 121, 47, 55, 81, 111, 60, 53, 40, 92, 61, 45, 111, 57, 98, 104, 85, 23, 72, 105, 102, 97, 22, 104, 108, 59, 99, 108, 124, 29, 126, 120};
   }

   private static byte[] mxkzvrcnrhvjlny() {
      return new byte[]{-110, -34, 70, -43, 41, 51, 17, 13, 116, 114, 33, 89, 121, 42, 126, 14, 44, 56, 86, 106, 54, 55, 44, 88, 58, 94, 105, 56, 96, 112, 88, 21, 64, 104, 97, 109, 19, 110, 111, 50, 111, 114, 124, 7, 124, 126, 88, 78, 36, 26, 91, 43, 96, 78, 1, 58, 117, 37, 1, 65, 10, 36, 111, 101, 71, 55, 40, 71, 25, 6, 113, 122, 36, 34};
   }

   private static byte[] qrgtupbwgnkpkke() {
      return new byte[]{-112, -39, 65, -41, 41, 59, 24, 110, 117, 18, 38, 39, 123, 66, 118, 16, 44, 52, 84, 20, 49, 80, 44, 56, 51, 83, 104, 71, 103, 22, 90, 109, 72, 11, 97, 8, 17, 10, 104, 61, 111, 31};
   }

   private static byte[] tsddnpzsafepijz() {
      return new byte[]{-107, -37, 69, -40, 43, 62, 19, 109, 114, 21, 35, 36, 125, 78, 112, 28, 46, 51, 83, 19, 53, 81, 41, 48, 60, 86, 110, 64, 96, 16, 92, 111, 73, 10, 103, 9, 23, 13, 110, 57, 106, 25};
   }

   private static byte[] jokmlzzqzjzllcr() {
      return new byte[]{-106, -35, 69, -48, 45, 63, 21, 20, 119, 113, 32, 74, 125, 42, 118, 99, 40, 95, 86, 27, 54, 57, 41, 90, 58, 52, 104, 61, 101, 121, 95, 7, 73, 123, 97, 5, 17, 112, 107, 89, 105, 119, 125, 102, 121, 110, 95, 62, 39, 14, 81, 38, 97, 65, 7, 33, 115, 39, 3, 69, 8, 36, 107, 2, 68, 55, 41, 65, 23, 22, 115, 120, 35, 64, 124, 61, 114, 119, 42, 53, 82, 109, 53, 51, 40, 90, 62, 35, 106, 59, 97, 106, 92, 17, 72, 111, 101, 111, 19, 106, 111, 57, 106, 106, 124, 27, 125, 118};
   }

   private static byte[] sjkermdkehqbkhm() {
      return new byte[]{-110, -43, 71, 18, 45, 120, 21, 41, 116, 78, 42, 35, 126, 9, 116, 89, 47, 116, 86, 89, 55, 30, 40, 120, 62, 15, 105, 12, 107, 19, 95, 61, 74, 70, 98, 72};
   }

   private static byte[] cynbffydouynyqu() {
      return new byte[]{-105, -44, 66, 24, 36, 123, 19, 42, 117, 75, 43, 38, 116, 16, 119, 67, 44, 117, 83, 81, 50, 1, 33, 58, 56, 7, 104, 0, 106, 84};
   }

   private static byte[] krgphgxhqctvpda() {
      return new byte[]{-107, -37, 77, -43, 37, 59, 20, 108, 114, 23, 36, 43, 121, 78, 118, 28, 46, 51, 81, 22, 61, 82, 32, 56, 63, 81, 111, 66, 101, 26, 88, 97, 72, 7, 99, 15, 20, 8, 100, 63, 99, 31};
   }

   private static byte[] hrzglhrrfehcrkb() {
      return new byte[]{-105, -34, 77, 36, 42, 122, 23, 37, 120, 74, 33, 43, 122, 45, 112, 85, 47, 113, 83, 80, 61, 8};
   }

   private static byte[] lyprqlhkygpzanm() {
      return new byte[]{-105, -34, 77, 61, 42, 96, 23, 35, 120, 93, 33, 104, 122, 31, 112, 91, 47, 122, 83, 89, 61, 92, 47, 64, 60, 4, 101, 30, 96, 67, 91, 38, 78, 68};
   }

   private static byte[] eimyrkrrrragtwx() {
      return new byte[]{-112, -44, 64, -45, 44, 59};
   }

   private static byte[] tagjfuauhtrlydt() {
      return new byte[]{-107, -40, 76, 24, 45, 121, 18, 44, 120, 65, 35, 37, 116, 14, 118, 82, 47, 127, 89, 93, 53, 30, 32, 51, 58, 4, 111, 5, 106, 91};
   }

   private static byte[] hrfytwxtqwcaacg() {
      return new byte[]{-106, -35, 64, 19, 44, 96, 16, 47, 118, 72, 32, 123, 120, 8, 119, 91, 45, 109, 87, 94};
   }

   private static byte[] ijdrxefcmixajig() {
      return new byte[]{-106, -38, 76, 37, 47, 102, 16, 49, 112, 85, 37, 115, 120, 73, 126, 81, 43, 121, 82, 74, 60, 27, 42, 115, 59, 29, 109, 9, 100, 88, 89, 37, 64, 87, 102, 0, 23, 74, 101, 124, 105, 78, 125, 97, 120, 79, 92, 11, 37, 43, 91, 1, 103, 107, 5, 81, 127, 36, 7, 65, 11, 14, 107, 79, 67, 17, 41, 98, 25, 47, 118, 67, 32, 40, 116, 24, 116, 85, 45, 118, 81, 83, 51, 82, 44, 121, 50, 16, 107, 27, 97, 25, 85, 55, 74, 72, 96, 84, 20, 74, 106, 49};
   }

   private static byte[] omdmqfgkespzmdx() {
      return new byte[]{-111, -34, 69, -40, 47, 60, 17, 106, 120, 19, 33, 35, 116, 68, 113, 25, 40, 57, 85, 19, 53, 95, 42, 63, 58, 87, 101, 70, 96, 18, 85, 107, 79, 2, 101, 5, 16, 13, 108, 50, 105, 24};
   }

   private static byte[] lspttvzdvtcaehd() {
      return new byte[]{-99, -33, 66, 20, 44, 100, 20, 42, 118, 71, 32, 125, 123, 9, 114, 94, 43, 104, 89, 90};
   }

   private static byte[] qlqophqofftkjdl() {
      return new byte[]{-106, -35, 66, -42, 46, 59, 25, 109, 116, 22, 32, 34, 122, 64, 117, 25, 36, 51, 85, 16, 54, 87, 46, 62, 57, 83, 100, 64, 102, 19, 95, 105, 78, 4, 98, 12, 29, 13, 104, 58, 105, 31};
   }

   private static byte[] hddovgakuafzhrw() {
      return new byte[]{-107, -34, 67, -47, 37, 104, 20, 104, 118, 18, 35, 33, 123, 71, 126, 31, 41, 54, 87, 20, 53, 84, 47, 57, 50, 85, 105, 69, 100, 23, 92, 106, 79, 3, 105, 10, 16, 8, 106, 62, 106, 28, 123, 106};
   }

   private static byte[] omxaixkwcmdstxp() {
      return new byte[]{-107, -33, 67, -39, 41, 58, 19, 106, 113, 22, 35, 32, 123, 79, 114, 24, 46, 52, 80, 16, 53, 85, 47, 49, 62, 82, 110, 71, 99, 19, 92, 107, 79, 11, 101, 13, 23, 10, 109, 58, 106, 29};
   }

   private static byte[] ermttddynwqzdjy() {
      return new byte[]{-107, -44, 64, 39, 47, 97, 19, 38, 113, 81, 35, 99, 120, 3, 116, 89, 46, 117, 80, 80, 53, 22, 44, 103, 56, 61, 110, 58, 99, 126};
   }

   private static byte[] cniexdbfyewsxht() {
      return new byte[]{-107, -36, 64, 41, 42, 104, 23, 57, 114, 83, 35, 106, 120, 37, 113, 73, 42, 116, 83, 75, 53, 31, 44, 60, 61, 31, 106, 21, 96, 26, 92, 43, 76, 73, 102, 93, 19, 11, 110, 127, 106, 92, 120, 46, 126, 71, 93, 1, 34, 60, 82, 65, 100, 39, 0, 59, 113, 97, 6, 123, 11, 10, 110, 73, 67, 19, 43, 110, 18, 41, 112, 93, 38, 38, 123, 19, 112, 80, 47, 108, 81, 91, 48, 26, 47, 115, 60, 88};
   }

   private static byte[] spbbwyulftrxgui() {
      return new byte[]{-107, -36, 64, -44, 40, 104, 19, 102, 116, 23, 35, 35, 120, 66, 115, 31, 46, 56, 85, 17, 53, 86, 44, 60, 63, 85, 110, 75, 102, 18, 92, 104, 76, 6, 100, 10, 23, 6, 104, 59, 106, 30, 120, 111};
   }

   private static byte[] nbgwhdjwtslkblx() {
      return new byte[]{-99, -37, 67, -40, 47, 61, 18, 104, 113, 31, 36, 37, 116, 68, 112, 26, 42, 48, 89, 22, 51, 95, 42, 62, 57, 85, 108, 74, 101, 20, 85, 107, 78, 1, 103, 12, 28, 8, 106, 50, 105, 25};
   }

   private static byte[] oogneurwvtljopd() {
      return new byte[]{-100, -43, 67, 23, 43, 99, 24, 42, 120, 70, 42, 124, 120, 14, 117, 82, 43, 102, 88, 80};
   }

   private static byte[] mqiwsbpuxokvcxm() {
      return new byte[]{-105, -36, 69, 41, 47, 108, 18, 63, 113, 84, 35, 122};
   }

   private static byte[] xywwagqubibiryq() {
      return new byte[]{-107, -34, 67, 28, 42, 98, 24, 40, 119, 73};
   }

   private static byte[] cxbbnqpocbtkclr() {
      return new byte[]{-107, -34, 65, 17, 42, 98, 19, 36, 119, 75, 35, 120, 121, 10, 113, 89, 46, 102, 86, 93};
   }

   private static byte[] pdfenrhysygjrxt() {
      return new byte[]{-107, -44, 64, 19, 47, 98, 19, 42, 117, 72, 35, 114, 120, 8, 116, 89, 46, 104, 84, 94};
   }

   private static byte[] hyhkqmcwtkykysi() {
      return new byte[]{-107, -33, 69, 21, 42, 103, 17, 44, 114, 70, 35, 121, 125, 14, 113, 92, 44, 110, 83, 80};
   }

   private static byte[] vbqdjcosqbmryeb() {
      return new byte[]{-107, -34, 64, 23, 37, 97, 16, 44, 114, 73, 35, 120, 120, 12, 126, 90, 45, 110, 83, 95};
   }

   private static byte[] nnfkdhdqsvxfnxn() {
      return new byte[]{-111, -38, 66, 27, 41, 104, 18, 41, 117, 75, 37, 125, 116, 12, 126, 88, 40, 107, 85, 95};
   }

   private static byte[] rpioetbcobamcjc() {
      return new byte[]{-107, -37, 77, 27, 40, 97, 24, 43, 115, 73, 35, 125, 117, 0, 115, 90, 37, 105, 82, 95};
   }

   private static byte[] xhjccugimyrvryi() {
      return new byte[]{-100, -39, 64, 19, 46, 103, 24, 37, 121, 70, 38, 127, 124, 11, 113, 82, 36, 103, 88, 92};
   }

   private static byte[] xnpajxdtmlldzsc() {
      return new byte[]{-110, -36, 65, 18, 46, 98, 22, 41, 120, 72, 35, 126, 125, 11, 116, 92, 40, 102, 86, 89};
   }

   private static byte[] mrbogjsmmxaeznj() {
      return new byte[]{-107, -38, 67, 29, 44, 116, 24, 44};
   }

   private static byte[] uqozmorwhwouaqp() {
      return new byte[]{-107, -34, 65, 20, 43, 96, 18, 36, 114, 78, 35, 120, 121, 15, 112, 91, 47, 102, 83, 88};
   }

   private static byte[] alytknsvgsnvspm() {
      return new byte[]{-107, -43, 76, 0};
   }

   private static byte[] wzakuohmknxkmph() {
      return new byte[]{-111, -39, 64, 27, 42, 104, 16, 40, 112, 75, 38, 127, 116, 15, 126, 90, 41, 110, 85, 92};
   }

   private static byte[] ccrzaquyypygqyb() {
      return new byte[]{-111, -40, 71, 18, 37, 100, 24, 47, 118, 75, 39, 120, 125, 0, 114, 82, 46, 104, 85, 93};
   }

   private static byte[] cmmpfiecxvtgrfe() {
      return new byte[]{-107, -38, 71, 20, 40, 103, 17, 47, 118, 71, 35, 124, 127, 15, 115, 92, 44, 109, 87, 81};
   }

   private static byte[] klpgukhwfqklvci() {
      return new byte[]{-100, -35, 71, 26, 36, 96, 23, 36, 118, 70, 34, 120, 117, 1, 118, 93, 37, 104, 88, 88};
   }

   private static byte[] tqeuyusgpwtjnwq() {
      return new byte[]{-107, -36, 77, 18, 42, 101, 25, 46, 114, 81, 35, 111, 117, 3, 113, 85, 36, 80, 83, 91, 53, 11};
   }

   private static byte[] jcsxskzsyehaagj() {
      return new byte[]{-100, -38, 69, 22, 47, 127, 25, 40, 118, 64, 37, 33, 122, 11, 115, 85, 46, 118, 88, 86, 53, 26, 42, 127, 50, 14, 107, 2, 100, 17, 91, 63, 77, 74, 99, 74};
   }

   private static int saxuwxcnfwcxyrlg(int var0, int var1) {
      return var0 ^ var1;
   }
}
nt var1) {
      return var0 ^ var1;
   }
}
1;
   }
}
nt var1) {
      return var0 ^ var1;
   }
}
