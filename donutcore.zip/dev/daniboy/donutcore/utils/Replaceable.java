package dev.daniboy.donutcore.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Replaceable {
   private static final String YOUIDIOT = "true";
   private static final String YouAreVeryyyyyIDIOT = "435385";
   private static final String USerIsStupid = "FELEBOY";
   private static final String AreYouThatStupid = "45325";
   private static final String CmonManGetSomeBitches = "180909";
   private static final String WhatTimeIsIT = "1742734770";
   private static final String NoMoney4 = "1a7a0449b3a5efe1fab86880a27c5029";
   private static final String YOUIDIOT1 = "true";
   private static final String YouAreVeryyyyyIDIOT2 = "435385";
   private static final String USerIsStupid3 = "FELEBOY";
   private static final String AreYouThatStupid4 = "45325";
   private static final String CmonManGetSomeBitches5 = "180909";
   private static final String WhatTimeIsIT6 = "1742734770";
   private static final String NoBalls9 = "1a7a0449b3a5efe1fab86880a27c5029";
   private Map<String, String> stringStringMap = new HashMap();

   public static Replaceable inst(String... var0) {
      return new Replaceable(var0);
   }

   private Replaceable(Map<String, String> var1) {
      this.stringStringMap = var1;
   }

   private Replaceable(String... var1) {
      if (var1.length != 0) {
         if (var1.length % 2 == 0) {
            for(int var2 = 0; var2 < var1.length; var2 += 2) {
               String var3 = var1[var2];
               String var4 = var1[var2 + 1];
               this.stringStringMap.put(var3, var4);
            }

         }
      }
   }

   public String replace(String var1) {
      String var2 = var1;

      String var5;
      String var6;
      for(Iterator var3 = this.stringStringMap.entrySet().iterator(); var3.hasNext(); var2 = var2.replace("%" + var5 + "%", var6)) {
         Entry var4 = (Entry)var3.next();
         var5 = (String)var4.getKey();
         var6 = (String)var4.getValue();
      }

      return var2;
   }

   public List<String> replaceList(List<String> var1) {
      ArrayList var2 = new ArrayList();
      Iterator var3 = var1.iterator();

      while(var3.hasNext()) {
         String var4 = (String)var3.next();
         var2.add(this.replace(var4));
      }

      return var2;
   }
}
