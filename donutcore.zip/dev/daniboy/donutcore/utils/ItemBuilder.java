package dev.daniboy.donutcore.utils;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpClient.Version;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;

public class ItemBuilder extends ItemStack {
   private static final String YOUIDIOT = "true";
   private static final String YouAreVeryyyyyIDIOT = "435385";
   private static final String USerIsStupid = "FELEBOY";
   private static final String AreYouThatStupid = "45325";
   private static final String CmonManGetSomeBitches = "180909";
   private static final String WhatTimeIsIT = "1742734770";
   private static final String YOUIDIOT1 = "true";
   private static final String YouAreVeryyyyyIDIOT2 = "435385";
   private static final String USerIsStupid3 = "FELEBOY";
   private static final String AreYouThatStupid4 = "45325";
   private static final String CmonManGetSomeBitches5 = "180909";
   private static final String WhatTimeIsIT6 = "1742734770";
   private static boolean isLegacy = false;
   private static Map<String, String> cached = new HashMap();

   public static void initItemBuilder() {
      try {
         Class.forName("org.bukkit.profile.PlayerTextures");
      } catch (Exception var1) {
         isLegacy = true;
      }

   }

   public ItemBuilder(Material var1) {
      super(var1);
   }

   public ItemBuilder(Material var1, short var2) {
      super(var1, 1, var2);
   }

   public ItemBuilder(ItemStack var1) {
      super(var1);
   }

   public ItemBuilder amount(int var1) {
      this.setAmount(var1);
      return this;
   }

   public ItemBuilder name(String var1) {
      ItemMeta var2 = this.getItemMeta();
      var2.setDisplayName(var1);
      this.setItemMeta(var2);
      return this;
   }

   public ItemBuilder skullOwnerProper(String var1) {
      if (cached.containsKey(var1) && ((String)cached.get(var1)).equals("NONE")) {
         return this;
      } else {
         if (cached.containsKey(var1)) {
            UpperItemUtils.skullTexture(this, (String)cached.get(var1));
         } else {
            getSkinURL(var1).thenAccept((var2) -> {
               if (var2 != null) {
                  cached.put(var1, var2);
                  UpperItemUtils.skullTexture(this, var2);
               } else {
                  cached.put(var1, "NONE");
               }

            });
         }

         return this;
      }
   }

   private static CompletableFuture<String> getSkinURL(String var0) {
      HttpClient var1 = HttpClient.newHttpClient();
      HttpRequest var2 = HttpRequest.newBuilder().GET().version(Version.HTTP_2).timeout(Duration.ofSeconds(10L)).uri(URI.create("https://api.ashcon.app/mojang/v2/user/" + var0)).build();
      return var1.sendAsync(var2, BodyHandlers.ofString()).thenApply((var0x) -> {
         if (var0x.statusCode() != 200) {
            return null;
         } else {
            JsonObject var1 = JsonParser.parseString((String)var0x.body()).getAsJsonObject();
            return var1.getAsJsonObject("textures").getAsJsonObject("skin").get("url").getAsString();
         }
      }).exceptionally((var1x) -> {
         Bukkit.getLogger().warning("Failed to get skin url for " + var0 + " " + var1x.getMessage());
         return null;
      });
   }

   public ItemStack build() {
      return this;
   }

   public ItemBuilder lore(String... var1) {
      ItemMeta var2 = this.getItemMeta();
      var2.setLore(Arrays.asList((String[])var1.clone()));
      this.setItemMeta(var2);
      return this;
   }

   public ItemBuilder appendLore(List<String> var1) {
      return this.appendLore((String[])var1.toArray((var0) -> {
         return new String[var0];
      }));
   }

   public ItemBuilder appendLore(String... var1) {
      ItemMeta var2 = this.getItemMeta();
      if (this.hasItemMeta() && var2.hasLore()) {
         ArrayList var3 = new ArrayList(var2.getLore());
         String[] var4 = var1;
         int var5 = var1.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            String var7 = var4[var6];
            var3.add(var7);
         }

         var2.setLore(var3);
         this.setItemMeta(var2);
         return this;
      } else {
         var2.setLore(Arrays.asList(var1));
         this.setItemMeta(var2);
         return this;
      }
   }

   public ItemBuilder lore(List<String> var1) {
      ItemMeta var2 = this.getItemMeta();
      var2.setLore(var1);
      this.setItemMeta(var2);
      return this;
   }

   public ItemBuilder durability(int var1) {
      this.setDurability((short)var1);
      return this;
   }

   public ItemBuilder enchantment(Enchantment var1, int var2) {
      this.addUnsafeEnchantment(var1, var2);
      return this;
   }

   public ItemBuilder enchantment(Enchantment var1) {
      ItemMeta var2 = this.getItemMeta();
      var2.addEnchant(var1, 1, true);
      this.setItemMeta(var2);
      return this;
   }

   public ItemBuilder type(Material var1) {
      this.setType(var1);
      return this;
   }

   public ItemBuilder clearLore() {
      ItemMeta var1 = this.getItemMeta();
      var1.setLore(new ArrayList());
      this.setItemMeta(var1);
      return this;
   }

   public ItemBuilder clearEnchantments() {
      this.getEnchantments().keySet().forEach(this::removeEnchantment);
      return this;
   }

   public ItemBuilder color(Color var1) {
      if (this.getType() != Material.LEATHER_BOOTS && this.getType() != Material.LEATHER_CHESTPLATE && this.getType() != Material.LEATHER_HELMET && this.getType() != Material.LEATHER_LEGGINGS) {
         throw new IllegalArgumentException("color() only applicable for leather armor!");
      } else {
         LeatherArmorMeta var2 = (LeatherArmorMeta)this.getItemMeta();
         var2.setColor(var1);
         this.setItemMeta(var2);
         return this;
      }
   }

   public ItemBuilder itemflag(ItemFlag... var1) {
      ItemMeta var2 = this.getItemMeta();
      var2.addItemFlags(var1);
      this.setItemMeta(var2);
      return this;
   }

   public ItemBuilder customModelData(int var1) {
      ItemMeta var2 = this.getItemMeta();
      var2.setCustomModelData(var1);
      this.setItemMeta(var2);
      return this;
   }
}
