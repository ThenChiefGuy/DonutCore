package dev.daniboy.donutcore.utils;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.profile.PlayerTextures;

public class UpperItemUtils {
   private static Map<String, PlayerProfile> caching = new HashMap();

   public static ItemBuilder skullTexture(ItemBuilder var0, String var1) {
      SkullMeta var2 = (SkullMeta)var0.getItemMeta();
      PlayerProfile var3;
      if (caching.containsKey(var1)) {
         var3 = (PlayerProfile)caching.get(var1);
      } else {
         var3 = Bukkit.createPlayerProfile(UUID.randomUUID());
         PlayerTextures var4 = var3.getTextures();

         try {
            var4.setSkin(new URL(var1));
         } catch (MalformedURLException var6) {
            var6.printStackTrace();
         }

         var3.setTextures(var4);
         var3.isComplete();
         caching.put(var1, var3);
      }

      var2.setOwnerProfile(var3);
      var0.setItemMeta(var2);
      return var0;
   }
}
