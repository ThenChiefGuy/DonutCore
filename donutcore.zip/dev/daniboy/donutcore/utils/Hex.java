package dev.daniboy.donutcore.utils;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.bukkit.ChatColor;

public class Hex {
   private static final String Builtbybit = "true";
   private static final String YourUserID = "435385";
   private static final String YourUsername = "FELEBOY";
   private static final String ResourceID = "45325";
   private static final String Version = "180909";
   private static final String TimeWhenDownloaded = "1742734770";
   private static final String idkwhattocallthis = "1a7a0449b3a5efe1fab86880a27c5029";

   public static String hex(String var0) {
      if (var0 == null) {
         return null;
      } else {
         Pattern var1 = Pattern.compile("(#[a-fA-F0-9]{6})");

         for(Matcher var2 = var1.matcher(var0); var2.find(); var2 = var1.matcher(var0)) {
            String var3 = var0.substring(var2.start(), var2.end());
            String var4 = var3.replace('#', 'x');
            char[] var5 = var4.toCharArray();
            StringBuilder var6 = new StringBuilder("");
            char[] var7 = var5;
            int var8 = var5.length;

            for(int var9 = 0; var9 < var8; ++var9) {
               char var10 = var7[var9];
               var6.append("&" + var10);
            }

            var0 = var0.replace(var3, var6.toString());
         }

         return ChatColor.translateAlternateColorCodes('&', var0).replace('&', '§');
      }
   }

   public static List<String> hex(List<String> var0) {
      return var0.stream().map(Hex::hex).toList();
   }

   public static List<String> hex(List<String> var0, Replaceable var1) {
      return hex(var1.replaceList(var0));
   }
}
