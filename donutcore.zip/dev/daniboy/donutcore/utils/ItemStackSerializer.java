package dev.daniboy.donutcore.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

public class ItemStackSerializer {
   public static String serializeItemStack(ItemStack var0) throws IOException {
      ByteArrayOutputStream var1 = new ByteArrayOutputStream();
      BukkitObjectOutputStream var2 = new BukkitObjectOutputStream(var1);

      try {
         var2.writeObject(var0);
      } catch (Throwable var6) {
         try {
            var2.close();
         } catch (Throwable var5) {
            var6.addSuppressed(var5);
         }

         throw var6;
      }

      var2.close();
      return Base64.getEncoder().encodeToString(var1.toByteArray());
   }

   public static ItemStack deserializeItemStack(String var0) throws IOException, ClassNotFoundException {
      ByteArrayInputStream var1 = new ByteArrayInputStream(Base64.getDecoder().decode(var0));
      BukkitObjectInputStream var2 = new BukkitObjectInputStream(var1);

      ItemStack var3;
      try {
         var3 = (ItemStack)var2.readObject();
      } catch (Throwable var6) {
         try {
            var2.close();
         } catch (Throwable var5) {
            var6.addSuppressed(var5);
         }

         throw var6;
      }

      var2.close();
      return var3;
   }
}
