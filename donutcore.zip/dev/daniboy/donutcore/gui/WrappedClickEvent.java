package dev.daniboy.donutcore.gui;

import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class WrappedClickEvent {
   private Player player;
   private Inventory inventory;
   private ItemStack itemStack;
   private ClickType clickType;
   private int slot;
   private final ItemStack cursor;
   private boolean isCancelled;
   private static int y0rL9ruX4F;
   private transient int lsH0cdfcDs;
   private static String[] nothing_to_see_here = new String[19];

   public WrappedClickEvent(Player var1, Inventory var2, ItemStack var3, ClickType var4, int var5, ItemStack var6, int var7) {
      int var24 = 1208973449 ^ 1793856781;
      super();

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24)) {
         case 60327628:
            var24 ^= 95516193;
         case 1695172820:
            var24 = 215027396 ^ 1004640771 ^ Integer.parseInt("1753297985") ^ var7;
            this.lsH0cdfcDs = 2122013165 ^ y0rL9ruX4F;
            var24 = oogwbkkkuxalsifx(var24, 1491106649);
            var24 ^= 1428174826;
            boolean var9 = false;
            this.isCancelled = var9;
            var24 ^= 1366143902;
            this.player = var1;
            var24 ^= 1930407633;
            this.inventory = var2;
            var24 ^= 874714709;
            this.itemStack = var3;
            var24 ^= 1845896850;
            this.clickType = var4;
            var24 ^= 830206777;
            this.slot = var5;
            var24 ^= 2113499479;
            this.cursor = var6;
            var24 ^= 1546091928;
            return;
         case 930762251:
         default:
            throw new IllegalAccessException();
         case 1025868016:
         }
      }
   }

   public Player getPlayer$624284539(int var1) {
      int var5 = 75353665 ^ 331681475 ^ this.lsH0cdfcDs ^ var1;
      var5 ^= 2054451207;
      Player var3 = this.player;
      return var3;
   }

   public Inventory getInventory$1458066743(int var1) {
      int var5 = 1274340365 ^ 1342710705 ^ this.lsH0cdfcDs ^ var1;
      var5 ^= 786152081;
      Inventory var3 = this.inventory;
      return var3;
   }

   public ItemStack getItemStack$386585608(int var1) {
      int var5 = 642472070 ^ 634706096 ^ this.lsH0cdfcDs ^ var1;
      var5 ^= 699860742;
      ItemStack var3 = this.itemStack;
      return var3;
   }

   public ClickType getClickType() {
      int var5 = 1086678672 ^ 336646762 ^ this.lsH0cdfcDs;
      var5 ^= 2029337694;
      ClickType var2 = this.clickType;
      return var2;
   }

   public int getSlot$2125716982(int var1) {
      int var5 = 1095655614 ^ 600833194 ^ this.lsH0cdfcDs ^ var1;
      var5 ^= 556676365;
      int var3 = this.slot;
      return var3;
   }

   public ItemStack getCursor$1334603673(int var1) {
      int var5 = 786860794 ^ 1554871665 ^ this.lsH0cdfcDs ^ var1;
      var5 ^= 49888144;
      ItemStack var3 = this.cursor;
      return var3;
   }

   public boolean isRightClick$1018531030(int var1) {
      int var10 = 1505997837 ^ 1070234346 ^ this.lsH0cdfcDs ^ var1;
      var10 ^= 973719666;
      ClickType var4 = this.clickType;
      ClickType var3 = ClickType.RIGHT;
      byte var7;
      if (var4 != var3) {
         var10 ^= 1572974323;
         ClickType var6 = this.clickType;
         ClickType var8 = ClickType.SHIFT_RIGHT;
         if (var6 != var8) {
            var10 ^= 652114256;
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var10) != 75117725) {
               var10 ^= 29673937;
               throw new IllegalAccessException();
            }

            var10 ^= 372751573;
            var7 = (byte)(220363041 ^ var10);
            var10 ^= 390298498;
            return (boolean)var7;
         }

         var10 ^= 1092108328;
      } else {
         var10 ^= 1467585661;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var10) != 191882370) {
            var10 = oogwbkkkuxalsifx(var10, 765626895);
            throw new IllegalAccessException();
         }

         var10 ^= 1268808358;
      }

      var7 = (byte)(2094267533 ^ var10);
      var10 = oogwbkkkuxalsifx(var10, 11029115);

      try {
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var10) != 19910149) {
            throw null;
         }

         throw new IOException();
      } catch (IOException var11) {
         switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var10)) {
         case -472008773:
            var10 ^= 1597059545;
            break;
         case -162114271:
            var10 = oogwbkkkuxalsifx(var10, 494947722);
            break;
         default:
            throw new IllegalAccessException("Error in hash");
         }
      }

      var10 ^= 959153549;
      return (boolean)var7;
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣤⣤⣤⣤⣤⣶⣦⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⡿⠛⠉⠙⠛⠛⠛⠛⠻⢿⣿⣷⣤⡀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠋⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⠈⢻⣿⣿⡄⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⠀⠀⠀⣸⣿⡏⠀⠀⠀⣠⣶⣾⣿⣿⣿⠿⠿⠿⢿⣿⣿⣿⣄⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠁⠀⠀⢰⣿⣿⣯⠁⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣷⡄⠀";
      nothing_to_see_here[5] = "⠀⠀⣀⣤⣴⣶⣶⣿⡟⠀⠀⠀⢸⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣷⠀";
      nothing_to_see_here[6] = "⠀⢰⣿⡟⠋⠉⣹⣿⡇⠀⠀⠀⠘⣿⣿⣿⣿⣷⣦⣤⣤⣤⣶⣶⣶⣶⣿⣿⣿⠀";
      nothing_to_see_here[7] = "⠀⢸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠀";
      nothing_to_see_here[8] = "⠀⣸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠉⠻⠿⣿⣿⣿⣿⡿⠿⠿⠛⢻⣿⡇⠀⠀";
      nothing_to_see_here[9] = "⠀⣿⣿⠁⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣧⠀⠀";
      nothing_to_see_here[10] = "⠀⣿⣿⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀";
      nothing_to_see_here[11] = "⠀⣿⣿⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀";
      nothing_to_see_here[12] = "⠀⢿⣿⡆⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⠀";
      nothing_to_see_here[13] = "⠀⠸⣿⣧⡀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠃⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠛⢿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⣰⣿⣿⣷⣶⣶⣶⣶⠶⠀⢠⣿⣿⠀⠀⠀";
      nothing_to_see_here[15] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⣽⣿⡏⠁⠀⠀⢸⣿⡇⠀⠀⠀";
      nothing_to_see_here[16] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⢹⣿⡆⠀⠀⠀⣸⣿⠇⠀⠀⠀";
      nothing_to_see_here[17] = "⠀⠀⠀⠀⠀⠀⠀⢿⣿⣦⣄⣀⣠⣴⣿⣿⠁⠀⠈⠻⣿⣿⣿⣿⡿⠏⠀⠀⠀⠀";
      nothing_to_see_here[18] = "⠀⠀⠀⠀⠀⠀⠀⠈⠛⠻⠿⠿⠿⠿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      int var3 = (new Random(336072192552698876L)).nextInt();
      y0rL9ruX4F = 1087633898 ^ var3;
   }

   public static String cniatvffil(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] yccdohgqfivnqop() {
      return new byte[]{11, 87, 108, 110, 69, 56, 9, 50, 80, 106, 31, 47, 54, 54, 62, 94, 108, 103, 87, 47, 121, 54, 83, 118, 33, 92, 98, 67, 122, 114, 34, 107, 23, 114};
   }

   private static int oogwbkkkuxalsifx(int var0, int var1) {
      return var0 ^ var1;
   }
}
