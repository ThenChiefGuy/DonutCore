package dev.daniboy.donutcore.gui.impl;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.internal.platform.WorldGuardPlatform;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.database.SQLiteManager;
import dev.daniboy.donutcore.gui.AbstractGui;
import dev.daniboy.donutcore.gui.WrappedClickEvent;
import dev.daniboy.donutcore.manager.TeleportManager;
import dev.daniboy.donutcore.utils.Hex;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class SpawnGUI extends AbstractGui {
   private final Map<Player, Object[]> opened;
   private final FileConfiguration afkSpawnGuiConfig;
   private final String guiTitle;
   private final SQLiteManager sqLiteManager;
   private final TeleportManager teleportManager;
   private final Map<Integer, ItemStack> SpawnItems;
   private final RegionContainer regionContainer;
   private static int YgrU5KeNrN;
   private transient int MrS68agYfe;
   private static String[] nothing_to_see_here = new String[18];

   public SpawnGUI(DonutCore var1, SQLiteManager var2, TeleportManager var3, int var4) {
      int var29 = 179704471 ^ 806877807;
      super(var1, 1156425752);

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var29)) {
         case 26839489:
            var29 ^= 758155995;
         case 1151649376:
            var29 = 137749943 ^ 486810079 ^ Integer.parseInt("565161028") ^ var4;
            this.MrS68agYfe = 1977242075 ^ YgrU5KeNrN;
            var29 = dpkxpdajfbbcxwly(var29, 722212480);
            var29 ^= 1780145294;
            HashMap var14 = new HashMap();
            this.opened = var14;
            var29 ^= 1146185878;
            HashMap var15 = new HashMap();
            this.SpawnItems = var15;
            var29 ^= 1454873079;
            FileConfiguration var17 = var1.getafkSpawnGuiConfig$23715181(125321510);
            this.afkSpawnGuiConfig = var17;
            var29 ^= 1929230365;
            FileConfiguration var19 = this.afkSpawnGuiConfig;
            String var27 = "spawn_gui.title";
            String var20 = var19.getString(var27);
            String var21 = Hex.hex(var20);
            this.guiTitle = var21;
            var29 ^= 2028988212;
            WorldGuard var22 = WorldGuard.getInstance();
            WorldGuardPlatform var23 = var22.getPlatform();
            RegionContainer var24 = var23.getRegionContainer();
            this.regionContainer = var24;
            var29 ^= 687596060;
            this.sqLiteManager = var2;
            var29 ^= 517770950;
            this.teleportManager = var3;
            var29 ^= 884738154;
            return;
         case 269193333:
         default:
            throw new IllegalAccessException();
         case 1173110255:
         }
      }
   }

   public void loadSpawnConfigValues$882403349(int var1) {
      int var176 = 1296662395 ^ 1908232447 ^ this.MrS68agYfe ^ var1;
      var176 ^= 946374665;
      SQLiteManager var19 = this.sqLiteManager;
      Map var20 = var19.getSpawnNumber$1518350224(567915392);
      var176 ^= 1349165630;
      TreeMap var21 = new TreeMap(var20);
      var176 ^= 108541164;
      FileConfiguration var23 = this.afkSpawnGuiConfig;
      String var116 = ykfmtnwufp(gyltdhcxjmbdfjp(), bfodvaubpfprqhm(), var176);
      int var24 = var23.getInt(var116);
      int var7 = var24;
      var176 ^= 1943059495;
      byte var117 = (byte)(1112081975 ^ var176);
      String var150 = ykfmtnwufp(ohzkjnlpcsjqoof(), bfodvaubpfprqhm(), var176);
      this.setConfigurableItem$1462918240(var117, var150, 976741356);
      var176 ^= 720015867;
      byte var118 = (byte)(1755551693 ^ var176);
      String var151 = ykfmtnwufp(snmjhffhvshwwcl(), bfodvaubpfprqhm(), var176);
      this.setConfigurableItem$1462918240(var118, var151, 976741356);
      var176 ^= 1572032096;
      byte var119 = (byte)(890296750 ^ var176);
      String var152 = ykfmtnwufp(lzsbtrmuzskzidt(), bfodvaubpfprqhm(), var176);
      this.setConfigurableItem$1462918240(var119, var152, 976741356);
      var176 ^= 548840293;
      Set var29 = var21.entrySet();
      Iterator var30 = var29.iterator();
      Iterator var8 = var30;
      var176 ^= 1498105761;

      label315:
      while(true) {
         byte var32 = var8.hasNext();
         if (var32 != (1290616152 ^ var176)) {
            var176 ^= 845805288;
            Object var34 = var8.next();
            Entry var35 = (Entry)var34;
            var176 ^= 1576634304;
            Object var37 = var35.getKey();
            Integer var38 = (Integer)var37;
            int var39 = var38;
            var176 ^= 1760280780;
            Object var41 = var35.getValue();
            Location var42 = (Location)var41;
            var176 ^= 254280408;
            String var43 = ykfmtnwufp(dwourgfhyqvsedb(), bfodvaubpfprqhm(), var176);
            World var44 = Bukkit.getWorld(var43);
            var176 ^= 725053021;
            PrintStream var45 = System.out;
            String var121 = String.valueOf(var44);
            String var122 = "Spawn World: " + var121;
            var45.println(var122);
            var176 ^= 1124591376;
            RegionContainer var47 = this.regionContainer;
            com.sk89q.worldedit.world.World var124 = BukkitAdapter.adapt(var44);
            RegionManager var48 = var47.get(var124);
            var176 ^= 1109984136;
            ArrayList var49 = new ArrayList();
            ArrayList var14 = var49;
            var176 ^= 1847946239;
            BlockVector3 var126 = BukkitAdapter.asBlockVector(var42);
            ApplicableRegionSet var51 = var48.getApplicableRegions(var126);
            Iterator var52 = var51.iterator();
            Iterator var15 = var52;
            var176 ^= 2049502019;

            while(true) {
               byte var54 = var15.hasNext();
               if (var54 == (2057995293 ^ var176)) {
                  var176 = dpkxpdajfbbcxwly(var176, 891123113);
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176) != 175385595) {
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176)) {
                        case 74302584:
                           break;
                        case 175385595:
                           var176 ^= 2067122722;
                           throw new RuntimeException();
                        case 537720902:
                        case 1060798444:
                        default:
                           throw new RuntimeException();
                        }
                     }
                  }

                  label229:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176)) {
                     case 175385595:
                        var176 ^= 82884431;
                        break label229;
                     case 700747773:
                        break;
                     case 747774109:
                        break label229;
                     case 1335159039:
                     default:
                        throw new RuntimeException();
                     }
                  }

                  ArrayList var69 = new ArrayList();
                  ArrayList var167 = var69;
                  var176 ^= 1563294293;
                  int var71 = var14.size();
                  ItemStack var165;
                  ItemMeta var166;
                  if (var71 >= var7) {
                     var176 ^= 713970625;
                     Material var163 = Material.REDSTONE_BLOCK;
                     ItemStack var102 = new ItemStack(var163, var39);
                     var165 = var102;
                     var176 ^= 1860868142;
                     ItemMeta var104 = var102.getItemMeta();
                     var166 = var104;
                     var176 ^= 1921552866;
                     FileConfiguration var106 = this.afkSpawnGuiConfig;
                     String var146 = ykfmtnwufp(mydzzdeerlhjzrr(), bfodvaubpfprqhm(), var176);
                     String var107 = var106.getString(var146);
                     String var108 = Hex.hex(var107);
                     var176 ^= 1491918550;
                     FileConfiguration var110 = this.afkSpawnGuiConfig;
                     String var147 = ykfmtnwufp(lfctgucmtdncbkp(), bfodvaubpfprqhm(), var176);
                     List var111 = var110.getStringList(var147);
                     List var112 = Hex.hex(var111);
                     var176 ^= 1158272128;
                     var104.setDisplayName(var108);
                     var176 ^= 668916034;
                     var69.addAll(var112);
                     var176 ^= 624745695;
                     var176 ^= 1494143720;

                     try {
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176) != 112584135) {
                           throw null;
                        }

                        throw new IOException();
                     } catch (IOException var178) {
                        switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var176)) {
                        case -506690406:
                           var176 = dpkxpdajfbbcxwly(var176, 588042733);
                           break;
                        case 880401411:
                           var176 ^= 431651582;
                           break;
                        default:
                           throw new IllegalAccessException("Error in hash");
                        }

                        var176 ^= 1594372488;
                     }
                  } else {
                     var176 = dpkxpdajfbbcxwly(var176, 499858100);
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176) != 109639795) {
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176)) {
                           case 109639795:
                              var176 ^= 1059306892;
                              throw new RuntimeException();
                           case 1266141252:
                           case 1827346702:
                           default:
                              throw new RuntimeException();
                           case 2041839404:
                           }
                        }
                     }

                     label217:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176)) {
                        case 109639795:
                           var176 ^= 487088551;
                           break label217;
                        case 229721249:
                        default:
                           throw new RuntimeException();
                        case 627577658:
                           break label217;
                        case 1436583020:
                        }
                     }

                     Material var153 = Material.ITEM_FRAME;
                     ItemStack var72 = new ItemStack(var153, var39);
                     var165 = var72;
                     var176 ^= 131858252;
                     ItemMeta var74 = var72.getItemMeta();
                     var166 = var74;
                     var176 ^= 1391280139;
                     FileConfiguration var76 = this.afkSpawnGuiConfig;
                     String var133 = ykfmtnwufp(fjrfomupuoryjny(), bfodvaubpfprqhm(), var176);
                     String var77 = var76.getString(var133);
                     String var134 = ykfmtnwufp(hujjvlxdtgrdhuu(), bfodvaubpfprqhm(), var176);
                     String var155 = String.valueOf(var39);
                     String var78 = var77.replace(var134, var155);
                     String var79 = Hex.hex(var78);
                     var176 ^= 1945184876;
                     var74.setDisplayName(var79);
                     var176 ^= 866046684;
                     FileConfiguration var82 = this.afkSpawnGuiConfig;
                     String var136 = ykfmtnwufp(obcafpuosywllbp(), bfodvaubpfprqhm(), var176);
                     List var83 = var82.getStringList(var136);
                     Iterator var84 = var83.iterator();
                     Iterator var170 = var84;
                     var176 ^= 249542290;

                     while(true) {
                        byte var86 = var170.hasNext();
                        if (var86 == (221189848 ^ var176)) {
                           var176 ^= 452186538;
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176) != 238802352) {
                              var176 = dpkxpdajfbbcxwly(var176, 593427684);
                              throw new RuntimeException();
                           }

                           var176 ^= 937539460;
                           break;
                        }

                        var176 ^= 701347303;
                        Object var88 = var170.next();
                        String var89 = (String)var88;
                        var176 ^= 756915255;
                        String var137 = ykfmtnwufp(mbuopjqomboemvw(), bfodvaubpfprqhm(), var176);
                        int var157 = var14.size();
                        String var158 = String.valueOf(var157);
                        String var91 = var89.replace(var137, var158);
                        var176 ^= 337401503;
                        String var138 = ykfmtnwufp(cplsvzmhegspcbh(), bfodvaubpfprqhm(), var176);
                        String var160 = String.valueOf(var7);
                        String var93 = var91.replace(var138, var160);
                        var176 ^= 964210883;
                        String var140 = Hex.hex(var93);
                        boolean var95 = var167.add(var140);
                        var176 ^= 534314389;

                        label191:
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176)) {
                           case 47328374:
                              var176 ^= 1087963844;
                              break label191;
                           case 1107878663:
                           default:
                              throw new RuntimeException();
                           case 1357371182:
                              break;
                           case 1889628640:
                              break label191;
                           }
                        }

                        try {
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176) != 259707443) {
                              throw null;
                           }

                           throw new RuntimeException();
                        } catch (RuntimeException var179) {
                           switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var176)) {
                           case -590270421:
                              var176 ^= 1343358854;
                              break;
                           case 172506306:
                              var176 = dpkxpdajfbbcxwly(var176, 1791043099);
                              break;
                           default:
                              throw new IOException("Error in hash");
                           }

                           var176 = dpkxpdajfbbcxwly(var176, 648492891);
                        }
                     }
                  }

                  var166.setLore(var167);
                  var176 ^= 1544913630;
                  boolean var98 = var165.setItemMeta(var166);
                  var176 ^= 2040725406;
                  Map var100 = this.SpawnItems;
                  byte var161 = (byte)(92933559 ^ var176);
                  int var144 = var39 - var161;
                  Integer var145 = var144;
                  var100.put(var145, var165);
                  var176 ^= 59839614;

                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176)) {
                     case 96038448:
                        var176 ^= 1078845289;
                     case 1563221907:
                        try {
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176) != 138962561) {
                              throw null;
                           }

                           throw new IOException();
                        } catch (IOException var177) {
                           switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var176)) {
                           case 556725363:
                              var176 = dpkxpdajfbbcxwly(var176, 1893399920);
                              break;
                           case 850801930:
                              var176 = dpkxpdajfbbcxwly(var176, 1386866015);
                              break;
                           default:
                              throw new IOException("Error in hash");
                           }

                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176)) {
                              case 145637699:
                                 var176 ^= 1477582502;
                              case 1359865921:
                                 continue label315;
                              case 1549985879:
                              default:
                                 throw new RuntimeException();
                              case 1987311862:
                              }
                           }
                        }
                     case 1694487423:
                     default:
                        throw new RuntimeException();
                     case 1820065237:
                     }
                  }
               }

               var176 ^= 165150438;
               Object var56 = var15.next();
               ProtectedRegion var57 = (ProtectedRegion)var56;
               ProtectedRegion var16 = var57;
               var176 ^= 133480269;
               Collection var58 = Bukkit.getOnlinePlayers();
               Iterator var59 = var58.iterator();
               Iterator var17 = var59;
               var176 ^= 805303483;

               while(true) {
                  byte var61 = var17.hasNext();
                  if (var61 == (1534472461 ^ var176)) {
                     label253:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176)) {
                        case 20227199:
                           var176 ^= 1447721370;
                           break label253;
                        case 52445193:
                        default:
                           throw new RuntimeException();
                        case 1196946722:
                           break;
                        case 1558139856:
                           break label253;
                        }
                     }

                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176) != 161792408) {
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176)) {
                           case 161792408:
                              var176 ^= 968782593;
                              throw new RuntimeException();
                           case 640628167:
                           case 1444894050:
                           default:
                              throw new RuntimeException();
                           case 1977663212:
                           }
                        }
                     }

                     label242:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176)) {
                        case 161792408:
                           var176 ^= 1203934641;
                           break label242;
                        case 1404093415:
                        default:
                           throw new RuntimeException();
                        case 1719136232:
                           break;
                        case 1795949549:
                           break label242;
                        }
                     }

                     var176 ^= 515125509;

                     try {
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176) != 55672265) {
                           throw null;
                        }

                        throw new IllegalAccessException();
                     } catch (IllegalAccessException var180) {
                        switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var176)) {
                        case -1571331814:
                           var176 ^= 1914258897;
                           break;
                        case 1431663033:
                           var176 = dpkxpdajfbbcxwly(var176, 217647045);
                           break;
                        default:
                           throw new IOException("Error in hash");
                        }

                        var176 = dpkxpdajfbbcxwly(var176, 1559834095);
                        break;
                     }
                  }

                  var176 ^= 518157253;
                  Object var63 = var17.next();
                  Player var64 = (Player)var63;
                  var176 ^= 833331084;
                  Location var128 = var64.getLocation();
                  BlockVector3 var129 = BukkitAdapter.asBlockVector(var128);
                  byte var66 = var16.contains(var129);
                  if (var66 != (1950342468 ^ var176)) {
                     var176 ^= 1908584997;
                     String var131 = var64.getName();
                     boolean var68 = var14.add(var131);
                     var176 ^= 1509804996;
                  } else {
                     var176 ^= 2139744710;
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176) != 112266765) {
                        var176 = dpkxpdajfbbcxwly(var176, 1060376340);
                        throw new RuntimeException();
                     }

                     label275:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176)) {
                        case 112266765:
                           var176 ^= 1471582247;
                           break label275;
                        case 363115606:
                           break;
                        case 1272160888:
                        default:
                           throw new RuntimeException();
                        case 1392771251:
                           break label275;
                        }
                     }
                  }

                  var176 ^= 113282510;

                  try {
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176) != 265554687) {
                        throw null;
                     }

                     throw new IOException();
                  } catch (IOException var181) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var176)) {
                     case -743948109:
                        var176 = dpkxpdajfbbcxwly(var176, 1859588596);
                        break;
                     case -704558246:
                        var176 ^= 1315057801;
                        break;
                     default:
                        throw new RuntimeException("Error in hash");
                     }

                     var176 = dpkxpdajfbbcxwly(var176, 1339304175);
                  }
               }
            }
         }

         label312:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176)) {
            case 84666935:
               var176 ^= 814571143;
               break label312;
            case 248972126:
            default:
               throw new RuntimeException();
            case 1091202293:
               break;
            case 1188725203:
               break label312;
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176) != 16432608) {
            var176 ^= 1222793289;
            throw new RuntimeException();
         }

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var176)) {
            case 16432608:
               var176 ^= 1895467281;
               return;
            case 367283076:
            default:
               throw new RuntimeException();
            case 1030951060:
               return;
            case 1991301414:
            }
         }
      }
   }

   private void setConfigurableItem$1462918240(int var1, String var2, int var3) {
      int var48 = 1941854626 ^ 528741577 ^ this.MrS68agYfe ^ var3;
      var48 ^= 1969595204;
      FileConfiguration var12 = this.afkSpawnGuiConfig;
      String var34 = var2 + ".material";
      String var6 = ykfmtnwufp(lilsyazzcypyova(), bfodvaubpfprqhm(), var48);
      String var13 = var12.getString(var34, var6);
      Material var14 = Material.getMaterial(var13);
      var48 ^= 441446177;
      FileConfiguration var16 = this.afkSpawnGuiConfig;
      String var36 = var2 + ".display_name";
      String var44 = ykfmtnwufp(xksuucngejrdzom(), bfodvaubpfprqhm(), var48);
      String var17 = var16.getString(var36, var44);
      String var18 = Hex.hex(var17);
      var48 ^= 1983938018;
      FileConfiguration var20 = this.afkSpawnGuiConfig;
      String var38 = var2 + ".lore";
      List var21 = var20.getStringList(var38);
      List var22 = Hex.hex(var21);
      var48 ^= 542553721;
      ItemStack var23 = new ItemStack(var14);
      var48 ^= 1239926474;
      ItemMeta var25 = var23.getItemMeta();
      var48 ^= 2040701767;
      if (var25 != null) {
         var48 ^= 387946243;
         var25.setDisplayName(var18);
         var48 ^= 950275975;
         var25.setLore(var22);
         var48 ^= 2130625687;
         var23.setItemMeta(var25);
         var48 ^= 1234525287;
      } else {
         var48 ^= 1752471662;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var48) != 152935115) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var48)) {
               case 152935115:
                  var48 ^= 1686944573;
                  throw new RuntimeException();
               case 869510936:
                  break;
               case 1006989335:
               case 1184051160:
               default:
                  throw new RuntimeException();
               }
            }
         }

         var48 ^= 1889835034;
      }

      Map var32 = this.SpawnItems;
      Integer var43 = var1;
      var32.put(var43, var23);
      var48 ^= 609468567;
   }

   public Inventory generateInventory$919822562(Player var1, Object[] var2, int var3) {
      int var32 = 1399194211 ^ 1815008481 ^ this.MrS68agYfe ^ var3;
      var32 ^= 146720396;
      Object var4 = null;
      byte var5 = (byte)(1052387765 ^ var32);
      String var27 = this.guiTitle;
      Inventory var10 = Bukkit.createInventory((InventoryHolder)var4, var5, var27);
      Inventory var7 = var10;
      var32 ^= 951812181;
      this.loadSpawnConfigValues$882403349(870176311);
      var32 ^= 900062689;
      Map var13 = this.SpawnItems;
      Set var14 = var13.entrySet();
      Iterator var15 = var14.iterator();
      Iterator var8 = var15;
      var32 ^= 365444904;

      while(true) {
         byte var17 = var8.hasNext();
         if (var17 == (644631327 ^ var32)) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32)) {
               case 175241184:
                  var32 ^= 554899227;
               case 195432071:
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32) == 117924156) {
                     var32 = dpkxpdajfbbcxwly(var32, 842704685);
                     return var7;
                  }

                  var32 = dpkxpdajfbbcxwly(var32, 1158067900);
                  throw new IllegalAccessException();
               case 1171218712:
               default:
                  throw new IllegalAccessException();
               case 1306634161:
               }
            }
         }

         var32 ^= 276469133;
         Object var19 = var8.next();
         Entry var20 = (Entry)var19;
         var32 ^= 625352032;
         Object var24 = var20.getKey();
         Integer var25 = (Integer)var24;
         int var26 = var25;
         Object var29 = var20.getValue();
         ItemStack var30 = (ItemStack)var29;
         var7.setItem(var26, var30);
         var32 ^= 349025912;
         var32 ^= 1934798989;

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32) != 38992242) {
               throw null;
            }

            throw new RuntimeException();
         } catch (RuntimeException var33) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var32)) {
            case -1501681605:
               var32 = dpkxpdajfbbcxwly(var32, 321184495);
               break;
            case -1061470261:
               var32 ^= 536625169;
               break;
            default:
               throw new RuntimeException("Error in hash");
            }

            var32 = dpkxpdajfbbcxwly(var32, 1099394295);
         }
      }
   }

   public void click$2048279449(WrappedClickEvent var1, int var2) {
      int var78 = 96663122 ^ 292086379 ^ this.MrS68agYfe ^ var2;
      var78 ^= 1047357372;
      Player var14 = var1.getPlayer$624284539(1206635844);
      var78 ^= 1593308323;
      ItemStack var16 = var1.getItemStack$386585608(389697697);
      var78 ^= 811605559;
      if (var16 != null) {
         var78 ^= 95570168;
         Material var19 = var16.getType();
         Material var4 = Material.AIR;
         if (var19 == var4) {
            var78 ^= 1338401507;
            return;
         }

         var78 = dpkxpdajfbbcxwly(var78, 445634834);
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) != 43434653) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
               case 43434653:
                  var78 ^= 565702970;
                  throw new RuntimeException();
               case 139401181:
               case 333390165:
               default:
                  throw new RuntimeException();
               case 776926308:
               }
            }
         } else {
            var78 ^= 724358831;
            int var21 = var1.getSlot$2125716982(2104088370);
            byte var60 = (byte)(1201408153 ^ var78);
            if (var21 == var60) {
               var78 ^= 302751621;
               SQLiteManager var69 = this.sqLiteManager;
               Map var70 = var69.getSpawnNumber$1518350224(567915392);
               Collection var71 = var70.values();
               ArrayList var22 = new ArrayList(var71);
               var78 ^= 757281232;
               byte var24 = var22.isEmpty();
               if (var24 != (2025105149 ^ var78)) {
                  var78 ^= 1216481225;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) == 225044578) {
                     var78 ^= 396987689;
                     String var63 = ykfmtnwufp(cudpjabnqmyjhsg(), bfodvaubpfprqhm(), var78);
                     var14.sendMessage(var63);
                     var78 ^= 1787154888;
                     return;
                  }

                  var78 ^= 2100399625;
               } else {
                  var78 ^= 183196786;
                  Collections.shuffle(var22);
                  var78 ^= 1906543438;
                  byte var61 = (byte)(66875841 ^ var78);
                  Object var27 = var22.get(var61);
                  Location var28 = (Location)var27;
                  var78 ^= 1650807881;
                  var14.closeInventory();
                  var78 ^= 1602447374;
                  TeleportManager var31 = this.teleportManager;
                  var31.teleportWithCountdown$168586022(var14, var28, 1255099300);
                  var78 ^= 1960289261;
                  var78 ^= 1196559630;

                  try {
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) != 174441740) {
                        throw null;
                     }

                     throw new RuntimeException();
                  } catch (RuntimeException var80) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var78)) {
                     case -2114281214:
                        var78 = dpkxpdajfbbcxwly(var78, 1023307235);
                        break;
                     case 1828657960:
                        var78 ^= 1633606310;
                        break;
                     default:
                        throw new IOException("Error in hash");
                     }
                  }

                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                     case 45495080:
                        var78 ^= 568050710;
                        return;
                     case 1129369389:
                     default:
                        throw new RuntimeException();
                     case 1596405876:
                        return;
                     case 1644805777:
                     }
                  }
               }
            } else {
               label240:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                  case 180229977:
                     var78 ^= 1812266503;
                     break label240;
                  case 1582551539:
                  default:
                     throw new RuntimeException();
                  case 1604248031:
                     break;
                  case 1706629972:
                     break label240;
                  }
               }

               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) != 75003499) {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                     case 75003499:
                        var78 ^= 1721751954;
                        throw new RuntimeException();
                     case 238884460:
                     case 1251639765:
                     default:
                        throw new RuntimeException();
                     case 1499275228:
                     }
                  }
               } else {
                  var78 ^= 1597237587;
                  byte var34 = var16.hasItemMeta();
                  if (var34 == (1957371900 ^ var78)) {
                     var78 = dpkxpdajfbbcxwly(var78, 1497950433);
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) == 149521195) {
                        var78 ^= 535804423;
                        return;
                     }

                     var78 = dpkxpdajfbbcxwly(var78, 1625610272);
                  } else {
                     var78 ^= 808505678;
                     ItemMeta var36 = var16.getItemMeta();
                     byte var37 = var36.hasDisplayName();
                     if (var37 != (1151061682 ^ var78)) {
                        var78 ^= 250518397;
                        ItemMeta var39 = var16.getItemMeta();
                        String var40 = var39.getDisplayName();
                        var78 ^= 712907021;
                        String var42 = ChatColor.stripColor(var40);
                        var78 ^= 1284849583;
                        String var64 = ykfmtnwufp(dnmrbteuhdttone(), bfodvaubpfprqhm(), var78);
                        String var73 = ykfmtnwufp(tncwsexqdnmyban(), bfodvaubpfprqhm(), var78);
                        String var44 = var42.replaceAll(var64, var73);
                        var78 ^= 317901089;
                        byte var46 = var44.isEmpty();
                        if (var46 == (1047312972 ^ var78)) {
                           var78 ^= 2016358808;
                           int var48 = Integer.parseInt(var44);
                           var78 ^= 367656484;
                           SQLiteManager var50 = this.sqLiteManager;
                           Map var51 = var50.getSpawnNumber$1518350224(567915392);
                           var78 ^= 1573327878;
                           Integer var66 = var48;
                           Object var53 = var51.get(var66);
                           Location var54 = (Location)var53;
                           var78 ^= 2010667966;
                           if (var54 != null) {
                              var78 ^= 1858225801;
                              var14.closeInventory();
                              var78 ^= 658701657;
                              TeleportManager var58 = this.teleportManager;
                              var58.teleportWithCountdown$168586022(var14, var54, 1255099300);

                              label176:
                              while(true) {
                                 switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                                 case 224893731:
                                    var78 ^= 1841107416;
                                    break label176;
                                 case 260696808:
                                 default:
                                    throw new RuntimeException();
                                 case 935740223:
                                    break;
                                 case 1231566915:
                                    break label176;
                                 }
                              }

                              try {
                                 if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) != 87608052) {
                                    throw null;
                                 }

                                 throw new IllegalAccessException();
                              } catch (IllegalAccessException var79) {
                                 switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var78)) {
                                 case -331054590:
                                    var78 = dpkxpdajfbbcxwly(var78, 682318365);
                                    break;
                                 case 1477259691:
                                    var78 ^= 505572456;
                                    break;
                                 default:
                                    throw new IOException("Error in hash");
                                 }
                              }

                              var78 = dpkxpdajfbbcxwly(var78, 1194297159);
                           } else {
                              var78 ^= 1200860467;
                              if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) != 141228888) {
                                 while(true) {
                                    switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                                    case 141228888:
                                       var78 ^= 1931589702;
                                       throw new RuntimeException();
                                    case 656848922:
                                    case 1387068372:
                                    default:
                                       throw new RuntimeException();
                                    case 1031741385:
                                    }
                                 }
                              } else {
                                 label189:
                                 while(true) {
                                    switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                                    case 74066132:
                                    default:
                                       throw new RuntimeException();
                                    case 141228888:
                                       var78 ^= 539230983;
                                    case 509007046:
                                       break label189;
                                    case 2021325631:
                                    }
                                 }

                                 String var68 = ykfmtnwufp(xjjdxvuzhgpzubr(), bfodvaubpfprqhm(), var78);
                                 var14.sendMessage(var68);
                                 var78 ^= 739170662;
                              }
                           }

                           return;
                        } else {
                           label201:
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                              case 95601938:
                                 break label201;
                              case 150115999:
                                 var78 ^= 1939587647;
                                 break label201;
                              case 1578191606:
                                 break;
                              case 1787559005:
                              default:
                                 throw new RuntimeException();
                              }
                           }

                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) == 118437033) {
                              var78 = dpkxpdajfbbcxwly(var78, 2147169641);
                              return;
                           }

                           var78 = dpkxpdajfbbcxwly(var78, 15750990);
                        }
                     } else {
                        label229:
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                           case 82683107:
                              var78 ^= 90988802;
                           case 537809856:
                              break label229;
                           case 590823149:
                              break;
                           case 1554232783:
                           default:
                              throw new RuntimeException();
                           }
                        }

                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) != 265266578) {
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                              case 213799947:
                                 break;
                              case 255851700:
                              case 1066382570:
                              default:
                                 throw new RuntimeException();
                              case 265266578:
                                 var78 ^= 217088141;
                                 throw new RuntimeException();
                              }
                           }
                        } else {
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                              case 96752941:
                                 break;
                              case 265266578:
                                 var78 ^= 1945887402;
                                 return;
                              case 576307724:
                              default:
                                 throw new RuntimeException();
                              case 1786917270:
                                 return;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      } else {
         label252:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
            case 266451286:
               var78 ^= 1656593641;
            case 725212436:
               break label252;
            case 1022118984:
               break;
            case 1048011319:
            default:
               throw new RuntimeException();
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) == 21924327) {
            var78 ^= 684308210;
            return;
         }

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
            case 21924327:
               var78 ^= 1547172921;
               throw new RuntimeException();
            case 119245916:
            case 1042955632:
            default:
               throw new RuntimeException();
            case 598502903:
            }
         }
      }

      throw new RuntimeException();
   }

   public void removeSpawnItem(int var1) {
      int var11 = 610889922 ^ 2027361799 ^ this.MrS68agYfe;
      var11 ^= 5213192;
      Map var5 = this.SpawnItems;
      byte var4 = (byte)(205240196 ^ var11);
      int var7 = var1 - var4;
      Integer var8 = var7;
      var5.remove(var8);
      var11 ^= 1601937489;
   }

   public boolean isInGUI$652632361(Player var1, int var2) {
      int var8 = 2013415683 ^ 1724686099 ^ this.MrS68agYfe ^ var2;
      var8 ^= 218368325;
      Map var5 = this.opened;
      boolean var6 = var5.containsKey(var1);
      return var6;
   }

   public void remove$1734529989(Player var1, int var2) {
      int var8 = 241664340 ^ 605371435 ^ this.MrS68agYfe ^ var2;
      var8 ^= 1179006035;
      Map var5 = this.opened;
      var5.remove(var1);
      var8 ^= 135989892;
   }

   public void addToOpened$232106327(Player var1, Object[] var2, int var3) {
      int var10 = 1483000037 ^ 56346266 ^ this.MrS68agYfe ^ var3;
      var10 ^= 27319459;
      Map var7 = this.opened;
      var7.put(var1, var2);
      var10 ^= 1204201983;
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣶⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⠿⠟⠛⠻⣿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣆⣀⣀⠀⣿⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠻⣿⣿⣿⠅⠛⠋⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[5] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢼⣿⣿⣿⣃⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[6] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣟⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣛⣛⣫⡄⠀⢸⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣾⡆⠸⣿⣿⣿⡷⠂⠨⣿⣿⣿⣿⣶⣦⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣾⣿⣿⣿⣿⡇⢀⣿⡿⠋⠁⢀⡶⠪⣉⢸⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⡏⢸⣿⣷⣿⣿⣷⣦⡙⣿⣿⣿⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣇⢸⣿⣿⣿⣿⣿⣷⣦⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[15] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[16] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[17] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣵⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      int var3 = (new Random(-4487970365578537263L)).nextInt();
      YgrU5KeNrN = 1840806210 ^ var3;
   }

   public static String ykfmtnwufp(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] bfodvaubpfprqhm() {
      return new byte[]{12, 85, 120, 77, 75, 66, 46, 99, 38, 56, 41, 63, 10, 94, 65, 115, 50, 3, 56, 88, 114, 15, 79, 43, 75, 14, 76, 34, 42, 107, 59, 78, 25, 42, 94, 79, 86, 47, 77, 7, 52, 4, 47, 96, 76, 120, 66, 31, 25, 49, 23};
   }

   private static byte[] mydzzdeerlhjzrr() {
      return new byte[]{-57, -98, 77, 9, 122, 3, 25, 53, 31, 122, 29, 100, 61, 48, 112, 35, 5, 79, 13, 5, 71, 22, 126, 119, 124, 88, 117, 111, 30, 46, 12, 19, 40, 124, 105, 15, 99, 126, 120, 66, 5, 70, 24, 121, 117, 41, 118, 67, 46, 115, 38, 75, 98, 45, 120, 30, 119, 96, 82, 72, 15, 112, 6, 94, 106, 25, 68, 102};
   }

   private static byte[] obcafpuosywllbp() {
      return new byte[]{-60, -100, 73, 14, 122, 1, 28, 48, 16, 121, 24, 97, 59, 50, 115, 38, 4, 64, 9, 1, 67, 18, 125, 106, 125, 72, 125, 115, 27, 47, 9, 18, 47, 67, 111, 19, 103, 115, 127, 71, 2, 87};
   }

   private static byte[] lfctgucmtdncbkp() {
      return new byte[]{-64, -102, 74, 14, 121, 0, 25, 51, 30, 118, 27, 97, 56, 49, 115, 38, 5, 71, 0, 8, 64, 17, 125, 118, 121, 93, 123, 107, 18, 34, 9, 18, 43, 123, 108, 4, 97, 123, 117, 76, 6, 71, 29, 126, 126, 38, 117, 65, 33, 122, 37, 89};
   }

   private static byte[] mbuopjqomboemvw() {
      return new byte[]{-61, -100, 79, 95, 121, 0, 25, 57, 22, 104, 31, 113, 61, 9, 115, 54, 4, 64, 9, 75};
   }

   private static byte[] ohzkjnlpcsjqoof() {
      return new byte[]{-61, -101, 73, 12, 123, 10, 31, 59, 20, 120, 24, 96, 59, 51, 113, 44, 3, 79, 10, 6, 67, 16, 126, 123, 123, 87, 125, 120, 24, 55, 10, 32, 40, 104, 110, 22, 103, 113, 127, 85, 5, 106, 30, 51, 124, 50, 115, 84, 43, 105, 38, 74};
   }

   private static byte[] cplsvzmhegspcbh() {
      return new byte[]{-57, -102, 73, 92, 127, 29, 23, 52, 17, 117, 25, 81, 62, 26, 115, 38, 4, 85, 13, 17, 67, 94, 123, 107, 114, 75, 123, 50};
   }

   private static byte[] snmjhffhvshwwcl() {
      return new byte[]{-61, -99, 77, 11, 126, 7, 31, 53, 18, 127, 24, 102, 63, 52, 116, 33, 3, 65, 12, 1, 67, 22, 122, 109, 126, 75, 125, 116, 30, 44, 10, 23};
   }

   private static byte[] lzsbtrmuzskzidt() {
      return new byte[]{-54, -109, 72, 12, 114, 4, 25, 49, 20, 119, 16, 97, 56, 56, 119, 35, 1, 68, 0, 8, 66, 19, 118, 115, 124, 88, 126, 98, 19, 47, 9, 40, 47, 109, 109, 28, 110, 113, 125, 80, 13, 109, 24, 50, 126, 50, 123, 93, 43, 103, 33, 76};
   }

   private static byte[] fjrfomupuoryjny() {
      return new byte[]{-61, -101, 75, 10, 126, 3, 24, 54, 17, 123, 24, 96, 57, 53, 116, 37, 4, 66, 15, 5, 67, 16, 124, 108, 126, 79, 122, 119, 29, 40, 10, 17, 42, 65, 107, 16, 96, 122, 122, 94, 5, 80};
   }

   private static byte[] hujjvlxdtgrdhuu() {
      return new byte[]{-61, -101, 75, 92, 126, 29, 24, 34, 17, 97, 24, 108, 57, 15, 116, 48, 4, 18};
   }

   private static byte[] gyltdhcxjmbdfjp() {
      return new byte[]{-54, -103, 74, 15, 126, 10, 28, 54, 22, 119, 26, 99, 59, 52, 121, 38, 6, 70, 0, 2, 64, 16, 122, 126, 121, 91, 124, 98, 25, 6, 10, 11, 33, 116, 106, 30, 110, 101, 127, 83, 1, 78, 29, 39};
   }

   private static byte[] dwourgfhyqvsedb() {
      return new byte[]{-61, -101, 77, 45, 120, 1, 22, 59, 30, 127, 24, 96};
   }

   private static byte[] xksuucngejrdzom() {
      return new byte[]{-61, -99, 79, 63, 114, 17, 25, 48, 31, 109, 24, 125, 61, 4, 120, 49, 5, 22, 1, 34, 67, 89, 120, 112, 114, 93};
   }

   private static byte[] lilsyazzcypyova() {
      return new byte[]{-61, -109, 76, 46, 121, 37, 22, 24, 17, 67, 24, 67};
   }

   private static byte[] xjjdxvuzhgpzubr() {
      return new byte[]{-57, -102, 75, 42, 115, 7, 27, 52, 18, 122, 25, 98, 62, 70, 116, 54, 4, 88, 13, 1, 65, 85, 119, 106, 126, 24, 120, 121, 26, 55, 15, 2, 44, 63, 104, 29, 99, 112, 126, 70, 12, 95, 26, 50, 120, 99};
   }

   private static byte[] dnmrbteuhdttone() {
      return new byte[]{-59, -98, 64, 35, 115, 45, 25, 103, 23, 34, 29, 62, 63, 59};
   }

   private static byte[] tncwsexqdnmyban() {
      return new byte[0];
   }

   private static byte[] cudpjabnqmyjhsg() {
      return new byte[]{-60, -100, 76, 52, 127, 31, 23, 119, 23, 125, 31, 123, 61, 11, 115, 61, 6, 92, 14, 78, 70, 72, 123, 118, 114, 83, 125, 122, 28, 43, 12, 9, 43, 51, 106, 31, 96, 111, 121, 81, 0, 95, 22, 56, 125, 47, 116, 73, 46, 105, 37, 80, 97, 103};
   }

   private static int dpkxpdajfbbcxwly(int var0, int var1) {
      return var0 ^ var1;
   }
}
