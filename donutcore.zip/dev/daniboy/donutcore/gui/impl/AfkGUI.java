package dev.daniboy.donutcore.gui.impl;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.internal.platform.WorldGuardPlatform;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.database.SQLiteManager;
import dev.daniboy.donutcore.gui.AbstractGui;
import dev.daniboy.donutcore.gui.WrappedClickEvent;
import dev.daniboy.donutcore.manager.TeleportManager;
import dev.daniboy.donutcore.utils.Hex;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class AfkGUI extends AbstractGui {
   private final Map<Player, Object[]> opened;
   private final FileConfiguration afkSpawnGuiConfig;
   private final String guiTitle;
   private final SQLiteManager sqLiteManager;
   private final TeleportManager teleportManager;
   private final Map<Integer, ItemStack> afkItems;
   private final RegionContainer regionContainer;
   private static int 6Mktfpr5ue;
   private transient int NV6ekYepud;
   private static byte[] gkmsdlfhnn;
   private static String[] nothing_to_see_here = new String[15];

   public AfkGUI(DonutCore var1, SQLiteManager var2, TeleportManager var3, int var4) {
      int var29 = 876313255 ^ 141727428;
      super(var1, 1156425752);
      var29 = blbquqyvjqgjhvwn(var29, 1299619068);
      var29 = 1680320480 ^ 199615660 ^ Integer.parseInt("50176990") ^ var4;
      this.NV6ekYepud = 1500772219 ^ 6Mktfpr5ue;
      var29 ^= 1125760640;
      var29 ^= 1184469572;
      HashMap var14 = new HashMap();
      this.opened = var14;
      var29 ^= 1655747640;
      HashMap var15 = new HashMap();
      this.afkItems = var15;
      var29 ^= 477023418;
      FileConfiguration var17 = var1.getafkSpawnGuiConfig$23715181(125321510);
      this.afkSpawnGuiConfig = var17;
      var29 ^= 2094818552;
      FileConfiguration var19 = this.afkSpawnGuiConfig;
      String var27 = "afk_gui.title";
      String var20 = var19.getString(var27);
      String var21 = Hex.hex(var20);
      this.guiTitle = var21;
      var29 ^= 1788019565;
      WorldGuard var22 = WorldGuard.getInstance();
      WorldGuardPlatform var23 = var22.getPlatform();
      RegionContainer var24 = var23.getRegionContainer();
      this.regionContainer = var24;
      var29 ^= 1552242764;
      this.sqLiteManager = var2;
      var29 ^= 430178688;
      this.teleportManager = var3;
      var29 ^= 718324024;
   }

   public void loadAfkConfigValues$568738828(int var1) {
      int var170 = 846335633 ^ 1684493048 ^ this.NV6ekYepud ^ var1;
      var170 ^= 342156494;
      SQLiteManager var20 = this.sqLiteManager;
      Map var21 = var20.getAfkNumber$322438506(1276746628);
      var170 ^= 590951816;
      TreeMap var22 = new TreeMap(var21);
      var170 ^= 699976505;
      FileConfiguration var24 = this.afkSpawnGuiConfig;
      String var114 = cbnglzggvx(tuevegopvisgnxa(), var170);
      int var25 = var24.getInt(var114);
      int var7 = var25;
      var170 ^= 2085811143;
      byte var115 = (byte)(373820420 ^ var170);
      String var146 = cbnglzggvx(kpdvzpjmzjrajkk(), var170);
      this.setConfigurableItem$596163210(var115, var146, 709598146);
      var170 ^= 1540290052;
      byte var116 = (byte)(1300691457 ^ var170);
      String var147 = cbnglzggvx(idhmvgougwzxygz(), var170);
      this.setConfigurableItem$596163210(var116, var147, 709598146);
      var170 ^= 493992446;
      byte var117 = (byte)(1358382076 ^ var170);
      String var148 = cbnglzggvx(ovvgivfpfvrmpnm(), var170);
      this.setConfigurableItem$596163210(var117, var148, 709598146);
      var170 ^= 163298156;
      Set var30 = var22.entrySet();
      Iterator var31 = var30.iterator();
      Iterator var8 = var31;
      var170 ^= 1429681190;

      while(true) {
         byte var33 = var8.hasNext();
         if (var33 == (209439876 ^ var170)) {
            var170 = blbquqyvjqgjhvwn(var170, 862564062);
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170) == 171155868) {
               var170 ^= 620466801;
               return;
            }

            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170)) {
               case 171155868:
                  var170 ^= 251531295;
                  throw new IllegalAccessException();
               case 209859870:
               case 1679905914:
               default:
                  throw new IllegalAccessException();
               case 1694522621:
               }
            }
         }

         var170 ^= 1135351073;
         Object var35 = var8.next();
         Entry var36 = (Entry)var35;
         var170 ^= 1569216125;
         Object var38 = var36.getKey();
         Integer var39 = (Integer)var38;
         int var40 = var39;
         var170 ^= 1906273734;
         Object var42 = var36.getValue();
         Location var43 = (Location)var42;
         var170 ^= 1247877275;
         RegionContainer var45 = this.regionContainer;
         World var119 = var43.getWorld();
         com.sk89q.worldedit.world.World var120 = BukkitAdapter.adapt(var119);
         RegionManager var46 = var45.get(var120);
         var170 ^= 1668452193;
         ArrayList var47 = new ArrayList();
         ArrayList var15 = var47;
         var170 ^= 505458781;
         BlockVector3 var122 = BukkitAdapter.asBlockVector(var43);
         ApplicableRegionSet var49 = var46.getApplicableRegions(var122);
         Iterator var50 = var49.iterator();
         Iterator var16 = var50;
         var170 ^= 814087956;

         while(true) {
            byte var52 = var16.hasNext();
            if (var52 == (1685469869 ^ var170)) {
               var170 = blbquqyvjqgjhvwn(var170, 2040284333);
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170) != 167135690) {
                  var170 = blbquqyvjqgjhvwn(var170, 738593861);
                  throw new IllegalAccessException();
               }

               var170 = blbquqyvjqgjhvwn(var170, 318967028);
               ArrayList var53 = new ArrayList();
               ArrayList var161 = var53;
               var170 ^= 1084677680;
               int var55 = var15.size();
               ItemStack var12;
               ItemMeta var13;
               if (var55 >= var7) {
                  var170 ^= 981057746;
                  Material var159 = Material.REDSTONE_BLOCK;
                  ItemStack var86 = new ItemStack(var159, var40);
                  var12 = var86;
                  var170 ^= 1779031645;
                  ItemMeta var88 = var86.getItemMeta();
                  var13 = var88;
                  var170 ^= 1003380112;
                  FileConfiguration var90 = this.afkSpawnGuiConfig;
                  String var137 = cbnglzggvx(ukafbobzrkfoenm(), var170);
                  String var91 = var90.getString(var137);
                  String var92 = Hex.hex(var91);
                  var170 ^= 1834963293;
                  FileConfiguration var94 = this.afkSpawnGuiConfig;
                  String var138 = cbnglzggvx(mknkyepdbbmmsmx(), var170);
                  List var95 = var94.getStringList(var138);
                  List var96 = Hex.hex(var95);
                  var170 ^= 1816333740;
                  var88.setDisplayName(var92);
                  var170 ^= 1781507190;
                  var53.addAll(var96);
                  var170 ^= 2099684576;

                  label161:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170)) {
                     case 76230616:
                        var170 ^= 1362105575;
                     case 358767307:
                        break label161;
                     case 953357185:
                        break;
                     case 1594086308:
                     default:
                        throw new IllegalAccessException();
                     }
                  }

                  try {
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170) != 259810964) {
                        throw null;
                     }

                     throw new IOException();
                  } catch (IOException var172) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var170)) {
                     case -2139895415:
                        var170 ^= 398437515;
                        break;
                     case 379927259:
                        var170 ^= 1164276449;
                        break;
                     default:
                        throw new RuntimeException("Error in hash");
                     }
                  }

                  var170 ^= 1632247181;
               } else {
                  var170 ^= 622814897;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170) != 267182866) {
                     var170 = blbquqyvjqgjhvwn(var170, 1522317360);
                     throw new IllegalAccessException();
                  }

                  label201:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170)) {
                     case 98917759:
                        break;
                     case 104620099:
                        break label201;
                     case 267182866:
                        var170 ^= 748790919;
                        break label201;
                     case 1303362517:
                     default:
                        throw new IllegalAccessException();
                     }
                  }

                  Material var149 = Material.ITEM_FRAME;
                  ItemStack var56 = new ItemStack(var149, var40);
                  var12 = var56;
                  var170 ^= 1064931190;
                  ItemMeta var58 = var56.getItemMeta();
                  var13 = var58;
                  var170 ^= 371716431;
                  FileConfiguration var60 = this.afkSpawnGuiConfig;
                  String var124 = cbnglzggvx(wamgnouvlafbztv(), var170);
                  String var61 = var60.getString(var124);
                  String var125 = cbnglzggvx(isngerraxqehdlo(), var170);
                  String var151 = String.valueOf(var40);
                  String var62 = var61.replace(var125, var151);
                  String var63 = Hex.hex(var62);
                  var170 ^= 593607360;
                  var58.setDisplayName(var63);
                  var170 ^= 175546936;
                  FileConfiguration var66 = this.afkSpawnGuiConfig;
                  String var127 = cbnglzggvx(qbzzdihdtdtstgt(), var170);
                  List var67 = var66.getStringList(var127);
                  Iterator var68 = var67.iterator();
                  Iterator var18 = var68;
                  var170 ^= 1110840866;

                  label191:
                  while(true) {
                     byte var70 = var18.hasNext();
                     if (var70 == (93199889 ^ var170)) {
                        label151:
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170)) {
                           case 87374241:
                              var170 ^= 101490606;
                           case 141303254:
                              break label151;
                           case 705365805:
                           default:
                              throw new IllegalAccessException();
                           case 1408768212:
                           }
                        }

                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170) != 55204385) {
                           var170 ^= 846132218;
                           throw new IllegalAccessException();
                        }

                        var170 ^= 1165576584;
                        break;
                     }

                     var170 ^= 1182322252;
                     Object var72 = var18.next();
                     String var73 = (String)var72;
                     var170 ^= 1682169484;
                     String var128 = cbnglzggvx(yngexuuzyluppzl(), var170);
                     int var153 = var15.size();
                     String var154 = String.valueOf(var153);
                     String var75 = var73.replace(var128, var154);
                     var170 ^= 1893408163;
                     String var129 = cbnglzggvx(hbsbwaznpwyocrq(), var170);
                     String var156 = String.valueOf(var7);
                     String var77 = var75.replace(var129, var156);
                     var170 ^= 516244703;
                     String var131 = Hex.hex(var77);
                     boolean var79 = var161.add(var131);
                     var170 ^= 1363357256;
                     var170 = blbquqyvjqgjhvwn(var170, 409812900);

                     try {
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170) != 8188249) {
                           throw null;
                        }

                        throw new IOException();
                     } catch (IOException var173) {
                        switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var170)) {
                        case -356167797:
                           var170 = blbquqyvjqgjhvwn(var170, 961949268);
                           break;
                        case 69874184:
                           var170 ^= 1150009828;
                           break;
                        default:
                           throw new IllegalAccessException("Error in hash");
                        }

                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170)) {
                           case 64774849:
                              var170 ^= 1098946996;
                              continue label191;
                           case 658676237:
                              break;
                           case 2013012122:
                           default:
                              throw new IllegalAccessException();
                           case 2078671299:
                              continue label191;
                           }
                        }
                     }
                  }
               }

               var13.setLore(var161);
               var170 ^= 1055907727;
               boolean var82 = var12.setItemMeta(var13);
               var170 ^= 1814843086;
               Map var84 = this.afkItems;
               byte var157 = (byte)(339237239 ^ var170);
               int var135 = var40 - var157;
               Integer var136 = var135;
               var84.put(var136, var12);
               var170 ^= 118338355;
               var170 ^= 401445566;

               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170) != 76215731) {
                     throw null;
                  }

                  throw new RuntimeException();
               } catch (RuntimeException var171) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var170)) {
                  case -2144559544:
                     var170 ^= 1702175197;
                     break;
                  case 650364888:
                     var170 ^= 1906887407;
                     break;
                  default:
                     throw new IOException("Error in hash");
                  }

                  var170 = blbquqyvjqgjhvwn(var170, 2030796432);
                  break;
               }
            }

            var170 ^= 1626482384;
            Object var101 = var16.next();
            ProtectedRegion var102 = (ProtectedRegion)var101;
            ProtectedRegion var163 = var102;
            var170 ^= 364821726;
            Collection var103 = Bukkit.getOnlinePlayers();
            Iterator var104 = var103.iterator();
            Iterator var165 = var104;
            var170 ^= 1243868561;

            while(true) {
               byte var106 = var165.hasNext();
               if (var106 == (1528384818 ^ var170)) {
                  label236:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170)) {
                     case 8478345:
                        var170 ^= 168499779;
                        break label236;
                     case 1302860514:
                     default:
                        throw new IllegalAccessException();
                     case 1341042699:
                        break label236;
                     case 1519003342:
                     }
                  }

                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170) != 219404408) {
                     var170 = blbquqyvjqgjhvwn(var170, 1627268404);
                     throw new IllegalAccessException();
                  }

                  label225:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170)) {
                     case 77245717:
                        break;
                     case 219404408:
                        var170 ^= 246904516;
                        break label225;
                     case 388857351:
                     default:
                        throw new IllegalAccessException();
                     case 1321265830:
                        break label225;
                     }
                  }

                  label216:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170)) {
                     case 156217067:
                        var170 ^= 2089461827;
                        break label216;
                     case 481631685:
                     default:
                        throw new IllegalAccessException();
                     case 1787589610:
                        break;
                     case 1854414701:
                        break label216;
                     }
                  }

                  try {
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170) != 70006883) {
                        throw null;
                     }

                     throw new RuntimeException();
                  } catch (RuntimeException var174) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var170)) {
                     case 302867683:
                        var170 = blbquqyvjqgjhvwn(var170, 1076990590);
                        break;
                     case 427577265:
                        var170 = blbquqyvjqgjhvwn(var170, 23050004);
                        break;
                     default:
                        throw new IllegalAccessException("Error in hash");
                     }

                     var170 = blbquqyvjqgjhvwn(var170, 1174799439);
                     break;
                  }
               }

               var170 ^= 1969294805;
               Object var108 = var165.next();
               Player var109 = (Player)var108;
               var170 ^= 1916121373;
               Location var142 = var109.getLocation();
               BlockVector3 var143 = BukkitAdapter.asBlockVector(var142);
               byte var111 = var163.contains(var143);
               if (var111 != (1548612090 ^ var170)) {
                  var170 ^= 1230001265;
                  String var145 = var109.getName();
                  boolean var113 = var15.add(var145);
                  var170 ^= 888333366;
               } else {
                  var170 ^= 1994697311;
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170) != 44567334) {
                     var170 = blbquqyvjqgjhvwn(var170, 457517536);
                     throw new IllegalAccessException();
                  }

                  var170 ^= 189143576;
               }

               label254:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170)) {
                  case 29339313:
                     var170 ^= 550020805;
                     break label254;
                  case 1638584041:
                     break;
                  case 1651517898:
                  default:
                     throw new IllegalAccessException();
                  case 2070509015:
                     break label254;
                  }
               }

               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var170) != 18180135) {
                     throw null;
                  }

                  throw new IllegalAccessException();
               } catch (IllegalAccessException var175) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var170)) {
                  case -1556183752:
                     var170 = blbquqyvjqgjhvwn(var170, 1255264413);
                     break;
                  case 155139008:
                     var170 = blbquqyvjqgjhvwn(var170, 1603397442);
                     break;
                  default:
                     throw new IllegalAccessException("Error in hash");
                  }

                  var170 ^= 95374600;
               }
            }
         }
      }
   }

   private void setConfigurableItem$596163210(int var1, String var2, int var3) {
      int var48 = 387436335 ^ 1866505089 ^ this.NV6ekYepud ^ var3;
      var48 ^= 1420437581;
      FileConfiguration var12 = this.afkSpawnGuiConfig;
      String var34 = var2 + ".material";
      String var6 = cbnglzggvx(oyawokyyjqettbg(), var48);
      String var13 = var12.getString(var34, var6);
      Material var14 = Material.getMaterial(var13);
      var48 ^= 647681877;
      FileConfiguration var16 = this.afkSpawnGuiConfig;
      String var36 = var2 + ".display_name";
      String var44 = cbnglzggvx(bjhwlzbmggpqrvo(), var48);
      String var17 = var16.getString(var36, var44);
      String var18 = Hex.hex(var17);
      var48 ^= 666043691;
      FileConfiguration var20 = this.afkSpawnGuiConfig;
      String var38 = var2 + ".lore";
      List var21 = var20.getStringList(var38);
      List var22 = Hex.hex(var21);
      var48 ^= 1094192202;
      ItemStack var23 = new ItemStack(var14);
      var48 ^= 1052678386;
      ItemMeta var25 = var23.getItemMeta();
      var48 ^= 1982032595;
      if (var25 != null) {
         var48 ^= 1059332537;
         var25.setDisplayName(var18);
         var48 ^= 1506038231;
         var25.setLore(var22);
         var48 ^= 1924661461;
         var23.setItemMeta(var25);
         var48 ^= 678024999;
      } else {
         label24:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var48)) {
            case 227753741:
               var48 ^= 82423909;
            case 896405110:
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var48) == 100619684) {
                  var48 ^= 953686009;
                  break label24;
               }

               var48 = blbquqyvjqgjhvwn(var48, 1389474373);
               throw new IllegalAccessException();
            case 315332059:
               break;
            case 674162682:
            default:
               throw new IllegalAccessException();
            }
         }
      }

      Map var32 = this.afkItems;
      Integer var43 = var1;
      var32.put(var43, var23);
      var48 ^= 1077533139;
   }

   public Inventory generateInventory$919822562(Player var1, Object[] var2, int var3) {
      int var32 = 558219135 ^ 1082313116 ^ this.NV6ekYepud ^ var3;
      var32 ^= 1651822970;
      Object var4 = null;
      byte var5 = (byte)(643007327 ^ var32);
      String var27 = this.guiTitle;
      Inventory var10 = Bukkit.createInventory((InventoryHolder)var4, var5, var27);
      Inventory var7 = var10;
      var32 ^= 380064684;
      this.loadAfkConfigValues$568738828(1586297296);
      var32 ^= 545087687;
      Map var13 = this.afkItems;
      Set var14 = var13.entrySet();
      Iterator var15 = var14.iterator();
      Iterator var8 = var15;
      var32 ^= 1246160623;

      while(true) {
         byte var17 = var8.hasNext();
         if (var17 == (1523537645 ^ var32)) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32)) {
               case 267510436:
                  var32 ^= 1245992265;
               case 1757421771:
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32) == 870278) {
                     var32 = blbquqyvjqgjhvwn(var32, 240782072);
                     return var7;
                  }

                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32)) {
                     case 870278:
                        var32 ^= 1096812998;
                        throw new RuntimeException();
                     case 339263807:
                     case 398156225:
                     default:
                        throw new RuntimeException();
                     case 1909684369:
                     }
                  }
               case 1123725300:
               default:
                  throw new RuntimeException();
               case 1403952885:
               }
            }
         } else {
            var32 ^= 381536479;
            Object var19 = var8.next();
            Entry var20 = (Entry)var19;
            var32 ^= 365847657;
            Object var24 = var20.getKey();
            Integer var25 = (Integer)var24;
            int var26 = var25;
            Object var29 = var20.getValue();
            ItemStack var30 = (ItemStack)var29;
            var7.setItem(var26, var30);
            var32 ^= 846781109;

            label61:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32)) {
               case 13341705:
                  var32 ^= 224930247;
                  break label61;
               case 49046927:
               default:
                  throw new RuntimeException();
               case 340997168:
                  break;
               case 1825568023:
                  break label61;
               }
            }
         }

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32) != 116209427) {
               throw null;
            }

            throw new IOException();
         } catch (IOException var33) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var32)) {
            case -1304675606:
               var32 = blbquqyvjqgjhvwn(var32, 1480868159);
               break;
            case 895502667:
               var32 ^= 1756352331;
               break;
            default:
               throw new IOException("Error in hash");
            }

            var32 = blbquqyvjqgjhvwn(var32, 1422692495);
         }
      }
   }

   public void click$2048279449(WrappedClickEvent var1, int var2) {
      int var78 = 1334273058 ^ 1036320534 ^ this.NV6ekYepud ^ var2;
      var78 ^= 1411843910;
      Player var14 = var1.getPlayer$624284539(1206635844);
      var78 ^= 1389469029;
      ItemStack var16 = var1.getItemStack$386585608(389697697);
      var78 ^= 1591266930;
      if (var16 != null) {
         var78 ^= 1077277100;
         Material var19 = var16.getType();
         Material var4 = Material.AIR;
         if (var19 == var4) {
            var78 ^= 958443288;
            return;
         }

         var78 ^= 1662646550;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) != 54330822) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
               case 54330822:
                  var78 ^= 1925944813;
                  throw new IllegalAccessException();
               case 178359244:
               case 2021972972:
               default:
                  throw new IllegalAccessException();
               case 1576016457:
               }
            }
         } else {
            var78 ^= 1651923360;
            int var21 = var1.getSlot$2125716982(2104088370);
            byte var60 = (byte)(1883657679 ^ var78);
            if (var21 == var60) {
               var78 ^= 620299627;
               SQLiteManager var71 = this.sqLiteManager;
               Map var72 = var71.getAfkNumber$322438506(1276746628);
               Collection var73 = var72.values();
               ArrayList var49 = new ArrayList(var73);
               var78 ^= 18122731;
               byte var51 = var49.isEmpty();
               if (var51 == (1437325182 ^ var78)) {
                  var78 ^= 1619698048;
                  Collections.shuffle(var49);
                  var78 ^= 1028359337;
                  byte var67 = (byte)(141226583 ^ var78);
                  Object var55 = var49.get(var67);
                  Location var56 = (Location)var55;
                  var78 ^= 623307939;
                  var14.closeInventory();
                  var78 ^= 36009454;
                  TeleportManager var59 = this.teleportManager;
                  var59.teleportWithCountdown$168586022(var14, var56, 1255099300);
                  var78 ^= 516551457;
                  var78 ^= 1495878284;

                  try {
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) != 176906443) {
                        throw null;
                     }

                     throw new RuntimeException();
                  } catch (RuntimeException var79) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var78)) {
                     case 489666090:
                        var78 = blbquqyvjqgjhvwn(var78, 929824879);
                        break;
                     case 1146000827:
                        var78 ^= 473965597;
                        break;
                     default:
                        throw new IllegalAccessException("Error in hash");
                     }

                     var78 = blbquqyvjqgjhvwn(var78, 1232338076);
                     return;
                  }
               }

               var78 = blbquqyvjqgjhvwn(var78, 992284463);
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) == 104115602) {
                  var78 ^= 623430822;
                  String var66 = cbnglzggvx(qyhckvnagwbenbs(), var78);
                  var14.sendMessage(var66);
                  var78 ^= 1981554369;
                  return;
               }

               var78 ^= 242565602;
            } else {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                  case 159921882:
                     var78 ^= 655472071;
                  case 349660440:
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) != 154801465) {
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                           case 51240334:
                              break;
                           case 154801465:
                              var78 ^= 934050186;
                              throw new IllegalAccessException();
                           case 183091668:
                           case 1934052691:
                           default:
                              throw new IllegalAccessException();
                           }
                        }
                     } else {
                        var78 = blbquqyvjqgjhvwn(var78, 1819757715);
                        byte var23 = var16.hasItemMeta();
                        if (var23 != (991997098 ^ var78)) {
                           var78 ^= 1517966917;
                           ItemMeta var25 = var16.getItemMeta();
                           byte var26 = var25.hasDisplayName();
                           if (var26 != (1633352431 ^ var78)) {
                              var78 ^= 930064418;
                              ItemMeta var28 = var16.getItemMeta();
                              String var29 = var28.getDisplayName();
                              var78 ^= 1519305248;
                              String var31 = ChatColor.stripColor(var29);
                              var78 ^= 938750039;
                              String var61 = cbnglzggvx(phbmunmabuqgnlj(), var78);
                              String var5 = cbnglzggvx(ibffkwvlilihegt(), var78);
                              String var33 = var31.replaceAll(var61, var5);
                              var78 ^= 2135657919;
                              byte var35 = var33.isEmpty();
                              if (var35 == (1141124357 ^ var78)) {
                                 var78 ^= 752621868;
                                 int var37 = Integer.parseInt(var33);
                                 var78 ^= 1985707234;
                                 SQLiteManager var39 = this.sqLiteManager;
                                 Map var40 = var39.getAfkNumber$322438506(1276746628);
                                 var78 ^= 662670119;
                                 Integer var63 = var37;
                                 Object var42 = var40.get(var63);
                                 Location var43 = (Location)var42;
                                 var78 ^= 1685483441;
                                 if (var43 != null) {
                                    var78 ^= 1279786997;
                                    var14.closeInventory();
                                    var78 ^= 1430860529;
                                    TeleportManager var47 = this.teleportManager;
                                    var47.teleportWithCountdown$168586022(var14, var43, 1255099300);

                                    label145:
                                    while(true) {
                                       switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                                       case 79706136:
                                          var78 ^= 915056975;
                                       case 360526603:
                                          break label145;
                                       case 462230290:
                                          break;
                                       case 1918495718:
                                       default:
                                          throw new IllegalAccessException();
                                       }
                                    }

                                    try {
                                       if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) != 217895332) {
                                          throw null;
                                       }

                                       throw new RuntimeException();
                                    } catch (RuntimeException var80) {
                                       switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var78)) {
                                       case -1871298381:
                                          var78 ^= 1734043161;
                                          break;
                                       case -504224902:
                                          var78 ^= 1231809120;
                                          break;
                                       default:
                                          throw new IOException("Error in hash");
                                       }
                                    }

                                    var78 ^= 2031179693;
                                    return;
                                 }

                                 var78 = blbquqyvjqgjhvwn(var78, 1977372343);
                                 if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) == 237535219) {
                                    var78 ^= 1487422565;
                                    String var65 = cbnglzggvx(xabpfmhngjrlrnp(), var78);
                                    var14.sendMessage(var65);
                                    var78 ^= 481976109;
                                    return;
                                 }

                                 var78 ^= 1219328857;
                              } else {
                                 while(true) {
                                    switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                                    case 63460157:
                                       var78 ^= 1612846382;
                                    case 471696095:
                                       if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) == 101329141) {
                                          var78 = blbquqyvjqgjhvwn(var78, 1214431625);
                                          return;
                                       }

                                       while(true) {
                                          switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                                          case 101329141:
                                             var78 ^= 1155375512;
                                             throw new IllegalAccessException();
                                          case 1252787149:
                                          case 1580103735:
                                          default:
                                             throw new IllegalAccessException();
                                          case 1447821004:
                                          }
                                       }
                                    case 819564551:
                                       break;
                                    case 1024463986:
                                    default:
                                       throw new IllegalAccessException();
                                    }
                                 }
                              }
                           } else {
                              var78 ^= 1878204375;
                              if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) == 208216757) {
                                 var78 ^= 1659706522;
                                 return;
                              }

                              var78 ^= 1850899595;
                           }

                           throw new IllegalAccessException();
                        } else {
                           var78 ^= 1776644207;
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) == 6228344) {
                              var78 = blbquqyvjqgjhvwn(var78, 1048651111);
                              return;
                           }

                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78)) {
                              case 6228344:
                                 var78 ^= 842941814;
                                 throw new IllegalAccessException();
                              case 664868132:
                                 break;
                              case 1119064293:
                              case 2112754378:
                              default:
                                 throw new IllegalAccessException();
                              }
                           }
                        }
                     }
                  case 777563806:
                  default:
                     throw new IllegalAccessException();
                  case 1694411856:
                  }
               }
            }
         }
      } else {
         var78 = blbquqyvjqgjhvwn(var78, 416191937);
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var78) == 17289445) {
            var78 ^= 1641794421;
            return;
         }

         var78 = blbquqyvjqgjhvwn(var78, 1227425942);
      }

      throw new IllegalAccessException();
   }

   public void removeAfkItem(int var1) {
      int var11 = 974696561 ^ 1177220859 ^ this.NV6ekYepud;
      var11 ^= 188206795;
      Map var5 = this.afkItems;
      byte var4 = (byte)(191088757 ^ var11);
      int var7 = var1 - var4;
      Integer var8 = var7;
      var5.remove(var8);
      var11 ^= 5674346;
   }

   public boolean isInGUI$652632361(Player var1, int var2) {
      int var8 = 1839157745 ^ 1247838830 ^ this.NV6ekYepud ^ var2;
      var8 ^= 1647165461;
      Map var5 = this.opened;
      boolean var6 = var5.containsKey(var1);
      return var6;
   }

   public void remove$1734529989(Player var1, int var2) {
      int var8 = 768515061 ^ 146350422 ^ this.NV6ekYepud ^ var2;
      var8 ^= 814062827;
      Map var5 = this.opened;
      var5.remove(var1);
      var8 ^= 1583964220;
   }

   public void addToOpened$232106327(Player var1, Object[] var2, int var3) {
      int var10 = 20390945 ^ 804772839 ^ this.NV6ekYepud ^ var3;
      var10 ^= 337633011;
      Map var7 = this.opened;
      var7.put(var1, var2);
      var10 ^= 179909655;
   }

   static {
      nothing_to_see_here[0] = "⠄⠄⠄⢰⣧⣼⣯⠄⣸⣠⣶⣶⣦⣾⠄⠄⠄⠄⡀⠄⢀⣿⣿⠄⠄⠄⢸⡇⠄⠄";
      nothing_to_see_here[1] = "⠄⠄⠄⣾⣿⠿⠿⠶⠿⢿⣿⣿⣿⣿⣦⣤⣄⢀⡅⢠⣾⣛⡉⠄⠄⠄⠸⢀⣿⠄";
      nothing_to_see_here[2] = "⠄⠄⢀⡋⣡⣴⣶⣶⡀⠄⠄⠙⢿⣿⣿⣿⣿⣿⣴⣿⣿⣿⢃⣤⣄⣀⣥⣿⣿⠄";
      nothing_to_see_here[3] = "⠄⠄⢸⣇⠻⣿⣿⣿⣧⣀⢀⣠⡌⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿⣿⣿⣿⠄";
      nothing_to_see_here[4] = "⠄⢀⢸⣿⣷⣤⣤⣤⣬⣙⣛⢿⣿⣿⣿⣿⣿⣿⡿⣿⣿⡍⠄⠄⢀⣤⣄⠉⠋⣰";
      nothing_to_see_here[5] = "⠄⣼⣖⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⢇⣿⣿⡷⠶⠶⢿⣿⣿⠇⢀⣤";
      nothing_to_see_here[6] = "⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣽⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣷⣶⣥⣴⣿⡗";
      nothing_to_see_here[7] = "⢀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠄";
      nothing_to_see_here[8] = "⢸⣿⣦⣌⣛⣻⣿⣿⣧⠙⠛⠛⡭⠅⠒⠦⠭⣭⡻⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠄";
      nothing_to_see_here[9] = "⠘⣿⣿⣿⣿⣿⣿⣿⣿⡆⠄⠄⠄⠄⠄⠄⠄⠄⠹⠈⢋⣽⣿⣿⣿⣿⣵⣾⠃⠄";
      nothing_to_see_here[10] = "⠄⠘⣿⣿⣿⣿⣿⣿⣿⣿⠄⣴⣿⣶⣄⠄⣴⣶⠄⢀⣾⣿⣿⣿⣿⣿⣿⠃⠄⠄";
      nothing_to_see_here[11] = "⠄⠄⠈⠻⣿⣿⣿⣿⣿⣿⡄⢻⣿⣿⣿⠄⣿⣿⡀⣾⣿⣿⣿⣿⣛⠛⠁⠄⠄⠄";
      nothing_to_see_here[12] = "⠄⠄⠄⠄⠈⠛⢿⣿⣿⣿⠁⠞⢿⣿⣿⡄⢿⣿⡇⣸⣿⣿⠿⠛⠁⠄⠄⠄⠄⠄";
      nothing_to_see_here[13] = "⠄⠄⠄⠄⠄⠄⠄⠉⠻⣿⣿⣾⣦⡙⠻⣷⣾⣿⠃⠿⠋⠁⠄⠄⠄⠄⠄⢀⣠⣴";
      nothing_to_see_here[14] = "⣿⣿⣿⣶⣶⣮⣥⣒⠲⢮⣝⡿⣿⣿⡆⣿⡿⠃⠄⠄⠄⠄⠄⠄⠄⣠⣴⣿⣿⣿";
      gkmsdlfhnn = lyxnvmwrgttgjrx();
      int var3 = (new Random(454226240799652523L)).nextInt();
      6Mktfpr5ue = 959815983 ^ var3;
   }

   public static String cbnglzggvx(byte[] var0, int var1) {
      String var10 = Integer.toString(var1);
      byte[] var11 = var10.getBytes();
      byte[] var8 = var11;
      byte var12 = 0;
      int var9 = var12;

      while(true) {
         int var17 = var0.length;
         if (var9 >= var17) {
            Charset var5 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var5);
            return var14;
         }

         byte var20 = var0[var9];
         int var33 = var8.length;
         int var30 = var9 % var33;
         byte var27 = var8[var30];
         int var21 = var20 ^ var27;
         byte var22 = (byte)var21;
         var0[var9] = var22;
         byte var23 = var0[var9];
         byte[] var28 = gkmsdlfhnn;
         byte[] var34 = gkmsdlfhnn;
         int var35 = var34.length;
         int var32 = var9 % var35;
         byte var29 = var28[var32];
         int var24 = var23 ^ var29;
         byte var25 = (byte)var24;
         var0[var9] = var25;
         ++var9;
      }
   }

   private static byte[] lyxnvmwrgttgjrx() {
      return new byte[]{19, 70, 65, 41, 24, 101, 38, 117, 17, 25, 82, 21, 120, 42, 11, 74, 40, 81, 127, 26, 39, 83, 121, 60, 39, 120, 104, 9, 31, 15, 12, 127, 8, 117, 15, 88, 90, 71, 90, 14, 4, 98, 66, 47, 124, 102, 94, 35, 15, 91, 91, 2, 70, 22, 12, 79, 18, 71, 41, 11, 49, 9, 61, 66, 5, 31, 117, 51, 101, 96, 104, 21, 8, 51, 80, 41, 88, 5, 68, 125, 9, 12, 100, 44, 67, 41, 4, 3, 3, 46, 41, 39, 28, 24, 89, 117, 5, 112, 62, 46, 107, 68, 46, 77, 3, 80, 94, 53, 52, 55, 117, 59, 16, 120, 108, 86, 116};
   }

   private static byte[] ukafbobzrkfoenm() {
      return new byte[]{-37, -118, 119, 126, 41, 49, 19, 41, 32, 112, 97, 68, 78, 110, 57, 22, 31, 78, 73, 68, 17, 4, 72, 118, 18, 63, 89, 83, 44, 88, 58, 55, 58, 37, 56, 27, 108, 7, 108, 22, 53, 52, 119, 113, 77, 35, 109, 101, 57, 6, 105, 86, 113, 94, 58, 35, 36, 31, 24, 88, 4, 83, 12, 17};
   }

   private static byte[] qbzzdihdtdtstgt() {
      return new byte[]{-36, -117, 113, 123, 42, 55, 21, 46, 36, 127, 99, 64, 72, 108, 57, 23, 27, 79, 74, 66, 22, 7, 73, 100, 21, 19, 91, 85, 42, 89, 61, 63, 56, 35};
   }

   private static byte[] hbsbwaznpwyocrq() {
      return new byte[]{-36, -115, 119, 58, 32, 59, 23, 35, 34, 81, 99, 126, 78, 108, 51, 21, 25, 7, 76, 83, 22, 2, 79, 120, 31, 56, 89, 27};
   }

   private static byte[] tuevegopvisgnxa() {
      return new byte[]{-36, -114, 121, 120, 41, 54, 18, 45, 36, 115, 99, 69, 64, 111, 58, 22, 28, 76, 74, 66, 22, 5, 65, 116, 22, 18, 92, 74, 42, 86, 61, 41, 48, 60, 62, 8, 110, 6, 111, 72};
   }

   private static byte[] kpdvzpjmzjrajkk() {
      return new byte[]{-34, -114, 114, 112, 42, 51, 18, 40, 41, 117, 101, 65, 64, 109, 59, 23, 30, 71, 76, 79, 20, 10, 75, 111, 19, 37, 80, 101, 40, 76, 52, 44, 56, 38, 57, 5, 105, 47, 105, 87, 54, 32, 118, 107, 68, 58, 105, 103};
   }

   private static byte[] yngexuuzyluppzl() {
      return new byte[]{-37, -113, 119, 61, 47, 34, 20, 42, 34, 78, 100, 90, 73, 120, 60, 10, 27, 17, 73, 9};
   }

   private static byte[] mknkyepdbbmmsmx() {
      return new byte[]{-36, -117, 112, 113, 44, 50, 23, 43, 40, 118, 99, 64, 73, 102, 63, 18, 25, 74, 70, 71, 22, 0, 72, 125, 19, 57, 89, 80, 38, 94, 61, 52, 57, 41, 59, 27, 107, 1, 99, 16, 53, 60, 115, 121, 72, 37, 111, 115};
   }

   private static byte[] idhmvgougwzxygz() {
      return new byte[]{-36, -118, 113, 120, 46, 58, 23, 43, 33, 114, 99, 65, 72, 111, 61, 26, 25, 74, 79, 79, 22, 6, 73, 103};
   }

   private static byte[] wamgnouvlafbztv() {
      return new byte[]{-36, -127, 116, 126, 33, 53, 16, 38, 36, 127, 99, 74, 77, 105, 50, 21, 30, 71, 74, 66, 22, 13, 76, 97, 30, 17, 94, 95, 42, 87, 61, 42, 61, 38};
   }

   private static byte[] isngerraxqehdlo() {
      return new byte[]{-36, -127, 116, 58, 33, 61, 16, 56, 36, 77, 99, 79, 77, 121, 50, 14, 30, 76};
   }

   private static byte[] ovvgivfpfvrmpnm() {
      return new byte[]{-36, -118, 116, 112, 43, 59, 20, 46, 34, 118, 99, 65, 77, 103, 56, 27, 26, 79, 76, 68, 22, 5, 76, 124, 20, 52, 90, 102, 44, 79, 61, 45, 61, 42, 60, 5, 104, 40, 105, 95, 53, 35, 119, 101, 79, 49, 108, 100};
   }

   private static byte[] bjhwlzbmggpqrvo() {
      return new byte[]{-36, -116, 117, 85, 43, 56, 20, 33, 38, 75, 99, 85, 76, 126, 56, 6, 26, 67, 72, 103, 22, 7, 77, 105, 20, 37};
   }

   private static byte[] oyawokyyjqettbg() {
      return new byte[]{-33, -119, 119, 74, 44, 8, 18, 12, 32, 101, 96, 96};
   }

   private static byte[] phbmunmabuqgnlj() {
      return new byte[]{-44, -128, 116, 66, 47, 15, 20, 118, 37, 13, 107, 25, 72, 64};
   }

   private static byte[] ibffkwvlilihegt() {
      return new byte[0];
   }

   private static byte[] xabpfmhngjrlrnp() {
      return new byte[]{-36, -127, 120, 93, 47, 48, 16, 39, 38, 12, 99, 93, 65, 112, 60, 16, 30, 6, 72, 91, 22, 75, 64, 103, 16, 36, 94, 68, 40, 26, 61, 33, 49, 47, 56, 30, 108, 16, 109, 95, 53, 116};
   }

   private static byte[] qyhckvnagwbenbs() {
      return new byte[]{-36, -117, 119, 94, 41, 61, 19, 96, 37, 75, 99, 65, 78, 120, 58, 93, 29, 20, 75, 70, 22, 8, 79, 107, 22, 59, 93, 79, 43, 28, 61, 44, 62, 58, 62, 14, 111, 27, 110, 81, 53, 49, 116, 116, 77, 61, 107, 115, 59, 70};
   }

   private static int blbquqyvjqgjhvwn(int var0, int var1) {
      return var0 ^ var1;
   }
}
