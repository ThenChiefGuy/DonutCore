package dev.daniboy.donutcore.gui.impl;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.gui.AbstractGui;
import dev.daniboy.donutcore.gui.WrappedClickEvent;
import dev.daniboy.donutcore.utils.Hex;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class HelpGUI extends AbstractGui {
   private final Map<Player, Object[]> opened;
   private final Map<Integer, String> slotHelpCommandMap;
   private final DonutCore plugin;
   private String title;
   private int size;
   private final Map<Integer, ItemStack> items;
   private static int 6lAgMf2qc9;
   private transient int eSeMJsajxU;
   private static byte[] vinpiloltu;
   private static String[] nothing_to_see_here = new String[18];

   public HelpGUI(DonutCore var1, int var2) {
      int var14 = 2097305523 ^ 1494100487;
      super(var1, 1156425752);

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var14)) {
         case 98047872:
            var14 ^= 175784720;
         case 34451631:
            var14 = 930050976 ^ 1230967791 ^ Integer.parseInt("346814195") ^ var2;
            this.eSeMJsajxU = 1307732325 ^ 6lAgMf2qc9;
            var14 ^= 992321520;
            var14 ^= 552293867;
            HashMap var9 = new HashMap();
            this.opened = var9;
            var14 ^= 1676347067;
            HashMap var10 = new HashMap();
            this.slotHelpCommandMap = var10;
            var14 ^= 293235445;
            HashMap var11 = new HashMap();
            this.items = var11;
            var14 ^= 1588592389;
            this.plugin = var1;
            var14 ^= 707058159;
            return;
         case 1844235671:
         default:
            throw new IOException();
         case 2057413859:
         }
      }
   }

   public Inventory generateInventory$919822562(Player var1, Object[] var2, int var3) {
      int var32 = 1521081032 ^ 1709442510 ^ this.eSeMJsajxU ^ var3;
      var32 ^= 1772874414;
      Object var4 = null;
      int var22 = this.size;
      String var27 = this.title;
      Inventory var10 = Bukkit.createInventory((InventoryHolder)var4, var22, var27);
      Inventory var7 = var10;
      var32 ^= 478427807;
      Map var12 = this.items;
      Set var13 = var12.entrySet();
      Iterator var14 = var13.iterator();
      Iterator var8 = var14;
      var32 ^= 54230531;

      while(true) {
         byte var16 = var8.hasNext();
         if (var16 != (1239390614 ^ var32)) {
            var32 ^= 1932886634;
            Object var18 = var8.next();
            Entry var19 = (Entry)var18;
            var32 ^= 761273389;
            Object var24 = var19.getKey();
            Integer var25 = (Integer)var24;
            int var26 = var25;
            Object var29 = var19.getValue();
            ItemStack var30 = (ItemStack)var29;
            var7.setItem(var26, var30);
            var32 ^= 1149156377;

            label45:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32)) {
               case 44726311:
                  var32 ^= 2135656209;
                  break label45;
               case 1102296488:
               default:
                  throw new IllegalAccessException();
               case 1375294561:
                  break label45;
               case 1787179757:
               }
            }
         } else {
            var32 ^= 1322338027;
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32) != 111015563) {
               var32 = wcdoexwoampjcxjs(var32, 150429935);
               throw new IllegalAccessException();
            } else {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32)) {
                  case 111015563:
                     var32 ^= 749612967;
                     return var7;
                  case 1188771874:
                     break;
                  case 1862741966:
                     return var7;
                  case 2137104230:
                  default:
                     throw new IllegalAccessException();
                  }
               }
            }
         }

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32) != 112372059) {
               throw null;
            }

            throw new IOException();
         } catch (IOException var33) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var32)) {
            case -814242608:
               var32 ^= 1742208655;
               break;
            case 1710876361:
               var32 ^= 1384527564;
               break;
            default:
               throw new IllegalAccessException("Error in hash");
            }

            var32 ^= 937857923;
         }
      }
   }

   public void click$2048279449(WrappedClickEvent var1, int var2) {
      int var24 = 1741856888 ^ 413283140 ^ this.eSeMJsajxU ^ var2;
      var24 ^= 520164229;
      int var8 = var1.getSlot$2125716982(2104088370);
      var24 ^= 325780428;
      Player var10 = var1.getPlayer$624284539(1206635844);
      var24 ^= 1082492159;
      byte var12 = this.isInGUI$652632361(var10, 901967400);
      if (var12 != (227016793 ^ var24)) {
         var24 ^= 950022202;
         Map var14 = this.slotHelpCommandMap;
         Integer var21 = var8;
         Object var15 = var14.get(var21);
         String var16 = (String)var15;
         var24 ^= 1923151517;
         if (var16 != null) {
            var24 ^= 989105887;
            var10.performCommand(var16);
            var24 ^= 800307237;
         } else {
            var24 ^= 2021145104;
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24) != 199415293) {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24)) {
                  case 199415293:
                     var24 ^= 1698567315;
                     throw new IOException();
                  case 241242493:
                  case 951481217:
                  default:
                     throw new IOException();
                  case 952602758:
                  }
               }
            }

            var24 ^= 1832848618;
         }
      } else {
         label51:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24)) {
            case 171412772:
               var24 ^= 1701338388;
               break label51;
            case 1308207262:
            default:
               throw new IOException();
            case 1489083208:
               break;
            case 1629586930:
               break label51;
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24) != 187882533) {
            var24 = wcdoexwoampjcxjs(var24, 841921840);
            throw new IOException();
         }

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24)) {
            case 187882533:
               var24 ^= 976203081;
               return;
            case 796767344:
               return;
            case 983208575:
               break;
            case 1251698662:
            default:
               throw new IOException();
            }
         }
      }

   }

   public void loadHelpConfigValues$1430792781(int var1) {
      int var128 = 1526310311 ^ 209960452 ^ this.eSeMJsajxU ^ var1;
      var128 ^= 868557781;
      DonutCore var19 = this.plugin;
      FileConfiguration var20 = var19.getHelpGuiConfig$689393799(1284949057);
      FileConfiguration var7 = var20;
      var128 ^= 1997391475;
      String var4 = rsumticnwh(gpikuwzqzkrnwer(), var128);
      String var74 = var20.getString(var4);
      String var75 = Hex.hex(var74);
      this.title = var75;
      var128 ^= 1369153824;
      String var113 = rsumticnwh(hbcfhdpfxiyaoca(), var128);
      int var77 = var20.getInt(var113);
      this.size = var77;
      var128 ^= 167161122;
      String var78 = rsumticnwh(otfieflgpucrlug(), var128);
      ConfigurationSection var24 = var20.getConfigurationSection(var78);
      var128 ^= 1804585524;
      if (var24 != null) {
         var128 ^= 88337080;
         byte var79 = (byte)(1327419570 ^ var128);
         Set var27 = var24.getKeys((boolean)var79);
         Iterator var28 = var27.iterator();
         Iterator var9 = var28;
         var128 ^= 666923899;

         label126:
         while(true) {
            byte var30 = var9.hasNext();
            if (var30 == (1759421385 ^ var128)) {
               label88:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128)) {
                  case 187643275:
                     var128 ^= 307080320;
                     break label88;
                  case 721694331:
                  default:
                     throw new IllegalAccessException();
                  case 1418181986:
                     break label88;
                  case 2058120396:
                  }
               }

               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128) != 226268942) {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128)) {
                     case 226268942:
                        var128 ^= 1820047317;
                        throw new IllegalAccessException();
                     case 336111440:
                     case 1529833789:
                     default:
                        throw new IllegalAccessException();
                     case 2121945817:
                     }
                  }
               }

               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128)) {
                  case 226268942:
                     var128 ^= 2013004797;
                     return;
                  case 326978315:
                     return;
                  case 596689099:
                     break;
                  case 1504867691:
                  default:
                     throw new IllegalAccessException();
                  }
               }
            }

            var128 ^= 270391261;
            Object var32 = var9.next();
            String var33 = (String)var32;
            var128 ^= 1548529965;
            String var35 = "help_gui.items." + var33 + ".";
            var128 ^= 1969817250;
            String var81 = var35 + "display_name";
            String var37 = var7.getString(var81);
            String var38 = Hex.hex(var37);
            var128 ^= 1581735503;
            String var83 = var35 + "material";
            String var40 = var7.getString(var83);
            Material var41 = Material.getMaterial(var40);
            var128 ^= 1515940032;
            String var85 = var35 + "lore";
            List var43 = var7.getStringList(var85);
            Stream var44 = var43.stream();
            Function var86 = Hex::hex;
            var128 ^= 817667861;
            Stream var45 = var44.map(var86);
            var128 ^= 1165700769;
            Collector var87 = Collectors.toList();
            Object var46 = var45.collect(var87);
            List var47 = (List)var46;
            var128 ^= 524232889;
            String var89 = var35 + "slot";
            int var49 = var7.getInt(var89);
            var128 ^= 476075033;
            ItemStack var50 = new ItemStack(var41);
            var128 ^= 1306445029;
            ItemMeta var52 = var50.getItemMeta();
            var128 ^= 1380090513;
            if (var52 != null) {
               var128 ^= 1687567172;
               var52.setDisplayName(var38);
               var128 ^= 1065458488;
               var52.setLore(var47);
               var128 ^= 1004250578;
               byte var92 = (byte)(1546812379 ^ var128);
               ItemFlag[] var93 = new ItemFlag[var92];
               byte var5 = (byte)(1546812378 ^ var128);
               ItemFlag var6 = ItemFlag.HIDE_ATTRIBUTES;
               var93[var5] = var6;
               var52.addItemFlags(var93);
               var128 ^= 971201863;
               byte var94 = (byte)(1708205724 ^ var128);
               ItemFlag[] var95 = new ItemFlag[var94];
               byte var117 = (byte)(1708205725 ^ var128);
               ItemFlag var122 = ItemFlag.HIDE_DESTROYS;
               var95[var117] = var122;
               var52.addItemFlags(var95);
               var128 ^= 642551953;
               byte var96 = (byte)(1134409229 ^ var128);
               ItemFlag[] var97 = new ItemFlag[var96];
               byte var118 = (byte)(1134409228 ^ var128);
               ItemFlag var123 = ItemFlag.HIDE_ENCHANTS;
               var97[var118] = var123;
               var52.addItemFlags(var97);
               var128 ^= 1499948525;
               byte var98 = (byte)(452645856 ^ var128);
               ItemFlag[] var99 = new ItemFlag[var98];
               byte var119 = (byte)(452645857 ^ var128);
               ItemFlag var124 = ItemFlag.HIDE_PLACED_ON;
               var99[var119] = var124;
               var52.addItemFlags(var99);
               var128 ^= 966791240;
               byte var100 = (byte)(593150888 ^ var128);
               ItemFlag[] var101 = new ItemFlag[var100];
               byte var120 = (byte)(593150889 ^ var128);
               ItemFlag var125 = ItemFlag.HIDE_POTION_EFFECTS;
               var101[var120] = var125;
               var52.addItemFlags(var101);
               var128 ^= 620827207;
               byte var102 = (byte)(106680815 ^ var128);
               ItemFlag[] var103 = new ItemFlag[var102];
               byte var121 = (byte)(106680814 ^ var128);
               ItemFlag var126 = ItemFlag.HIDE_UNBREAKABLE;
               var103[var121] = var126;
               var52.addItemFlags(var103);
               var128 ^= 2423999;
               var50.setItemMeta(var52);
               var128 ^= 1458891789;
            } else {
               var128 = wcdoexwoampjcxjs(var128, 1545852867);
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128) != 195893263) {
                  var128 ^= 1983189291;
                  break;
               }

               var128 ^= 810969323;
            }

            Map var65 = this.items;
            Integer var106 = var49;
            var65.put(var106, var50);
            var128 ^= 378955116;
            String var108 = var35 + "command";
            byte var68 = var7.contains(var108);
            if (var68 != (1176347696 ^ var128)) {
               var128 ^= 512962823;
               String var110 = var35 + "command";
               String var70 = var7.getString(var110);
               var128 ^= 120945393;
               Map var72 = this.slotHelpCommandMap;
               Integer var112 = var49;
               var72.put(var112, var70);
               var128 ^= 1361033808;
            } else {
               label119:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128)) {
                  case 131672064:
                     var128 ^= 2016087569;
                     break label119;
                  case 498767521:
                     break;
                  case 1340603269:
                  default:
                     throw new IllegalAccessException();
                  case 1528347600:
                     break label119;
                  }
               }

               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128) != 143251369) {
                  var128 ^= 685642429;
                  break;
               }

               var128 ^= 814940087;
            }

            var128 = wcdoexwoampjcxjs(var128, 1361040885);

            try {
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128) != 159061764) {
                  throw null;
               }

               throw new RuntimeException();
            } catch (RuntimeException var129) {
               switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var128)) {
               case -35912934:
                  var128 = wcdoexwoampjcxjs(var128, 1519756836);
                  break;
               case 2120818952:
                  var128 ^= 182649446;
                  break;
               default:
                  throw new IOException("Error in hash");
               }

               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128)) {
                  case 81479372:
                     var128 ^= 1844479374;
                  case 1088083563:
                     continue label126;
                  case 1386060981:
                     break;
                  case 1498305042:
                  default:
                     throw new IllegalAccessException();
                  }
               }
            }
         }
      } else {
         label150:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128)) {
            case 1370670:
               var128 ^= 975159247;
            case 176092502:
               break label150;
            case 233031792:
               break;
            case 589603696:
            default:
               throw new IllegalAccessException();
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128) != 159421295) {
            var128 = wcdoexwoampjcxjs(var128, 1722432857);
         } else {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128)) {
               case 159421295:
                  var128 ^= 2100136305;
                  return;
               case 642407347:
                  break;
               case 1881108461:
               default:
                  throw new IllegalAccessException();
               case 2086907737:
                  return;
               }
            }
         }
      }

      throw new IllegalAccessException();
   }

   public boolean isInGUI$652632361(Player var1, int var2) {
      int var8 = 880156404 ^ 1862684220 ^ this.eSeMJsajxU ^ var2;
      var8 ^= 1872563243;
      Map var5 = this.opened;
      boolean var6 = var5.containsKey(var1);
      return var6;
   }

   public void remove$1734529989(Player var1, int var2) {
      int var8 = 1262081177 ^ 769649924 ^ this.eSeMJsajxU ^ var2;
      var8 ^= 1608085848;
      Map var5 = this.opened;
      var5.remove(var1);
      var8 ^= 1077748054;
   }

   public void addToOpened$232106327(Player var1, Object[] var2, int var3) {
      int var10 = 1972487314 ^ 177280949 ^ this.eSeMJsajxU ^ var3;
      var10 ^= 2075538829;
      Map var7 = this.opened;
      var7.put(var1, var2);
      var10 ^= 589454584;
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣶⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⠿⠟⠛⠻⣿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣆⣀⣀⠀⣿⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠻⣿⣿⣿⠅⠛⠋⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[5] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢼⣿⣿⣿⣃⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[6] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣟⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣛⣛⣫⡄⠀⢸⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣾⡆⠸⣿⣿⣿⡷⠂⠨⣿⣿⣿⣿⣶⣦⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣾⣿⣿⣿⣿⡇⢀⣿⡿⠋⠁⢀⡶⠪⣉⢸⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⡏⢸⣿⣷⣿⣿⣷⣦⡙⣿⣿⣿⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣇⢸⣿⣿⣿⣿⣿⣷⣦⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[15] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[16] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[17] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣵⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      vinpiloltu = ffwjngpxjouqwja();
      int var3 = (new Random(2255647273756019779L)).nextInt();
      6lAgMf2qc9 = 1293093645 ^ var3;
   }

   public static String rsumticnwh(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = vinpiloltu;
         byte[] var34 = vinpiloltu;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] ffwjngpxjouqwja() {
      return new byte[]{74, 3, 96, 1, 71, 107, 93, 45, 82, 106, 37, 43, 61, 38, 97, 43, 12, 67, 20, 3, 21, 52, 80, 73, 79, 55, 23, 77, 46, 1, 82, 7, 71, 50, 78, 114, 67, 64, 24, 117, 32, 8, 80, 17, 18, 25, 61, 97, 4, 51, 122, 61, 72, 117, 37, 66, 73, 72, 45, 42, 118, 78, 39, 83, 125, 50, 42, 60, 5, 45, 103, 58, 21, 108, 56, 44, 56, 10, 106, 125, 26, 127, 34, 42, 69, 71, 44, 39, 92};
   }

   private static byte[] otfieflgpucrlug() {
      return new byte[]{-127, -54, 87, 93, 112, 60, 108, 120, 98, 47, 19, 67, 9, 118, 83, 111, 53, 26, 33, 27, 34, 105, 103, 15, 126, 107, 39, 21, 24, 69};
   }

   private static byte[] hbcfhdpfxiyaoca() {
      return new byte[]{-126, -53, 83, 93, 112, 63, 106, 118, 96, 44, 18, 71, 9, 118, 80, 105, 59, 24, 34, 26, 38, 115, 103, 17, 120, 122, 37, 30};
   }

   private static byte[] gpikuwzqzkrnwer() {
      return new byte[]{-122, -52, 84, 91, 113, 60, 104, 113, 106, 46, 23, 68, 9, 115, 87, 108, 57, 26, 44, 25, 39, 112, 100, 18, 121, 113, 34, 17, 22, 80};
   }

   private static int wcdoexwoampjcxjs(int var0, int var1) {
      return var1 ^ var0;
   }
}
