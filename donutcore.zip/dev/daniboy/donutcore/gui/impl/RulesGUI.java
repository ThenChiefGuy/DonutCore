package dev.daniboy.donutcore.gui.impl;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.gui.AbstractGui;
import dev.daniboy.donutcore.gui.WrappedClickEvent;
import dev.daniboy.donutcore.utils.Hex;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class RulesGUI extends AbstractGui {
   private final Map<Player, Object[]> opened;
   private final Map<Integer, String> slotRulesCommandMap;
   private final DonutCore plugin;
   private String title;
   private int size;
   private final Map<Integer, ItemStack> items;
   private static int ihz4GhIM0J;
   private transient int 1SGelhQcn1;
   private static byte[] qmphhugeeh;
   private static String[] nothing_to_see_here = new String[13];

   public RulesGUI(DonutCore var1, int var2) {
      int var14 = 1960061881 ^ 1905270217;
      super(var1, 1156425752);

      label30:
      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var14)) {
         case 82835021:
            var14 ^= 375767013;
         case 691907912:
            var14 = 171492497 ^ 567615754 ^ Integer.parseInt("2082587670") ^ var2;
            this.1SGelhQcn1 = 28756755 ^ ihz4GhIM0J;

            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var14)) {
               case 84994481:
                  var14 ^= 523866323;
               case 587390516:
                  break label30;
               case 759631309:
               default:
                  throw new IllegalAccessException();
               case 1878882723:
               }
            }
         case 784055444:
         default:
            throw new IllegalAccessException();
         case 1661369476:
         }
      }

      var14 ^= 240949350;
      HashMap var9 = new HashMap();
      this.opened = var9;
      var14 ^= 216110755;
      HashMap var10 = new HashMap();
      this.slotRulesCommandMap = var10;
      var14 ^= 850757053;
      HashMap var11 = new HashMap();
      this.items = var11;
      var14 ^= 1601862093;
      this.plugin = var1;
      var14 ^= 533195429;
   }

   public Inventory generateInventory$919822562(Player var1, Object[] var2, int var3) {
      int var32 = 858199806 ^ 1993225528 ^ this.1SGelhQcn1 ^ var3;
      var32 ^= 981609327;
      Object var4 = null;
      int var22 = this.size;
      String var27 = this.title;
      Inventory var10 = Bukkit.createInventory((InventoryHolder)var4, var22, var27);
      Inventory var7 = var10;
      var32 ^= 1101779546;
      Map var12 = this.items;
      Set var13 = var12.entrySet();
      Iterator var14 = var13.iterator();
      Iterator var8 = var14;
      var32 ^= 1446429135;

      while(true) {
         byte var16 = var8.hasNext();
         if (var16 == (2069545832 ^ var32)) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32)) {
               case 251634115:
                  var32 ^= 1095318053;
               case 1145588523:
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32) == 8816918) {
                     var32 ^= 663686957;
                     return var7;
                  }

                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32)) {
                     case 8816918:
                        var32 ^= 293814337;
                        throw new IllegalAccessException();
                     case 717686188:
                     case 1459971927:
                     default:
                        throw new IllegalAccessException();
                     case 1721495940:
                     }
                  }
               case 340613723:
                  break;
               case 1519520660:
               default:
                  throw new IllegalAccessException();
               }
            }
         } else {
            var32 ^= 1051555959;
            Object var18 = var8.next();
            Entry var19 = (Entry)var18;
            var32 ^= 65161106;
            Object var24 = var19.getKey();
            Integer var25 = (Integer)var24;
            int var26 = var25;
            Object var29 = var19.getValue();
            ItemStack var30 = (ItemStack)var29;
            var7.setItem(var26, var30);
            var32 ^= 1627463852;

            label61:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32)) {
               case 196627819:
                  var32 ^= 868860719;
                  break label61;
               case 1352097197:
               default:
                  throw new IllegalAccessException();
               case 1421013557:
                  break;
               case 1712631136:
                  break label61;
               }
            }
         }

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32) != 141326582) {
               throw null;
            }

            throw new IllegalAccessException();
         } catch (IllegalAccessException var33) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var32)) {
            case -1494681488:
               var32 ^= 737520304;
               break;
            case -476259936:
               var32 ^= 593178250;
               break;
            default:
               throw new RuntimeException("Error in hash");
            }

            var32 = rseyqugetnctdjqz(var32, 1148352214);
         }
      }
   }

   public void click$2048279449(WrappedClickEvent var1, int var2) {
      int var24 = 2115887779 ^ 193463218 ^ this.1SGelhQcn1 ^ var2;
      var24 ^= 345777373;
      int var8 = var1.getSlot$2125716982(2104088370);
      var24 ^= 1635827610;
      Player var10 = var1.getPlayer$624284539(1206635844);
      var24 ^= 1669754461;
      byte var12 = this.isInGUI$652632361(var10, 901967400);
      if (var12 == (1311908654 ^ var24)) {
         var24 = rseyqugetnctdjqz(var24, 886547424);
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24) == 236770154) {
            var24 = rseyqugetnctdjqz(var24, 586468384);
            return;
         }

         var24 ^= 657547618;
      } else {
         var24 ^= 1660178497;
         Map var14 = this.slotRulesCommandMap;
         Integer var21 = var8;
         Object var15 = var14.get(var21);
         String var16 = (String)var15;
         var24 ^= 724508346;
         if (var16 != null) {
            var24 ^= 933549677;
            var10.performCommand(var16);
            var24 ^= 1750923094;
            return;
         }

         label44:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24)) {
            case 111698063:
            default:
               throw new RuntimeException();
            case 124440862:
               var24 ^= 1798728737;
            case 202593607:
               break label44;
            case 567037721:
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24) != 49315607) {
            var24 = rseyqugetnctdjqz(var24, 822861912);
         } else {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24)) {
               case 49315607:
                  var24 ^= 885935386;
                  return;
               case 942093420:
                  return;
               case 1332706165:
               default:
                  throw new RuntimeException();
               case 1568990944:
               }
            }
         }
      }

      throw new RuntimeException();
   }

   public void loadRulesConfigValues$113812495(int var1) {
      int var128 = 1921016656 ^ 956217833 ^ this.1SGelhQcn1 ^ var1;
      var128 ^= 1417844670;
      DonutCore var19 = this.plugin;
      FileConfiguration var20 = var19.getRulesGuiConfig$546180320(482433505);
      FileConfiguration var7 = var20;
      var128 ^= 103204224;
      String var4 = zkdbypvnci(jtoneooecgdcygw(), var128);
      String var74 = var20.getString(var4);
      String var75 = Hex.hex(var74);
      this.title = var75;
      var128 ^= 569832606;
      String var113 = zkdbypvnci(stickxxmddzvthu(), var128);
      int var77 = var20.getInt(var113);
      this.size = var77;
      var128 ^= 1307623413;
      String var78 = zkdbypvnci(qrkeabyodrcjflb(), var128);
      ConfigurationSection var24 = var20.getConfigurationSection(var78);
      var128 ^= 639766202;
      if (var24 == null) {
         label79:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128)) {
            case 74333955:
               var128 ^= 1075458575;
               break label79;
            case 89463183:
            default:
               throw new IOException();
            case 2007555744:
               break;
            case 2012814550:
               break label79;
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128) != 83743599) {
            var128 ^= 217031552;
            throw new IOException();
         }

         var128 = rseyqugetnctdjqz(var128, 446381960);
      } else {
         var128 ^= 1631536141;
         byte var79 = (byte)(1703320898 ^ var128);
         Set var27 = var24.getKeys((boolean)var79);
         Iterator var28 = var27.iterator();
         Iterator var9 = var28;
         var128 ^= 1866975416;

         while(true) {
            byte var30 = var9.hasNext();
            if (var30 == (180442618 ^ var128)) {
               var128 = rseyqugetnctdjqz(var128, 1444576716);
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128) != 65585459) {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128)) {
                     case 65585459:
                        var128 ^= 345465078;
                        throw new IOException();
                     case 208605674:
                     case 1976418346:
                     default:
                        throw new IOException();
                     case 927077766:
                     }
                  }
               }

               var128 ^= 48495870;
               break;
            }

            var128 ^= 1307396068;
            Object var32 = var9.next();
            String var33 = (String)var32;
            var128 ^= 1700894052;
            String var35 = "rules_gui.items." + var33 + ".";
            var128 ^= 1291767688;
            String var81 = var35 + "display_name";
            String var37 = var7.getString(var81);
            String var38 = Hex.hex(var37);
            var128 ^= 439217147;
            String var83 = var35 + "material";
            String var40 = var7.getString(var83);
            Material var41 = Material.getMaterial(var40);
            var128 ^= 912280988;
            String var85 = var35 + "lore";
            List var43 = var7.getStringList(var85);
            Stream var44 = var43.stream();
            Function var86 = Hex::hex;
            Stream var45 = var44.map(var86);
            Collector var87 = Collectors.toList();
            Object var46 = var45.collect(var87);
            List var47 = (List)var46;
            var128 ^= 1479025020;
            String var89 = var35 + "slot";
            int var49 = var7.getInt(var89);
            var128 ^= 1945621943;
            ItemStack var50 = new ItemStack(var41);
            var128 ^= 593911116;
            ItemMeta var52 = var50.getItemMeta();
            var128 ^= 1565371700;
            if (var52 != null) {
               var128 ^= 201181760;
               var52.setDisplayName(var38);
               var128 ^= 857982391;
               var52.setLore(var47);
               var128 ^= 109951625;
               byte var92 = (byte)(693722969 ^ var128);
               ItemFlag[] var93 = new ItemFlag[var92];
               byte var5 = (byte)(693722968 ^ var128);
               ItemFlag var6 = ItemFlag.HIDE_ATTRIBUTES;
               var93[var5] = var6;
               var52.addItemFlags(var93);
               var128 ^= 2091887920;
               byte var94 = (byte)(1442247273 ^ var128);
               ItemFlag[] var95 = new ItemFlag[var94];
               byte var117 = (byte)(1442247272 ^ var128);
               ItemFlag var122 = ItemFlag.HIDE_DESTROYS;
               var95[var117] = var122;
               var52.addItemFlags(var95);
               var128 ^= 1690848220;
               byte var96 = (byte)(826194357 ^ var128);
               ItemFlag[] var97 = new ItemFlag[var96];
               byte var118 = (byte)(826194356 ^ var128);
               ItemFlag var123 = ItemFlag.HIDE_ENCHANTS;
               var97[var118] = var123;
               var52.addItemFlags(var97);
               var128 ^= 1531042619;
               byte var98 = (byte)(1786733198 ^ var128);
               ItemFlag[] var99 = new ItemFlag[var98];
               byte var119 = (byte)(1786733199 ^ var128);
               ItemFlag var124 = ItemFlag.HIDE_PLACED_ON;
               var99[var119] = var124;
               var52.addItemFlags(var99);
               var128 ^= 575943392;
               byte var100 = (byte)(1210798190 ^ var128);
               ItemFlag[] var101 = new ItemFlag[var100];
               byte var120 = (byte)(1210798191 ^ var128);
               ItemFlag var125 = ItemFlag.HIDE_POTION_EFFECTS;
               var101[var120] = var125;
               var52.addItemFlags(var101);
               var128 ^= 1351053974;
               byte var102 = (byte)(413934328 ^ var128);
               ItemFlag[] var103 = new ItemFlag[var102];
               byte var121 = (byte)(413934329 ^ var128);
               ItemFlag var126 = ItemFlag.HIDE_UNBREAKABLE;
               var103[var121] = var126;
               var52.addItemFlags(var103);
               var128 ^= 2127759156;
               var50.setItemMeta(var52);
               var128 ^= 1541640274;
            } else {
               label101:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128)) {
                  case 212152995:
                     var128 ^= 434007239;
                     break label101;
                  case 546563676:
                  default:
                     throw new IOException();
                  case 865553196:
                     break;
                  case 1989319768:
                     break label101;
                  }
               }

               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128) != 213633927) {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128)) {
                     case 213633927:
                        var128 ^= 1184419361;
                        throw new IOException();
                     case 1196412215:
                     case 1422285500:
                     default:
                        throw new IOException();
                     case 1747511002:
                     }
                  }
               }

               var128 = rseyqugetnctdjqz(var128, 860369790);
            }

            Map var65 = this.items;
            Integer var106 = var49;
            var65.put(var106, var50);
            var128 ^= 399794513;
            String var108 = var35 + "command";
            byte var68 = var7.contains(var108);
            if (var68 != (709416142 ^ var128)) {
               var128 ^= 261577226;
               String var110 = var35 + "command";
               String var70 = var7.getString(var110);
               var128 ^= 1414272568;
               Map var72 = this.slotRulesCommandMap;
               Integer var112 = var49;
               var72.put(var112, var70);
               var128 ^= 31683140;
            } else {
               var128 ^= 562464511;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128) != 115324144) {
                  var128 ^= 1132600049;
                  throw new IOException();
               }

               var128 = rseyqugetnctdjqz(var128, 2076096649);
            }

            label89:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128)) {
               case 69925238:
                  break;
               case 165328564:
                  var128 ^= 56151504;
                  break label89;
               case 389029851:
               default:
                  throw new IOException();
               case 405025874:
                  break label89;
               }
            }

            try {
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var128) != 253607793) {
                  throw null;
               }

               throw new IOException();
            } catch (IOException var129) {
               switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var128)) {
               case -1723778237:
                  var128 = rseyqugetnctdjqz(var128, 222804064);
                  break;
               case -392188390:
                  var128 ^= 595356363;
                  break;
               default:
                  throw new IllegalAccessException("Error in hash");
               }

               var128 ^= 1957612274;
            }
         }
      }

   }

   public boolean isInGUI$652632361(Player var1, int var2) {
      int var8 = 1544483706 ^ 2083290826 ^ this.1SGelhQcn1 ^ var2;
      var8 ^= 1838385403;
      Map var5 = this.opened;
      boolean var6 = var5.containsKey(var1);
      return var6;
   }

   public void remove$1734529989(Player var1, int var2) {
      int var8 = 1635917921 ^ 1056300530 ^ this.1SGelhQcn1 ^ var2;
      var8 ^= 1962823087;
      Map var5 = this.opened;
      var5.remove(var1);
      var8 ^= 199768421;
   }

   public void addToOpened$232106327(Player var1, Object[] var2, int var3) {
      int var10 = 522047372 ^ 431695683 ^ this.1SGelhQcn1 ^ var3;
      var10 ^= 739438797;
      Map var7 = this.opened;
      var7.put(var1, var2);
      var10 ^= 457940702;
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⣠⣶⡾⠏⠉⠙⠳⢦⡀⠀⠀⠀⢠⠞⠉⠙⠲⡀⠀    ";
      nothing_to_see_here[2] = "⠀⠀⠀⣴⠿⠏⠀⠀⠀⠀⠀⠀⢳⡀⠀⡏⠀⠀⠀⠀⠀⢷     ";
      nothing_to_see_here[3] = "⠀⠀⢠⣟⣋⡀⢀⣀⣀⡀⠀⣀⡀⣧⠀⢸⠀⠀⠀⠀⠀ ⡇    ";
      nothing_to_see_here[4] = "⠀⠀⢸⣯⡭⠁⠸⣛⣟⠆⡴⣻⡲⣿⠀⣸⠀⠀OK⠀ ⡇    ";
      nothing_to_see_here[5] = "⠀⠀⣟⣿⡭⠀⠀⠀⠀⠀⢱⠀⠀⣿⠀⢹⠀⠀⠀⠀⠀ ⡇    ";
      nothing_to_see_here[6] = "⠀⠀⠙⢿⣯⠄⠀⠀⠀⢀⡀⠀⠀⡿⠀⠀⡇⠀⠀⠀⠀⡼     ";
      nothing_to_see_here[7] = "⠀⠀⠀⠀⠹⣶⠆⠀⠀⠀⠀⠀⡴⠃⠀⠀⠘⠤⣄⣠⠞⠀     ";
      nothing_to_see_here[8] = "⠀⠀⠀⠀⠀⢸⣷⡦⢤⡤⢤⣞⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[9] = "⠀⠀⢀⣤⣴⣿⣏⠁⠀⠀⠸⣏⢯⣷⣖⣦⡀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[10] = "⢀⣾⣽⣿⣿⣿⣿⠛⢲⣶⣾⢉⡷⣿⣿⠵⣿⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[11] = "⣼⣿⠍⠉⣿⡭⠉⠙⢺⣇⣼⡏⠀⠀⠀⣄⢸⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[12] = "⣿⣿⣧⣀⣿.........⣀⣰⣏⣘⣆⣀⠀⠀       ";
      qmphhugeeh = sylqbmvzlwxyqpy();
      int var3 = (new Random(8039635429122645555L)).nextInt();
      ihz4GhIM0J = 1577698736 ^ var3;
   }

   public static String zkdbypvnci(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = qmphhugeeh;
         byte[] var34 = qmphhugeeh;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] sylqbmvzlwxyqpy() {
      return new byte[]{66, 111, 75, 6, 14, 72, 62, 11, 95, 43, 88, 8, 118, 53, 9, 20, 16, 100, 122, 21, 18, 48, 51, 27, 88, 71, 87, 43, 35, 109, 77, 12, 2, 45, 44, 94, 76, 28, 63, 92, 30, 85, 55, 71, 3, 123, 61, 47};
   }

   private static byte[] jtoneooecgdcygw() {
      return new byte[]{-115, -93, 122, 76, 55, 8, 12, 87, 102, 122, 105, 72, 71, 82, 48, 70, 34, 33, 67, 72, 35, 45, 2, 87, 97, 27, 101, 111, 26, 53, 124, 90};
   }

   private static byte[] stickxxmddzvthu() {
      return new byte[]{-115, -88, 125, 77, 61, 13, 7, 94, 106, 124, 105, 67, 64, 83, 58, 67, 41, 40, 79, 78, 35, 38, 5, 81, 107, 30, 110, 104, 22, 58};
   }

   private static byte[] qrkeabyodrcjflb() {
      return new byte[]{-119, -88, 123, 66, 61, 5, 9, 87, 102, 123, 96, 75, 64, 89, 49, 68, 32, 40, 79, 68, 34, 40, 0, 74, 111, 3, 110, 123, 27, 48, 123, 76};
   }

   private static int rseyqugetnctdjqz(int var0, int var1) {
      return var1 ^ var0;
   }
}
