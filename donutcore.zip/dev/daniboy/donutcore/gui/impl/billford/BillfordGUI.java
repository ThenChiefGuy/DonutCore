package dev.daniboy.donutcore.gui.impl.billford;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.billford.items.CritMultiplier;
import dev.daniboy.donutcore.billford.items.StrengthRod;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.config.SoundConfig;
import dev.daniboy.donutcore.config.wrapper.SoundWrapper;
import dev.daniboy.donutcore.database.SQLiteManager;
import dev.daniboy.donutcore.gui.AbstractGui;
import dev.daniboy.donutcore.gui.WrappedClickEvent;
import dev.daniboy.donutcore.utils.Hex;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.IntConsumer;
import java.util.function.IntPredicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;

public class BillfordGUI extends AbstractGui {
   private final Map<Player, Object[]> opened;
   private final SQLiteManager sqLiteManager;
   private final String anvilDisplayName;
   private final DonutCore plugin;
   private final FileConfiguration billfordGuiConfig;
   private static int teQksBq9uU;
   private transient int btIRYCzsco;
   private static byte[] yauzbgmfnf;
   private static String[] nothing_to_see_here = new String[15];

   public BillfordGUI(DonutCore var1, SQLiteManager var2, int var3) {
      int var22 = 1610113890 ^ 1596477988;
      super(var1, 1156425752);
      var22 ^= 764847442;
      var22 = 1589485130 ^ 110963726 ^ Integer.parseInt("256402438") ^ var3;
      this.btIRYCzsco = 32407622 ^ teQksBq9uU;
      var22 = bynukygzdcwuqufw(var22, 916206225);
      var22 ^= 1617450902;
      HashMap var11 = new HashMap();
      this.opened = var11;
      var22 ^= 1621437490;
      this.plugin = var1;
      var22 ^= 1143040233;
      this.sqLiteManager = var2;
      var22 ^= 533226419;
      FileConfiguration var15 = var1.getBillfordGuiConfig$756205206(1840850862);
      this.billfordGuiConfig = var15;
      var22 ^= 979590964;
      FileConfiguration var17 = this.billfordGuiConfig;
      String var20 = "billford_gui.anvil.display_name";
      String var18 = var17.getString(var20);
      String var19 = Hex.hex(var18);
      this.anvilDisplayName = var19;
      var22 ^= 850729597;
   }

   public Inventory generateInventory$919822562(Player var1, Object[] var2, int var3) {
      int var47 = 1482396365 ^ 1203931425 ^ this.btIRYCzsco ^ var3;
      var47 ^= 301131754;
      FileConfiguration var11 = this.billfordGuiConfig;
      String var5 = jrfprvwezs(kqhbctgmyhicqto(), var47);
      String var12 = var11.getString(var5);
      String var13 = Hex.hex(var12);
      var47 ^= 976986483;
      Object var14 = null;
      byte var29 = (byte)(384841998 ^ var47);
      Inventory var15 = Bukkit.createInventory((InventoryHolder)var14, var29, var13);
      var47 ^= 474636695;
      SQLiteManager var17 = this.sqLiteManager;
      Map var18 = var17.getAllBillfordItems$1462928060(1379584926);
      var47 ^= 1717592296;
      if (var18 != null) {
         var47 ^= 1259047351;
         byte var21 = var18.isEmpty();
         if (var21 == (668054000 ^ var47)) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var47)) {
               case 220622608:
                  var47 ^= 12667856;
               case 1811309633:
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var47) == 196133774) {
                     var47 ^= 815254999;
                     Collection var36 = var18.values();
                     byte var7 = (byte)(394737655 ^ var47);
                     ItemStack[] var45 = new ItemStack[var7];
                     Object[] var37 = var36.toArray(var45);
                     ItemStack[] var38 = (ItemStack[])var37;
                     this.populateSavedItems$2133869943(var15, var38, 1851252250);
                     var47 ^= 1641174480;
                     ItemStack var40 = this.createFillItem$419675493(889953558);
                     this.fillEmptySlots$1205928634(var15, var40, 1232501387);
                     var47 ^= 881028702;
                     byte var33 = (byte)(1121324142 ^ var47);
                     ItemStack var42 = this.createTradeButton$1802623419(2034338071);
                     var15.setItem(var33, var42);
                     var47 ^= 1420922844;
                     byte var34 = (byte)(375882684 ^ var47);
                     ItemStack var44 = this.createTradeChoiceItem$1296355453(1548095980);
                     var15.setItem(var34, var44);
                     var47 ^= 473509190;
                     return var15;
                  }

                  var47 = bynukygzdcwuqufw(var47, 1890974443);
                  throw new IOException();
               case 537817874:
                  break;
               case 1070547196:
               default:
                  throw new IOException();
               }
            }
         }

         var47 ^= 1254937395;
      } else {
         label50:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var47)) {
            case 48669139:
               var47 ^= 2082517369;
            case 758979947:
               break label50;
            case 1193846316:
            default:
               throw new IOException();
            case 1207952416:
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var47) != 15038738) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var47)) {
               case 15038738:
                  var47 ^= 1197443573;
                  throw new IOException();
               case 60687199:
               case 1693983661:
               default:
                  throw new IOException();
               case 1717466116:
               }
            }
         }

         var47 = bynukygzdcwuqufw(var47, 2112351229);
      }

      MessagesConfig var22 = MessagesConfig.NOBILLFORDITEMS;
      var22.send(var1);
      var47 ^= 1579409614;
      Object var23 = null;
      return (Inventory)var23;
   }

   private void populateSavedItems$2133869943(Inventory var1, ItemStack[] var2, int var3) {
      int var57 = 27515110 ^ 2014441755 ^ this.btIRYCzsco ^ var3;
      var57 ^= 1959916236;
      byte var4 = (byte)(403834282 ^ var57);
      int[] var12 = new int[var4];
      byte var5 = (byte)(403834275 ^ var57);
      byte var6 = (byte)(403834281 ^ var57);
      var12[var5] = var6;
      byte var38 = (byte)(403834274 ^ var57);
      byte var48 = (byte)(403834280 ^ var57);
      var12[var38] = var48;
      byte var39 = (byte)(403834273 ^ var57);
      byte var49 = (byte)(403834287 ^ var57);
      var12[var39] = var49;
      byte var40 = (byte)(403834272 ^ var57);
      byte var50 = (byte)(403834288 ^ var57);
      var12[var40] = var50;
      byte var41 = (byte)(403834279 ^ var57);
      byte var51 = (byte)(403834295 ^ var57);
      var12[var41] = var51;
      byte var42 = (byte)(403834278 ^ var57);
      byte var52 = (byte)(403834294 ^ var57);
      var12[var42] = var52;
      byte var43 = (byte)(403834277 ^ var57);
      byte var53 = (byte)(403834303 ^ var57);
      var12[var43] = var53;
      byte var44 = (byte)(403834276 ^ var57);
      byte var54 = (byte)(403834302 ^ var57);
      var12[var44] = var54;
      byte var45 = (byte)(403834283 ^ var57);
      byte var55 = (byte)(403834301 ^ var57);
      var12[var45] = var55;
      int[] var7 = var12;
      var57 ^= 961446273;
      byte var13 = (byte)(559711266 ^ var57);
      int var8 = var13;
      var57 ^= 1448798113;

      while(true) {
         int var30 = var7.length;
         if (var8 < var30) {
            var57 ^= 869991533;
            int var32 = var2.length;
            if (var8 >= var32) {
               var57 ^= 1127185140;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57) != 124976314) {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57)) {
                     case 93584978:
                     case 901591917:
                     default:
                        throw new IOException();
                     case 124976314:
                        var57 ^= 407088316;
                        throw new IOException();
                     case 1927338613:
                     }
                  }
               }

               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57)) {
                  case 88594010:
                  default:
                     throw new IOException();
                  case 124976314:
                     var57 ^= 2019650855;
                     return;
                  case 423223661:
                     return;
                  case 1213576037:
                  }
               }
            }

            var57 ^= 324141359;
            ItemStack var17 = var2[var8];
            ItemStack var18 = var17.clone();
            var57 ^= 722213019;
            ItemMeta var20 = var18.getItemMeta();
            var57 ^= 53246255;
            if (var20 != null) {
               var57 ^= 599518923;
               List var23 = var20.getLore();
               var57 ^= 1632536674;
               if (var23 != null) {
                  var57 ^= 1707953614;
                  var20.setLore(var23);
                  var57 ^= 1859650047;
               } else {
                  label84:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57)) {
                     case 115286208:
                        var57 ^= 646632407;
                        break label84;
                     case 384432667:
                     default:
                        throw new IOException();
                     case 476252871:
                        break label84;
                     case 1376755468:
                     }
                  }

                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57) != 98845477) {
                     var57 ^= 73466797;
                     break;
                  }

                  var57 ^= 765435878;
               }

               boolean var27 = var18.setItemMeta(var20);
               var57 ^= 389374865;
            } else {
               var57 = bynukygzdcwuqufw(var57, 112601119);
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57) != 178303684) {
                  var57 = bynukygzdcwuqufw(var57, 1722326732);
                  break;
               }

               label72:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57)) {
                  case 98621625:
                  default:
                     throw new IOException();
                  case 178303684:
                     var57 ^= 1482907926;
                     break label72;
                  case 543349030:
                     break;
                  case 1047316400:
                     break label72;
                  }
               }
            }

            int var37 = var7[var8];
            var1.setItem(var37, var18);
            var57 ^= 225271510;
            var8 += 739709099 ^ var57;
            var57 ^= 1308103713;

            try {
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57) != 230652194) {
                  throw null;
               }

               throw new IOException();
            } catch (IOException var58) {
               switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var57)) {
               case -1027692248:
                  var57 ^= 1911140677;
                  break;
               case 259531867:
                  var57 = bynukygzdcwuqufw(var57, 139550955);
                  break;
               default:
                  throw new RuntimeException("Error in hash");
               }

               var57 ^= 515377123;
            }
         } else {
            var57 = bynukygzdcwuqufw(var57, 1914457622);
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var57) != 80252833) {
               var57 ^= 447454259;
               break;
            }

            var57 = bynukygzdcwuqufw(var57, 2055822760);
            return;
         }
      }

      throw new IOException();
   }

   private ItemStack createFillItem$419675493(int var1) {
      int var31 = 1038093939 ^ 247201363 ^ this.btIRYCzsco ^ var1;
      var31 ^= 1398106456;
      FileConfiguration var9 = this.billfordGuiConfig;
      String var3 = jrfprvwezs(caktjqkdwbhquox(), var31);
      String var10 = var9.getString(var3);
      Material var11 = Material.getMaterial(var10);
      var31 ^= 822875437;
      FileConfiguration var13 = this.billfordGuiConfig;
      String var25 = jrfprvwezs(gschxkxebhpjugu(), var31);
      String var14 = var13.getString(var25);
      String var15 = Hex.hex(var14);
      var31 ^= 486042301;
      FileConfiguration var17 = this.billfordGuiConfig;
      String var26 = jrfprvwezs(uytnckohxjsowui(), var31);
      List var18 = var17.getStringList(var26);
      Stream var19 = var18.stream();
      Function var27 = Hex::hex;
      Stream var20 = var19.map(var27);
      Collector var28 = Collectors.toList();
      Object var21 = var20.collect(var28);
      List var22 = (List)var21;
      var31 ^= 1098271694;
      ItemStack var24 = this.createItem$1585078124(var11, var15, var22, 940461645);
      return var24;
   }

   private void fillEmptySlots$1205928634(Inventory var1, ItemStack var2, int var3) {
      int var34 = 561740614 ^ 348741715 ^ this.btIRYCzsco ^ var3;
      var34 ^= 1533130012;
      byte var4 = (byte)(1552143363 ^ var34);
      int[] var8 = new int[var4];
      byte var5 = (byte)(1552143370 ^ var34);
      byte var6 = (byte)(1552143360 ^ var34);
      var8[var5] = var6;
      byte var15 = (byte)(1552143371 ^ var34);
      byte var24 = (byte)(1552143361 ^ var34);
      var8[var15] = var24;
      byte var16 = (byte)(1552143368 ^ var34);
      byte var25 = (byte)(1552143366 ^ var34);
      var8[var16] = var25;
      byte var17 = (byte)(1552143369 ^ var34);
      byte var26 = (byte)(1552143385 ^ var34);
      var8[var17] = var26;
      byte var18 = (byte)(1552143374 ^ var34);
      byte var27 = (byte)(1552143390 ^ var34);
      var8[var18] = var27;
      byte var19 = (byte)(1552143375 ^ var34);
      byte var28 = (byte)(1552143391 ^ var34);
      var8[var19] = var28;
      byte var20 = (byte)(1552143372 ^ var34);
      byte var29 = (byte)(1552143382 ^ var34);
      var8[var20] = var29;
      byte var21 = (byte)(1552143373 ^ var34);
      byte var30 = (byte)(1552143383 ^ var34);
      var8[var21] = var30;
      byte var22 = (byte)(1552143362 ^ var34);
      byte var31 = (byte)(1552143380 ^ var34);
      var8[var22] = var31;
      var34 ^= 1847825220;
      byte var9 = (byte)(849364814 ^ var34);
      int var12 = var1.getSize();
      IntStream var10 = IntStream.range(var9, var12);
      IntConsumer var14 = (var3x) -> {
         int var14 = 2031902835 ^ 2070675272 ^ teQksBq9uU;
         var14 ^= 1319158928;
         IntStream var7 = Arrays.stream(var8);
         IntPredicate var10 = (var1x) -> {
            int var7 = 1262081743 ^ 727964739 ^ teQksBq9uU;
            var7 ^= 1500349141;
            byte var4;
            if (var1x != var3x) {
               var7 ^= 1868549859;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var7) == 108506144) {
                  var7 ^= 1343093278;
                  var4 = (byte)(2091727978 ^ var7);
                  var7 ^= 540442259;
                  return (boolean)var4;
               } else {
                  var7 ^= 860220646;
                  throw new RuntimeException();
               }
            } else {
               var7 ^= 2039112245;
               var4 = (byte)(980773539 ^ var7);

               label45:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var7)) {
                  case 21185772:
                     var7 ^= 1733565015;
                     break label45;
                  case 1149828257:
                     break;
                  case 1364545106:
                  default:
                     throw new RuntimeException();
                  case 2059843887:
                     break label45;
                  }
               }

               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var7) != 74487803) {
                     throw null;
                  }

                  throw new IOException();
               } catch (IOException var8) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var7)) {
                  case -385120342:
                     var7 = bynukygzdcwuqufw(var7, 979451685);
                     break;
                  case 266364763:
                     var7 = bynukygzdcwuqufw(var7, 113001275);
                     break;
                  default:
                     throw new IllegalAccessException("Error in hash");
                  }
               }

               var7 = bynukygzdcwuqufw(var7, 1004211497);
               return (boolean)var4;
            }
         };
         byte var8x = var7.noneMatch(var10);
         if (var8x != (908057445 ^ var14)) {
            var14 ^= 1370302254;
            var1.setItem(var3x, var2);
            var14 ^= 2001768007;
         } else {
            var14 ^= 1695573708;
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var14) != 15608952) {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var14)) {
                  case 15608952:
                     var14 ^= 695767976;
                     throw new RuntimeException();
                  case 221681189:
                     break;
                  case 530869651:
                  case 1713993570:
                  default:
                     throw new RuntimeException();
                  }
               }
            } else {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var14)) {
                  case 15608952:
                     var14 ^= 1139658661;
                     return;
                  case 1134278244:
                  default:
                     throw new RuntimeException();
                  case 1283080083:
                     break;
                  case 1364180598:
                     return;
                  }
               }
            }
         }
      };
      var10.forEach(var14);
      var34 ^= 2011351072;
   }

   private ItemStack createTradeButton$1802623419(int var1) {
      int var20 = 1509934082 ^ 2058506948 ^ this.btIRYCzsco ^ var1;
      var20 ^= 1574935138;
      FileConfiguration var7 = this.billfordGuiConfig;
      String var3 = jrfprvwezs(qdqljusprapszdk(), var20);
      List var8 = var7.getStringList(var3);
      Stream var9 = var8.stream();
      Function var15 = Hex::hex;
      Stream var10 = var9.map(var15);
      Collector var16 = Collectors.toList();
      Object var11 = var10.collect(var16);
      List var12 = (List)var11;
      var20 ^= 946070783;
      Material var17 = Material.ANVIL;
      String var18 = this.anvilDisplayName;
      ItemStack var14 = this.createItem$1585078124(var17, var18, var12, 940461645);
      return var14;
   }

   private ItemStack createTradeChoiceItem$1296355453(int var1) {
      int var34 = 1859509495 ^ 1838784740 ^ this.btIRYCzsco ^ var1;
      var34 ^= 1952190716;
      FileConfiguration var8 = this.billfordGuiConfig;
      String var3 = jrfprvwezs(kcsccavmyqyjyqr(), var34);
      String var9 = var8.getString(var3);
      var34 ^= 509030295;
      if (var9 == null) {
         var34 ^= 1901306248;
         Object var11 = null;
         return (ItemStack)var11;
      } else {
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34)) {
            case 124543281:
               var34 ^= 62226332;
            case 275684543:
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34) != 105608634) {
                  var34 ^= 1558530581;
                  throw new IOException();
               }

               int var36;
               byte var7;
               var34 = bynukygzdcwuqufw(var34, 1383353060);
               String var13 = var9.toLowerCase();
               byte var14 = (byte)(-535193445 ^ var34);
               var7 = var14;
               int var16 = var13.hashCode();
               var36 = var16 ^ var34;
               label145:
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36)) {
               case 90986899:
                  var34 = bynukygzdcwuqufw(var34, 997183212);
                  String var29 = jrfprvwezs(xvzjojliqwawxox(), var34);
                  byte var25 = var13.equals(var29);
                  if (var25 != (613001608 ^ var34)) {
                     var34 ^= 1325054118;
                     byte var26 = (byte)(1785925935 ^ var34);
                     var7 = var26;
                     var34 ^= 2075863937;
                  } else {
                     label131:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34)) {
                        case 52601397:
                           break;
                        case 113941758:
                           var34 ^= 392783434;
                        case 822064833:
                           break label131;
                        case 1183157898:
                        default:
                           throw new IOException();
                        }
                     }

                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34) != 75735399) {
                        var34 ^= 580364375;
                        throw new IOException();
                     }

                     var34 ^= 573109613;
                  }
                  break;
               case 257692586:
                  var34 ^= 51784713;
                  String var27 = jrfprvwezs(zzblahrdofaruiw(), var34);
                  byte var18 = var13.equals(var27);
                  if (var18 != (485509997 ^ var34)) {
                     var34 ^= 367926114;
                     byte var19 = (byte)(152981519 ^ var34);
                     var7 = var19;
                     var34 = bynukygzdcwuqufw(var34, 533154703);

                     try {
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34) != 205829009) {
                           throw null;
                        }

                        throw new IOException();
                     } catch (IOException var39) {
                        switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var34)) {
                        case -1228350464:
                           var34 = bynukygzdcwuqufw(var34, 645832680);
                           break;
                        case 1299135899:
                           var34 ^= 1493853147;
                           break;
                        default:
                           throw new IOException("Error in hash");
                        }
                     }

                     var34 ^= 560971463;
                     break;
                  } else {
                     var34 ^= 1748033822;
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34) != 37043966) {
                        var34 = bynukygzdcwuqufw(var34, 1706544614);
                        throw new IOException();
                     }

                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34)) {
                        case 37043966:
                           var34 ^= 1695060188;
                           break label145;
                        case 140203821:
                        default:
                           throw new IOException();
                        case 287317836:
                           break;
                        case 570864345:
                           break label145;
                        }
                     }
                  }
               default:
                  var34 = bynukygzdcwuqufw(var34, 237919691);
               }

               var36 = var7 ^ var34;
               Object var21;
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36)) {
               case 41148537:
                  label120:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34)) {
                     case 41148539:
                        var34 ^= 2147133493;
                        break label120;
                     case 49718376:
                     default:
                        throw new IOException();
                     case 327176441:
                        break label120;
                     case 1643010196:
                     }
                  }

                  DonutCore var30 = this.plugin;
                  var21 = new CritMultiplier(var30, 1399757288);

                  label109:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34)) {
                     case 92377656:
                        var34 ^= 536785182;
                     case 317719828:
                        break label109;
                     case 477123890:
                     default:
                        throw new IOException();
                     case 1904723512:
                     }
                  }

                  try {
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34) != 209450243) {
                        throw null;
                     }

                     throw new IllegalAccessException();
                  } catch (IllegalAccessException var38) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var34)) {
                     case -1906238429:
                        var34 ^= 1551553984;
                        break;
                     case -1650054552:
                        var34 ^= 1040331529;
                        break;
                     default:
                        throw new IllegalAccessException("Error in hash");
                     }

                     var34 = bynukygzdcwuqufw(var34, 537394177);
                     return (ItemStack)var21;
                  }
               case 41148539:
                  var34 = bynukygzdcwuqufw(var34, 423180706);
                  DonutCore var32 = this.plugin;
                  var21 = new StrengthRod(var32, 1546977824);
                  var34 = bynukygzdcwuqufw(var34, 1430348151);

                  try {
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var34) != 92660604) {
                        throw null;
                     }

                     throw new IllegalAccessException();
                  } catch (IllegalAccessException var37) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var34)) {
                     case -310176814:
                        var34 = bynukygzdcwuqufw(var34, 1350387236);
                        break;
                     case 156392874:
                        var34 ^= 1290235883;
                        break;
                     default:
                        throw new IllegalAccessException("Error in hash");
                     }
                  }

                  var34 = bynukygzdcwuqufw(var34, 8138267);
                  return (ItemStack)var21;
               default:
                  var34 ^= 991448975;
                  FileConfiguration var23 = this.billfordGuiConfig;
                  String var28 = jrfprvwezs(fqnzoshfhqeopmq(), var34);
                  var21 = var23.getItemStack(var28);
                  var34 ^= 660701029;
                  return (ItemStack)var21;
               }
            case 220738909:
               break;
            case 287303362:
            default:
               throw new IOException();
            }
         }
      }
   }

   private ItemStack createItem$1585078124(Material var1, String var2, List var3, int var4) {
      int var21 = 1812202741 ^ 1179907496 ^ this.btIRYCzsco ^ var4;
      var21 ^= 92422741;
      ItemStack var5 = new ItemStack(var1);
      var21 ^= 781249279;
      ItemMeta var10 = var5.getItemMeta();
      var21 ^= 1374215438;
      if (var10 != null) {
         var21 ^= 1915809233;
         var10.setDisplayName(var2);
         var21 ^= 2007244902;
         var10.setLore(var3);
         var21 ^= 1876529670;
         var5.setItemMeta(var10);
         var21 ^= 1921449020;
         return var5;
      } else {
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var21)) {
            case 97723473:
               var21 ^= 1441776687;
            case 1805228981:
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var21) == 141376814) {
                  var21 = bynukygzdcwuqufw(var21, 1294231458);
                  return var5;
               }

               var21 ^= 244931812;
               throw new IllegalAccessException();
            case 1257004676:
               break;
            case 2128825581:
            default:
               throw new IllegalAccessException();
            }
         }
      }
   }

   public void click$2048279449(WrappedClickEvent var1, int var2) {
      int var36 = 1946216179 ^ 981778347 ^ this.btIRYCzsco ^ var2;
      var36 ^= 1358137710;
      int var10 = var1.getSlot$2125716982(2104088370);
      var36 ^= 1105804384;
      Player var12 = var1.getPlayer$624284539(1206635844);
      var36 ^= 890281209;
      byte var4 = (byte)(1992293252 ^ var36);
      if (var10 == var4) {
         var36 ^= 586018007;
         SQLiteManager var15 = this.sqLiteManager;
         Map var16 = var15.getAllBillfordItems$1462928060(1379584926);
         Collection var17 = var16.values();
         byte var25 = (byte)(1414666052 ^ var36);
         ItemStack[] var26 = new ItemStack[var25];
         Object[] var18 = var17.toArray(var26);
         ItemStack[] var19 = (ItemStack[])var18;
         var36 ^= 148876584;
         byte var21 = this.hasRequiredItems$1947537244(var12, var19, 311290208);
         if (var21 == (1552792172 ^ var36)) {
            var36 ^= 1987620256;
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36) == 54195438) {
               var36 = bynukygzdcwuqufw(var36, 1415385319);
               MessagesConfig var23 = MessagesConfig.INVALIDBILLFORDITEMS;
               var23.send(var12);
               var36 ^= 1986333701;
               SoundWrapper var24 = SoundConfig.TRADEFAIL;
               var24.play(var12);
               var36 ^= 52579726;
            } else {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36)) {
                  case 54195438:
                     var36 ^= 1496357209;
                     throw new IllegalAccessException();
                  case 251877188:
                     break;
                  case 812204633:
                  case 1450534596:
                  default:
                     throw new IllegalAccessException();
                  }
               }
            }
         } else {
            var36 ^= 949766994;
            Inventory var32 = var1.getInventory$1458066743(1496261850);
            byte var6 = (byte)(1678897447 ^ var36);
            ItemStack var33 = var32.getItem(var6);
            this.processTrade$1665015831(var12, var33, var19, 544018113);

            label68:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36)) {
               case 27285076:
                  break;
               case 31631225:
                  var36 ^= 2003971838;
               case 294982746:
                  break label68;
               case 2027020247:
               default:
                  throw new IllegalAccessException();
               }
            }

            try {
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36) != 93426407) {
                  throw null;
               }

               throw new IllegalAccessException();
            } catch (IllegalAccessException var37) {
               switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var36)) {
               case -1692467712:
                  var36 ^= 1901504250;
                  break;
               case -332169285:
                  var36 = bynukygzdcwuqufw(var36, 531830477);
                  break;
               default:
                  throw new IllegalAccessException("Error in hash");
               }
            }

            var36 = bynukygzdcwuqufw(var36, 1775910810);
         }
      } else {
         var36 ^= 1178725157;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36) == 250376350) {
            var36 ^= 990991894;
         } else {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var36)) {
               case 18079663:
                  break;
               case 250376350:
                  var36 ^= 1127980579;
                  throw new IllegalAccessException();
               case 856237177:
               case 908497639:
               default:
                  throw new IllegalAccessException();
               }
            }
         }
      }
   }

   private boolean hasRequiredItems$1947537244(Player var1, ItemStack[] var2, int var3) {
      int var49 = 1238420670 ^ 1064510362 ^ this.btIRYCzsco ^ var3;
      var49 ^= 2007385094;
      HashMap var4 = new HashMap();
      HashMap var7 = var4;
      var49 ^= 1591984382;
      ItemStack[] var8 = var2;
      int var14 = var2.length;
      int var9 = var14;
      byte var15 = (byte)(911049268 ^ var49);
      int var10 = var15;
      var49 ^= 864944318;

      while(var10 < var9) {
         var49 ^= 695293543;
         ItemStack var18 = var8[var10];
         var49 ^= 1705168116;
         int var37 = var18.getAmount();
         Integer var38 = var37;
         BiFunction var6 = Integer::sum;
         var7.merge(var18, var38, var6);
         var49 ^= 1753559671;
         var10 += 563423855 ^ var49;
         var49 = bynukygzdcwuqufw(var49, 198991644);

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var49) != 32405957) {
               throw null;
            }

            throw new RuntimeException();
         } catch (RuntimeException var51) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var49)) {
            case 777961849:
               var49 = bynukygzdcwuqufw(var49, 658427981);
               break;
            case 1380690833:
               var49 ^= 683441424;
               break;
            default:
               throw new IllegalAccessException("Error in hash");
            }

            var49 = bynukygzdcwuqufw(var49, 121015016);
         }
      }

      var49 ^= 50306296;
      if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var49) != 113793974) {
         var49 ^= 793086478;
      } else {
         var49 ^= 2045982382;
         Set var22 = var7.entrySet();
         Iterator var23 = var22.iterator();
         Iterator var46 = var23;
         var49 ^= 345276718;

         label118:
         while(true) {
            byte var25 = var46.hasNext();
            if (var25 == (1784392178 ^ var49)) {
               label83:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var49)) {
                  case 236057375:
                     var49 ^= 84685217;
                  case 431219525:
                     break label83;
                  case 2065201219:
                     break;
                  case 2109141121:
                  default:
                     throw new IOException();
                  }
               }

               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var49) != 129620087) {
                  var49 ^= 1194200111;
                  break;
               }

               label72:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var49)) {
                  case 129620087:
                     var49 ^= 1845143328;
                     break label72;
                  case 484177076:
                     break;
                  case 1176495830:
                  default:
                     throw new IOException();
                  case 1568956268:
                     break label72;
                  }
               }

               byte var32 = (byte)(44908402 ^ var49);
               return (boolean)var32;
            }

            var49 ^= 110215257;
            Object var27 = var46.next();
            Entry var28 = (Entry)var27;
            var49 ^= 270581559;
            Object var40 = var28.getKey();
            ItemStack var41 = (ItemStack)var40;
            Object var43 = var28.getValue();
            Integer var44 = (Integer)var43;
            int var45 = var44;
            byte var30 = this.hasEnoughItems$1827087114(var1, var41, var45, 845668809);
            if (var30 == (2095765148 ^ var49)) {
               var49 ^= 836255019;
               byte var31 = (byte)(1295182775 ^ var49);
               return (boolean)var31;
            }

            var49 = bynukygzdcwuqufw(var49, 444632731);
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var49) != 107900135) {
               var49 = bynukygzdcwuqufw(var49, 1309920379);
               break;
            }

            var49 ^= 1073646609;

            label95:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var49)) {
               case 227541886:
                  var49 ^= 1879204670;
                  break label95;
               case 633500540:
               default:
                  throw new IOException();
               case 1187677727:
                  break;
               case 1633706869:
                  break label95;
               }
            }

            try {
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var49) != 9710411) {
                  throw null;
               }

               throw new IOException();
            } catch (IOException var50) {
               switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var49)) {
               case -842384077:
                  var49 ^= 2143842477;
                  break;
               case 1286977857:
                  var49 = bynukygzdcwuqufw(var49, 803700771);
                  break;
               default:
                  throw new IllegalAccessException("Error in hash");
               }

               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var49)) {
                  case 34945011:
                  default:
                     throw new IOException();
                  case 101328363:
                     var49 ^= 1814732537;
                     continue label118;
                  case 241917693:
                     break;
                  case 1058049563:
                     continue label118;
                  }
               }
            }
         }
      }

      throw new IOException();
   }

   private void processTrade$1665015831(Player var1, ItemStack var2, ItemStack[] var3, int var4) {
      int var37 = 1957022570 ^ 1047978248 ^ this.btIRYCzsco ^ var4;
      var37 ^= 1385680382;
      if (var2 != null) {
         var37 ^= 278102455;
         ItemStack[] var9 = var3;
         int var15 = var3.length;
         int var10 = var15;
         byte var16 = (byte)(1402759266 ^ var37);
         int var11 = var16;
         var37 ^= 1344077215;

         label105:
         while(var11 < var10) {
            var37 ^= 2038338423;
            ItemStack var24 = var9[var11];
            var37 ^= 1857325891;
            this.removeItems$1198590671(var1, var24, 401241792);
            var37 ^= 164686502;
            var11 += 496658286 ^ var37;
            var37 = bynukygzdcwuqufw(var37, 2144500401);

            try {
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var37) != 241949590) {
                  throw null;
               }

               throw new IllegalAccessException();
            } catch (IllegalAccessException var39) {
               switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var37)) {
               case -1855835021:
                  var37 = bynukygzdcwuqufw(var37, 658209075);
                  break;
               case 306245363:
                  var37 = bynukygzdcwuqufw(var37, 928981603);
                  break;
               default:
                  throw new IllegalAccessException("Error in hash");
               }

               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var37)) {
                  case 81616489:
                     var37 ^= 1452780096;
                     continue label105;
                  case 247246489:
                     break;
                  case 362413055:
                  default:
                     throw new IOException();
                  case 501307200:
                     continue label105;
                  }
               }
            }
         }

         var37 ^= 1709590525;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var37) != 107434118) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var37)) {
               case 71528749:
               case 478381551:
               default:
                  throw new IOException();
               case 107434118:
                  var37 ^= 1456045043;
                  throw new IOException();
               case 1943996923:
               }
            }
         } else {
            label81:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var37)) {
               case 107434118:
                  var37 ^= 1240142821;
                  break label81;
               case 424364671:
                  break;
               case 1348860026:
               default:
                  throw new IOException();
               case 1540452314:
                  break label81;
               }
            }

            PlayerInventory var19 = var1.getInventory();
            byte var27 = (byte)(797819364 ^ var37);
            ItemStack[] var28 = new ItemStack[var27];
            byte var7 = (byte)(797819365 ^ var37);
            ItemStack var35 = var2.clone();
            var28[var7] = var35;
            var19.addItem(var28);
            var37 ^= 1063291895;
            MessagesConfig var21 = MessagesConfig.BILLFORDTRADESUCCESS;
            var21.send(var1);
            var37 ^= 1184647947;
            SoundWrapper var22 = SoundConfig.TRADESUCCESS;
            var22.play(var1);
            var37 ^= 875557731;

            try {
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var37) != 244815762) {
                  throw null;
               } else {
                  throw new IOException();
               }
            } catch (IOException var38) {
               switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var37)) {
               case -2107968583:
                  var37 ^= 941627266;
                  break;
               case 318215123:
                  var37 ^= 1781906319;
                  break;
               default:
                  throw new IllegalAccessException("Error in hash");
               }

               var37 = bynukygzdcwuqufw(var37, 1509945334);
            }
         }
      } else {
         label116:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var37)) {
            case 32413187:
               var37 ^= 2068352264;
               break label116;
            case 1251323487:
               break;
            case 1430745547:
               break label116;
            case 2081826513:
            default:
               throw new IOException();
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var37) == 218786603) {
            var37 = bynukygzdcwuqufw(var37, 386805152);
            MessagesConfig var26 = MessagesConfig.NOBILLFORDITEMS;
            var26.send(var1);
            var37 ^= 2128473982;
         } else {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var37)) {
               case 218786603:
                  var37 ^= 149474606;
                  throw new IOException();
               case 661097085:
               case 1473293007:
               default:
                  throw new IOException();
               case 1866028111:
               }
            }
         }
      }
   }

   private void removeItems$1198590671(Player var1, ItemStack var2, int var3) {
      int var64 = 1160764176 ^ 1300715800 ^ this.btIRYCzsco ^ var3;
      var64 ^= 582888053;
      int var12 = var2.getAmount();
      int var7 = var12;
      var64 ^= 200619841;
      PlayerInventory var14 = var1.getInventory();
      ItemStack[] var15 = var14.getContents();
      ItemStack[] var8 = var15;
      var64 ^= 1187245597;
      byte var16 = (byte)(200017769 ^ var64);
      int var9 = var16;
      var64 ^= 360894745;

      while(true) {
         int var48 = var8.length;
         if (var9 < var48) {
            var64 ^= 1943285423;
            if (var7 > (1840969951 ^ var64)) {
               var64 ^= 1555464073;
               ItemStack var20 = var8[var9];
               var64 ^= 1628555858;
               if (var20 != null) {
                  var64 ^= 905687342;
                  Material var23 = var20.getType();
                  Material var51 = var2.getType();
                  if (var23 == var51) {
                     byte var11;
                     label280: {
                        var64 ^= 914239109;
                        byte var24 = (byte)(1402524335 ^ var64);
                        var11 = var24;
                        var64 ^= 1612138439;
                        byte var26 = var2.hasItemMeta();
                        if (var26 != (865047912 ^ var64)) {
                           var64 ^= 327966808;
                           byte var28 = var20.hasItemMeta();
                           if (var28 != (537130288 ^ var64)) {
                              var64 ^= 1566836519;
                              ItemMeta var30 = var20.getItemMeta();
                              ItemMeta var53 = var2.getItemMeta();
                              byte var31 = var30.equals(var53);
                              var11 = var31;
                              var64 ^= 2094404570;

                              try {
                                 if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 26657281) {
                                    throw null;
                                 }

                                 throw new RuntimeException();
                              } catch (RuntimeException var67) {
                                 switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var64)) {
                                 case 227479144:
                                    var64 = bynukygzdcwuqufw(var64, 394676101);
                                    break;
                                 case 1444493010:
                                    var64 ^= 1559527570;
                                    break;
                                 default:
                                    throw new IOException("Error in hash");
                                 }

                                 var64 = bynukygzdcwuqufw(var64, 1297517137);
                                 break label280;
                              }
                           }

                           label241:
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                              case 235375374:
                                 var64 ^= 1686846404;
                              case 302305595:
                                 break label241;
                              case 804928009:
                                 break;
                              case 1408596538:
                              default:
                                 throw new IllegalAccessException();
                              }
                           }

                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 80303216) {
                              while(true) {
                                 switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                                 case 80303216:
                                    var64 ^= 1976720563;
                                    throw new IllegalAccessException();
                                 case 868136273:
                                    break;
                                 case 966018021:
                                 case 1813937001:
                                 default:
                                    throw new IllegalAccessException();
                                 }
                              }
                           }

                           label231:
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                              case 80303216:
                                 var64 ^= 975305443;
                              case 768149477:
                                 break label231;
                              case 1361368014:
                                 break;
                              case 1491772119:
                              default:
                                 throw new IllegalAccessException();
                              }
                           }
                        } else {
                           var64 = bynukygzdcwuqufw(var64, 56830734);
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 248152073) {
                              var64 ^= 28716065;
                              break;
                           }

                           var64 = bynukygzdcwuqufw(var64, 1313180273);
                        }

                        byte var41 = var2.hasItemMeta();
                        if (var41 == (2125018135 ^ var64)) {
                           var64 ^= 1490714955;
                           byte var43 = var20.hasItemMeta();
                           if (var43 == (645117276 ^ var64)) {
                              var64 ^= 730504158;
                              byte var44 = (byte)(234434179 ^ var64);
                              var11 = var44;
                              var64 ^= 1452802715;
                           } else {
                              var64 = bynukygzdcwuqufw(var64, 878427121);
                              if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 53317191) {
                                 var64 ^= 594713834;
                                 break;
                              }

                              var64 = bynukygzdcwuqufw(var64, 1229529780);
                           }
                        } else {
                           label220:
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                              case 90679877:
                                 var64 ^= 926281615;
                                 break label220;
                              case 736523958:
                                 break;
                              case 1643175446:
                              default:
                                 throw new IllegalAccessException();
                              case 2143496220:
                                 break label220;
                              }
                           }

                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 245342442) {
                              var64 = bynukygzdcwuqufw(var64, 2026260959);
                              break;
                           }

                           var64 = bynukygzdcwuqufw(var64, 318633857);
                        }
                     }

                     if (var11 != (1533094937 ^ var64)) {
                        var64 ^= 1228055482;
                        int var34 = var20.getAmount();
                        if (var34 > var7) {
                           var64 ^= 658276705;
                           int var56 = var20.getAmount();
                           int var57 = var56 - var7;
                           var20.setAmount(var57);
                           var64 ^= 1104640079;
                           byte var36 = (byte)(1958246029 ^ var64);
                           var7 = var36;
                           var64 ^= 1981426990;

                           try {
                              if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 41432906) {
                                 throw null;
                              }

                              throw new RuntimeException();
                           } catch (RuntimeException var66) {
                              switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var64)) {
                              case 353557784:
                                 var64 ^= 1961542643;
                                 break;
                              case 874364129:
                                 var64 ^= 1355493324;
                                 break;
                              default:
                                 throw new RuntimeException("Error in hash");
                              }
                           }

                           var64 ^= 377100874;
                        } else {
                           label205:
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                              case 58848280:
                                 var64 ^= 50144025;
                              case 616914973:
                                 break label205;
                              case 1172301163:
                                 break;
                              case 1800005416:
                              default:
                                 throw new IllegalAccessException();
                              }
                           }

                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 5406214) {
                              var64 = bynukygzdcwuqufw(var64, 569655037);
                              break;
                           }

                           var64 = bynukygzdcwuqufw(var64, 1691868624);
                           int var59 = var20.getAmount();
                           int var38 = var7 - var59;
                           var7 = var38;
                           var64 ^= 867845179;
                           Object var62 = null;
                           var8[var9] = (ItemStack)var62;
                           var64 ^= 670152523;
                        }
                     } else {
                        var64 = bynukygzdcwuqufw(var64, 1399751172);
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 126794548) {
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                              case 80397264:
                              case 121222624:
                              default:
                                 throw new IllegalAccessException();
                              case 126794548:
                                 var64 ^= 961887322;
                                 throw new IllegalAccessException();
                              case 1992562134:
                              }
                           }
                        }

                        var64 ^= 1748839431;
                     }
                  } else {
                     label195:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                        case 52049968:
                           break label195;
                        case 91221367:
                           var64 ^= 139075618;
                           break label195;
                        case 929242137:
                           break;
                        case 1451612585:
                        default:
                           throw new IllegalAccessException();
                        }
                     }

                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 75401187) {
                        var64 = bynukygzdcwuqufw(var64, 1559645775);
                        break;
                     }

                     var64 ^= 228482578;
                  }
               } else {
                  var64 = bynukygzdcwuqufw(var64, 837007121);
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 232678774) {
                     var64 = bynukygzdcwuqufw(var64, 1352951890);
                     break;
                  }

                  var64 = bynukygzdcwuqufw(var64, 30177295);
               }

               var9 += 1613922843 ^ var64;

               label184:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                  case 174177312:
                     var64 ^= 504024627;
                     break label184;
                  case 697274750:
                     break;
                  case 953402006:
                  default:
                     throw new IllegalAccessException();
                  case 1436634278:
                     break label184;
                  }
               }

               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 76377527) {
                     throw null;
                  }

                  throw new IllegalAccessException();
               } catch (IllegalAccessException var65) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var64)) {
                  case -238919349:
                     var64 = bynukygzdcwuqufw(var64, 2020714706);
                     break;
                  case 1069201890:
                     var64 = bynukygzdcwuqufw(var64, 1103016903);
                     break;
                  default:
                     throw new IllegalAccessException("Error in hash");
                  }

                  var64 ^= 405222027;
                  continue;
               }
            }

            label269:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
               case 77213578:
                  var64 ^= 459480245;
                  break label269;
               case 929757213:
                  break;
               case 1416290535:
                  break label269;
               case 1792435357:
               default:
                  throw new IllegalAccessException();
               }
            }

            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 105274452) {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                  case 105274452:
                     var64 ^= 1199797805;
                     throw new IllegalAccessException();
                  case 909630383:
                  case 947527257:
                  default:
                     throw new IllegalAccessException();
                  case 1492311539:
                  }
               }
            }

            label259:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
               case 105274452:
                  var64 ^= 93275695;
               case 249878019:
                  break label259;
               case 817007656:
               default:
                  throw new IllegalAccessException();
               case 1710471827:
               }
            }
         } else {
            var64 ^= 2106793585;
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64) != 29085820) {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var64)) {
                  case 29085820:
                     var64 ^= 1386699334;
                     throw new IllegalAccessException();
                  case 200540241:
                     break;
                  case 754699080:
                  case 1334972386:
                  default:
                     throw new IllegalAccessException();
                  }
               }
            }

            var64 ^= 279669316;
         }

         PlayerInventory var46 = var1.getInventory();
         var46.setContents(var8);
         var64 ^= 88031726;
         var1.updateInventory();
         var64 ^= 1936108373;
         return;
      }

      throw new IllegalAccessException();
   }

   private boolean hasEnoughItems$1827087114(Player var1, ItemStack var2, int var3, int var4) {
      int var55 = 574161413 ^ 1324915715 ^ this.btIRYCzsco ^ var4;
      var55 ^= 2005693122;
      byte var5 = (byte)(1376521605 ^ var55);
      int var7 = var5;
      var55 ^= 811446589;
      PlayerInventory var14 = var1.getInventory();
      ItemStack[] var15 = var14.getContents();
      ItemStack[] var8 = var15;
      int var17 = var15.length;
      int var9 = var17;
      byte var18 = (byte)(1649523896 ^ var55);
      int var10 = var18;
      var55 ^= 568273216;

      while(true) {
         label226:
         while(true) {
            if (var10 < var9) {
               var55 ^= 1496551959;
               ItemStack var23 = var8[var10];
               var55 ^= 1822609346;
               if (var23 != null) {
                  var55 ^= 1096305811;
                  Material var26 = var23.getType();
                  Material var48 = var2.getType();
                  if (var26 == var48) {
                     byte var12;
                     label234: {
                        var55 ^= 1172099931;
                        byte var27 = (byte)(1922783205 ^ var55);
                        var12 = var27;
                        var55 ^= 2011633333;
                        byte var29 = var2.hasItemMeta();
                        if (var29 != (92029264 ^ var55)) {
                           var55 ^= 1046252941;
                           byte var31 = var23.hasItemMeta();
                           if (var31 != (992005341 ^ var55)) {
                              var55 ^= 58451704;
                              ItemMeta var43 = var23.getItemMeta();
                              ItemMeta var53 = var2.getItemMeta();
                              byte var44 = var43.equals(var53);
                              var12 = var44;
                              var55 = bynukygzdcwuqufw(var55, 1826605379);

                              try {
                                 if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55) != 62991377) {
                                    throw null;
                                 }

                                 throw new IllegalAccessException();
                              } catch (IllegalAccessException var57) {
                                 switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var55)) {
                                 case -1540941006:
                                    var55 ^= 1698394177;
                                    break;
                                 case -1199296096:
                                    var55 ^= 649008403;
                                    break;
                                 default:
                                    throw new IOException("Error in hash");
                                 }
                              }

                              var55 ^= 58148967;
                              break label234;
                           }

                           var55 ^= 481393739;
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55) != 212492723) {
                              var55 ^= 1810400021;
                              break;
                           }

                           var55 = bynukygzdcwuqufw(var55, 636649354);
                        } else {
                           var55 = bynukygzdcwuqufw(var55, 2009060324);
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55) != 240819967) {
                              var55 ^= 1052418359;
                              break;
                           }

                           var55 ^= 1889557928;
                        }

                        byte var33 = var2.hasItemMeta();
                        if (var33 != (40095516 ^ var55)) {
                           var55 ^= 1300604664;
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55) != 181281487) {
                              var55 ^= 60775015;
                              break;
                           }

                           var55 ^= 2100212388;
                        } else {
                           var55 ^= 1083123691;
                           byte var35 = var23.hasItemMeta();
                           if (var35 == (1122822391 ^ var55)) {
                              var55 ^= 1565010150;
                              byte var36 = (byte)(530890768 ^ var55);
                              var12 = var36;
                              var55 ^= 762059601;
                           } else {
                              label206:
                              while(true) {
                                 switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55)) {
                                 case 28000690:
                                    var55 ^= 1631738772;
                                 case 1192592186:
                                    break label206;
                                 case 1264190856:
                                 default:
                                    throw new RuntimeException();
                                 case 1312684333:
                                 }
                              }

                              if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55) != 86136865) {
                                 while(true) {
                                    switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55)) {
                                    case 86136865:
                                       var55 ^= 1876394208;
                                       throw new RuntimeException();
                                    case 1241818489:
                                       break;
                                    case 1473323157:
                                    case 1854450456:
                                    default:
                                       throw new RuntimeException();
                                    }
                                 }
                              }

                              var55 = bynukygzdcwuqufw(var55, 291924003);
                           }
                        }
                     }

                     if (var12 != (852024128 ^ var55)) {
                        var55 ^= 692726901;
                        int var50 = var23.getAmount();
                        int var39 = var7 + var50;
                        var7 = var39;
                        var55 ^= 880309484;
                        if (var39 >= var3) {
                           var55 ^= 1637635546;
                           byte var41 = (byte)(1315362306 ^ var55);
                           return (boolean)var41;
                        }

                        var55 ^= 151941345;
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55) != 192590280) {
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55)) {
                              case 45096435:
                              case 78955855:
                              default:
                                 throw new RuntimeException();
                              case 192590280:
                                 var55 ^= 1787674811;
                                 throw new RuntimeException();
                              case 1094743578:
                              }
                           }
                        }

                        label187:
                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55)) {
                           case 192590280:
                              var55 ^= 1089477349;
                              break label187;
                           case 208097232:
                           default:
                              throw new RuntimeException();
                           case 439654595:
                              break label187;
                           case 1059484576:
                           }
                        }
                     } else {
                        var55 = bynukygzdcwuqufw(var55, 2125621095);
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55) != 70090993) {
                           var55 ^= 233380;
                           break;
                        }

                        var55 = bynukygzdcwuqufw(var55, 712922618);
                     }
                  } else {
                     var55 = bynukygzdcwuqufw(var55, 452787637);
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55) != 144381758) {
                        var55 ^= 1640123016;
                        break;
                     }

                     var55 = bynukygzdcwuqufw(var55, 1270845654);
                  }
               } else {
                  var55 = bynukygzdcwuqufw(var55, 712291739);
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55) != 51388411) {
                     var55 = bynukygzdcwuqufw(var55, 269635125);
                     break;
                  }

                  var55 ^= 980391019;
               }

               var10 += 1711598044 ^ var55;
               var55 ^= 2100797389;

               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55) != 78884748) {
                     throw null;
                  }

                  throw new IllegalAccessException();
               } catch (IllegalAccessException var56) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var55)) {
                  case -644108160:
                     var55 ^= 432863545;
                     break;
                  case 272783146:
                     var55 ^= 1089979852;
                     break;
                  default:
                     throw new RuntimeException("Error in hash");
                  }
               }

               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55)) {
                  case 47158473:
                     var55 ^= 1097931473;
                     continue label226;
                  case 350633680:
                  default:
                     throw new RuntimeException();
                  case 909787910:
                     break;
                  case 1857407114:
                     continue label226;
                  }
               }
            }

            var55 = bynukygzdcwuqufw(var55, 766125902);
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55) != 90666084) {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55)) {
                  case 90666084:
                     var55 ^= 576553269;
                     throw new RuntimeException();
                  case 870790217:
                  case 1046383877:
                  default:
                     throw new RuntimeException();
                  case 1189029579:
                  }
               }
            }

            var55 = bynukygzdcwuqufw(var55, 1068482700);
            byte var21;
            if (var7 < var3) {
               var55 = bynukygzdcwuqufw(var55, 1108268124);
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55) == 97706464) {
                  var55 = bynukygzdcwuqufw(var55, 1481838997);
                  var21 = (byte)(1272362995 ^ var55);
                  var55 ^= 1402875567;
                  return (boolean)var21;
               }

               var55 = bynukygzdcwuqufw(var55, 1610388965);
               break;
            }

            var55 ^= 966037768;
            var21 = (byte)(1746920243 ^ var55);

            label223:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55)) {
               case 50088863:
               default:
                  throw new RuntimeException();
               case 163422255:
                  var55 ^= 1220566593;
               case 526817699:
                  break label223;
               case 562495955:
               }
            }

            try {
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var55) != 263282641) {
                  throw null;
               }

               throw new RuntimeException();
            } catch (RuntimeException var58) {
               switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var55)) {
               case 117304217:
                  var55 ^= 492185973;
                  break;
               case 1766754656:
                  var55 = bynukygzdcwuqufw(var55, 815809834);
                  break;
               default:
                  throw new IllegalAccessException("Error in hash");
               }
            }

            var55 ^= 633408858;
            return (boolean)var21;
         }

         throw new RuntimeException();
      }
   }

   public boolean isInGUI$652632361(Player var1, int var2) {
      int var8 = 845008190 ^ 1293992659 ^ this.btIRYCzsco ^ var2;
      var8 ^= 1828116121;
      Map var5 = this.opened;
      boolean var6 = var5.containsKey(var1);
      return var6;
   }

   public void remove$1734529989(Player var1, int var2) {
      int var8 = 1973914571 ^ 268001771 ^ this.btIRYCzsco ^ var2;
      var8 ^= 998419381;
      Map var5 = this.opened;
      var5.remove(var1);
      var8 ^= 903947960;
   }

   public void addToOpened$232106327(Player var1, Object[] var2, int var3) {
      int var10 = 891508359 ^ 683121498 ^ this.btIRYCzsco ^ var3;
      var10 ^= 1013766964;
      Map var7 = this.opened;
      var7.put(var1, var2);
      var10 ^= 1613756215;
   }

   static {
      nothing_to_see_here[0] = "⢀⡴⠑⡄⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠸⡇⠀⠿⡀⠀⠀⠀⣀⡴⢿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠑⢄⣠⠾⠁⣀⣄⡈⠙⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⢀⡀⠁⠀⠀⠈⠙⠛⠂⠈⣿⣿⣿⣿⣿⠿⡿⢿⣆⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⢀⡾⣁⣀⠀⠴⠂⠙⣗⡀⠀⢻⣿⣿⠭⢤⣴⣦⣤⣹⠀⠀⠀⢀⢴⣶⣆";
      nothing_to_see_here[5] = "⠀⠀⢀⣾⣿⣿⣿⣷⣮⣽⣾⣿⣥⣴⣿⣿⡿⢂⠔⢚⡿⢿⣿⣦⣴⣾⠁⠸⣼⡿";
      nothing_to_see_here[6] = "⠀⢀⡞⠁⠙⠻⠿⠟⠉⠀⠛⢹⣿⣿⣿⣿⣿⣌⢤⣼⣿⣾⣿⡟⠉⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⣾⣷⣶⠇⠀⠀⣤⣄⣀⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠉⠈⠉⠀⠀⢦⡈⢻⣿⣿⣿⣶⣶⣶⣶⣤⣽⡹⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠉⠲⣽⡻⢿⣿⣿⣿⣿⣿⣿⣷⣜⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣷⣶⣮⣭⣽⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⠿⠿⠿⠿⠛⠉              ";
      yauzbgmfnf = isphmvmtsbkzozl();
      int var3 = (new Random(7838706670558687627L)).nextInt();
      teQksBq9uU = -88312558 ^ var3;
   }

   public static String jrfprvwezs(byte[] var0, int var1) {
      String var10 = Integer.toString(var1);
      byte[] var11 = var10.getBytes();
      byte[] var8 = var11;
      byte var12 = 0;
      int var9 = var12;

      while(true) {
         int var17 = var0.length;
         if (var9 >= var17) {
            Charset var5 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var5);
            return var14;
         }

         byte var20 = var0[var9];
         int var33 = var8.length;
         int var30 = var9 % var33;
         byte var27 = var8[var30];
         int var21 = var20 ^ var27;
         byte var22 = (byte)var21;
         var0[var9] = var22;
         byte var23 = var0[var9];
         byte[] var28 = yauzbgmfnf;
         byte[] var34 = yauzbgmfnf;
         int var35 = var34.length;
         int var32 = var9 % var35;
         byte var29 = var28[var32];
         int var24 = var23 ^ var29;
         byte var25 = (byte)var24;
         var0[var9] = var25;
         ++var9;
      }
   }

   private static byte[] isphmvmtsbkzozl() {
      return new byte[]{80, 18, 106, 72, 105, 101, 13, 19, 114, 26, 83, 25, 116, 56, 49, 18, 56, 1, 86, 46, 82, 85, 26, 48, 66, 24, 75, 44, 43, 21, 105, 67, 98, 38, 113};
   }

   private static byte[] kqhbctgmyhicqto() {
      return new byte[]{-103, -40, 91, 31, 93, 60, 63, 70, 75, 65, 102, 78, 65, 99, 1, 82, 1, 92, 97, 68, 99, 7, 46, 117, 112, 72, 114, 53, 30, 80, 92, 30, 82, 96, 72, 5, 37, 58};
   }

   private static byte[] caktjqkdwbhquox() {
      return new byte[]{-103, -38, 94, 26, 93, 58, 52, 74, 66, 65, 100, 75, 68, 99, 7, 89, 13, 85, 97, 70, 102, 2, 46, 115, 123, 68, 123, 53, 28, 71, 89, 30, 84, 115, 68, 12, 37, 2, 124, 48, 81, 79, 42, 34, 42, 9, 46, 110, 8, 104, 36, 96, 52, 18, 25, 0, 97, 88, 4, 29, 33, 31, 28, 112};
   }

   private static byte[] gschxkxebhpjugu() {
      return new byte[]{-101, -33, 89, 27, 94, 52, 57, 75, 65, 67, 97, 76, 69, 96, 9, 84, 12, 86, 99, 67, 97, 3, 45, 125, 118, 69, 120, 55, 25, 64, 88, 29, 90, 126, 69, 15, 39, 7, 123, 49, 82, 65, 39, 35, 41, 11, 43, 105, 9, 98, 42, 101, 53, 22, 27, 16, 102, 71, 7, 27, 44, 6, 31, 65, 39, 52, 114, 52, 30, 40, 100, 68};
   }

   private static byte[] uytnckohxjsowui() {
      return new byte[]{-104, -39, 94, 31, 90, 56, 52, 75, 68, 66, 103, 74, 71, 99, 8, 84, 14, 81, 98, 68, 97, 6, 35, 113, 116, 69, 127, 55, 24, 71, 80, 30, 84, 126, 69, 9, 33, 1, 113, 52, 83, 77, 39, 34, 41, 10, 32, 110, 14, 105, 38, 98, 50, 16, 23, 3};
   }

   private static byte[] qdqljusprapszdk() {
      return new byte[]{-100, -35, 83, 28, 93, 58, 56, 77, 67, 71, 97, 79, 77, 97, 5, 86, 13, 87, 103, 64, 96, 2, 35, 115, 118, 71, 126, 48, 26, 69, 91, 29, 91, 102, 69, 15, 39, 52, 121, 118, 87, 81, 42, 43, 46, 23, 44, 35};
   }

   private static byte[] fqnzoshfhqeopmq() {
      return new byte[]{-103, -36, 82, 25, 89, 56, 56, 75, 70, 65, 98, 71, 71, 103, 5, 85, 12, 81, 97, 64, 106, 1, 42, 113, 119, 69, 127, 53, 26, 89, 90, 1, 86, 114, 69, 0, 37, 62, 112, 5, 85, 90, 38, 46, 46, 11, 40, 37, 11, 98, 38, 104};
   }

   private static byte[] zzblahrdofaruiw() {
      return new byte[]{-102, -43, 95, 14, 89, 40, 52, 88, 69, 75, 107, 66, 65, 111, 8, 95, 1, 94, 98, 100, 103, 15, 42, 109};
   }

   private static byte[] kcsccavmyqyjyqr() {
      return new byte[]{-97, -34, 94, 19, 92, 56, 52, 75, 71, 71, 98, 76, 64, 110, 4, 84, 1, 81, 99, 64, 99, 1, 46, 124, 119, 69, 114, 54, 30, 80, 88, 2, 86, 126, 68, 0, 43, 59, 125, 7, 84, 93, 39, 35, 47, 8, 32, 41, 13, 99, 35, 110};
   }

   private static byte[] xvzjojliqwawxox() {
      return new byte[]{-104, -36, 89, 27, 89, 38, 59, 74, 74, 88, 98, 71, 68, 125, 0, 72, 8, 77, 96, 118, 97, 21, 42, 109, 116, 65, 115, 127, 26, 84};
   }

   private static int bynukygzdcwuqufw(int var0, int var1) {
      return var1 ^ var0;
   }
}
