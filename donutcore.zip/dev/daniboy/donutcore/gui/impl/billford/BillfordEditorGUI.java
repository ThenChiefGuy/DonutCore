package dev.daniboy.donutcore.gui.impl.billford;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.gui.AbstractGui;
import dev.daniboy.donutcore.gui.WrappedClickEvent;
import dev.daniboy.donutcore.utils.Hex;
import dev.daniboy.donutcore.utils.ItemBuilder;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class BillfordEditorGUI extends AbstractGui {
   private final DonutCore plugin;
   private final Map<Player, Object[]> opened;
   private final FileConfiguration billfordGuiConfig;
   private static int OZDKSqGQRu;
   private transient int GpfyIGQz2I;
   private static byte[] idtlsfkpfs;
   private static String[] nothing_to_see_here = new String[18];

   public BillfordEditorGUI(DonutCore var1, int var2) {
      int var13 = 1365512305 ^ 2120104483;
      super(var1, 1156425752);
      var13 ^= 316505156;
      var13 = 620632850 ^ 283662543 ^ Integer.parseInt("1293729235") ^ var2;
      this.GpfyIGQz2I = 229386958 ^ OZDKSqGQRu;

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var13)) {
         case 133172013:
            var13 ^= 1174296559;
         case 1313152594:
            var13 ^= 34552323;
            ConcurrentHashMap var8 = new ConcurrentHashMap();
            this.opened = var8;
            var13 ^= 958439931;
            this.plugin = var1;
            var13 ^= 176732167;
            FileConfiguration var11 = var1.getBillfordGuiConfig$756205206(1840850862);
            this.billfordGuiConfig = var11;
            var13 ^= 603269673;
            return;
         case 1704230817:
            break;
         case 2033955666:
         default:
            throw new IllegalAccessException();
         }
      }
   }

   public Inventory generateInventory$919822562(Player var1, Object[] var2, int var3) {
      int var49 = 2142918269 ^ 1458398552 ^ this.GpfyIGQz2I ^ var3;
      var49 ^= 1427317615;
      FileConfiguration var13 = this.billfordGuiConfig;
      String var5 = ehnlorxodz(gnehcrifmrxfquf(), var49);
      String var14 = var13.getString(var5);
      String var15 = Hex.hex(var14);
      var49 ^= 424123001;
      Object var16 = null;
      byte var31 = (byte)(1452016177 ^ var49);
      Inventory var17 = Bukkit.createInventory((InventoryHolder)var16, var31, var15);
      var49 ^= 1653512929;
      Material var32 = Material.BLAZE_POWDER;
      String var40 = ehnlorxodz(ovuuaikotcpeysp(), var49);
      ItemStack var19 = this.createItem$305086769(var32, var40, 411645963);
      var49 ^= 633121673;
      Material var33 = Material.BLAZE_ROD;
      String var41 = ehnlorxodz(aaqcnkhsenseelc(), var49);
      ItemStack var21 = this.createItem$305086769(var33, var41, 411645963);
      var49 ^= 1224260387;
      Material var34 = Material.BLACK_STAINED_GLASS;
      String var42 = ehnlorxodz(prrpsgaqrrmptqq(), var49);
      ItemStack var23 = this.createItem$305086769(var34, var42, 411645963);
      var49 ^= 1992848436;
      Material var35 = Material.CRAFTING_TABLE;
      String var43 = ehnlorxodz(kcoaspnpdhqxmxj(), var49);
      ItemStack var25 = this.createItem$305086769(var35, var43, 411645963);
      var49 ^= 1212708521;
      byte var36 = (byte)(1741064922 ^ var49);
      var17.setItem(var36, var19);
      var49 ^= 54505471;
      byte var37 = (byte)(1694049569 ^ var49);
      var17.setItem(var37, var21);
      var49 ^= 541806902;
      byte var38 = (byte)(1152545799 ^ var49);
      var17.setItem(var38, var23);
      var49 ^= 751849822;
      byte var39 = (byte)(1751262583 ^ var49);
      var17.setItem(var39, var25);
      var49 ^= 170134877;
      return var17;
   }

   private ItemStack createItem$305086769(Material var1, String var2, int var3) {
      int var16 = 1912107533 ^ 364095644 ^ this.GpfyIGQz2I ^ var3;
      var16 ^= 1336881075;
      ItemStack var5 = new ItemStack(var1);
      ItemBuilder var4 = new ItemBuilder(var5);
      FileConfiguration var10 = this.billfordGuiConfig;
      String var14 = "billford_gui.billfordeditor_gui." + var2;
      var16 ^= 6265164;
      String var11 = var10.getString(var14);
      String var12 = Hex.hex(var11);
      ItemBuilder var7 = var4.name(var12);
      var16 ^= 1826573464;
      ItemStack var8 = var7.build();
      var16 ^= 1276079899;
      return var8;
   }

   public void click$2048279449(WrappedClickEvent var1, int var2) {
      int var50 = 1698548560 ^ 732648402 ^ this.GpfyIGQz2I ^ var2;
      var50 ^= 2088262997;
      int var9 = var1.getSlot$2125716982(2104088370);
      var50 ^= 1799068027;
      Player var11 = var1.getPlayer$624284539(1206635844);
      var50 ^= 219168140;
      ItemStack var13 = var1.getCursor$1334603673(89939990);
      var50 ^= 367121598;
      byte var4 = (byte)(1278923498 ^ var50);
      if (var9 == var4) {
         var50 ^= 779070842;
         DonutCore var16 = this.plugin;
         BillfordEditorItemsGUI var17 = var16.getBillfordEditorItemsGui$131132968(11136247);
         byte var5 = (byte)(1649770401 ^ var50);
         Object[] var45 = new Object[var5];
         var17.open$967512435(var11, var45, 1892453237);

         label172:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50)) {
            case 243647762:
               var50 ^= 1511294328;
            case 275579784:
               break label172;
            case 449864054:
            default:
               throw new IOException();
            case 2046176269:
            }
         }

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50) != 218099269) {
               throw null;
            }

            throw new IOException();
         } catch (IOException var51) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var50)) {
            case -1039149367:
               var50 ^= 354377749;
               break;
            case 1665273827:
               var50 ^= 1094114096;
               break;
            default:
               throw new RuntimeException("Error in hash");
            }
         }

         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50)) {
            case 132605621:
               var50 ^= 2000481148;
               return;
            case 453781882:
            default:
               throw new IOException();
            case 464876329:
               return;
            case 2111857182:
            }
         }
      } else {
         var50 ^= 2027955272;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50) != 107481446) {
            var50 = oomlyrufewuxlagd(var50, 1763030780);
            throw new IOException();
         }

         var50 = oomlyrufewuxlagd(var50, 725204243);
         byte var33 = (byte)(534989727 ^ var50);
         if (var9 == var33) {
            var50 ^= 596061844;
            if (var13 != null) {
               var50 ^= 2031745022;
               Material var21 = var13.getType();
               Material var34 = Material.AIR;
               if (var21 != var34) {
                  var50 ^= 2040707239;
                  Optional var43 = Optional.empty();
                  this.saveTradeChoice$1897065175(var43, var13, 902243137);
                  var50 ^= 1435280757;
                  DonutCore var30 = this.plugin;
                  var30.saveBillfordGuiConfig$978105170(1372127931);
                  var50 ^= 1192954812;
                  MessagesConfig var31 = MessagesConfig.SAVINGTRADEITEMS;
                  var31.send(var11);

                  label132:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50)) {
                     case 162311927:
                        var50 ^= 1422883460;
                        break label132;
                     case 564738869:
                        break;
                     case 703147919:
                     default:
                        throw new IOException();
                     case 895642487:
                        break label132;
                     }
                  }

                  try {
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50) != 224855719) {
                        throw null;
                     }

                     throw new IOException();
                  } catch (IOException var53) {
                     switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var50)) {
                     case -734007293:
                        var50 ^= 1890835115;
                        break;
                     case -544100285:
                        var50 ^= 1908806307;
                        break;
                     default:
                        throw new IOException("Error in hash");
                     }
                  }

                  var50 ^= 1347835163;
                  return;
               }

               var50 = oomlyrufewuxlagd(var50, 561058879);
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50) != 30941488) {
                  var50 ^= 969131706;
                  throw new IOException();
               }

               var50 ^= 1238016822;
            } else {
               var50 ^= 1328540016;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50) != 258085706) {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50)) {
                     case 258085706:
                        var50 ^= 780454923;
                        throw new IOException();
                     case 637858218:
                     case 956692176:
                     default:
                        throw new IOException();
                     case 1893830255:
                     }
                  }
               }

               var50 = oomlyrufewuxlagd(var50, 1586342279);
            }
         } else {
            var50 ^= 2114129754;
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50) != 228779142) {
               var50 = oomlyrufewuxlagd(var50, 1009714357);
               throw new IOException();
            }

            var50 ^= 1277583673;
         }

         byte var35 = (byte)(767960552 ^ var50);
         if (var9 == var35) {
            var50 ^= 2130586957;
            MessagesConfig var23 = MessagesConfig.SAVINGCRITMULTIPLER;
            var23.send(var11);
            var50 ^= 2047536275;
            String var37 = ehnlorxodz(jhdmtoaqkdiowqc(), var50);
            Optional var38 = Optional.of(var37);
            Object var46 = null;
            this.saveTradeChoice$1897065175(var38, (ItemStack)var46, 902243137);

            label143:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50)) {
               case 265466628:
                  var50 ^= 880511131;
                  break label143;
               case 796548983:
                  break;
               case 1308629897:
               default:
                  throw new IOException();
               case 1417696857:
                  break label143;
               }
            }

            try {
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50) != 146694088) {
                  throw null;
               }

               throw new IOException();
            } catch (IOException var52) {
               switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var50)) {
               case -848013495:
                  var50 ^= 942946991;
                  break;
               case -364157648:
                  var50 ^= 483646688;
                  break;
               default:
                  throw new RuntimeException("Error in hash");
               }
            }

            var50 ^= 1543029238;
         } else {
            var50 = oomlyrufewuxlagd(var50, 1329214246);
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50) != 264769249) {
               var50 = oomlyrufewuxlagd(var50, 1060329130);
               throw new IOException();
            }

            var50 = oomlyrufewuxlagd(var50, 410176684);
            byte var39 = (byte)(2056182374 ^ var50);
            if (var9 == var39) {
               var50 ^= 1019069972;
               MessagesConfig var26 = MessagesConfig.SAVINGSRENGTHROD;
               var26.send(var11);
               var50 ^= 1431309770;
               String var41 = ehnlorxodz(wyywzpcpfnvcpii(), var50);
               Optional var42 = Optional.of(var41);
               Object var47 = null;
               this.saveTradeChoice$1897065175(var42, (ItemStack)var47, 902243137);
               var50 ^= 1224826887;
            } else {
               var50 = oomlyrufewuxlagd(var50, 1816230154);
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50) != 204626496) {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var50)) {
                     case 204626496:
                        var50 ^= 1258349324;
                        throw new IOException();
                     case 603085873:
                        break;
                     case 1098904900:
                     case 1800278244:
                     default:
                        throw new IOException();
                     }
                  }
               }

               var50 ^= 1286460115;
            }
         }
      }

   }

   private void saveTradeChoice$1897065175(Optional var1, ItemStack var2, int var3) {
      int var11 = 1727188329 ^ 930565461 ^ this.GpfyIGQz2I ^ var3;
      var11 ^= 152335994;
      Consumer var8 = (var1x) -> {
         int var8 = 147970550 ^ 1110037452 ^ this.GpfyIGQz2I;
         var8 ^= 683209209;
         FileConfiguration var5 = this.billfordGuiConfig;
         String var3 = ehnlorxodz(lzddgxccwahjdsr(), var8);
         var5.set(var3, var1x);
      };
      Runnable var9 = () -> {
         int var8 = 781898776 ^ 2045654262 ^ this.GpfyIGQz2I;
         var8 ^= 1665597923;
         FileConfiguration var5 = this.billfordGuiConfig;
         String var3 = ehnlorxodz(nsjrsefqwcndbyy(), var8);
         var5.set(var3, var2);
      };
      var1.ifPresentOrElse(var8, var9);
      var11 ^= 111782769;
   }

   private void saveTradeChoice(ItemStack var1) {
      int var8 = 474994426 ^ 1892561333 ^ this.GpfyIGQz2I;
      var8 ^= 283164740;
      FileConfiguration var5 = this.billfordGuiConfig;
      String var3 = ehnlorxodz(zzchixicfzafbuz(), var8);
      var5.set(var3, var1);
      var8 ^= 1924765666;
   }

   public boolean isInGUI$652632361(Player var1, int var2) {
      int var8 = 475793541 ^ 1544498858 ^ this.GpfyIGQz2I ^ var2;
      var8 ^= 1466668819;
      Map var5 = this.opened;
      boolean var6 = var5.containsKey(var1);
      return var6;
   }

   public void remove$1734529989(Player var1, int var2) {
      int var8 = 2108706497 ^ 517377426 ^ this.GpfyIGQz2I ^ var2;
      var8 ^= 99472193;
      Map var5 = this.opened;
      var5.remove(var1);
      var8 ^= 483239153;
   }

   public void addToOpened$232106327(Player var1, Object[] var2, int var3) {
      int var10 = 607577218 ^ 966293283 ^ this.GpfyIGQz2I ^ var3;
      var10 ^= 819598504;
      Map var7 = this.opened;
      var7.put(var1, var2);
      var10 ^= 2055600299;
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣶⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⠿⠟⠛⠻⣿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣆⣀⣀⠀⣿⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠻⣿⣿⣿⠅⠛⠋⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[5] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢼⣿⣿⣿⣃⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[6] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣟⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣛⣛⣫⡄⠀⢸⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣾⡆⠸⣿⣿⣿⡷⠂⠨⣿⣿⣿⣿⣶⣦⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣾⣿⣿⣿⣿⡇⢀⣿⡿⠋⠁⢀⡶⠪⣉⢸⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⡏⢸⣿⣷⣿⣿⣷⣦⡙⣿⣿⣿⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣇⢸⣿⣿⣿⣿⣿⣷⣦⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[15] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[16] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[17] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣵⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      idtlsfkpfs = zxpnxoncbbedjns();
      int var3 = (new Random(-8359423772121303346L)).nextInt();
      OZDKSqGQRu = -609283898 ^ var3;
   }

   public static String ehnlorxodz(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = idtlsfkpfs;
         byte[] var34 = idtlsfkpfs;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] zxpnxoncbbedjns() {
      return new byte[]{52, 111, 38, 102, 100, 68, 15, 77, 81, 51, 106, 120, 90, 119, 78, 64, 70, 28, 51, 96, 107, 35, 38, 17, 96, 91, 88, 121, 34, 110, 2, 98, 71, 33, 63, 113, 47, 109, 28, 99, 19, 61, 23, 30, 71, 23, 90, 38, 16, 66, 35, 83, 47, 113, 100, 19, 12, 90, 57, 40, 76, 96, 112, 50, 13, 41, 103, 24, 28, 77, 29, 11, 79, 65, 61, 48, 87, 6, 103, 84, 89, 125, 50, 20, 30, 11, 43, 21, 116, 85, 8, 119, 48, 21, 35, 56};
   }

   private static byte[] nsjrsefqwcndbyy() {
      return new byte[]{-5, -91, 30, 52, 92, 27, 61, 24, 102, 109, 91, 43, 98, 40, 118, 4, 116, 65, 4, 13, 90, 113, 30, 84, 88, 4, 106, 110, 21, 40, 51, 37, 127, 112, 7, 35, 29, 49, 43, 14, 34, 107, 47, 70, 127, 78, 104, 118, 39, 19, 18, 3};
   }

   private static byte[] lzddgxccwahjdsr() {
      return new byte[]{-5, -93, 31, 52, 84, 26, 56, 24, 101, 110, 89, 39, 106, 40, 121, 5, 127, 76, 2, 12, 82, 116, 22, 83, 87, 11, 108, 102, 17, 35, 50, 32, 112, 119, 6, 33, 30, 59, 37, 12, 35, 105, 32, 79, 115, 73, 105, 118, 32, 17, 20, 1};
   }

   private static byte[] aaqcnkhsenseelc() {
      return new byte[]{-8, -87, 17, 35, 83, 7, 57, 8, 104, 100, 83, 33, 108, 39, 121, 2, 113, 77, 1, 43, 92, 122, 17, 66, 86, 65, 97, 47, 27, 48, 52, 38, 112, 103, 8, 36, 29, 53, 43, 44, 36, 100, 33, 72, 126, 72, 99, 116};
   }

   private static byte[] gnehcrifmrxfquf() {
      return new byte[]{-5, -93, 21, 60, 83, 25, 61, 24, 96, 111, 91, 45, 105, 32, 121, 6, 116, 65, 2, 15, 90, 119, 21, 92, 87, 6, 106, 110, 19, 60, 51, 56, 116, 117, 8, 41, 29, 50, 45, 60, 34, 124, 36, 66, 112, 70, 104, 123, 33, 27, 18, 20, 28, 38, 83, 85, 62, 60, 8, 127, 125, 38, 67, 99, 58, 51, 85, 85, 45, 20, 44, 76, 124, 21, 10, 97};
   }

   private static byte[] prrpsgaqrrmptqq() {
      return new byte[]{-5, -92, 31, 48, 83, 25, 59, 31, 98, 90, 91, 37, 99, 52, 121, 28, 114, 71};
   }

   private static byte[] ovuuaikotcpeysp() {
      return new byte[]{-14, -89, 20, 48, 92, 3, 59, 16, 103, 127, 93, 39, 111, 58, 123, 24, 114, 94, 11, 62, 89, 102, 30, 72, 84, 6, 110, 36, 21, 46, 55, 119, 114, 113, 11, 46, 23, 41, 46, 38, 43, 100, 35, 75, 113, 86, 109, 122, 37, 27, 22, 10, 27, 34};
   }

   private static byte[] kcoaspnpdhqxmxj() {
      return new byte[]{-3, -87, 17, 61, 93, 18, 55, 26, 103, 98, 83, 38, 98, 41, 119, 13, 127, 88, 4, 60, 92, 68, 31, 65, 88, 22, 110, 43, 27, 52};
   }

   private static byte[] jhdmtoaqkdiowqc() {
      return new byte[]{-4, -87, 23, 55, 84, 7, 63, 28, 100, 113, 83, 36, 104, 50, 127, 28, 126, 93, 5, 48, 90, 97, 22, 76, 80, 10, 109, 42, 27, 45};
   }

   private static byte[] wyywzpcpfnvcpii() {
      return new byte[]{-7, -94, 19, 39, 81, 9, 56, 15, 98, 101, 88, 35, 104, 37, 119, 3, 118, 71, 0, 32, 94, 126, 19, 76};
   }

   private static byte[] zzchixicfzafbuz() {
      return new byte[]{-7, -89, 19, 61, 82, 27, 56, 16, 101, 108, 93, 43, 99, 46, 120, 5, 119, 76, 0, 8, 94, 125, 16, 82, 87, 3, 108, 100, 21, 47, 59, 38, 113, 119, 14, 33, 28, 63, 41, 5, 37, 104, 32, 71, 115, 75, 109, 122, 41, 23, 21, 1};
   }

   private static int oomlyrufewuxlagd(int var0, int var1) {
      return var0 ^ var1;
   }
}
