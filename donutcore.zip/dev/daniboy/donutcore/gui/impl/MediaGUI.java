package dev.daniboy.donutcore.gui.impl;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.gui.AbstractGui;
import dev.daniboy.donutcore.gui.WrappedClickEvent;
import dev.daniboy.donutcore.utils.Hex;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;

public class MediaGUI extends AbstractGui {
   private final Map<Player, Object[]> opened;
   private final Map<Integer, String> slotMediaCommandMap;
   private final DonutCore plugin;
   private String title;
   private int size;
   private final Map<Integer, ItemStack> items;
   private static int YdbcE8YRJ4;
   private transient int ZO0bVNNKeV;
   private static byte[] lqklwylrhp;
   private static String[] nothing_to_see_here = new String[15];

   public MediaGUI(DonutCore var1, int var2) {
      int var14 = 1784936821 ^ 89681613;
      super(var1, 1156425752);

      label30:
      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var14)) {
         case 126032591:
            var14 ^= 652207427;
         case 1144497204:
            var14 = 1358774271 ^ 1904788893 ^ Integer.parseInt("746332289") ^ var2;
            this.ZO0bVNNKeV = 1998519904 ^ YdbcE8YRJ4;

            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var14)) {
               case 254465826:
                  var14 ^= 25781338;
               case 1140816545:
                  break label30;
               case 1148761209:
               default:
                  throw new IOException();
               case 1470870233:
               }
            }
         case 198275204:
         default:
            throw new IOException();
         case 833994656:
         }
      }

      var14 ^= 1567368586;
      HashMap var9 = new HashMap();
      this.opened = var9;
      var14 ^= 1020207737;
      HashMap var10 = new HashMap();
      this.slotMediaCommandMap = var10;
      var14 ^= 982407734;
      HashMap var11 = new HashMap();
      this.items = var11;
      var14 ^= 1238249574;
      this.plugin = var1;
      var14 ^= 515794613;
   }

   public Inventory generateInventory$919822562(Player var1, Object[] var2, int var3) {
      int var32 = 848121674 ^ 46271324 ^ this.ZO0bVNNKeV ^ var3;
      var32 ^= 247400034;
      Object var4 = null;
      int var22 = this.size;
      String var27 = this.title;
      Inventory var10 = Bukkit.createInventory((InventoryHolder)var4, var22, var27);
      Inventory var7 = var10;
      var32 ^= 1135428223;
      Map var12 = this.items;
      Set var13 = var12.entrySet();
      Iterator var14 = var13.iterator();
      Iterator var8 = var14;
      var32 ^= 1496409379;

      while(true) {
         byte var16 = var8.hasNext();
         if (var16 == (1137476376 ^ var32)) {
            var32 ^= 520116432;
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32) != 63747359) {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32)) {
                  case 63747359:
                     var32 ^= 2038078909;
                     throw new IOException();
                  case 1363842121:
                     break;
                  case 1937134147:
                  case 2020159280:
                  default:
                     throw new IOException();
                  }
               }
            }

            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32)) {
               case 63747359:
                  var32 ^= 627446602;
                  return var7;
               case 575891618:
                  return var7;
               case 915482834:
               default:
                  throw new IOException();
               case 1287168767:
               }
            }
         }

         var32 ^= 2132578605;
         Object var19 = var8.next();
         Entry var20 = (Entry)var19;
         var32 ^= 355999320;
         Object var24 = var20.getKey();
         Integer var25 = (Integer)var24;
         int var26 = var25;
         Object var29 = var20.getValue();
         ItemStack var30 = (ItemStack)var29;
         var7.setItem(var26, var30);
         var32 ^= 638686488;

         label50:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32)) {
            case 200876956:
               break label50;
            case 250844843:
               var32 ^= 1039385195;
               break label50;
            case 907271031:
            default:
               throw new IOException();
            case 1571183719:
            }
         }

         try {
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var32) != 15999616) {
               throw null;
            }

            throw new IllegalAccessException();
         } catch (IllegalAccessException var33) {
            switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var32)) {
            case -1873618703:
               var32 = sakplmsmaqzgezwi(var32, 1182646259);
               break;
            case -121277342:
               var32 ^= 728713825;
               break;
            default:
               throw new IllegalAccessException("Error in hash");
            }

            var32 = sakplmsmaqzgezwi(var32, 935028725);
         }
      }
   }

   public void click$2048279449(WrappedClickEvent var1, int var2) {
      int var24 = 29726490 ^ 2139373014 ^ this.ZO0bVNNKeV ^ var2;
      var24 ^= 1424427580;
      int var8 = var1.getSlot$2125716982(2104088370);
      var24 ^= 605353371;
      Player var10 = var1.getPlayer$624284539(1206635844);
      var24 ^= 2012508615;
      byte var12 = this.isInGUI$652632361(var10, 901967400);
      if (var12 == (544681453 ^ var24)) {
         var24 ^= 1826862077;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24) == 73383595) {
            var24 ^= 1092850836;
            return;
         }

         var24 = sakplmsmaqzgezwi(var24, 2000292);
      } else {
         var24 ^= 1169692873;
         Map var14 = this.slotMediaCommandMap;
         Integer var21 = var8;
         Object var15 = var14.get(var21);
         String var16 = (String)var15;
         var24 ^= 1835575567;
         if (var16 != null) {
            var24 ^= 456141013;
            var10.performCommand(var16);
            var24 ^= 505462394;
            return;
         }

         label36:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24)) {
            case 12891700:
               var24 ^= 213182809;
               break label36;
            case 515984180:
            default:
               throw new IllegalAccessException();
            case 785381730:
               break;
            case 1912651200:
               break label36;
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var24) == 64109065) {
            var24 ^= 161775606;
            return;
         }

         var24 ^= 1218014918;
      }

      throw new IllegalAccessException();
   }

   public void loadMediaConfigValues$2120577358(int var1) {
      int var161 = 867306594 ^ 988728837 ^ this.ZO0bVNNKeV ^ var1;
      var161 ^= 1633686535;
      DonutCore var19 = this.plugin;
      FileConfiguration var20 = var19.getMediaGuiConfig$1766465157(1842172223);
      FileConfiguration var7 = var20;
      var161 ^= 1506948653;
      String var4 = kfvgbegqsn(slttdlewzoswtou(), var161);
      String var84 = var20.getString(var4);
      String var85 = Hex.hex(var84);
      this.title = var85;
      var161 ^= 2064537366;
      String var134 = kfvgbegqsn(elfpupqufxcfcfk(), var161);
      int var87 = var20.getInt(var134);
      this.size = var87;
      var161 ^= 369701375;
      String var88 = kfvgbegqsn(mdxbijkapwjzcho(), var161);
      ConfigurationSection var24 = var20.getConfigurationSection(var88);
      var161 ^= 2034440579;
      if (var24 == null) {
         var161 ^= 2088305838;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161) != 51734349) {
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161)) {
               case 51734349:
                  var161 ^= 1935896319;
                  throw new IOException();
               case 485601637:
               case 1152138431:
               default:
                  throw new IOException();
               case 1263092132:
               }
            }
         }

         var161 ^= 1195311868;
      } else {
         var161 ^= 1244616716;
         byte var89 = (byte)(1390829229 ^ var161);
         Set var27 = var24.getKeys((boolean)var89);
         Iterator var28 = var27.iterator();
         Iterator var9 = var28;
         var161 ^= 1545112313;

         label131:
         while(true) {
            byte var30 = var9.hasNext();
            if (var30 == (251581524 ^ var161)) {
               var161 = sakplmsmaqzgezwi(var161, 376392174);
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161) != 261765385) {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161)) {
                     case 4912866:
                     case 1740320473:
                     default:
                        throw new IOException();
                     case 261765385:
                        var161 ^= 256045386;
                        throw new IOException();
                     case 927589436:
                     }
                  }
               }

               var161 ^= 991862089;
               break;
            }

            var161 ^= 815295549;
            Object var32 = var9.next();
            String var33 = (String)var32;
            var161 ^= 521577901;
            String var35 = "media_gui.items." + var33 + ".";
            var161 ^= 377828140;
            String var91 = var35 + "display_name";
            String var37 = var7.getString(var91);
            String var38 = Hex.hex(var37);
            var161 ^= 612330800;
            String var93 = var35 + "material";
            String var40 = var7.getString(var93);
            Material var41 = Material.getMaterial(var40);
            var161 ^= 969996350;
            String var95 = var35 + "lore";
            List var43 = var7.getStringList(var95);
            Stream var44 = var43.stream();
            Function var96 = Hex::hex;
            Stream var45 = var44.map(var96);
            Collector var97 = Collectors.toList();
            Object var46 = var45.collect(var97);
            List var47 = (List)var46;
            var161 ^= 1502616994;
            String var99 = var35 + "slot";
            int var49 = var7.getInt(var99);
            var161 ^= 743702377;
            ItemStack var50 = new ItemStack(var41);
            var161 ^= 749845163;
            ItemMeta var52 = var50.getItemMeta();
            var161 ^= 1750659762;
            if (var52 != null) {
               var161 ^= 811911093;
               var52.setDisplayName(var38);
               var161 ^= 1617159025;
               var52.setLore(var47);
               var161 ^= 1599043435;
               byte var57 = var52 instanceof LeatherArmorMeta;
               if (var57 != (339231387 ^ var161)) {
                  var161 ^= 45095917;
                  String var103 = var35 + "color";
                  byte var59 = var7.contains(var103);
                  if (var59 != (378034550 ^ var161)) {
                     var161 ^= 1503215865;
                     String var105 = var35 + "color";
                     String var61 = var7.getString(var105);
                     String var106 = kfvgbegqsn(jlnkurhyyaiburg(), var161);
                     String[] var62 = var61.split(var106);
                     var161 ^= 1738991386;
                     LeatherArmorMeta var64 = (LeatherArmorMeta)var52;
                     byte var136 = (byte)(683146901 ^ var161);
                     String var108 = var62[var136];
                     int var109 = Integer.parseInt(var108);
                     byte var5 = (byte)(683146900 ^ var161);
                     String var138 = var62[var5];
                     int var139 = Integer.parseInt(var138);
                     byte var6 = (byte)(683146903 ^ var161);
                     String var143 = var62[var6];
                     int var144 = Integer.parseInt(var143);
                     Color var110 = Color.fromRGB(var109, var139, var144);
                     var64.setColor(var110);
                     var161 ^= 604862907;
                     byte var111 = (byte)(213550895 ^ var161);
                     ItemFlag[] var112 = new ItemFlag[var111];
                     byte var145 = (byte)(213550894 ^ var161);
                     ItemFlag var152 = ItemFlag.HIDE_DYE;
                     var112[var145] = var152;
                     var52.addItemFlags(var112);
                     var161 ^= 2052735190;
                     byte var113 = (byte)(1994442745 ^ var161);
                     ItemFlag[] var114 = new ItemFlag[var113];
                     byte var146 = (byte)(1994442744 ^ var161);
                     ItemFlag var153 = ItemFlag.HIDE_ATTRIBUTES;
                     var114[var146] = var153;
                     var52.addItemFlags(var114);
                     var161 ^= 1074930006;
                     byte var115 = (byte)(921888431 ^ var161);
                     ItemFlag[] var116 = new ItemFlag[var115];
                     byte var147 = (byte)(921888430 ^ var161);
                     ItemFlag var154 = ItemFlag.HIDE_DESTROYS;
                     var116[var147] = var154;
                     var52.addItemFlags(var116);
                     var161 ^= 2142273209;
                     byte var117 = (byte)(1229101078 ^ var161);
                     ItemFlag[] var118 = new ItemFlag[var117];
                     byte var148 = (byte)(1229101079 ^ var161);
                     ItemFlag var155 = ItemFlag.HIDE_ENCHANTS;
                     var118[var148] = var155;
                     var52.addItemFlags(var118);
                     var161 ^= 232116360;
                     byte var119 = (byte)(1150765214 ^ var161);
                     ItemFlag[] var120 = new ItemFlag[var119];
                     byte var149 = (byte)(1150765215 ^ var161);
                     ItemFlag var156 = ItemFlag.HIDE_PLACED_ON;
                     var120[var149] = var156;
                     var52.addItemFlags(var120);
                     var161 ^= 1704286809;
                     byte var121 = (byte)(553784007 ^ var161);
                     ItemFlag[] var122 = new ItemFlag[var121];
                     byte var150 = (byte)(553784006 ^ var161);
                     ItemFlag var157 = ItemFlag.HIDE_POTION_EFFECTS;
                     var122[var150] = var157;
                     var52.addItemFlags(var122);
                     var161 ^= 310791874;
                     byte var123 = (byte)(864312325 ^ var161);
                     ItemFlag[] var124 = new ItemFlag[var123];
                     byte var151 = (byte)(864312324 ^ var161);
                     ItemFlag var158 = ItemFlag.HIDE_UNBREAKABLE;
                     var124[var151] = var158;
                     var52.addItemFlags(var124);
                     var161 ^= 1105615772;
                  } else {
                     var161 ^= 1365771157;
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161) != 188938231) {
                        var161 = sakplmsmaqzgezwi(var161, 1345533459);
                        throw new IOException();
                     }

                     var161 = sakplmsmaqzgezwi(var161, 897736059);
                  }
               } else {
                  var161 = sakplmsmaqzgezwi(var161, 522919814);
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161) != 91590523) {
                     var161 ^= 482357741;
                     throw new IOException();
                  }

                  var161 ^= 2037471877;
               }

               boolean var73 = var50.setItemMeta(var52);
               var161 ^= 84336049;
            } else {
               var161 ^= 1989570885;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161) != 82720572) {
                  var161 = sakplmsmaqzgezwi(var161, 2050296961);
                  throw new IOException();
               }

               var161 = sakplmsmaqzgezwi(var161, 444775000);
            }

            Map var75 = this.items;
            Integer var127 = var49;
            var75.put(var127, var50);
            var161 ^= 717513416;
            String var129 = var35 + "command";
            byte var78 = var7.contains(var129);
            if (var78 != (1570814177 ^ var161)) {
               var161 ^= 1003455960;
               String var131 = var35 + "command";
               String var80 = var7.getString(var131);
               var161 ^= 1778460952;
               Map var82 = this.slotMediaCommandMap;
               Integer var133 = var49;
               var82.put(var133, var80);
               var161 ^= 550816771;
            } else {
               var161 ^= 1660390179;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161) != 179882768) {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161)) {
                     case 179882768:
                        var161 ^= 679763762;
                        throw new IOException();
                     case 287012809:
                     case 1468462267:
                     default:
                        throw new IOException();
                     case 1733203880:
                     }
                  }
               }

               var161 = sakplmsmaqzgezwi(var161, 334359520);
            }

            label105:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161)) {
               case 111816315:
                  var161 ^= 2117812819;
                  break label105;
               case 1257318930:
                  break;
               case 1654089321:
               default:
                  throw new IOException();
               case 1714599548:
                  break label105;
               }
            }

            try {
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161) != 266029499) {
                  throw null;
               }

               throw new IOException();
            } catch (IOException var162) {
               switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var161)) {
               case -1811098742:
                  var161 = sakplmsmaqzgezwi(var161, 1165764495);
                  break;
               case -1371836999:
                  var161 ^= 574279753;
                  break;
               default:
                  throw new RuntimeException("Error in hash");
               }

               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var161)) {
                  case 242989025:
                     var161 ^= 419654058;
                  case 702180254:
                     continue label131;
                  case 1106090341:
                  default:
                     throw new IOException();
                  case 1209780078:
                  }
               }
            }
         }
      }

   }

   public boolean isInGUI$652632361(Player var1, int var2) {
      int var8 = 1053333562 ^ 136331438 ^ this.ZO0bVNNKeV ^ var2;
      var8 ^= 331492408;
      Map var5 = this.opened;
      boolean var6 = var5.containsKey(var1);
      return var6;
   }

   public void remove$1734529989(Player var1, int var2) {
      int var8 = 827093953 ^ 1257890710 ^ this.ZO0bVNNKeV ^ var2;
      var8 ^= 710244584;
      Map var5 = this.opened;
      var5.remove(var1);
      var8 ^= 1672253744;
   }

   public void addToOpened$232106327(Player var1, Object[] var2, int var3) {
      int var10 = 727368029 ^ 1840716071 ^ this.ZO0bVNNKeV ^ var3;
      var10 ^= 1776067858;
      Map var7 = this.opened;
      var7.put(var1, var2);
      var10 ^= 1008780440;
   }

   static {
      nothing_to_see_here[0] = " ⠁⡼⠋⠀⣆⠀⠀⣰⣿⣫⣾⢿⣿⣿⠍⢠⠠⠀⠀⢀⠰⢾⣺⣻⣿⣿⣿⣷⡀⠀";
      nothing_to_see_here[1] = "⣥⠀⠀⠀⠁⠀⠠⢻⢬⠁⣠⣾⠛⠁⠀⠀⠀⠀⠀⠀⠀⠐⠱⠏⡉⠙⣿⣿⡇⠀";
      nothing_to_see_here[2] = "⢳⠀⢰⡖⠀⠀⠈⠀⣺⢰⣿⢻⣾⣶⣿⣿⣶⣶⣤⣤⣴⣾⣿⣷⣼⡆⢸⣿⣧⠀";
      nothing_to_see_here[3] = "⠈⠀⠜⠈⣀⣔⣦⢨⣿⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣅⣼⠛⢹⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⢋⡿⡿⣯⣭⡟⣟⣿⣿⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⡘⠀";
      nothing_to_see_here[5] = "⡀⠐⠀⠀⠀⣿⣯⡿⣿⣿⣿⣯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣉⢽⣿⡆⠀⠀";
      nothing_to_see_here[6] = "⢳⠀⠄⠀⢀⣿⣿⣿⣿⣿⣿⣿⠙⠉⠉⠉⠛⣻⢛⣿⠛⠃⠀⠐⠛⠻⣿⡇⠀⠀";
      nothing_to_see_here[7] = "⣾⠄⠀⠀⢸⣿⣿⡿⠟⠛⠁⢀⠀⢀⡄⣀⣠⣾⣿⣿⡠⣴⣎⣀⣠⣠⣿⡇⠀⠀";
      nothing_to_see_here[8] = "⣧⠀⣴⣄⣽⣿⣿⣿⣶⣶⣖⣶⣬⣾⣿⣾⣿⣿⣿⣿⣽⣿⣿⣿⣿⣿⣿⡇⠀⠀";
      nothing_to_see_here[9] = "⣿⣶⣈⡯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣹⢧⣿⣿⣿⣄⠙⢿⣿⣿⣿⠇⠀⠀";
      nothing_to_see_here[10] = "⠹⣿⣿⣧⢌⢽⣻⢿⣯⣿⣿⣿⣿⠟⣠⡘⠿⠟⠛⠛⠟⠛⣧⡈⠻⣾⣿⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠈⠉⣷⡿⣽⠶⡾⢿⣿⣿⣿⢃⣤⣿⣷⣤⣤⣄⣄⣠⣼⡿⢷⢀⣿⡏⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⢀⣿⣷⠌⣈⣏⣝⠽⡿⣷⣾⣏⣀⣉⣉⣀⣀⣀⣠⣠⣄⡸⣾⣿⠃⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⣰⡿⣿⣧⡐⠄⠱⣿⣺⣽⢟⣿⣿⢿⣿⣍⠉⢀⣀⣐⣼⣯⡗⠟⡏⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⣰⣿⠀⣿⣿⣴⡀⠂⠘⢹⣭⡂⡚⠿⢿⣿⣿⣿⡿⢿⢿⡿⠿⢁⣴⣿⣷⣶⣦⣤";
      lqklwylrhp = remzwujrifdtldr();
      int var3 = (new Random(289962747667210150L)).nextInt();
      YdbcE8YRJ4 = 305274973 ^ var3;
   }

   public static String kfvgbegqsn(byte[] var0, int var1) {
      String var8 = Integer.toString(var1);
      byte[] var9 = var8.getBytes();
      byte[] var6 = var9;
      byte var10 = 0;
      int var7 = var10;

      while(true) {
         int var15 = var0.length;
         if (var7 >= var15) {
            Charset var29 = StandardCharsets.UTF_16;
            String var14 = new String(var0, var29);
            return var14;
         }

         byte var18 = var0[var7];
         int var33 = var6.length;
         int var30 = var7 % var33;
         byte var26 = var6[var30];
         int var19 = var18 ^ var26;
         byte var20 = (byte)var19;
         var0[var7] = var20;
         byte var21 = var0[var7];
         byte[] var27 = lqklwylrhp;
         byte[] var34 = lqklwylrhp;
         int var35 = var34.length;
         int var32 = var7 % var35;
         byte var28 = var27[var32];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var7] = var23;
         ++var7;
      }
   }

   private static byte[] remzwujrifdtldr() {
      return new byte[]{12, 47, 28, 59, 89, 74, 22, 122, 125, 86, 61, 17, 60, 114, 79, 84, 30, 21, 29, 49, 108, 20, 111, 122, 84, 16, 75, 124, 75, 21, 92, 23, 75, 68, 63, 17, 50, 74, 71, 52, 105, 48, 71, 29, 5, 113, 110, 88, 48, 110, 48, 98, 107, 75, 49, 117, 10};
   }

   private static byte[] mdxbijkapwjzcho() {
      return new byte[]{-61, -26, 47, 96, 109, 27, 39, 38, 68, 15, 12, 70, 15, 27, 123, 7, 47, 88, 36, 104, 93, 12, 92, 37, 96, 80, 122, 33, 114, 72, 109, 82};
   }

   private static byte[] elfpupqufxcfcfk() {
      return new byte[]{-64, -32, 44, 99, 105, 23, 35, 39, 76, 8, 15, 64, 12, 24, 127, 11, 43, 89, 44, 111, 94, 10, 95, 60, 100, 65, 126, 63, 122, 71};
   }

   private static byte[] slttdlewzoswtou() {
      return new byte[]{-64, -31, 44, 99, 96, 23, 37, 42, 74, 13, 12, 64, 9, 20, 119, 0, 42, 87, 47, 105, 92, 15, 86, 54, 103, 77, 124, 58, 122, 73, 105, 75};
   }

   private static byte[] jlnkurhyyaiburg() {
      return new byte[]{-61, -29, 46, 33};
   }

   private static int sakplmsmaqzgezwi(int var0, int var1) {
      return var1 ^ var0;
   }
}
