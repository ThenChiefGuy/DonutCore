package dev.daniboy.donutcore.gui;

import dev.daniboy.donutcore.DonutCore;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import org.bukkit.Server;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.PluginManager;

public abstract class AbstractGui implements Listener {
   private DonutCore plugin;
   private static final long COOLDOWN_TIME = 80L;
   private static Map<Player, Long> cooldown;
   private static boolean alreadyRegistered;
   private static int mAQBQ1Bl0Q;
   private transient int pFoQXZjfFn;
   private static String[] nothing_to_see_here = new String[15];

   public AbstractGui(DonutCore var1, int var2) {
      int var21 = 1281534363 ^ 479038816;
      super();
      var21 ^= 104431511;
      var21 = 1338971752 ^ 1136254787 ^ Integer.parseInt("508377695") ^ var2;
      this.pFoQXZjfFn = 1358901432 ^ mAQBQ1Bl0Q;
      var21 ^= 1803702934;
      var21 ^= 1431680020;
      this.plugin = var1;
      var21 ^= 1864724440;
      boolean var7 = alreadyRegistered;
      if (!var7) {
         var21 ^= 729841482;
         Server var9 = var1.getServer();
         PluginManager var10 = var9.getPluginManager();
         Listener var15 = new Listener(559738319) {
            private static int gk0SK4TZCJ;
            private transient int M9leZ09Lfl;
            private static byte[] xypdsgrhsz;
            private static String[] nothing_to_see_here = new String[17];

            {
               int var7 = 876298508 ^ 216181553;

               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var7)) {
                  case 237374735:
                     var7 ^= 1296984346;
                  case 140946685:
                     var7 = 168111472 ^ 1793036910 ^ Integer.parseInt("873583094") ^ var2;
                     this.M9leZ09Lfl = 779194110 ^ gk0SK4TZCJ;
                     var7 = mautwkanmholxstu(var7, 967708275);
                     return;
                  case 1124211753:
                  default:
                     throw new IOException();
                  case 1343982098:
                  }
               }
            }

            @EventHandler
            public void onQuit(PlayerQuitEvent var1) {
               int var10 = 1014005989 ^ 1898167687 ^ this.M9leZ09Lfl;
               var10 ^= 1587303279;
               Player var5 = var1.getPlayer();
               var10 ^= 332754552;
               Map var6 = AbstractGui.cooldown;
               var6.remove(var5);
               var10 ^= 1512812256;
            }

            static {
               nothing_to_see_here[0] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⣀⣠⣤⣶⣶⣶⣤⣄⣀⣀⠄⠄⠄⠄⠄";
               nothing_to_see_here[1] = "⠄⠄⠄⠄⠄⠄⠄⠄⣀⣤⣤⣶⣿⣿⣿⣿⣿⣿⣿⣟⢿⣿⣿⣿⣶⣤⡀⠄";
               nothing_to_see_here[2] = "⠄⠄⠄⠄⠄⠄⢀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣜⠿⠿⣿⣿⣧⢓";
               nothing_to_see_here[3] = "⠄⠄⠄⠄⠄⡠⢛⣿⣿⣿⡟⣿⣿⣽⣋⠻⢻⣿⣿⣿⣿⡻⣧⡠⣭⣭⣿⡧";
               nothing_to_see_here[4] = "⠄⠄⠄⠄⠄⢠⣿⡟⣿⢻⠃⣻⣨⣻⠿⡀⣝⡿⣿⣿⣷⣜⣜⢿⣝⡿⡻⢔";
               nothing_to_see_here[5] = "⠄⠄⠄⠄⠄⢸⡟⣷⢿⢈⣚⣓⡡⣻⣿⣶⣬⣛⣓⣉⡻⢿⣎⠢⠻⣴⡾⠫";
               nothing_to_see_here[6] = "⠄⠄⠄⠄⠄⢸⠃⢹⡼⢸⣿⣿⣿⣦⣹⣿⣿⣿⠿⠿⠿⠷⣎⡼⠆⣿⠵⣫";
               nothing_to_see_here[7] = "⠄⠄⠄⠄⠄⠈⠄⠸⡟⡜⣩⡄⠄⣿⣿⣿⣿⣶⢀⢀⣿⣷⣿⣿⡐⡇⡄⣿";
               nothing_to_see_here[8] = "⠄⠄⠄⠄⠄⠄⠄⠄⠁⢶⢻⣧⣖⣿⣿⣿⣿⣿⣿⣿⣿⡏⣿⣇⡟⣇⣷⣿";
               nothing_to_see_here[9] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⣆⣤⣽⣿⡿⠿⠿⣿⣿⣦⣴⡇⣿⢨⣾⣿⢹⢸";
               nothing_to_see_here[10] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⣿⠊⡛⢿⣿⣿⣿⣿⡿⣫⢱⢺⡇⡏⣿⣿⣸⡼";
               nothing_to_see_here[11] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⢸⡿⠄⣿⣷⣾⡍⣭⣶⣿⣿⡌⣼⣹⢱⠹⣿⣇⣧";
               nothing_to_see_here[12] = "⠄⠄⠄⠄⠄⠄⠄⠄⠄⣼⠁⣤⣭⣭⡌⢁⣼⣿⣿⣿⢹⡇⣭⣤⣶⣤⡝⡼";
               nothing_to_see_here[13] = "⠄⣀⠤⡀⠄⠄⠄⠄⠄⡏⣈⡻⡿⠃⢀⣾⣿⣿⣿⡿⡼⠁⣿⣿⣿⡿⢷⢸";
               nothing_to_see_here[14] = "⢰⣷⡧⡢⠄⠄⠄⠄⠠⢠⡛⠿⠄⠠⠬⠿⣿⠭⠭⢱⣇⣀⣭⡅⠶⣾⣷⣶";
               nothing_to_see_here[15] = "⠈⢿⣿⣧⠄⠄⠄⠄⢀⡛⠿⠄⠄⠄⠄⢠⠃⠄⠄⡜⠄⠄⣤⢀⣶⣮⡍⣴";
               nothing_to_see_here[16] = "⠄⠈⣿⣿⡀⠄⠄⠄⢩⣝⠃⠄⠄⢀⡄⡎⠄⠄⠄⠇⠄⠄⠅⣴⣶⣶⠄⣶";
               xypdsgrhsz = uzvhbeenofnitcz();
               int var3 = (new Random(6156919113051281710L)).nextInt();
               gk0SK4TZCJ = 1735335202 ^ var3;
            }

            public static String dqixzmuqpk(byte[] var0, int var1) {
               String var8 = Integer.toString(var1);
               byte[] var9 = var8.getBytes();
               byte[] var6 = var9;
               byte var10 = 0;
               int var7 = var10;

               while(true) {
                  int var15 = var0.length;
                  if (var7 >= var15) {
                     Charset var29 = StandardCharsets.UTF_16;
                     String var14 = new String(var0, var29);
                     return var14;
                  }

                  byte var18 = var0[var7];
                  int var33 = var6.length;
                  int var30 = var7 % var33;
                  byte var26 = var6[var30];
                  int var19 = var18 ^ var26;
                  byte var20 = (byte)var19;
                  var0[var7] = var20;
                  byte var21 = var0[var7];
                  byte[] var27 = xypdsgrhsz;
                  byte[] var34 = xypdsgrhsz;
                  int var35 = var34.length;
                  int var32 = var7 % var35;
                  byte var28 = var27[var32];
                  int var22 = var21 ^ var28;
                  byte var23 = (byte)var22;
                  var0[var7] = var23;
                  ++var7;
               }
            }

            private static byte[] uzvhbeenofnitcz() {
               return new byte[]{12, 117, 77, 87, 90, 6, 53};
            }

            private static int mautwkanmholxstu(int var0, int var1) {
               return var0 ^ var1;
            }
         };
         var10.registerEvents(var15, var1);
         var21 ^= 740413320;
         boolean var11 = true;
         alreadyRegistered = var11;
         var21 ^= 2011894905;
      } else {
         var21 ^= 1883940027;
      }

      Server var13 = var1.getServer();
      PluginManager var14 = var13.getPluginManager();
      Listener var16 = new Listener(2134997498) {
         private static int lesWFrMTkw;
         private transient int 7BsJtnHcDH;
         private static String[] nothing_to_see_here = new String[15];

         {
            int var7 = 324286487 ^ 2119129861;

            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var7)) {
               case 56976105:
                  var7 ^= 324823071;
               case 1448908645:
                  var7 = 1465447165 ^ 1291143789 ^ Integer.parseInt("447466087") ^ var2;
                  this.7BsJtnHcDH = 341326511 ^ lesWFrMTkw;
                  var7 = iwizunndidujyoaw(var7, 784758801);
                  return;
               case 1372121244:
                  break;
               case 1475623679:
               default:
                  throw new RuntimeException();
               }
            }
         }

         @EventHandler
         public void onInvClick(InventoryClickEvent var1) {
            int var58 = 1828654797 ^ 2072354366 ^ this.7BsJtnHcDH;
            var58 ^= 1836043023;
            HumanEntity var17 = var1.getWhoClicked();
            Player var18 = (Player)var17;
            var58 ^= 408632800;
            Inventory var20 = var1.getClickedInventory();
            var58 ^= 1454493471;
            ItemStack var22 = var1.getCurrentItem();
            var58 ^= 1538925016;
            ClickType var24 = var1.getClick();
            var58 ^= 1146267749;
            int var26 = var1.getSlot();
            var58 ^= 362318905;
            ItemStack var28 = var1.getCursor();
            var58 ^= 258526302;
            AbstractGui var30 = AbstractGui.this;
            byte var31 = var30.isInGUI$652632361(var18, 901967400);
            if (var31 == (917208019 ^ var58)) {
               var58 ^= 2090535368;
            } else {
               var58 ^= 1422881135;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var58) != 245479080) {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var58)) {
                     case 245479080:
                        var58 ^= 70490127;
                        throw new RuntimeException();
                     case 482053356:
                        break;
                     case 1081764715:
                     case 1800162108:
                     default:
                        throw new RuntimeException();
                     }
                  }
               } else {
                  var58 = iwizunndidujyoaw(var58, 486778448);
                  ClickType var33 = var1.getClick();
                  byte var34 = var33.isKeyboardClick();
                  if (var34 != (2137500908 ^ var58)) {
                     var58 ^= 2119361663;
                     byte var36 = var20 instanceof PlayerInventory;
                     if (var36 == (20269203 ^ var58)) {
                        var58 ^= 807771135;
                        byte var52 = (byte)(823186285 ^ var58);
                        var1.setCancelled((boolean)var52);
                        var58 ^= 2118942854;
                        var18.updateInventory();
                        var58 ^= 515570936;
                        return;
                     }

                     var58 ^= 1626292817;
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var58) != 227939597) {
                        var58 = iwizunndidujyoaw(var58, 126720113);
                        throw new RuntimeException();
                     }

                     var58 ^= 862401079;
                  } else {
                     label84:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var58)) {
                        case 114860142:
                           var58 ^= 915878976;
                        case 1396086751:
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var58) != 256011837) {
                              var58 ^= 799476255;
                              throw new RuntimeException();
                           }

                           var58 = iwizunndidujyoaw(var58, 458072153);
                           break label84;
                        case 971934734:
                           break;
                        case 1505770441:
                        default:
                           throw new RuntimeException();
                        }
                     }
                  }

                  byte var40 = var20 instanceof PlayerInventory;
                  if (var40 != (1388132597 ^ var58)) {
                     var58 ^= 1133098389;
                     ClickType var48 = var1.getClick();
                     byte var49 = var48.isShiftClick();
                     if (var49 != (288656736 ^ var58)) {
                        var58 ^= 285059003;
                        byte var55 = (byte)(29960922 ^ var58);
                        var1.setCancelled((boolean)var55);
                        var58 ^= 1017699645;
                        var18.updateInventory();
                        var58 ^= 131929344;
                     } else {
                        var58 ^= 402277639;
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var58) != 107076910) {
                           while(true) {
                              switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var58)) {
                              case 107076910:
                                 var58 ^= 1620662996;
                                 throw new RuntimeException();
                              case 255401743:
                                 break;
                              case 1971695699:
                              case 2082911754:
                              default:
                                 throw new RuntimeException();
                              }
                           }
                        }

                        var58 = iwizunndidujyoaw(var58, 1014114945);
                     }

                  } else {
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var58)) {
                        case 5164263:
                           var58 ^= 444386966;
                        case 1237740698:
                           if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var58) == 217548190) {
                              var58 ^= 216151597;
                              byte var53 = (byte)(1143193679 ^ var58);
                              var1.setCancelled((boolean)var53);
                              var58 ^= 993827718;
                              var18.updateInventory();
                              var58 ^= 548609874;
                              boolean var44 = AbstractGui.resetCooldown$164070003(var18, 893517380);
                              var58 ^= 1790058718;
                              AbstractGui var46 = AbstractGui.this;
                              WrappedClickEvent var54 = new WrappedClickEvent(var18, var20, var22, var24, var26, var28, 2028190499);
                              var46.click$2048279449(var54, 1729596340);
                              var58 ^= 446960274;
                              return;
                           }

                           var58 ^= 781608144;
                           throw new RuntimeException();
                        case 202880285:
                        default:
                           throw new RuntimeException();
                        case 472925840:
                        }
                     }
                  }
               }
            }
         }

         static {
            nothing_to_see_here[0] = " ⠁⡼⠋⠀⣆⠀⠀⣰⣿⣫⣾⢿⣿⣿⠍⢠⠠⠀⠀⢀⠰⢾⣺⣻⣿⣿⣿⣷⡀⠀";
            nothing_to_see_here[1] = "⣥⠀⠀⠀⠁⠀⠠⢻⢬⠁⣠⣾⠛⠁⠀⠀⠀⠀⠀⠀⠀⠐⠱⠏⡉⠙⣿⣿⡇⠀";
            nothing_to_see_here[2] = "⢳⠀⢰⡖⠀⠀⠈⠀⣺⢰⣿⢻⣾⣶⣿⣿⣶⣶⣤⣤⣴⣾⣿⣷⣼⡆⢸⣿⣧⠀";
            nothing_to_see_here[3] = "⠈⠀⠜⠈⣀⣔⣦⢨⣿⣿⣿⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣅⣼⠛⢹⠀";
            nothing_to_see_here[4] = "⠀⠀⠀⠀⢋⡿⡿⣯⣭⡟⣟⣿⣿⣽⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⡘⠀";
            nothing_to_see_here[5] = "⡀⠐⠀⠀⠀⣿⣯⡿⣿⣿⣿⣯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣉⢽⣿⡆⠀⠀";
            nothing_to_see_here[6] = "⢳⠀⠄⠀⢀⣿⣿⣿⣿⣿⣿⣿⠙⠉⠉⠉⠛⣻⢛⣿⠛⠃⠀⠐⠛⠻⣿⡇⠀⠀";
            nothing_to_see_here[7] = "⣾⠄⠀⠀⢸⣿⣿⡿⠟⠛⠁⢀⠀⢀⡄⣀⣠⣾⣿⣿⡠⣴⣎⣀⣠⣠⣿⡇⠀⠀";
            nothing_to_see_here[8] = "⣧⠀⣴⣄⣽⣿⣿⣿⣶⣶⣖⣶⣬⣾⣿⣾⣿⣿⣿⣿⣽⣿⣿⣿⣿⣿⣿⡇⠀⠀";
            nothing_to_see_here[9] = "⣿⣶⣈⡯⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠋⣹⢧⣿⣿⣿⣄⠙⢿⣿⣿⣿⠇⠀⠀";
            nothing_to_see_here[10] = "⠹⣿⣿⣧⢌⢽⣻⢿⣯⣿⣿⣿⣿⠟⣠⡘⠿⠟⠛⠛⠟⠛⣧⡈⠻⣾⣿⠀⠀⠀";
            nothing_to_see_here[11] = "⠀⠈⠉⣷⡿⣽⠶⡾⢿⣿⣿⣿⢃⣤⣿⣷⣤⣤⣄⣄⣠⣼⡿⢷⢀⣿⡏⠀⠀⠀";
            nothing_to_see_here[12] = "⠀⠀⢀⣿⣷⠌⣈⣏⣝⠽⡿⣷⣾⣏⣀⣉⣉⣀⣀⣀⣠⣠⣄⡸⣾⣿⠃⠀⠀⠀";
            nothing_to_see_here[13] = "⠀⣰⡿⣿⣧⡐⠄⠱⣿⣺⣽⢟⣿⣿⢿⣿⣍⠉⢀⣀⣐⣼⣯⡗⠟⡏⠀⠀⠀⠀";
            nothing_to_see_here[14] = "⣰⣿⠀⣿⣿⣴⡀⠂⠘⢹⣭⡂⡚⠿⢿⣿⣿⣿⡿⢿⢿⡿⠿⢁⣴⣿⣷⣶⣦⣤";
            int var3 = (new Random(6075255617052050649L)).nextInt();
            lesWFrMTkw = -277012631 ^ var3;
         }

         public static String zvjpwsdqzq(byte[] var0, byte[] var1, int var2) {
            String var9 = Integer.toString(var2);
            byte[] var10 = var9.getBytes();
            byte[] var7 = var10;
            byte var11 = 0;
            int var8 = var11;

            while(true) {
               int var16 = var0.length;
               if (var8 >= var16) {
                  Charset var30 = StandardCharsets.UTF_16;
                  String var15 = new String(var0, var30);
                  return var15;
               }

               byte var19 = var0[var8];
               int var34 = var7.length;
               int var31 = var8 % var34;
               byte var27 = var7[var31];
               int var20 = var19 ^ var27;
               byte var21 = (byte)var20;
               var0[var8] = var21;
               byte var22 = var0[var8];
               int var36 = var1.length;
               int var33 = var8 % var36;
               byte var29 = var1[var33];
               int var23 = var22 ^ var29;
               byte var24 = (byte)var23;
               var0[var8] = var24;
               ++var8;
            }
         }

         private static byte[] wkgrlkeklsmtfdk() {
            return new byte[]{25, 15, 74, 42, 48, 77, 70, 71, 119, 18, 76, 32, 61, 59, 112, 77, 77, 119, 114, 109, 71, 105, 114, 7, 22, 29, 77, 114, 48, 68, 20, 74, 15, 34, 89, 125, 124, 32, 120, 56, 36, 14, 53, 34, 81, 77, 8, 37, 117, 3, 115};
         }

         private static int iwizunndidujyoaw(int var0, int var1) {
            return var0 ^ var1;
         }
      };
      var14.registerEvents(var16, var1);
      var21 ^= 879074608;
   }

   public static boolean resetCooldown$164070003(Player var0, int var1) {
      int var45 = 233299773 ^ 1139535962 ^ mAQBQ1Bl0Q ^ var1;
      var45 ^= 1595558478;
      Map var2 = cooldown;
      byte var12 = var2.containsKey(var0);
      if (var12 == (1225592688 ^ var45)) {
         var45 ^= 1138748497;
         Map var13 = cooldown;
         long var4 = System.currentTimeMillis();
         long var6 = 80L;
         long var33 = var4 + var6;
         Long var35 = var33;
         var13.put(var0, var35);
         var45 ^= 1138977345;
         byte var15 = (byte)(1227983201 ^ var45);
         return (boolean)var15;
      } else {
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var45)) {
            case 227083492:
               var45 ^= 116488051;
            case 1887825700:
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var45) != 184117113) {
                  var45 = nnpqjysqusysoxda(var45, 462393974);
                  throw new RuntimeException();
               } else {
                  var45 ^= 1732807173;
                  long var16 = System.currentTimeMillis();
                  var45 ^= 541782086;
                  Map var18 = cooldown;
                  Object var19 = var18.get(var0);
                  Long var20 = (Long)var19;
                  long var21 = var20;
                  var45 ^= 1307110948;
                  long var46;
                  int var25 = (var46 = var16 - var21) == 0L ? 0 : (var46 < 0L ? -1 : 1);
                  if (var25 > (1159130212 ^ var45)) {
                     var45 ^= 1037409699;
                     Map var27 = cooldown;
                     long var38 = System.currentTimeMillis();
                     long var43 = 80L;
                     long var40 = var38 + var43;
                     Long var42 = var40;
                     var27.put(var0, var42);
                     var45 ^= 1024288528;
                     byte var29 = (byte)(1171134166 ^ var45);
                     return (boolean)var29;
                  }

                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var45)) {
                     case 98316055:
                        var45 ^= 1875189468;
                     case 1268676225:
                        if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var45) == 49974423) {
                           var45 = nnpqjysqusysoxda(var45, 763652058);
                           byte var26 = (byte)(123180386 ^ var45);
                           return (boolean)var26;
                        }

                        while(true) {
                           switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var45)) {
                           case 49974423:
                              var45 ^= 2124421325;
                              throw new RuntimeException();
                           case 137164439:
                              break;
                           case 791557925:
                           case 824007657:
                           default:
                              throw new RuntimeException();
                           }
                        }
                     case 214939117:
                     default:
                        throw new RuntimeException();
                     case 1095635375:
                     }
                  }
               }
            case 926323824:
            default:
               throw new RuntimeException();
            case 1611555944:
            }
         }
      }
   }

   public abstract void click$2048279449(WrappedClickEvent var1, int var2);

   public DonutCore plugin() {
      int var5 = 952982506 ^ 31735980 ^ this.pFoQXZjfFn;
      var5 ^= 955509059;
      DonutCore var2 = this.plugin;
      return var2;
   }

   public abstract boolean isInGUI$652632361(Player var1, int var2);

   public abstract void remove$1734529989(Player var1, int var2);

   public void open$967512435(Player var1, Object[] var2, int var3) {
      int var17 = 687741156 ^ 268870240 ^ this.pFoQXZjfFn ^ var3;
      var17 ^= 1468028516;
      Inventory var8 = this.generateInventory$919822562(var1, var2, 1501979845);
      var17 ^= 906669786;
      if (var8 == null) {
         var17 ^= 1822325083;
      } else {
         var17 = nnpqjysqusysoxda(var17, 717277932);
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var17) != 164212032) {
            var17 ^= 1145975353;
            throw new IllegalAccessException();
         } else {
            var17 ^= 410705416;
            var1.openInventory(var8);
            var17 ^= 607159335;
            this.addToOpened$232106327(var1, var2, 1698934540);
            var17 ^= 2136879628;
         }
      }
   }

   public DonutCore getPlugin() {
      int var5 = 1319065713 ^ 1300161626 ^ this.pFoQXZjfFn;
      var5 ^= 1251485891;
      DonutCore var2 = this.plugin;
      return var2;
   }

   public abstract void addToOpened$232106327(Player var1, Object[] var2, int var3);

   public abstract Inventory generateInventory$919822562(Player var1, Object[] var2, int var3);

   static {
      nothing_to_see_here[0] = "⢀⡴⠑⡄⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠸⡇⠀⠿⡀⠀⠀⠀⣀⡴⢿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠑⢄⣠⠾⠁⣀⣄⡈⠙⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⢀⡀⠁⠀⠀⠈⠙⠛⠂⠈⣿⣿⣿⣿⣿⠿⡿⢿⣆⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⢀⡾⣁⣀⠀⠴⠂⠙⣗⡀⠀⢻⣿⣿⠭⢤⣴⣦⣤⣹⠀⠀⠀⢀⢴⣶⣆";
      nothing_to_see_here[5] = "⠀⠀⢀⣾⣿⣿⣿⣷⣮⣽⣾⣿⣥⣴⣿⣿⡿⢂⠔⢚⡿⢿⣿⣦⣴⣾⠁⠸⣼⡿";
      nothing_to_see_here[6] = "⠀⢀⡞⠁⠙⠻⠿⠟⠉⠀⠛⢹⣿⣿⣿⣿⣿⣌⢤⣼⣿⣾⣿⡟⠉⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⣾⣷⣶⠇⠀⠀⣤⣄⣀⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠉⠈⠉⠀⠀⢦⡈⢻⣿⣿⣿⣶⣶⣶⣶⣤⣽⡹⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠉⠲⣽⡻⢿⣿⣿⣿⣿⣿⣿⣷⣜⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣷⣶⣮⣭⣽⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⠿⠿⠿⠿⠛⠉              ";
      int var7 = 911090783 ^ 1026513732 ^ Integer.parseInt("508377695");
      int var4 = (new Random(-7024061260094216563L)).nextInt();
      mAQBQ1Bl0Q = 1503039841 ^ var4;
      var7 ^= 460640907;
      HashMap var0 = new HashMap();
      cooldown = var0;
      var7 ^= 938338830;
      byte var1 = (byte)(968195521 ^ var7);
      alreadyRegistered = (boolean)var1;
   }

   public static String gzrkyvwnni(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] jzgysaumokpiyvw() {
      return new byte[]{29, 10, 125, 120, 10, 68, 112, 50, 82, 33, 89, 36, 26, 48, 48, 108, 47, 38, 21, 123, 79, 81, 123, 44, 18, 122, 69, 84, 97, 3, 41, 77, 99, 87, 40, 58, 109, 87, 90, 2, 49, 117, 80, 122, 40, 53, 119, 83, 34, 115, 20, 45};
   }

   private static int nnpqjysqusysoxda(int var0, int var1) {
      return var0 ^ var1;
   }
}
