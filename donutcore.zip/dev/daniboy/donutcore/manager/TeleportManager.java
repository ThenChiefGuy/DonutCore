package dev.daniboy.donutcore.manager;

import dev.daniboy.donutcore.DonutCore;
import dev.daniboy.donutcore.config.MainConfig;
import dev.daniboy.donutcore.config.MessagesConfig;
import dev.daniboy.donutcore.config.SoundConfig;
import dev.daniboy.donutcore.config.wrapper.SoundWrapper;
import fnhndduvxgwosuvi.nqlipuvkfzlomfdg;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.PluginManager;
import org.bukkit.scheduler.BukkitRunnable;

public class TeleportManager implements Listener {
   private final DonutCore plugin;
   private final Map<UUID, BukkitRunnable> tasks;
   private static int QFV12yhpY7;
   private transient int 2OHRem2nNh;
   private static String[] nothing_to_see_here = new String[13];

   public TeleportManager(DonutCore var1, int var2) {
      int var12 = 792677445 ^ 1578211310;
      super();

      while(true) {
         switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var12)) {
         case 189446325:
            var12 ^= 1893996460;
         case 1573626907:
            var12 = 1560915159 ^ 542228969 ^ Integer.parseInt("64199518") ^ var2;
            this.2OHRem2nNh = 1949111784 ^ QFV12yhpY7;

            label27:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var12)) {
               case 28188300:
                  var12 ^= 675095141;
                  break label27;
               case 111053320:
               default:
                  throw new IllegalAccessException();
               case 1152773266:
                  break label27;
               case 2134421731:
               }
            }

            var12 ^= 1283364089;
            ConcurrentHashMap var4 = new ConcurrentHashMap();
            this.tasks = var4;
            var12 ^= 1479790779;
            this.plugin = var1;
            var12 ^= 317421868;
            PluginManager var7 = Bukkit.getPluginManager();
            var7.registerEvents(this, var1);
            var12 ^= 552666694;
            return;
         case 1073495133:
            break;
         case 1127857177:
         default:
            throw new IllegalAccessException();
         }
      }
   }

   public void teleportWithCountdown$168586022(final Player var1, final Location var2, int var3) {
      int var28 = 921668092 ^ 1775106131 ^ this.2OHRem2nNh ^ var3;
      var28 ^= 275630552;
      final int var4 = MainConfig.Teleport.COUNTDOWN_DURATION;
      var28 ^= 1957361997;
      this.cancelExistingTask$339589993(var1, 617524192);
      var28 ^= 672026636;
      BukkitRunnable var13 = new BukkitRunnable(2113932514) {
         int countdown;
         private static int zmTgmkgZMs;
         private transient int SRM4eZ7WOr;
         private static byte[] zsevriybgi;
         private static String[] nothing_to_see_here = new String[19];

         {
            int var19 = 1632853550 ^ 2061984577;

            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var19)) {
               case 95235251:
                  var19 ^= 1966652315;
               case 761802611:
                  var19 = 1969931793 ^ 316129799 ^ Integer.parseInt("1999736320") ^ var5;
                  this.SRM4eZ7WOr = 702382039 ^ zmTgmkgZMs;
                  var19 = rpynqfmhzxtnivwl(var19, 1920355066);
                  var19 ^= 2130909868;
                  int var17 = var4;
                  this.countdown = var17;
                  return;
               case 411767694:
               default:
                  throw new IOException();
               case 1105604851:
               }
            }
         }

         public void run() {
            int var44 = 1583540741 ^ 661664991 ^ this.SRM4eZ7WOr;
            var44 ^= 726988274;
            int var6 = this.countdown;
            if (var6 > (271289140 ^ var44)) {
               var44 ^= 723861853;
               MessagesConfig var19 = MessagesConfig.TELEPORTCOUNTDOWN;
               Player var31 = var1;
               byte var3 = (byte)(990825067 ^ var44);
               String[] var36 = new String[var3];
               byte var4x = (byte)(990825065 ^ var44);
               String var5 = jjbwlawcpr(aojtdqrqrfxneum(), var44);
               var36[var4x] = var5;
               byte var38 = (byte)(990825064 ^ var44);
               int var40 = this.countdown;
               String var41 = String.valueOf(var40);
               var36[var38] = var41;
               var19.send(var31, var36);
               var44 ^= 1935659854;
               SoundWrapper var20 = SoundConfig.TELEPORTCOUNTDOWN;
               Player var33 = var1;
               var20.play(var33);
               var44 ^= 960697247;
               int var34 = this.countdown;
               byte var37 = (byte)(1897007801 ^ var44);
               int var35 = var34 - var37;
               this.countdown = var35;
               var44 ^= 949754288;

               try {
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44) != 243469649) {
                     throw null;
                  }

                  throw new IllegalAccessException();
               } catch (IllegalAccessException var45) {
                  switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var44)) {
                  case -334160208:
                     var44 = rpynqfmhzxtnivwl(var44, 966316288);
                     break;
                  case 1282447426:
                     var44 ^= 1838440926;
                     break;
                  default:
                     throw new IOException("Error in hash");
                  }
               }

               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44)) {
                  case 99818084:
                     var44 ^= 959108888;
                     return;
                  case 1548023013:
                     break;
                  case 1734728318:
                     return;
                  case 1865776492:
                  default:
                     throw new IllegalAccessException();
                  }
               }
            } else {
               label86:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44)) {
                  case 257183135:
                     var44 ^= 1790068759;
                  case 791882089:
                     break label86;
                  case 1411310536:
                     break;
                  case 1826575526:
                  default:
                     throw new IllegalAccessException();
                  }
               }

               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44) != 227119242) {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44)) {
                     case 227119242:
                        var44 ^= 1618081171;
                        throw new IllegalAccessException();
                     case 312343634:
                     case 1417708972:
                     default:
                        throw new IllegalAccessException();
                     case 2072358618:
                     }
                  }
               } else {
                  var44 = rpynqfmhzxtnivwl(var44, 406276139);
                  byte var8 = this.isCancelled();
                  if (var8 == (1655606024 ^ var44)) {
                     var44 ^= 2122176852;
                     Player var10 = var1;
                     Location var22 = var2;
                     var10.teleport(var22);
                     var44 ^= 2115001705;
                     MessagesConfig var12 = MessagesConfig.TELEPORTING;
                     Player var24 = var1;
                     var12.send(var24);
                     var44 ^= 813873226;
                     SoundWrapper var13 = SoundConfig.TELEPORTCOMPLETE;
                     Player var26 = var1;
                     var13.play(var26);
                     var44 ^= 848975400;
                  } else {
                     label73:
                     while(true) {
                        switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44)) {
                        case 254955505:
                           var44 ^= 883160029;
                           break label73;
                        case 298639180:
                           break;
                        case 953332110:
                           break label73;
                        case 1983142865:
                        default:
                           throw new IllegalAccessException();
                        }
                     }

                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var44) != 112872465) {
                        var44 ^= 1290096229;
                        throw new IllegalAccessException();
                     }

                     var44 = rpynqfmhzxtnivwl(var44, 920033666);
                  }

                  TeleportManager var15 = TeleportManager.this;
                  Map var16 = var15.tasks;
                  Player var28 = var1;
                  UUID var29 = var28.getUniqueId();
                  var16.remove(var29);
                  var44 ^= 1887510856;
                  this.cancel();
                  var44 ^= 225076689;
               }
            }
         }

         static {
            nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣤⣤⣤⣤⣤⣶⣦⣤⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀";
            nothing_to_see_here[1] = "⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣿⡿⠛⠉⠙⠛⠛⠛⠛⠻⢿⣿⣷⣤⡀⠀⠀⠀⠀⠀";
            nothing_to_see_here[2] = "⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⠋⠀⠀⠀⠀⠀⠀⠀⢀⣀⣀⠈⢻⣿⣿⡄⠀⠀⠀⠀";
            nothing_to_see_here[3] = "⠀⠀⠀⠀⠀⠀⠀⣸⣿⡏⠀⠀⠀⣠⣶⣾⣿⣿⣿⠿⠿⠿⢿⣿⣿⣿⣄⠀⠀⠀";
            nothing_to_see_here[4] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠁⠀⠀⢰⣿⣿⣯⠁⠀⠀⠀⠀⠀⠀⠀⠈⠙⢿⣷⡄⠀";
            nothing_to_see_here[5] = "⠀⠀⣀⣤⣴⣶⣶⣿⡟⠀⠀⠀⢸⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣷⠀";
            nothing_to_see_here[6] = "⠀⢰⣿⡟⠋⠉⣹⣿⡇⠀⠀⠀⠘⣿⣿⣿⣿⣷⣦⣤⣤⣤⣶⣶⣶⣶⣿⣿⣿⠀";
            nothing_to_see_here[7] = "⠀⢸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠀";
            nothing_to_see_here[8] = "⠀⣸⣿⡇⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠉⠻⠿⣿⣿⣿⣿⡿⠿⠿⠛⢻⣿⡇⠀⠀";
            nothing_to_see_here[9] = "⠀⣿⣿⠁⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣧⠀⠀";
            nothing_to_see_here[10] = "⠀⣿⣿⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀";
            nothing_to_see_here[11] = "⠀⣿⣿⠀⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⠀⠀";
            nothing_to_see_here[12] = "⠀⢿⣿⡆⠀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⡇⠀⠀";
            nothing_to_see_here[13] = "⠀⠸⣿⣧⡀⠀⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⠃⠀⠀";
            nothing_to_see_here[14] = "⠀⠀⠛⢿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⣰⣿⣿⣷⣶⣶⣶⣶⠶⠀⢠⣿⣿⠀⠀⠀";
            nothing_to_see_here[15] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⣽⣿⡏⠁⠀⠀⢸⣿⡇⠀⠀⠀";
            nothing_to_see_here[16] = "⠀⠀⠀⠀⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⣿⣿⡇⠀⢹⣿⡆⠀⠀⠀⣸⣿⠇⠀⠀⠀";
            nothing_to_see_here[17] = "⠀⠀⠀⠀⠀⠀⠀⢿⣿⣦⣄⣀⣠⣴⣿⣿⠁⠀⠈⠻⣿⣿⣿⣿⡿⠏⠀⠀⠀⠀";
            nothing_to_see_here[18] = "⠀⠀⠀⠀⠀⠀⠀⠈⠛⠻⠿⠿⠿⠿⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
            zsevriybgi = nxxcrdwebkhlhng();
            int var3 = (new Random(-7034240712139272L)).nextInt();
            zmTgmkgZMs = 687175617 ^ var3;
         }

         public static String jjbwlawcpr(byte[] var0, int var1x) {
            String var10 = Integer.toString(var1x);
            byte[] var11 = var10.getBytes();
            byte[] var8 = var11;
            byte var12 = 0;
            int var9 = var12;

            while(true) {
               int var17 = var0.length;
               if (var9 >= var17) {
                  Charset var5 = StandardCharsets.UTF_16;
                  String var14 = new String(var0, var5);
                  return var14;
               }

               byte var20 = var0[var9];
               int var33 = var8.length;
               int var30 = var9 % var33;
               byte var27 = var8[var30];
               int var21 = var20 ^ var27;
               byte var22 = (byte)var21;
               var0[var9] = var22;
               byte var23 = var0[var9];
               byte[] var28 = zsevriybgi;
               byte[] var34 = zsevriybgi;
               int var35 = var34.length;
               int var32 = var9 % var35;
               byte var29 = var28[var32];
               int var24 = var23 ^ var29;
               byte var25 = (byte)var24;
               var0[var9] = var25;
               ++var9;
            }
         }

         private static byte[] nxxcrdwebkhlhng() {
            return new byte[]{69, 124, 63, 46, 67, 39, 99, 89, 118, 98, 18, 103, 3, 107, 63, 119, 86, 97, 24, 127, 17, 124, 71, 50, 86, 124, 25, 97, 61, 46, 47, 20, 33, 103, 41, 2, 59, 92, 71, 98, 27, 20, 92, 29, 117, 54, 126, 113, 125};
         }

         private static byte[] aojtdqrqrfxneum() {
            return new byte[]{-126, -70, 15, 117, 113, 125, 83, 26, 67, 53, 43, 35, 59, 61, 10, 40, 96, 35, 33, 40};
         }

         private static int rpynqfmhzxtnivwl(int var0, int var1x) {
            return var0 ^ var1x;
         }
      };
      var28 ^= 1920059813;
      Map var15 = this.tasks;
      UUID var20 = var1.getUniqueId();
      var15.put(var20, var13);
      var28 ^= 1681197975;
      DonutCore var22 = this.plugin;
      long var24 = 0L;
      long var26 = 20L;
      var13.runTaskTimer(var22, var24, var26);
      var28 ^= 106005734;
   }

   private void cancelExistingTask$339589993(Player var1, int var2) {
      int var13 = 1744162996 ^ 1898206432 ^ this.2OHRem2nNh ^ var2;
      var13 ^= 1282421052;
      Map var6 = this.tasks;
      UUID var11 = var1.getUniqueId();
      Object var7 = var6.remove(var11);
      BukkitRunnable var8 = (BukkitRunnable)var7;
      var13 ^= 1317894055;
      if (var8 != null) {
         var13 ^= 1753855818;
         var8.cancel();
         var13 ^= 1226060574;
      } else {
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var13)) {
            case 61430174:
               var13 ^= 1320573867;
            case 1180735406:
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var13) == 97366671) {
                  var13 = qeimkvfehxvdmpao(var13, 1865146367);
                  return;
               }

               var13 = qeimkvfehxvdmpao(var13, 784454483);
               throw new RuntimeException();
            case 175112326:
            default:
               throw new RuntimeException();
            case 1034149802:
            }
         }
      }
   }

   @EventHandler
   public void onPlayerMove(PlayerMoveEvent var1) {
      int var26 = 2096363468 ^ 1121277551 ^ this.2OHRem2nNh;
      var26 ^= 1274969932;
      Player var7 = var1.getPlayer();
      var26 ^= 176820317;
      UUID var9 = var7.getUniqueId();
      var26 ^= 544751129;
      Map var11 = this.tasks;
      byte var12 = var11.containsKey(var9);
      if (var12 != (1815039613 ^ var26)) {
         var26 ^= 1573733476;
         Location var19 = var1.getFrom();
         Location var23 = var1.getTo();
         byte var14 = this.hasPlayerMoved$1127470522(var19, var23, 652646192);
         if (var14 != (836897305 ^ var26)) {
            var26 ^= 282045178;
            this.cancelExistingTask$339589993(var7, 617524192);
            var26 ^= 396829969;
            MessagesConfig var16 = MessagesConfig.TELEPORTCANCELLED;
            var16.send(var7);
            var26 ^= 1445623547;
            SoundWrapper var17 = SoundConfig.TELEPORTCANCEL;
            var17.play(var7);
            var26 ^= 423312277;
         } else {
            var26 = qeimkvfehxvdmpao(var26, 858182167);
            if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var26) == 43550793) {
               var26 ^= 2069827730;
            } else {
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var26)) {
                  case 43550793:
                     var26 ^= 1413174442;
                     throw new IOException();
                  case 1144301361:
                     break;
                  case 1415669710:
                  case 1685491098:
                  default:
                     throw new IOException();
                  }
               }
            }
         }
      } else {
         var26 ^= 1850231857;
         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var26) == 37785664) {
            var26 = qeimkvfehxvdmpao(var26, 2080164560);
         } else {
            var26 ^= 1419284200;
            throw new IOException();
         }
      }
   }

   private boolean hasPlayerMoved$1127470522(Location var1, Location var2, int var3) {
      int var19 = 1862502670 ^ 1551196787 ^ this.2OHRem2nNh ^ var3;
      var19 ^= 1999872652;
      byte var12;
      if (var2 != null) {
         label157: {
            var19 ^= 2066090008;
            int var7 = var1.getBlockX();
            int var13 = var2.getBlockX();
            if (var7 == var13) {
               var19 ^= 1912671864;
               int var9 = var1.getBlockY();
               int var15 = var2.getBlockY();
               if (var9 == var15) {
                  var19 ^= 273606179;
                  int var11 = var1.getBlockZ();
                  int var17 = var2.getBlockZ();
                  if (var11 == var17) {
                     var19 = qeimkvfehxvdmpao(var19, 699210430);
                     if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var19) != 212823367) {
                        var19 ^= 1207625389;
                        throw new IOException();
                     }

                     var19 = qeimkvfehxvdmpao(var19, 779629652);
                     break label157;
                  }

                  var19 ^= 2135159126;
               } else {
                  var19 = qeimkvfehxvdmpao(var19, 1516579044);
                  if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var19) != 45484877) {
                     var19 = qeimkvfehxvdmpao(var19, 612119252);
                     throw new IOException();
                  }

                  label96:
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var19)) {
                     case 45484877:
                        var19 ^= 896024465;
                        break label96;
                     case 881711252:
                        break;
                     case 1944722095:
                        break label96;
                     case 2135162089:
                     default:
                        throw new IOException();
                     }
                  }
               }
            } else {
               var19 ^= 700799924;
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var19) != 51438394) {
                  while(true) {
                     switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var19)) {
                     case 51438394:
                        var19 ^= 635260924;
                        throw new IOException();
                     case 205801802:
                        break;
                     case 1435630428:
                     case 1447530616:
                     default:
                        throw new IOException();
                     }
                  }
               }

               label86:
               while(true) {
                  switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var19)) {
                  case 51438394:
                     var19 ^= 885605049;
                     break label86;
                  case 155093255:
                  default:
                     throw new IOException();
                  case 456477987:
                     break;
                  case 1993779021:
                     break label86;
                  }
               }
            }

            var12 = (byte)(931950851 ^ var19);

            label75:
            while(true) {
               switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var19)) {
               case 195046783:
                  var19 ^= 1812368770;
               case 776812117:
                  break label75;
               case 948575583:
               default:
                  throw new IOException();
               case 1485665299:
               }
            }

            try {
               if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var19) != 22876850) {
                  throw null;
               }

               throw new IOException();
            } catch (IOException var20) {
               switch(nqlipuvkfzlomfdg.lyvmtarecrvhtwki(var19)) {
               case -598219774:
                  var19 ^= 1537452588;
                  break;
               case -274566143:
                  var19 ^= 1037899820;
                  break;
               default:
                  throw new IOException("Error in hash");
               }
            }

            var19 = qeimkvfehxvdmpao(var19, 150353179);
            return (boolean)var12;
         }
      } else {
         label106:
         while(true) {
            switch(nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var19)) {
            case 82882840:
            default:
               throw new IOException();
            case 238160778:
               var19 ^= 769981552;
            case 293138017:
               break label106;
            case 2099990695:
            }
         }

         if (nqlipuvkfzlomfdg.wxqhyeyxrkgiiuik(var19) != 12677957) {
            var19 ^= 1524293664;
            throw new IOException();
         }

         var19 = qeimkvfehxvdmpao(var19, 861418201);
      }

      var12 = (byte)(1327148734 ^ var19);
      var19 ^= 1204145417;
      return (boolean)var12;
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⣠⣶⡾⠏⠉⠙⠳⢦⡀⠀⠀⠀⢠⠞⠉⠙⠲⡀⠀    ";
      nothing_to_see_here[2] = "⠀⠀⠀⣴⠿⠏⠀⠀⠀⠀⠀⠀⢳⡀⠀⡏⠀⠀⠀⠀⠀⢷     ";
      nothing_to_see_here[3] = "⠀⠀⢠⣟⣋⡀⢀⣀⣀⡀⠀⣀⡀⣧⠀⢸⠀⠀⠀⠀⠀ ⡇    ";
      nothing_to_see_here[4] = "⠀⠀⢸⣯⡭⠁⠸⣛⣟⠆⡴⣻⡲⣿⠀⣸⠀⠀OK⠀ ⡇    ";
      nothing_to_see_here[5] = "⠀⠀⣟⣿⡭⠀⠀⠀⠀⠀⢱⠀⠀⣿⠀⢹⠀⠀⠀⠀⠀ ⡇    ";
      nothing_to_see_here[6] = "⠀⠀⠙⢿⣯⠄⠀⠀⠀⢀⡀⠀⠀⡿⠀⠀⡇⠀⠀⠀⠀⡼     ";
      nothing_to_see_here[7] = "⠀⠀⠀⠀⠹⣶⠆⠀⠀⠀⠀⠀⡴⠃⠀⠀⠘⠤⣄⣠⠞⠀     ";
      nothing_to_see_here[8] = "⠀⠀⠀⠀⠀⢸⣷⡦⢤⡤⢤⣞⣁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[9] = "⠀⠀⢀⣤⣴⣿⣏⠁⠀⠀⠸⣏⢯⣷⣖⣦⡀⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[10] = "⢀⣾⣽⣿⣿⣿⣿⠛⢲⣶⣾⢉⡷⣿⣿⠵⣿⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[11] = "⣼⣿⠍⠉⣿⡭⠉⠙⢺⣇⣼⡏⠀⠀⠀⣄⢸⠀⠀⠀⠀⠀⠀    ";
      nothing_to_see_here[12] = "⣿⣿⣧⣀⣿.........⣀⣰⣏⣘⣆⣀⠀⠀       ";
      int var3 = (new Random(2338231151259859212L)).nextInt();
      QFV12yhpY7 = -1807568233 ^ var3;
   }

   public static String fgypqzdfgs(byte[] var0, byte[] var1, int var2) {
      String var9 = Integer.toString(var2);
      byte[] var10 = var9.getBytes();
      byte[] var7 = var10;
      byte var11 = 0;
      int var8 = var11;

      while(true) {
         int var16 = var0.length;
         if (var8 >= var16) {
            Charset var30 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var30);
            return var15;
         }

         byte var19 = var0[var8];
         int var34 = var7.length;
         int var31 = var8 % var34;
         byte var27 = var7[var31];
         int var20 = var19 ^ var27;
         byte var21 = (byte)var20;
         var0[var8] = var21;
         byte var22 = var0[var8];
         int var36 = var1.length;
         int var33 = var8 % var36;
         byte var29 = var1[var33];
         int var23 = var22 ^ var29;
         byte var24 = (byte)var23;
         var0[var8] = var24;
         ++var8;
      }
   }

   private static byte[] jjikrmuuvqhhkkd() {
      return new byte[]{67, 60, 13, 31, 58, 46, 95, 19, 24, 96, 3, 37, 3, 35, 85, 10, 13, 34, 92, 60, 60, 31, 51, 121, 41};
   }

   private static int qeimkvfehxvdmpao(int var0, int var1) {
      return var0 ^ var1;
   }
}
